from . import const
from ..hexmap import common as com

CarMarchSpeed = {'0': 40, '1': 60, '2': 90}
state_change_time = 75
BeObservedDis = {const.BopType.Infantry: 10,
                   const.BopType.Vehicle: 25,
                   const.BopType.Aircraft: 25}


def get_maneuver_time(bop, hexa, hexb, map, only_cost=False):
    assert hexa.distance_to(hexb) == 1
    if not can_go(bop, hexa, hexb, map):
        maneuver_time = float("inf")
        return maneuver_time

    cost = map.get_cost(hexa, hexb, bop['type'])
    if only_cost:
        return cost
    # 一格机动的时间为：一格距离除以修正的速度
    maneuver_time = map.dis_between_hex / (bop['basic_speed'] * 1000 / 3600) * cost
    return maneuver_time


def get_march_time(bop, hexa, hexb, map, only_cost=False):
    assert hexa.distance_to(hexb) == 1 and map.road_link(hexa, hexb) and bop['type'] == 2

    march_speed = CarMarchSpeed['2']
    cost = map.get_cost(hexa, hexb, bop['type'], march=True)
    if only_cost:
        return cost
    # 一格机动的时间为：一格距离除以修正的速度
    march_time = map.dis_between_hex / (march_speed * 1000 / 3600) * cost
    return march_time


def can_go(bop, hexa, hexb, map):  # 相邻两个高程差大于100米，且没有道路联通，则不能通行
    if bop['type'] == const.BopType.Infantry or bop['type'] == const.BopType.Aircraft:
        return True
    elif bop['type'] == const.BopType.Vehicle:
        if map.get_cost(hexa, hexb, bop['type']):
             return True
        else:
            return False
    else:
        raise Exception


def get_can_shoot_value(ubop):
    if ubop['sub_type'] == const.BopName.Tank:
        if ubop['change_state_remain_time'] != 0:
            value = (75 - ubop['change_state_remain_time']) / 75.0
        elif ubop['weapon_cool_time'] == 0:
            value =1
        else:
            value = (75 - ubop['weapon_cool_time']) / 75.0
    elif ubop['sub_type'] == const.BopName.Missile:
        value = 0
    else:
        if ubop['change_state_remain_time'] != 0:
            value = (75 - ubop['change_state_remain_time']) / 75.0
        elif ubop['get_off_partner_id'] != 0:
            value = 2
        elif ubop['get_on_partner_id'] != 0:
            value = 0
        elif ubop['stop'] == 0:
            value = 0
        elif ubop['sub_type'] == const.BopName.Soldier and ubop['keep'] == 1:
            value = 0
        else:
            value = 1
    return value


def can_observe(be_see_type, see_pos, be_see_pos, see_mode, my_map):
    see = my_map.can_see(see_pos, be_see_pos, see_mode)
    if see:
        dis = com.get_distance(see_pos, be_see_pos)
        observe_distance = BeObservedDis[be_see_type]
        if see_mode == const.SeeMode.SkyToSky or see_mode == const.SeeMode.GroundToSky:
            if dis <= observe_distance:
                return True
        if see_mode == const.SeeMode.GroundToGround or see_mode == const.SeeMode.SkyToGround:
            if my_map.is_hide_point(be_see_pos) and dis <= int(observe_distance/2):
                return True
            elif not my_map.is_hide_point(be_see_pos) and dis <= observe_distance:
                return True
    return False

