import queue
import numpy as np
from ..hexmap.hex import BoundedHex
from . import rule
from .rule import get_maneuver_time, get_march_time, can_go
from ..hexmap import common as com
from . import common, const
# from PIL import Image, ImageDraw, ImageFont
# import matplotlib.pyplot as plt
# import seaborn as sns


def get_maneuver_time_matrix(bop, int4, map):
    pre_visit = queue.Queue()
    pre_visit.put(int4)
    time_matrix = np.zeros(map.size)
    time_matrix[:] = -1
    time_matrix[com.cvtInt4loc2Offset(int4)] = 0

    while not pre_visit.empty():
        now_visit = BoundedHex(pre_visit.get_nowait(), size=map.size)
        neighbors = now_visit.arc([0, 5], 1)

        for neighbor in neighbors:
            neighbor = BoundedHex(neighbor, size=map.size)
            if map.in_map(neighbor.row, neighbor.col):
                if can_go(bop, now_visit, neighbor, map):
                    maneuver_time = get_maneuver_time(bop, now_visit, neighbor, map)
                    # neighbor格未被探索到，或者到达时间更快，则更新neighbor格到达时间
                    if time_matrix[neighbor.row, neighbor.col] == -1 or time_matrix[now_visit.row, now_visit.col] \
                            + maneuver_time < time_matrix[neighbor.row, neighbor.col]:
                        time_matrix[neighbor.row, neighbor.col] = \
                            time_matrix[now_visit.row, now_visit.col] + maneuver_time
                        pre_visit.put((neighbor.row, neighbor.col))
    return time_matrix


def get_march_time_matrix(bop, int4, map):
    pre_visit = queue.Queue()
    pre_visit.put(int4)
    time_matrix = np.ones((map.size))
    time_matrix[:] = -1
    time_matrix[com.cvtInt4loc2Offset(int4)] = 0

    while not pre_visit.empty():
        now_visit = pre_visit.get_nowait()
        now_visit = BoundedHex(now_visit, size=map.size)
        neighbors = now_visit.getSixNeighInOrder()
        for neighbor in neighbors:
            neighbor = BoundedHex(neighbor[0], neighbor[1], size=map.size)
            if map.in_map(neighbor.row, neighbor.col):
                if can_go(bop, now_visit, neighbor, map):
                    if map.road_link(now_visit, neighbor):
                        march_time = get_march_time(bop, now_visit, neighbor, map)
                        # print(now_visit.__str__(), neighbor.__str__(), march_time)
                        # 可以行军时，neighbor格未被探索到，或者到达时间更快，则更新neighbor格到达时间
                        if time_matrix[neighbor.row, neighbor.col] == -1 or time_matrix[now_visit.row, now_visit.col] \
                                + march_time < time_matrix[neighbor.row, neighbor.col]:
                            time_matrix[neighbor.row, neighbor.col] = \
                                time_matrix[now_visit.row, now_visit.col] + march_time
                            pre_visit.put((neighbor.row, neighbor.col))
                    else:
                        maneuver_time = get_maneuver_time(bop, now_visit, neighbor, map)
                        # neighbor格未被探索到，或者到达时间更快，则更新neighbor格到达时间
                        if map.have_road(neighbor):
                            maneuver_time += rule.state_change_time * 2

                        if time_matrix[neighbor.row, neighbor.col] == -1 or time_matrix[now_visit.row, now_visit.col] \
                                + maneuver_time < time_matrix[neighbor.row, neighbor.col]:
                            time_matrix[neighbor.row, neighbor.col] = \
                                time_matrix[now_visit.row, now_visit.col] + maneuver_time
                            pre_visit.put((neighbor.row, neighbor.col))
    return time_matrix

'''
主次夺控点作为主攻点的原则
1.距离相对更近，与敌人比较，至少近5格以上
2.夺控点3格内的被观察度总和更小。'''
def get_main_attack(my_ai):
    city_main = common.get_city_name(my_ai.cities_init,my_ai.color,value=80 )
    city_second = common.get_city_name(my_ai.cities_init, my_ai.color, value=50)

    bop_pos_init = [bop['cur_hex'] for bop in my_ai.our_bops_init if bop['type'] == const.BopType.Vehicle]
    bop_pos_init_tuple = com.cvtInt4loc2Offset(bop_pos_init)
    ubop_pos_init = [bop['cur_hex'] for bop in my_ai.enemy_bops_init if bop['type'] == const.BopType.Vehicle]
    ubop_pos_init_tuple = com.cvtInt4loc2Offset(ubop_pos_init)
    bop_maneuver_time_main = my_ai.see.get_maneuver_time(const.BopType.Vehicle, city_main['coord'])[tuple(zip(*bop_pos_init_tuple))].mean()
    ubop_maneuver_time_main = my_ai.see.get_maneuver_time(const.BopType.Vehicle, city_main['coord'])[tuple(zip(*ubop_pos_init_tuple))].mean()

    bop_maneuver_time_second = my_ai.see.get_maneuver_time(const.BopType.Vehicle, city_second['coord'])[
        tuple(zip(*bop_pos_init_tuple))].mean()
    ubop_maneuver_time_second = my_ai.see.get_maneuver_time(const.BopType.Vehicle, city_second['coord'])[
        tuple(zip(*ubop_pos_init_tuple))].mean()

    main_pos_int4 = [row * 100 + col for (row, col) in BoundedHex(city_main['coord']).arc([0, 5], 2, origin=True)]
    second_pos_int4 = [row * 100 + col for (row, col) in BoundedHex(city_second['coord']).arc([0, 5], 2, origin=True)]
    be_observed_main = observe_occupy_ability(const.BopType.Vehicle, const.BopType.Vehicle, main_pos_int4, my_ai, be_observed=True)
    be_observed_main = be_observed_main.mean()
    be_observed_second = observe_occupy_ability(const.BopType.Vehicle, const.BopType.Vehicle, second_pos_int4, my_ai, be_observed=True)
    be_observed_second = be_observed_second.mean()

    ###我方主攻点选择
    if ubop_maneuver_time_main - bop_maneuver_time_main >= 3 * 20:
        o_main_attack = city_main['coord']
        o_second_attack = city_second['coord']
    elif ubop_maneuver_time_second - bop_maneuver_time_second >= 3 * 20:
        o_main_attack = city_second['coord']
        o_second_attack = city_main['coord']

    elif be_observed_main < be_observed_second * 1.2:
        o_main_attack = city_main['coord']
        o_second_attack = city_second['coord']
    elif be_observed_second < be_observed_main * 0.8:
        o_main_attack = city_second['coord']
        o_second_attack = city_main['coord']
    else:
        o_main_attack = city_main['coord']
        o_second_attack = city_second['coord']
    ###预计敌方主攻点选择：
    if bop_maneuver_time_main - ubop_maneuver_time_main >= 3 * 20:
        e_main_attack = city_main['coord']
        e_second_attack = city_second['coord']
    elif bop_maneuver_time_second - ubop_maneuver_time_second >= 3 * 20:
        e_main_attack = city_second['coord']
        e_second_attack = city_main['coord']
    elif be_observed_main < be_observed_second * 1.2:
        e_main_attack = city_main['coord']
        e_second_attack = city_second['coord']
    elif be_observed_second < be_observed_main * 0.8:
        e_main_attack = city_second['coord']
        e_second_attack = city_main['coord']
    else:
        e_main_attack = city_main['coord']
        e_second_attack = city_second['coord']


    return {'o_main_attack': o_main_attack,
            'o_second_attack': o_second_attack,
            'e_main_attack': e_main_attack,
            'e_second_attack': e_second_attack}


'''
计算棋子bop在位置列表pos_list内每个位置的观察度，观察度以敌人可能出现的位置为基准进行计算
'''
def observe_ability_enemy(bop, ubop_type, pos_list, my_ai, be_observed=False):
    pos_tuple = com.cvtInt4loc2Offset(pos_list)
    time_list = my_ai.see.get_maneuver_time(bop['type'], bop['cur_hex'])[tuple(zip(*pos_tuple))].tolist()
    if be_observed:
        see_source = common.get_see_source(ubop_type)
        be_observed_zone = my_ai.enemy_observe_zone.get_be_observed_zone(time_list)
        LOS_np = my_ai.see.get_be_see_LOS(see_source, bop['type'], pos_list)
        observe_ability = (LOS_np * be_observed_zone).reshape(len(pos_list), -1).sum(axis=1)
    else:
        see_source = common.get_see_source(bop['type'])
        observe_zone = my_ai.enemy_observe_zone.get_observe_zone(time_list)
        be_LOS_np = my_ai.see.get_see_LOS(see_source, ubop_type, pos_list)
        observe_ability = (be_LOS_np * observe_zone).reshape(len(pos_list), -1).sum(axis=1)

    return observe_ability


# 计算一点对另一点（一般指夺控点）周边的观察度
def point_around_LOS(observe_point_list, bop_type, ubop_type, my_ai, city, dis=5, beta=.3, be_observed=False):
    pos_tuple = my_ai.hex_cache.get_circle(city['coord'], 0, dis)

    rows, cols = zip(*pos_tuple)
    if be_observed:
        see_source = common.get_see_source(ubop_type)
        LOS_np = my_ai.see.get_be_see_LOS(see_source, bop_type, observe_point_list)[:, rows, cols]

    else:
        see_source = common.get_see_source(bop_type)
        LOS_np = my_ai.see.get_see_LOS(see_source, ubop_type, observe_point_list)[:, rows, cols]
    maneuver_time = my_ai.see.get_maneuver_time(const.BopType.Vehicle, city['coord'])[rows, cols]

    dis_factor = com.apply_temperature(beta, max(maneuver_time) - maneuver_time)
    dis_factor = com.normalization(dis_factor)
    observe_ability = (LOS_np * dis_factor).sum(axis=1)
    return observe_ability


'''
计算棋子bop在位置列表pos_list内每个位置对夺控点的观察度，观察度为可通视位置之和，
'''
def observe_occupy_ability(bop_type, ubop_type, pos_list, my_ai, be_observed = False, city=None):
    if not city:
        cities = my_ai.cities_init
    else:
        cities = [city]

    all_observe = []
    for ct in cities:
        if not be_observed:
            observe = point_around_LOS(pos_list, bop_type, ubop_type, my_ai, ct, dis=2, beta=1, be_observed=be_observed)
            all_observe.append(observe)
        else:
            observe = point_around_LOS(pos_list, bop_type, ubop_type, my_ai, ct, dis=3, beta=1, be_observed=be_observed)
            all_observe.append(observe)
    all_observe = np.array(all_observe).sum(axis=0)

    return all_observe


def neighbor_observe_ability(pos_int4, observe_ability, dis):
    neighbor_observe = []
    for pos in pos_int4:
        neighbor_pos_tuple = BoundedHex(pos).arc([0, 5], dis)
        neighbor_pos_int4 = [row * 100 + col for (row, col) in neighbor_pos_tuple]
        pos_observe = [observe_ability[np.where(np.array(pos_int4) == pos1)] for pos1 in neighbor_pos_int4 if pos1 in pos_int4]
        neighbor_observe.append(max(pos_observe))
    return np.array(neighbor_observe).squeeze()


def get_stack_value(my_ai):
    cur_hexes = [bop_record['cur_hex'] for bop_id, bop_record in my_ai.enemy_predict.obops_record.items() if bop_record['live'] and bop_record['cur_hex']]
    future_hexes = [bop_record['future_hex'] for bop_id, bop_record in my_ai.enemy_predict.obops_record.items() if bop_record['live'] and bop_record['future_hex']]
    stack_value = np.zeros(my_ai.my_map.size)
    for int4 in cur_hexes:
        row, col = com.cvtInt4loc2Offset(int4)
        stack_value[row, col] += 1
    for int4 in future_hexes:
        row, col = com.cvtInt4loc2Offset(int4)
        stack_value[row, col] += 0.3
    return stack_value


def select_key_point(my_ai, bop, be_see_type, pos_list, center_int4, observe_point_dis=2, top_num=5, select=1, beta=5, **kwargs):
    if not pos_list:
        return bop['cur_hex']
    if isinstance(pos_list[0], tuple):
        pos_tuple = pos_list
        pos_int4 = com.cvtOffset2Int4loc(pos_list)
    elif isinstance(pos_list[0], int):
        pos_int4 = pos_list
        pos_tuple = com.cvtInt4loc2Offset(pos_list)

    combine = 0.0
    # 综合各项因素， 因素值越大越好

    '''
    kwargs = {'observed_ability': 0,
              'be_observed_ability': 0,
              'observed_city': 0,
              'maneuver_time': 2,
              'maneuver_dis': 2,
              'maneuver_time_main': 0,
              'maneuver_dis_main': 0
              'neighbor_max_observe_ability': 0,
              'hide_cond': 1,
              'stack': 0,
              'shoot_ability': 1,
              'be_shoot_ability': 0.5,
              'be_shoot_ability_aircraft': 0.5,
              'observe_enemy_ability': 0,
              'be_observed_enemy_ability': 0,
              'observe_enemy_time': 0,
              'be_shoot_ability_time': 0}
    '''
    # print(ai_group.color, bop['sub_type'])
    # with com.Timer(f'备选点数量为{len(pos_int4)}, 关键点选取消耗时间'):
    for key, value in kwargs.items():

        if key == 'observed_ability' and value > 0:
            observe_level = observe_ability_enemy(bop, be_see_type, pos_int4, my_ai, be_observed=False)
            # observe_level = observe_occupy_ability(bop['type'], be_see_type, pos_int4, ai_group, be_observed=False)
            # plot_hex(pos_int4, ai_group.my_map.map_id, blend_level=0.9, text=observe_level)

            combine += value * com.normalization(observe_level)

        if key == 'be_observed_ability' and value > 0:
            be_observed_level = observe_ability_enemy(bop, be_see_type, pos_int4, my_ai, be_observed=True)

            # be_observed_level = observe_occupy_ability(bop['type'], be_see_type, pos_int4, ai_group, be_observed=True)
            combine += value * (1.0 - com.normalization(be_observed_level))

        if key == 'observed_city' and value > 0:
            observe_level = observe_occupy_ability(bop['type'], be_see_type, pos_int4, my_ai, be_observed=False)
            combine += value * com.normalization(observe_level)

        if key == 'maneuver_time' and value > 0:
            maneuver_time = my_ai.see.get_maneuver_time(bop['type'], bop['cur_hex'])[tuple(zip(*pos_tuple))]
            combine += value * (1.0 - com.normalization(maneuver_time))

        if key == 'maneuver_dis' and value > 0:
            maneuver_dis = [com.get_distance(bop['cur_hex'], int4) for int4 in pos_int4]
            maneuver_dis = np.array(maneuver_dis)
            combine += value * (1.0 - com.normalization(maneuver_dis))

        if key == 'maneuver_time_main' and value > 0:
            maneuver_time_main = my_ai.see.get_maneuver_time(bop['type'], center_int4)[tuple(zip(*pos_tuple))]
            combine += value * (1.0 - com.normalization(maneuver_time_main))

        if key == 'maneuver_dis_main' and value > 0:
            maneuver_dis_main = [com.get_distance(center_int4, int4) for int4 in pos_int4]
            maneuver_dis_main = np.array(maneuver_dis_main)
            combine += value * (1.0 - com.normalization(maneuver_dis_main))

        if key == 'neighbor_max_observe_ability' and value > 0:
            neighbor_observe_level = observe_occupy_ability(bop['type'], be_see_type, pos_int4, my_ai, be_observed=False)
            hide_cond = my_ai.my_map.get_hide_array(bop['type'])[tuple(zip(*pos_tuple))]
            neighbor_max_observe_ability = neighbor_observe_ability(pos_int4, neighbor_observe_level, dis=observe_point_dis)
            neighbor_max_hide = neighbor_observe_ability(pos_int4, hide_cond, dis=observe_point_dis)
            combine += value * (com.normalization(neighbor_max_observe_ability) + 0.5 * com.normalization(neighbor_max_hide))

        if key == 'hide_cond' and value > 0:
            hide_cond = my_ai.my_map.get_hide_array(bop['type'])[tuple(zip(*pos_tuple))]
            combine += value * com.normalization(hide_cond)

        if key == 'stack' and value > 0:
            stack_value = get_stack_value(my_ai)[tuple(zip(*pos_tuple))]
            combine += value * (1 - com.normalization(stack_value))

        if key == 'shoot_ability' and value > 0:
            shoot_ability = my_ai.enemy_predict.attack_ability(bop, pos_int4, my_ai, ubop_type=None)
            combine += value * com.normalization(shoot_ability)

        if key == 'be_shoot_ability' and value > 0:
            be_shoot_ability = my_ai.enemy_predict.be_attacked_ability(bop, pos_int4, my_ai, ubop_type=None)
            combine += value * (1 - com.normalization(be_shoot_ability))

        if key == 'be_shoot_ability_aircraft' and value > 0:
            be_shoot_ability = my_ai.enemy_predict.be_attacked_ability(bop, pos_int4, my_ai, ubop_type=const.BopType.Aircraft)
            combine += value * (1 - com.normalization(be_shoot_ability))

        if key == 'observe_enemy_ability' and value > 0:
            observe_enemy_ability = my_ai.enemy_predict.observe_enemy_ability(bop, pos_int4, my_ai, ubop_type=None)
            combine += value * com.normalization(observe_enemy_ability)

        if key == 'be_observed_enemy_ability' and value > 0:
            be_observed_enemy_ability = my_ai.enemy_predict.be_observed_enemy_ability(bop, pos_int4, my_ai, ubop_type=None)
            combine += value * com.normalization(1 - be_observed_enemy_ability)

        if key == 'observe_enemy_time' and value > 0:
            observe_enemy_ability_time, _ = my_ai.replay_pos.replay_observe_attack_time(bop, pos_int4, 50, 200, my_ai, sub_type=None, name='observe')
            combine += value * com.normalization(observe_enemy_ability_time)

        if key == 'be_shoot_ability_time' and value > 0:
            _, be_attacked_ability_time = my_ai.replay_pos.replay_observed_attacked_time(bop, pos_int4, 0, 200, my_ai,
                                                                                     sub_type=None, name='attack')
            combine += value * (1 - com.normalization(be_attacked_ability_time))

    if top_num < len(pos_int4):
        top = sorted(zip(pos_int4, combine), key=lambda x: x[1], reverse=True)[:top_num]
    else:
        top = sorted(zip(pos_int4, combine), key=lambda x: x[1], reverse=True)
    top_pos, top_value = zip(*top)
    if select > len(top_pos):
        select = len(top_pos)
    result_int4 = int(np.random.choice(top_pos, select, p=com.apply_temperature(beta, top_value)))
    return result_int4


def city_enemy_ability(my_ai, city_coord):
    hexes_around_main = my_ai.hex_cache.get_circle(city_coord, 0, 2)
    ubop_pos_main = np.zeros(len(hexes_around_main))

    for ubop_id, ubop_record in my_ai.enemy_predict.ubops_record.items():
        if ubop_record['live']:
            ubop_pos_main += ubop_record['pos_predict'][tuple(zip(*hexes_around_main))]

    ubop_pos_main = float(ubop_pos_main.sum())

    return ubop_pos_main


def from_pixel(x=0, y=0):
    if isinstance(x, tuple):
        row_pixel, col_pixel = x[0], x[1]
    else:
        row_pixel, col_pixel = x, y


    row = (row_pixel - 13) // 45
    if row % 2 == 0:
        col = col_pixel // 52

    else:
        col = (col_pixel -26) // 52
    if row < 0:
        row = 0
    if col < 0:
        col = 0

    return (int(row), int(col))


def to_pixel(x=0, y=0):
    if isinstance(x, tuple):
        row, col = x[0], x[1]
    else:
        row, col = x, y

    if row % 2 == 0:
        pixel_y = col * 52

    else:
        pixel_y = col * 52 + 26

    pixel_x = row * 45 + 13
    #得到x、y，六角格中心坐标
    x1, x2, x3, x4, x5, x6 = pixel_y-25, pixel_y, pixel_y+25+1, pixel_y+25+1, pixel_y, pixel_y-25
    y1, y2, y3, y4, y5, y6 = pixel_x-16, pixel_x-28, pixel_x-16, pixel_x+16, pixel_x+28+1, pixel_x+16
    center = (pixel_y,pixel_x)
    w=[(x1,y1),(x2,y2),(x3,y3),(x4,y4),(x5,y5),(x6,y6)]
    return center, w


def plot_hex(postion_list, map_id, see_int4=None, blend_level=0.9, text=[]):    # todo Image module
    if not postion_list:
        print('无hex格子坐标要显示')
        return
    if isinstance(text, np.ndarray):
        text = text.tolist()

    map_dir = f'ai/hexmap/data/map/{map_id}/{map_id}.jpg'
    im = Image.open(map_dir)  # 作为背景
    img = im.convert('RGBA')  # 转换为RGBA模式,添加透明度通道,便于透明图像融合
    hex_draw = Image.new('RGBA', img.size, (255, 255, 255, 0))
    draw = ImageDraw.Draw(hex_draw)  # 引入画笔
    if isinstance(postion_list[0], int):
        postion_list = com.cvtInt4loc2Offset(postion_list)
    for i, (row, col) in enumerate(postion_list):
        center, around = to_pixel(row, col)
        draw.polygon(around, fill=(255, 0, 0, int(blend_level * 100)))
        if text:
            font = ImageFont.truetype("/usr/share/fonts/truetype/freefont/FreeMono.ttf", 15, encoding="utf-8")
            draw.text(center, str(format(text[i], '0.2f')), fill=(0, 0, 0), font=font)
    if see_int4:
        row, col = com.cvtInt4loc2Offset(see_int4)
        center, around = to_pixel(row, col)
        draw.polygon(around, fill=(0, 255, 0, int(blend_level * 100)))

    img = Image.alpha_composite(img, hex_draw)
    img.show()
    del draw
#
#
def plot_hot_map(data):
    sns.heatmap(data)
    plt.show()

