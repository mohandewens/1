import numpy as np
import pandas as pd
from . import common, const
from ..hexmap import common as com
import random

class Damage:

    def __init__(self):
        file_name = 'train_env/Data/weapons/anyweapen2air'
        self.anyweapen2air = self.read_file2array(file_name)

        file_name = 'train_env/Data/weapons/anyweapen2people_0_forPythonJuder'
        self.anyweapen2people_0 = self.read_file2array(file_name)

        file_name = 'train_env/Data/weapons/anyweapen2people_1_forPythonJuder'
        self.anyweapen2people_1 = self.read_file2array(file_name)

        file_name = 'train_env/Data/weapons/ele_rect_to_car'
        self.ele_rect_to_car = self.read_file2array(file_name)

        file_name = 'train_env/Data/weapons/ele_rect_to_peo'
        self.ele_rect_to_peo = self.read_file2array(file_name)

        file_name = 'train_env/Data/weapons/jm_offset_0'
        self.jm_offset_0 = self.read_file2array(file_name)

        file_name = 'train_env/Data/weapons/jm_offset_1'
        self.jm_offset_1 = self.read_file2array(file_name)

        file_name = 'train_env/Data/weapons/jm_offset_2'
        self.jm_offset_2 = self.read_file2array(file_name)

        file_name = 'train_env/Data/weapons/zm2car_0_forPythonJuder'
        self.zm2car_0 = self.read_file2array(file_name)

        file_name = 'train_env/Data/weapons/zm2car_1_forPythonJuder'
        self.zm2car_1 = self.read_file2array(file_name)

        file_name = 'train_env/Data/weapons/zm2car_2_forPythonJuder'
        self.zm2car_2 = self.read_file2array(file_name)

        file_name = 'train_env/Data/weapons/WpData.xls'
        self.WpData = pd.read_excel(file_name)


    def get_guide_damage(self, att_obj, tar_obj, guide_obj, WeaponID, map):
        att_hex, tar_hex = guide_obj['cur_hex'], tar_obj['cur_hex']
        att_type, tar_type = guide_obj['type'], tar_obj['type']
        att_blood, tar_blood = guide_obj['blood'], tar_obj['blood'],

        distance = com.get_distance(att_hex, tar_hex)

        original_attack_level = self.get_original_attack_level( WeaponID, tar_type, distance, ObjBlood=tar_blood)

        ###########高差修正
        if tar_type == const.BopType.Aircraft:
            ele_rec = 0
        else:
            ele_rec = self.get_ele_diff(att_hex, tar_hex, distance, tar_type, map)
        attack_level = original_attack_level + ele_rec
        #########

        random1 = random.randint(1,6) + random.randint(1,6)
        ####计算原始伤害值
        if tar_type == const.BopType.Aircraft:
            original_damage = self.anyweapen2air[random1-2][attack_level-1]
        elif tar_type == const.BopType.Infantry:
            original_damage = self.anyweapen2people_0[random1-2][attack_level-1]
        elif tar_type == const.BopType.Vehicle:
            attack_level_number = self.zm2car_0[att_blood-1][attack_level-1]
            original_damage = self.zm2car_1[random1-2][attack_level_number-1]
        #########

        #####属性修正
        damage_rec = self.get_attribute_rec(att_hex, tar_hex, att_type, tar_type, att_obj, tar_obj, map)
        #######
        damage = original_damage + damage_rec
        # print(f'引导射击初始攻击等级：{original_attack_level}，高差修正：{ele_rec}，初始伤害值：{original_damage} \
        # 属性修正：{damage_rec},最终伤害值{damage}')
        return damage

    def get_zhimiao_damage(self, att_obj, tar_obj, WeaponID, map):
        att_hex, tar_hex = att_obj['cur_hex'], tar_obj['cur_hex']
        att_type, tar_type = att_obj['type'], tar_obj['type']
        att_blood, tar_blood = att_obj['blood'], tar_obj['blood'],
        see_mode = common.get_see_mode(att_type, tar_type)

        if not map.can_see(att_hex, tar_hex, see_mode):  # 不可视
            return -1  # 表示不在可视范围
        distance = com.get_distance(att_hex, tar_hex)

        original_attack_level = self.get_original_attack_level( WeaponID, tar_type, distance, ObjBlood=tar_blood)

        ###########高差修正
        if tar_type == const.BopType.Aircraft:
            ele_rec = 0
        else:
            ele_rec = self.get_ele_diff(att_hex, tar_hex, distance, tar_type, map)
        attack_level = original_attack_level + ele_rec
        #########

        random1 = random.randint(1,6) + random.randint(1,6)
        ####计算原始伤害值
        if tar_type == const.BopType.Aircraft:
            original_damage = self.anyweapen2air[random1-2][attack_level-1]
        elif tar_type == const.BopType.Infantry:
            original_damage = self.anyweapen2people_0[random1-2][attack_level-1]
        elif tar_type == const.BopType.Vehicle:
            attack_level_number = self.zm2car_0[att_blood-1][attack_level-1]
            original_damage = self.zm2car_1[random1-2][attack_level_number-1]
        #########

        #####属性修正
        damage_rec = self.get_attribute_rec(att_hex, tar_hex, att_type, tar_type, att_obj, tar_obj, map)
        #######

        damage = original_damage + damage_rec
        # print(f'初始攻击等级：{original_attack_level}，高差修正：{ele_rec}，初始伤害值：{original_damage} \
        # 属性修正：{damage_rec},最终伤害值{damage}')
        return damage



    def get_attribute_rec(self,att_hex, tar_hex, att_type, tar_type, att_obj, tar_obj, map):
        random2 = random.randint(1,6) + random.randint(1,6)
        ####### 属性修正
        if tar_type == const.BopType.Aircraft:
            damage_rec = 0
        elif tar_type == const.BopType.Infantry:
            rec = 0
            # 射击者状态
            if att_obj['keep']:
                rec -= 1
            if att_obj['stop']==0 and att_obj['move_state'] == const.StateMode.Maneuver:
                rec -= 1
            # 目标的地形
            if map.is_resident(tar_hex):
                rec -= 1
            elif map.is_forest(tar_hex):
                rec -= 2
            # 目标状态
            if tar_obj['move_state'] == const.StateMode.Hide:
                rec -= 2
            elif tar_obj['stop']==0 and (tar_obj['move_state'] == const.StateMode.Maneuver or \
                                         tar_obj['move_state'] == const.StateMode.Rush_level_one or \
                                         tar_obj['move_state'] == const.StateMode.Rush_level_two):
                rec -= 2
            elif tar_obj['move_state'] == const.StateMode.March:
                rec += 4
            if tar_obj['stack']==1:
                rec += 2
            random3 = random2 + rec
            if random3 < 0:
                random3 = 0
            elif random3 > 8:
                random3 = 8
            damage_rec = self.anyweapen2people_1[random3][1]
        elif tar_type == const.BopType.Vehicle:
            rec = 0
            # 射击者状态
            if att_obj['keep']:
                rec -= 1
            if att_obj['stop'] == 0 and att_obj['move_state'] == const.StateMode.Maneuver:
                rec -= 1
            if att_obj['sub_type'] == const.BopName.Tank and map.is_waters(att_hex):
                rec -= 1
            # 目标所在地形
            if map.is_resident(tar_hex):
                rec -= 1
            elif map.is_forest(tar_hex):
                rec -= 2
            elif map.is_waters(tar_hex):
                rec -= 2
            # 目标状态
            if tar_obj['move_state'] == const.StateMode.Hide:
                rec -= 2
            elif tar_obj['stop']==0 and (tar_obj['move_state'] == const.StateMode.Maneuver or \
                                         tar_obj['move_state'] == const.StateMode.Rush_level_one or \
                                         tar_obj['move_state'] == const.StateMode.Rush_level_two):
                rec -= 2
            elif tar_obj['move_state'] == const.StateMode.March:
                rec += 4
            if tar_obj['stack']==1:
                rec += 2
            random3 = random2 + rec
            if random3 < -3:
                random3 = -3
            elif random3 > 12:
                random3 = 12
            armor = tar_obj['armor']
            damage_rec = self.zm2car_2[random3 + 3][armor]
        return damage_rec

    def get_ele_diff(self, att_hex, tar_hex, distance, tar_type, map):
        ele_diff = map.get_ele_diff(com.cvtInt4loc2Offset(att_hex), com.cvtInt4loc2Offset(tar_hex))
        if ele_diff < 0:
            if distance <= 12:
                if abs(ele_diff) >= 8:
                    ele_diff = 7
                if tar_type == const.BopType.Infantry:
                    ele_rec = self.ele_rect_to_peo[abs(ele_diff)-1][distance-1]
                else:
                    ele_rec = self.ele_rect_to_car[abs(ele_diff)-1][distance-1]
            else:
                ele_rec = 0
        else:
            ele_rec = 0
        return ele_rec

    def get_original_attack_level(self, WeaponID, TarType, dis, ObjBlood):
        assert self.weapon_can_attack_type(WeaponID, TarType)

        if WeaponID == 29 and TarType == const.BopType.Vehicle: # 正射击表格中没有轻武器对人员的基本攻击等级
            TarType = const.BopType.Infantry

        if TarType != const.BopType.Infantry:
            ObjBlood = 0

        WpData = self.WpData.loc[(self.WpData['WeaponID'] == WeaponID) &
                                 (self.WpData['TarType'] == TarType) &
                                 (self.WpData['ObjBlood'] == ObjBlood)]

        assert len(WpData) == 1, print(WeaponID, TarType, dis, ObjBlood, WpData)
        AttMin, AttMax = self.get_attack_distance(WeaponID, TarType)
        if dis < AttMin or dis > AttMax:
            print(f'距离为{dis}时，武器{WeaponID}攻击不到类型为{TarType}的棋子！！')
            return -1
        original_attack_level = int(WpData[str(dis)])
        return original_attack_level

    def get_bop_attack_distance(self, bop, TarType):
        weapon_ids = bop['carry_weapon_ids']

        att_max = []
        for weapon in weapon_ids:
            if self.weapon_can_attack_type(weapon, TarType):
                _, weapon_max = self.get_attack_distance(weapon, TarType)
                att_max.append(weapon_max)
        if not att_max:
            att_max.append(0)
        max_dis = max(att_max)
        return int(max_dis)


    def get_attack_distance(self, WeaponID, TarType):
        assert self.weapon_can_attack_type(WeaponID, TarType)
        AttDis = self.WpData.loc[(self.WpData['WeaponID'] == WeaponID) &
                                 (self.WpData['TarType'] == TarType), ['AttMin', 'AttMax']].values.squeeze()
        if AttDis.any():
            AttMin, AttMax = AttDis.min(), AttDis.max()
        else:
            AttMin, AttMax = 0, 0
        return AttMin, AttMax

    def weapon_can_attack_type(self, WeaponID, TarType):
        TarTypes = self.WpData.loc[(self.WpData['WeaponID'] == WeaponID), ['TarType']].values.squeeze()
        if TarType in TarTypes:
            return True
        elif 0 in TarTypes:
            return True
        elif WeaponID==29 and TarType==const.BopType.Vehicle:
            return True
        else:
            # print(f'武器{WeaponID}不能射击类型为{TarType}的算子！！')
            return False

    @staticmethod
    def read_file2array(file_name):
        try:
            data = []
            with open(file_name, 'r') as fp:
                while True:
                    text = fp.readline()
                    if not text:
                        break
                    text = text.split()
                    if text:
                        data.append(text)
                data = np.array(data).astype(int)
            return data
        except OSError as reason:
            print('读取文件出错了T_T')
            print('出错原因是%s' % str(reason))

if __name__ == '__main__':
    damage = Damage()
    # pass