from ..hexmap.hex import BoundedHex
import numpy as np
from . import const, rule


def get_distance(int4a, int4b):
    return BoundedHex(int4a).distance_to(BoundedHex(int4b))


def get_color_bops(operators, color=const.Color.RED):
    bops = [bop for bop in operators if bop['color'] == color]
    return bops

def get_color_bops_jiejutank(operators, color=const.Color.RED):
    bops = [bop for bop in operators if bop['color'] == color and bop['sub_type'] == const.BopName.Tank]
    jiejubop = []
    for bop in bops:
        if bop['obj_id']!= 12 and bop['obj_id']!= 13:
            jiejubop.append(bop)
    return jiejubop

def get_bop_obj_id(operators, obj_id):
    """Get bop in my observation based on its id."""
    bops = [bop for bop in operators if bop['obj_id'] == obj_id]
    if len(bops) == 1:
        return bops[0]
    elif len(bops) == 0:
        return []
    else:
        raise Exception

def get_action_bop_obj_id(action_bops, obj_id):
    """Get bop in my observation based on its id."""
    bops = [action_bop for action_bop in action_bops if action_bop.obj_id == obj_id]
    if len(bops) == 1:
        return bops[0]
    elif len(bops) == 0:
        return []
    else:
        raise Exception


def get_passenger_bop_obj_id(passengers, obj_id):
    """Get bop in my observation based on its id."""
    bops = [bop for bop in passengers if bop['obj_id'] == obj_id]
    if len(bops) == 1:
        return bops[0]
    elif len(bops) == 0:
        return None
    else:
        raise Exception


def get_passenger_number(bop, our_passengers, sub_type=None):
    passenger_ids = bop['passenger_ids']
    if passenger_ids:
        passenger_bops = []
        for obj_id in passenger_ids:
            passenger_bop = get_passenger_bop_obj_id(our_passengers, obj_id)
            if passenger_bop:
                passenger_bops.append(passenger_bop)
        if sub_type == None:
            num_passenger = len(passenger_bops)
        else:
            num_passenger = len(get_bop_sub_type(passenger_bops, sub_type))
        return num_passenger
    else:
        return 0


def get_city_coord(citys, coord):
    city = [city for city in citys if city['coord'] == coord]
    if len(city) == 1:
        return city[0]
    elif len(city) == 0:
        return []
    else:
        raise Exception


def my_city(citys, color, coord=None):
    if coord:
        city = get_city_coord(citys, coord)
        if city:
            return city['flag'] == color
        else:
            return False
    else:
        my_city = [city['flag'] == color for city in citys]
    return my_city


def get_bop_pos(operators, pos_int4):
    bops = [bop for bop in operators if bop['cur_hex'] == pos_int4]
    return bops


def get_init_pos(bop, bops_init):
    bop_init = get_bop_obj_id(bops_init, bop['obj_id'])
    if bop_init:
        return bop_init['cur_hex']
    else:
        return None


def get_bop_sub_type(operators, sub_type):
    """Get bop in my observation based on its sub_type."""
    bops = [bop for bop in operators if bop['sub_type'] == sub_type]
    return bops


def get_bop_sub_type_under_see(operators, sub_type, see_id_list):
    """Get bop in my observation based on its sub_type."""
    bops = [bop for bop in operators if (bop['sub_type'] == sub_type and bop['obj_id'] in see_id_list)]
    return bops


def get_bop_sub_type_under_attack(bop, my_ai, operators, sub_type, see_id_list):
    """Get bop in my observation based on its sub_type."""
    ubops = [bop for bop in operators if (bop['sub_type'] == sub_type and bop['obj_id'] in see_id_list)]
    for ubop in ubops:
        dis = get_distance(ubop['cur_hex'], bop['cur_hex'])
        attack_dis = my_ai.damage.get_bop_attack_distance(ubop, bop['type'])
        if my_ai.my_map.is_hide_point(bop['cur_hex']):
            if dis <= int(rule.BeObservedDis[bop['type']] / 2):
                return True
        else:
            if dis <= attack_dis:
                return True
    return False


def get_bop_sub_type_pos(operators, sub_type, pos):
    bops = [bop for bop in operators if (bop['sub_type'] == sub_type and bop['cur_hex'] == pos)]
    return bops


def subtype_to_type(sub_type):
    if sub_type in [const.BopName.Soldier]:
        return const.BopType.Infantry
    elif sub_type in [const.BopName.Vehicle, const.BopName.Tank, const.BopName.UnmannedVehicle, const.BopName.Artillery ,const.BopName.ScoutVehicle]:
        return const.BopType.Vehicle
    elif sub_type in [const.BopName.UAV, const.BopName.Missile, const.BopName.Helicopter, const.BopName.YSHelicopter]:
        return const.BopType.Aircraft
    else:
        raise Exception

def get_bop_type(operators, type):
    """Get bop in my observation based on its sub_type."""
    bops = [bop for bop in operators if bop['type'] == type]
    return bops


def get_city_name(citys, color,value=80):
    citys_name = [city for city in citys if city['value']==value]
    if len(citys_name) != 0:
        if value == 80:
            return citys_name[0]
        if value == 50 and color ==  1:
            return citys_name[0]
        if value == 50 and color == 0:
            return citys_name[1]
    elif len(citys_name) == 0:
        return False
    else:
        raise Exception


def get_bop_action_id_name(valid_actions, obj_id, action_name):
    """Get bop in my observation based on its sub_type."""
    actions = [action for id, action in valid_actions.items() if (id == obj_id and action_name in action.keys())]
    if len(actions) == 1:
        return actions[0]
    elif len(actions) == 0:
        return False
    else:
        raise Exception

def get_id_by_action_name(valid_actions, action_name):
    """Get bop in my observation based on its sub_type."""
    ids = [id for id, action in valid_actions.items() if action_name in action.keys()]
    if ids:
        return ids
    else:
        return []

def get_action_type(valid_actions, action_name):
    """Get bop in my observation based on its sub_type."""
    actions = [(id, action[action_name]) for id, action in valid_actions.items() if action_name in action.keys()]
    if actions:
        return actions
    else:
        return False

def get_see_source(bop_type):
    if bop_type == const.BopType.Aircraft:
        see_source = const.SeeSource.FromSky
    else:
        see_source = const.SeeSource.FromGround
    return see_source


def get_see_mode(see_bop_type, target_bop_type):
    if see_bop_type == const.BopType.Aircraft and target_bop_type == const.BopType.Aircraft:
        see_mode = const.SeeMode.SkyToSky
    elif see_bop_type == const.BopType.Aircraft and \
            (target_bop_type == const.BopType.Infantry or target_bop_type == const.BopType.Vehicle):
        see_mode = const.SeeMode.SkyToGround
    elif target_bop_type == const.BopType.Aircraft and \
            (see_bop_type == const.BopType.Infantry or see_bop_type == const.BopType.Vehicle):
        see_mode = const.SeeMode.GroundToSky
    elif (see_bop_type == const.BopType.Infantry or see_bop_type == const.BopType.Vehicle) and \
            (target_bop_type == const.BopType.Infantry or target_bop_type == const.BopType.Vehicle):
        see_mode = const.SeeMode.GroundToGround
    else:
        raise Exception
    return see_mode


def can_move(bop, my_ai):
    '''判断棋子是否能够移动'''
    move_actions = get_bop_action_id_name(my_ai.observation['valid_actions'], bop['obj_id'], const.ActionType.Move)
    if move_actions:
        return True
    else:
        return False

def get_see_enemy(bop, enemys):
    if bop['see_enemy_bop_ids']:
        ubops = [get_bop_obj_id(enemys, ubop_id) for ubop_id in bop['see_enemy_bop_ids']]
    else:
        ubops = []
    return ubops

def see_enemy_vehicle(enemys):
    ubops = get_bop_sub_type(enemys, const.BopName.Vehicle)
    ubops2 = get_bop_sub_type(enemys, const.BopName.ScoutVehicle)
    if ubops or ubops2:
        return True
    else:
        return False

def see_enemy_tank(enemys):
    ubops = get_bop_sub_type(enemys, const.BopName.Tank)
    if ubops:
        return True
    else:
        return False

def enemy_no_vehicle(my_ai):
    ubops_record = [ubop_record for ubop_id, ubop_record in my_ai.enemy_predict.ubops_record.items() if
                    ubop_record['live'] and (ubop_record['sub_type']==const.BopName.Vehicle or ubop_record['sub_type']==const.BopName.ScoutVehicle)]
    if ubops_record:
        return False
    else:
        return True