import pickle, time, copy
import multiprocessing as mp
from multiprocessing import Manager, Process, Lock
from datetime import datetime
from ctypes import c_char, c_uint32
import numpy as np
from ..hexmap import common as com
from . import const, common
import threading


class CCSharedObject:
    def __init__(self, size):
        self.size = size
        self.sharedmem_obj = mp.Array(c_char, size)
        self.sharedmem_obj_len = mp.Value(c_uint32, 0)
        self.done = mp.Value(c_uint32, 0)
        self.done.value = False
    # 将rawObj变量存入到共享区
    def SaveObj(self, rawObj):
        with self.sharedmem_obj.get_lock():
            picked_obj = pickle.dumps(rawObj)
            lenOfObj = len(picked_obj)
            # print(lenOfObj)
            if lenOfObj > self.size:
                print("shared obj buf overflow...")
                raise Exception("shared obj buf overflow...")
            else:
                self.sharedmem_obj_len.value = lenOfObj
                self.sharedmem_obj[0:lenOfObj] = picked_obj
                self.done.value = True
        # 将共享区变量取出，再转化为Python变量返回

    def GetObj(self):
        with self.sharedmem_obj.get_lock():
            bufLen = self.sharedmem_obj_len.value
            if not bufLen:
                raw_obj = None
            else:
                raw_obj = pickle.loads(self.sharedmem_obj[:bufLen])
                self.done.value = False
            return raw_obj


def attack_value_multi_process(my_map, see, damage, enemy_bops_init_all,
                                        hex_cache, ubops_record_share, our_bops_share, result_share, process_done):
    my_color = 0 if enemy_bops_init_all[0]['color'] else 1
    while not process_done.value:
        # with com.Timer('11111111111111111'):
        #     print(ubops_record_share.done.value)
        if ubops_record_share.done.value:
            ubops_record = ubops_record_share.GetObj()
            observation = our_bops_share.GetObj()

            our_bops = common.get_color_bops(observation['operators'] + observation['passengers'], color=my_color)
            cur_time = observation['time']['cur_step']

            result = Manager().dict()  # 生成一个字典{}
            lock = Lock()
            pro_obj = []  # 用于存储子进程
            for bop in our_bops:
                if bop['sub_type'] not in const.no_calcu_sub_type:
                    p = threading.Thread(target=thread_calu, args=(result, bop, ubops_record, cur_time, my_map, see, damage, enemy_bops_init_all,
                                        hex_cache, lock))
                    p.start()
                    pro_obj.append(p)

                    # import atexit  # kill the
                    # atexit.register(p.terminate)

            for pro in pro_obj:
                pro.join()

            result_share.SaveObj(result.copy())
        else:
            time.sleep(0.1)
    return


def thread_calu(result, bop, ubops_record, time, my_map, see, damage, enemy_bops_init_all,
                                        hex_cache, lock):
    result_temp = {}
    bop_around = hex_cache.get_circle(bop['cur_hex'], 0, const.calcu_dis)
    bop_around_int4 = com.cvtOffset2Int4loc(bop_around)
    be_attacked_value_soldier, be_observed_value_soldier = be_attacked_observed_ability(bop, bop_around_int4, time,
                                        my_map, see, damage, enemy_bops_init_all, ubops_record,  const.BopType.Infantry)
    be_attacked_value_vehicle, be_observed_value_vehicle = be_attacked_observed_ability(bop, bop_around_int4, time,
                                        my_map, see, damage, enemy_bops_init_all, ubops_record, const.BopType.Vehicle)
    be_attacked_value_Aircraft, be_observed_value_Aircraft = be_attacked_observed_ability(bop, bop_around_int4, time,
                                        my_map, see, damage, enemy_bops_init_all, ubops_record, const.BopType.Aircraft)
    result_temp['be_attacked_value_soldier'] = list(zip(bop_around_int4, be_attacked_value_soldier))
    result_temp['be_attacked_value_vehicle'] = list(zip(bop_around_int4, be_attacked_value_vehicle))
    result_temp['be_observed_value_soldier'] = list(zip(bop_around_int4, be_observed_value_soldier))
    result_temp['be_observed_value_vehicle'] = list(zip(bop_around_int4, be_observed_value_vehicle))
    result_temp['be_attacked_value_Aircraft'] = list(zip(bop_around_int4, be_attacked_value_Aircraft))
    result_temp['be_observed_value_Aircraft'] = list(zip(bop_around_int4, be_observed_value_Aircraft))

    attack_ability_soldier, observe_ability_soldier = attack_observe_ability(bop, bop_around_int4, see, damage,
                                                                             enemy_bops_init_all, ubops_record, const.BopType.Infantry)
    attack_ability_vehicle, observe_ability_vehicle = attack_observe_ability(bop, bop_around_int4, see, damage,
                                                                             enemy_bops_init_all, ubops_record, const.BopType.Vehicle)
    result_temp['attack_ability_soldier'] = list(zip(bop_around_int4, attack_ability_soldier))
    result_temp['attack_ability_vehicle'] = list(zip(bop_around_int4, attack_ability_vehicle))
    result_temp['observe_ability_soldier'] = list(zip(bop_around_int4, observe_ability_soldier))
    result_temp['observe_ability_vehicle'] = list(zip(bop_around_int4, observe_ability_vehicle))
    lock.acquire()
    result[bop['obj_id']] = copy.deepcopy(result_temp)
    lock.release()


# 计算某个点的被攻击度，短时间内的计算，考虑到敌方是否具有射击能力
def be_attacked_observed_ability(bop, int4_list, time, my_map, see, damage, enemy_bops_init_all, self_ubops_record, bop_type):
    if not int4_list:
        return [], []
    if bop['type'] == const.BopType.Aircraft:
        ubops_record = [ubop_record for ubop_id, ubop_record in self_ubops_record.items() if
                         ubop_record['live'] and
                         ubop_record['type'] == bop_type and ubop_record['sub_type'] not in const.no_calcu_sub_type_air]
        ubops_id = [ubop_id for ubop_id, ubop_record in self_ubops_record.items() if
                    ubop_record['live'] and
                    ubop_record['type'] == bop_type and ubop_record['sub_type'] not in const.no_calcu_sub_type_air]
    else:
        ubops_record = [ubop_record for ubop_id, ubop_record in self_ubops_record.items() if
                         ubop_record['live'] and
                         ubop_record['type'] == bop_type and ubop_record['sub_type'] not in const.no_calcu_sub_type]
        ubops_id = [ubop_id for ubop_id, ubop_record in self_ubops_record.items() if
                         ubop_record['live'] and
                         ubop_record['type'] == bop_type and ubop_record['sub_type'] not in const.no_calcu_sub_type]

    if not ubops_record:
        return np.zeros(len(int4_list)), np.zeros(len(int4_list))
    dis = [0]
    for ubop_id in ubops_id:
        ubop = common.get_bop_obj_id(enemy_bops_init_all, ubop_id)
        if ubop:
            if bop['sub_type'] in [const.BopName.UAV, const.BopName.Missile] or ubop['sub_type'] in [const.BopName.UAV, const.BopName.Missile]:
                be_shoot_dis = 1
            elif bop['sub_type'] in [const.BopName.Helicopter]:
                be_shoot_dis = 11
            else:
                be_shoot_dis = damage.get_bop_attack_distance(ubop, bop['type'])
            dis.append(be_shoot_dis)
    be_shoot_dis = max(dis)

    pos_tuple = com.cvtInt4loc2Offset(int4_list)
    maneuver_time = see.get_maneuver_time(bop['type'], bop['cur_hex'])[tuple(zip(*pos_tuple))] + time
    # 地形修正值，隐蔽地形被攻击度会降低
    hide_value = 1 - my_map.get_hide_array(bop['type'])[tuple(zip(*pos_tuple))] * 0.4
    ubops_predict = []
    for ubop_id, ubop_record in zip(ubops_id, ubops_record):
        if ubop_record['bop_record']:
            ubop = ubop_record['bop_record'][-1][1]
        else:
            ubop = common.get_bop_obj_id(enemy_bops_init_all, ubop_id)

        if ubop_record['shoot_ability'] == 1:
            shoot_ability = np.ones(len(int4_list))
        elif ubop_record['shoot_ability'] == 0:
            shoot_ability = (maneuver_time - ubop_record['can_shoot_time'] > 70)
        else:
            shoot_ability = np.ones(len(int4_list)) * ubop_record['shoot_ability']

        ubops_shoot_predict = ubop_record['pos_predict'] * shoot_ability[:, np.newaxis, np.newaxis]
        ubops_predict.append(ubops_shoot_predict)

    ubops_pos = np.array(ubops_predict).max(axis=0)

    be_LOS, ubop_shoot_LOS = see.get_be_shoot_LOS(common.get_see_source(bop_type),
                                        bop['type'], int4_list, be_shoot_dis, get_be_LOS=True)
    be_shoot_ability_bop = ubop_shoot_LOS * ubops_pos
    be_shoot_ability = be_shoot_ability_bop.sum(axis=(1, 2)) * hide_value
    #################
    be_observed_ability = (be_LOS * ubops_pos).sum(axis=(1, 2))
    return be_shoot_ability, be_observed_ability


# 计算某个点的攻击度，短时间内的计算，
def attack_observe_ability(bop, int4_list, see, damage, enemy_bops_init_all, self_ubops_record, bop_type):
    if not int4_list:
        return [], []
    if bop['sub_type'] == const.BopName.Tank:
        ubops_predict = [ubop_record['pos_predict'] for ubop_id, ubop_record in self_ubops_record.items() if
                         ubop_record['live'] and
                         ubop_record['type'] == bop_type and ubop_record['sub_type'] not in const.no_calcu_sub_type_tank]
        ubops_id = [ubop_id for ubop_id, ubop_record in self_ubops_record.items() if
                    ubop_record['live'] and
                    ubop_record['type'] == bop_type and ubop_record['sub_type'] not in const.no_calcu_sub_type_tank]
    else:
        ubops_predict = [ubop_record['pos_predict'] for ubop_id, ubop_record in self_ubops_record.items() if
                         ubop_record['live'] and
                         ubop_record['type'] == bop_type and ubop_record['sub_type'] not in const.no_calcu_sub_type]
        ubops_id = [ubop_id for ubop_id, ubop_record in self_ubops_record.items() if
                         ubop_record['live'] and
                         ubop_record['type'] == bop_type and ubop_record['sub_type'] not in const.no_calcu_sub_type]


    dis = [0]
    for ubop_id in ubops_id:
        ubop = common.get_bop_obj_id(enemy_bops_init_all, ubop_id)
        if ubop:
            if bop['sub_type'] in [const.BopName.UAV, const.BopName.Missile] or ubop['sub_type'] in [const.BopName.UAV, const.BopName.Missile]:
                shoot_dis = 2
            else:
                shoot_dis = damage.get_bop_attack_distance(bop, ubop['type'])
            dis.append(shoot_dis)
    shoot_dis = max(dis)

    if not ubops_predict:
        return np.zeros(len(int4_list)), np.zeros(len(int4_list))

    # 地形修正值，隐蔽地形攻击度会增强
    if len(ubops_predict) > 1:
        ubop_pos = np.array(ubops_predict).max(axis=0)
    else:
        ubop_pos = ubops_predict[0]
    # 计算攻击范围
    ubop_type = bop_type
    LOS, shoot_LOS = see.get_shoot_LOS(common.get_see_source(bop['type']), ubop_type, int4_list, shoot_dis, get_LOS=True)
    attack_ability = (shoot_LOS * ubop_pos).sum(axis=(1, 2))
    ##################
    observe_ability = (LOS * ubop_pos).sum(axis=(1, 2))

    return attack_ability, observe_ability
