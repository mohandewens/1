# -*- coding: utf-8 -*-
"""
Created on Mon Oct 15 19:00:35 2018

@author: Hello！更新敌情函数，敌人数量三个字典：1.敌人剩余兵力，2.消灭的敌人列表
"""

import time
import pandas as pd
import numpy as np
import os, glob, json, copy, zipfile
from . import common, const, util
from ..hexmap import common as com
from ..hexmap.hex import BoundedHex


class UpdateReplay:

    def __init__(self, my_ai, enemy_pos_dir):
        self.my_ai = my_ai
        if not os.path.isdir(enemy_pos_dir):
            os.makedirs(enemy_pos_dir)
        pos_file = os.path.join(enemy_pos_dir, 'replay_pos.pkl')
        replay_name_record = os.path.join(enemy_pos_dir, 'replay_name_record.pkl')
        self.size = my_ai.my_map.size
        col_np, row_np = np.meshgrid(np.arange(self.size[1]), np.arange(self.size[0]))
        index_array = (row_np * 100 + col_np).flatten()
        columns = np.append(['color', 'sub_type', 'serial', 'time'], index_array)
        self.columns = columns
        if not os.path.isfile(pos_file):
            print('Generate new enemy position probability')
            pd_data = []
            data = np.zeros((self.size[0], self.size[1])).flatten()
            for color in [0, 1]:
                bops_init = common.get_color_bops(my_ai.scenario_info['operators'], color=color)
                passengers_init = common.get_color_bops(my_ai.scenario_info['passengers'], color=color)
                bops_init.extend(passengers_init)
                sub_type_record = []
                for bop in bops_init:
                    sub_type = bop['sub_type']
                    serial = len([type for type in sub_type_record if type == sub_type])
                    sub_type_record.append(sub_type)
                    for time in range(0, my_ai.game_all_time + 1, 20):
                        data_append = np.append([color, sub_type, serial, time], data)
                        pd_data.append(data_append)
            pd_data = np.vstack(pd_data)
            pos_pd = pd.DataFrame(data=pd_data, index=None, columns=columns, dtype=np.int16).set_index(
                ['color', 'sub_type', 'serial', 'time'])
            pos_pd.to_pickle(pos_file)
            self.pos_file = pos_file
            self.replay_pos = pos_pd
        else:
            self.pos_file = pos_file
            self.replay_pos = pd.read_pickle(pos_file)
        # 多线线程更新复盘文件时，防止数据取用冲突，复制一份位置概率表
        self.replay_pos_copy = copy.deepcopy(self.replay_pos)

        if not os.path.isfile(replay_name_record):
            replay_name_pd = pd.DataFrame(columns=['replay_name'], dtype=str)
            replay_name_pd.to_pickle(replay_name_record)
            self.replay_name_record = replay_name_record
            self.replay_name = replay_name_pd.values.squeeze()
        else:
            self.replay_name_record = replay_name_record
            self.replay_name = pd.read_pickle(replay_name_record).values.squeeze()

    def append_columns(self, color, sub_type, serial, time):
        data = np.zeros((self.size[0], self.size[1])).flatten()
        data_np = np.append([color, sub_type, serial, time], data)
        data_np = np.expand_dims(data_np, 0)
        new_pd = pd.DataFrame(data=data_np, index=None, columns=self.columns, dtype=np.int16).set_index(
            ['color', 'sub_type', 'serial', 'time'])
        self.replay_pos_copy = self.replay_pos_copy.append(new_pd)

    def update_replays(self, my_color, replays_dir, two_color=True, number=None):

        for replay_file in glob.glob(os.path.join(replays_dir, '*.zip')):
            # scenario = int(replay_file.split('/')[-1].split('_')[-2])
            if replay_file not in self.replay_name:
                # 设定更新number个文件
                if number:
                    number -= 1
                    if number < 0:
                        return

                print(f'正在记录{replay_file}的位置信息...')
                self.replay_name = np.append(self.replay_name, replay_file)
                with zipfile.ZipFile(replay_file, 'r') as z:
                    z_file = z.read(z.namelist()[0]).decode('gbk')
                    replay = json.loads(z_file)
                    # print(replay)
                    # replay = json.load(z_file)
                    # with open(z.namelist()[0], 'r', encoding='gbk') as f:
                    #     replay = json.load(f)
                self.update_position(replay, my_color, two_color=two_color)
        self.replay_pos_copy.to_pickle(self.pos_file)
        replay_name_pd = pd.DataFrame(data=self.replay_name, columns=['replay_name'], dtype=str)
        replay_name_pd.to_pickle(self.replay_name_record)

    def update_record(self, replay, my_color, two_color=True):
        self.update_position(replay, my_color, two_color=two_color)
        self.replay_pos_copy.to_pickle(self.pos_file)
        print('当前历史信息更新完毕')

    def update_position(self, replay, my_color, two_color=True):
        ####为了实现20秒内位置不变就不更新位置
        last_state = {}
        last_state['operators'] = []
        last_time = 0
        sub_type_record_red = {}
        sub_type_record_blue = {}
        for state in replay[1:]:
            time = state['time']['cur_step'] // 20 * 20

            for operator in state['operators']:
                color = operator['color']
                if not two_color and color == my_color:
                    continue
                else:
                    last_operator = common.get_bop_obj_id(last_state['operators'], operator['obj_id'])
                    if not last_operator:
                        sub_type = operator['sub_type']
                        pos = operator['cur_hex']
                        if color == const.Color.RED:
                            if operator['obj_id'] in sub_type_record_red.keys():
                                serial = sub_type_record_red[operator['obj_id']][1]
                            else:
                                number = len([type for obj, (type, serial) in sub_type_record_red.items() if type == sub_type])
                                sub_type_record_red[operator['obj_id']] = (sub_type, number)
                                serial = number
                        else:
                            if operator['obj_id'] in sub_type_record_blue.keys():
                                serial = sub_type_record_blue[operator['obj_id']][1]
                            else:
                                number = len(
                                    [type for obj, (type, serial) in sub_type_record_blue.items() if type == sub_type])
                                sub_type_record_blue[operator['obj_id']] = (sub_type, number)
                                serial = number
                        # 突然出现的棋子，之前没有记录过，需要增加新的索引
                        if (color, sub_type, serial, time) not in self.replay_pos_copy.index.values.tolist():
                            # print(f'color{color}, sub_type{sub_type}, serial{serial}, time{time} no replays')
                            self.append_columns(color, sub_type, serial, time)

                        self.replay_pos_copy.loc[(color, sub_type, serial, time), [str(pos)]] += 0.1
                        self.replay_pos_copy.loc[(color, sub_type, serial, time)] = self.replay_pos_copy.loc[(
                            color, sub_type, serial, time)] / self.replay_pos_copy.loc[(
                            color, sub_type, serial, time)].sum()
                        # print(self.replay_pos_copy.loc[(color, sub_type, serial, time), [str(pos)]])

                    elif operator['cur_hex'] != last_operator['cur_hex'] or last_time != time:
                        # print(state['time']['cur_step'])
                        sub_type = operator['sub_type']
                        pos = operator['cur_hex']
                        if color == const.Color.RED:
                            serial = sub_type_record_red[operator['obj_id']][1]
                        else:
                            serial = sub_type_record_blue[operator['obj_id']][1]
                        # 突然出现的棋子，之前没有记录过，需要增加新的索引
                        if (color, sub_type, serial, time) not in self.replay_pos_copy.index.values.tolist():
                            # print(f'color{color}, sub_type{sub_type}, serial{serial}, time{time} no replays')
                            self.append_columns(color, sub_type, serial, time)

                        self.replay_pos_copy.loc[(color, sub_type, serial, time), [str(pos)]] += 0.1
                        # print(self.replay_pos.loc[(color, sub_type, serial, time), [str(pos)]])
                        self.replay_pos_copy.loc[(color, sub_type, serial, time)] = self.replay_pos_copy.loc[
                                                                                        (color, sub_type, serial,
                                                                                         time)] / \
                                                                                    self.replay_pos_copy.loc[(
                                                                                        color, sub_type, serial,
                                                                                        time)].sum()
            last_state = state
            if last_time != time:
                last_time = time

    def get_replay_pos(self, color, sub_type, serial, time):
        if const.replay_mode == 1:
            # time分为单个时间（int）和时间段[start, end]
            if isinstance(time, int):
                time == time // 20 * 20
                # 新出现的棋子，在概率表中没有记录
                if (color, sub_type, serial, time) not in self.replay_pos.index.values.tolist():
                    # print(f'color{color}, sub_type{sub_type}, serial{serial}, time{time} no replays')
                    return np.zeros(self.size)

                return self.replay_pos.loc[(color, sub_type, serial, time)].values.reshape(self.size)
            elif isinstance(time, list):
                start = time[0] // 20 * 20
                if start < 0:
                    start = 0
                elif start > self.my_ai.game_all_time:
                    start = self.my_ai.game_all_time - 40
                end = time[1] // 20 * 20
                if end < 0:
                    end = start + 40
                if end > self.my_ai.game_all_time:
                    end = self.my_ai.game_all_time
                if start > end:
                    start, end = end, start
                time_list = list(range(start, end + 1, 20))
                # 新出现的棋子，在概率表中没有记录
                if (color, sub_type, serial, start) not in self.replay_pos.index.values.tolist():
                    # print(f'color{color}, sub_type{sub_type}, serial{serial}, time{start} no replays')
                    return np.zeros(self.size)
                replay_pos = self.replay_pos.loc[(color, sub_type, serial, time_list)].values.reshape(-1,
                                                                                                      *self.size).max(
                    axis=0)
                # replay_pos = com.apply_temperature(1, replay_pos)
                return replay_pos
        elif const.replay_mode == 0:  # 仅以区域估计敌方位置概率
            # time分为单个时间（int）和时间段[start, end]
            if isinstance(time, int):
                time == time // 20 * 20
                enemy_zone = self.my_ai.enemy_observe_zone.get_be_observed_zone(time)
            elif isinstance(time, list):
                start = time[0] // 20 * 20
                if start < 0:
                    start = 0
                elif start > self.my_ai.game_all_time:
                    start = self.my_ai.game_all_time - 40
                end = time[1] // 20 * 20
                if end < 0:
                    end = start + 40
                if end > self.my_ai.game_all_time:
                    end = self.my_ai.game_all_time
                if start > end:
                    start, end = end, start
                time_list = list(range(start, end + 1, 20))
                enemy_zone = self.my_ai.enemy_observe_zone.get_be_observed_zone(time_list).max(axis=0)
            # 叠加地图因子
            if sub_type == const.BopName.Vehicle:
                w = -1
            else:
                w = 1
            enemy_zone = enemy_zone + enemy_zone * (self.my_ai.my_map.hide_road_array + \
                                                    0.3 * self.my_ai.my_map.only_forest_array + \
                                                    0.1 * self.my_ai.my_map.only_resident_array + \
                                                    w * 0.1 * self.my_ai.my_map.elevation_array)
            enemy_zone = com.apply_temperature(1, enemy_zone)
            return enemy_zone
        elif const.replay_mode == 2:  # 混合估计敌方位置概率
            # time分为单个时间（int）和时间段[start, end]
            if isinstance(time, int):
                time == time // 20 * 20
                # 新出现的棋子，在概率表中没有记录
                if (color, sub_type, serial, time) not in self.replay_pos.index.values.tolist():
                    # print(f'color{color}, sub_type{sub_type}, serial{serial}, time{time} no replays')
                    return np.zeros(self.size)

                replay_pos = self.replay_pos.loc[(color, sub_type, serial, time)].values.reshape(self.size)

                enemy_zone = self.my_ai.enemy_observe_zone.get_be_observed_zone(time)

            elif isinstance(time, list):
                start = time[0] // 20 * 20
                if start < 0:
                    start = 0
                elif start > self.my_ai.game_all_time:
                    start = self.my_ai.game_all_time - 40
                end = time[1] // 20 * 20
                if end < 0:
                    end = start + 40
                if end > self.my_ai.game_all_time:
                    end = self.my_ai.game_all_time
                if start > end:
                    start, end = end, start

                time_list = list(range(start, end + 1, 20))
                # 新出现的棋子，在概率表中没有记录
                if (color, sub_type, serial, start) not in self.replay_pos.index.values.tolist():
                    # print(f'color{color}, sub_type{sub_type}, serial{serial}, time{start} no replays')
                    replay_pos = np.zeros((self.size[0], self.size[1]))
                else:
                    try:
                        replay_pos = self.replay_pos.loc[(color, sub_type, serial, time_list)].values.\
                                        reshape(-1, self.size[0], self.size[1]).max(axis=0)
                    except Exception as e:
                        # print(f'{color, sub_type, serial, time_list}, error in echosentence_color {str(e)}')
                        raise

                enemy_zone = self.my_ai.enemy_observe_zone.get_be_observed_zone(time_list).max(axis=0)

            # 缩小敌方位置概率的范围
            replay_pos = com.apply_temperature(1, replay_pos * self.my_ai.enemy_observe_zone.enemy_all_zone_array)
            replay_pos = com.apply_temperature(1, replay_pos)
            # 叠加地图因子
            if sub_type == const.BopName.Vehicle:
                w = -1
            else:
                w = 1
            enemy_zone = enemy_zone + enemy_zone * (self.my_ai.my_map.hide_road_array + \
                                                    0.3 * self.my_ai.my_map.only_forest_array + \
                                                    0.1 * self.my_ai.my_map.only_resident_array + \
                                                    w * 0.1 * self.my_ai.my_map.elevation_array)
            enemy_zone = com.apply_temperature(1, enemy_zone)

            if self.my_ai.time < 400:
                replay_pos = 0.2 * replay_pos + 0.8 * enemy_zone
            else:
                replay_pos = 0.6 * replay_pos + 0.4 * enemy_zone
            return replay_pos

    # 次函数一般用在我方刚开始比赛时的选点
    # 计算某个点的在某个时间段内的复盘数据攻击度，默认我方具备射击能力,往前推start_time开始计算敌方位置，
    # 在往前推end_time作为记录敌方位置的结束时间
    def replay_observe_attack_time(self, bop, int4_list, front_continue_time, after_continue_time, my_ai, sub_type=None, name=None):
        if not int4_list:
            return []
        if bop['sub_type'] == const.BopName.Tank:
            ubops_record = [ubop_record for ubop_id, ubop_record in my_ai.enemy_predict.ubops_record.items() if
                            ubop_record['live'] and ubop_record['sub_type'] not in ubop_record['sub_type'] not in const.no_calcu_sub_type_tank]
        else:
            ubops_record = [ubop_record for ubop_id, ubop_record in my_ai.enemy_predict.ubops_record.items() if
                            ubop_record['live'] and ubop_record['sub_type'] not in const.no_calcu_sub_type]

        if sub_type:
            ubops_record = [ubop_record for ubop_record in ubops_record if ubop_record['sub_type'] == sub_type]
        if not ubops_record:
            return np.zeros(len(int4_list)), np.zeros(len(int4_list))

        pos_tuple = com.cvtInt4loc2Offset(int4_list)
        maneuver_time = my_ai.see.get_maneuver_time(bop['type'], bop['cur_hex'])[tuple(zip(*pos_tuple))] + my_ai.time
        down_time = maneuver_time - front_continue_time
        up_time = maneuver_time + after_continue_time
        down_time[down_time < 0] = 0
        down_time[down_time > my_ai.game_all_time] = my_ai.game_all_time - 20
        up_time[up_time > my_ai.game_all_time] = my_ai.game_all_time - 2

        attack_ability = []
        observe_ability = []
        for ubop_record in ubops_record:
            sub_type = ubop_record['sub_type']
            serial = ubop_record['serial']
            ubop_pos = []
            for down, up in zip(down_time, up_time):
                time = [down, up]
                replay_pos = self.get_replay_pos(my_ai.enemy_color, sub_type, serial, time)
                ubop_pos.append(replay_pos)

            ubop_pos = np.array(ubop_pos)

            # 计算攻击范围
            shoot_dis = my_ai.damage.get_bop_attack_distance(bop, ubop_record['type'])

            LOS, shoot_LOS = my_ai.see.get_shoot_LOS(common.get_see_source(bop['type']),
                                                    ubop_record['type'], int4_list, shoot_dis, get_LOS=True)
            ##################
            if name == 'attack':
                attack_ability.append((shoot_LOS * ubop_pos).sum(axis=(1, 2)))
            elif name == 'observe':
                observe_ability.append((LOS * ubop_pos).sum(axis=(1, 2)))
            else:
                observe_ability.append((LOS * ubop_pos).sum(axis=(1, 2)))
                attack_ability.append((shoot_LOS * ubop_pos).sum(axis=(1, 2)))
        ##################
        if name =='attack':
            return 0, np.vstack(attack_ability).sum(axis=0)
        elif name == 'observe':
            return np.vstack(observe_ability).sum(axis=0), 0
        else:
            return np.vstack(observe_ability).sum(axis=0), np.vstack(attack_ability).sum(axis=0)

    # 次函数一般用在我方刚开始比赛时的选点
    # 计算某个点某个时间段内的复盘数据被攻击度，默认敌方具备射击能力。maneuver_time - start_time：记录敌方位置开始的时间
    # maneuver_time + end_time作为敌方位置记录的结束时间
    def replay_observed_attacked_time(self, bop, int4_list, front_continue_time, after_continue_time, my_ai, sub_type=None, name=None):
        if not int4_list:
            return []

        if bop['type'] == const.BopType.Aircraft:
            ubops_record = [ubop_record for ubop_id, ubop_record in my_ai.enemy_predict.ubops_record.items() if
                             ubop_record['live'] and ubop_record['sub_type'] not in const.no_calcu_sub_type_air]
        else:
            ubops_record = [ubop_record for ubop_id, ubop_record in my_ai.enemy_predict.ubops_record.items() if
                             ubop_record['live'] and ubop_record['sub_type'] not in const.no_calcu_sub_type]

        if sub_type:
            ubops_record = [ubop_record for ubop_record in ubops_record if ubop_record['sub_type'] == sub_type]
        if not ubops_record:
            return np.zeros(len(int4_list)), np.zeros(len(int4_list))

        pos_tuple = com.cvtInt4loc2Offset(int4_list)
        maneuver_time = my_ai.see.get_maneuver_time(bop['type'], bop['cur_hex'])[tuple(zip(*pos_tuple))] + my_ai.time
        down_time = maneuver_time - front_continue_time
        up_time = maneuver_time + after_continue_time
        down_time[down_time < 0] = 0
        down_time[down_time > my_ai.game_all_time - 20] = my_ai.game_all_time - 22
        up_time[up_time > my_ai.game_all_time] = my_ai.game_all_time - 2

        be_attack_ability = []
        be_observed_ability = []
        for ubop_record in ubops_record:
            sub_type = ubop_record['sub_type']
            serial = ubop_record['serial']
            ubop_pos = []
            for down, up in zip(down_time, up_time):
                time = [down, up]
                replay_pos = self.get_replay_pos(my_ai.enemy_color, sub_type, serial, time)
                ubop_pos.append(replay_pos)

            ubop_pos = np.array(ubop_pos)
            # 计算攻击范围
            if ubop_record['bop_record']:
                ubop_history = ubop_record['bop_record'][-1][1]
            else:
                ubop_history = common.get_bop_sub_type(my_ai.enemy_bops_init_all, ubop_record['sub_type'])[0]
            be_shoot_dis = my_ai.damage.get_bop_attack_distance(ubop_history, bop['type'])

            be_LOS, be_shoot_LOS = my_ai.see.get_be_shoot_LOS(common.get_see_source(ubop_record['type']),
                                                          bop['type'], int4_list, be_shoot_dis, get_be_LOS=True)

            ##################
            if name == 'attack':
                be_attack_ability.append((be_shoot_LOS * ubop_pos).sum(axis=(1, 2)))
            elif name == 'observe':
                be_observed_ability.append(be_LOS * ubop_pos).sum(axis=(1, 2))
            else:
                be_observed_ability.append(be_LOS * ubop_pos).sum(axis=(1, 2))
                be_attack_ability.append((be_shoot_LOS * ubop_pos).sum(axis=(1, 2)))
            ##################
        if name == 'attack':
            return 0, np.vstack(be_attack_ability).sum(axis=0)
        elif name == 'observe':
            return np.vstack(be_observed_ability).sum(axis=0), 0
        else:
            return np.vstack(be_observed_ability).sum(axis=0), np.vstack(be_attack_ability).sum(axis=0)


class EnemyPredict:
    def __init__(self, my_ai):
        self.time = -1
        self.color = my_ai.color
        self.size = my_ai.my_map.size
        self.obop_ids = []
        self.obops_record = {}
        obops_init = my_ai.our_bops_init + my_ai.our_passengers_init
        for obop in obops_init:
            self.init_obops_record(obop)

        self.ubop_ids = []
        self.ubops_record = {}
        ubops_init = my_ai.enemy_bops_init + my_ai.enemy_passengers_init
        for ubop in ubops_init:
            self.init_ubops_record(ubop)
        self.score_record = []
        self.bop_record_length = 6

    def init_obops_record(self, obop):
        # 之前已经初始化，直接返回
        if obop['obj_id'] in self.obop_ids:
            return
        obops_dic = {'live': True,
                     'sub_type': None,
                     'serial': None,
                     'cur_hex': None,
                     'future_hex': None,
                     'bop_record': [],
                     }

        self.obop_ids.append(obop['obj_id'])
        # 找出此新增加类型的编号
        sub_type = obop['sub_type']
        serial = 0
        for obop_id, obop_record in self.obops_record.items():
            if obop_record['sub_type'] == sub_type:
                serial += 1
        self.obops_record[obop['obj_id']] = copy.deepcopy(obops_dic)
        self.obops_record[obop['obj_id']]['sub_type'] = sub_type
        self.obops_record[obop['obj_id']]['serial'] = serial

    def init_ubops_record(self, ubop):
        # 之前已经初始化，直接返回
        if ubop['obj_id'] in self.ubop_ids:
            return
        ubops_dic = {'live': True,
                     'blood': None,
                     'be_see': False,
                     'type': None,
                     'sub_type': None,
                     'serial': None,
                     'time': 0,
                     'guiding': False,
                     'shoot_ability': 0.5,
                     'can_shoot_time': 0,
                     'bop_record': [],
                     'pos_predict': None,
                     }
        self.ubop_ids.append(ubop['obj_id'])
        # 找出此新增加类型的编号
        sub_type = ubop['sub_type']
        serial = 0
        for ubop_id, ubop_record in self.ubops_record.items():
            if ubop_record['sub_type'] == sub_type:
                serial += 1

        self.ubops_record[ubop['obj_id']] = copy.deepcopy(ubops_dic)
        self.ubops_record[ubop['obj_id']]['type'] = ubop['type']
        self.ubops_record[ubop['obj_id']]['sub_type'] = sub_type
        self.ubops_record[ubop['obj_id']]['serial'] = serial
        self.ubops_record[ubop['obj_id']]['blood'] = ubop['blood']
        data = np.zeros(self.size)
        row, col = com.cvtInt4loc2Offset(ubop['cur_hex'])
        data[row, col] = 1
        self.ubops_record[ubop['obj_id']]['pos_predict'] = data

    def update(self, my_ai):
        # while my_ai.time < my_ai.game_all_time - 10:
        if self.time < my_ai.time:
            self.time = my_ai.time
            for obop in my_ai.our_bops:
                self.init_obops_record(obop)
            for ubop in my_ai.enemy_bops:
                self.init_ubops_record(ubop)

            self.update_obops_record(my_ai)
            self.update_ubops_record(my_ai)
            self.score_record.append(my_ai.score)
        #     else:
        #         time.sleep(0.01)
        # return

    def update_obops_record(self, my_ai):
        for obop_id, obop_record in self.obops_record.items():
            if obop_record['live'] == False:
                continue

            obop = common.get_bop_obj_id(my_ai.our_bops, obop_id)
            if obop:
                self.pop_bop_record(self.obops_record[obop_id]['bop_record'], obop, my_ai.time)
                self.obops_record[obop_id]['cur_hex'] = obop['cur_hex']

    def pop_bop_record(self, bop_record, bop, time):
        if bop_record is []:
            bop_record.append([time, bop])
        elif len(bop_record) < self.bop_record_length:
            bop_record.append([time, bop])
        elif bop_record[-2][0] < time - 20:
            bop_record.pop(0)
            bop_record.append([time, bop])
        else:
            bop_record.pop()
            bop_record.append([time, bop])

    def update_ubops_record(self, my_ai):
        ### 从可见敌方棋子信息中更新敌情，从可见敌方历史信息中更新敌情，从我方观察范围中更新敌情
        for ubop_id, ubop_record in self.ubops_record.items():
            # # 算子死亡不更新
            # if ubop_record['live'] == False:
            #     continue

            ubop = common.get_bop_obj_id(my_ai.enemy_bops, ubop_id)
            if ubop:
                self.update_ubop_see(ubop, my_ai)
            elif ubop_record['bop_record']:
                self.update_ubop_history(ubop_id, ubop_record, my_ai)
                self.update_ubop_our_see(ubop_id, ubop_record, my_ai, no_record=False)
            else:
                self.update_ubop_our_see(ubop_id, ubop_record, my_ai, no_record=True)

        ## 从裁决信息中更新敌情
        if my_ai.judge_info:
            self.update_judge_info(my_ai.judge_info, my_ai)

        ### 从夺控点颜色变化更新敌情信息

    def update_future_hex(self, obop_id, future_hex, my_ai):
        obop = common.get_bop_obj_id(my_ai.our_bops, obop_id)
        if obop:
            self.obops_record[obop_id]['future_hex'] = future_hex

    # 根据敌方可见算子更新敌情记录
    def update_ubop_see(self, ubop, my_ai):
        self.ubops_record[ubop['obj_id']]['live'] = True
        self.ubops_record[ubop['obj_id']]['be_see'] = True
        self.ubops_record[ubop['obj_id']]['time'] = my_ai.time
        self.ubops_record[ubop['obj_id']]['blood'] = ubop['blood']
        if ubop['sub_type'] == const.BopName.Tank:
            if ubop['change_state_remain_time'] > 20:
                self.ubops_record[ubop['obj_id']]['shoot_ability'] = 0
                if self.ubops_record[ubop['obj_id']]['can_shoot_time'] == 0:
                    self.ubops_record[ubop['obj_id']]['can_shoot_time'] = my_ai.time
            if ubop['weapon_cool_time'] <= 20:
                self.ubops_record[ubop['obj_id']]['shoot_ability'] = 1
                self.ubops_record[ubop['obj_id']]['can_shoot_time'] = 0
            else:
                self.ubops_record[ubop['obj_id']]['shoot_ability'] = 0
                if self.ubops_record[ubop['obj_id']]['can_shoot_time'] == 0:
                    self.ubops_record[ubop['obj_id']]['can_shoot_time'] = my_ai.time
        elif ubop['sub_type'] == const.BopName.Missile:
            self.ubops_record[ubop['obj_id']]['shoot_ability'] = 1
            self.ubops_record[ubop['obj_id']]['can_shoot_time'] = 0
        else:
            if ubop['change_state_remain_time'] > 20:
                self.ubops_record[ubop['obj_id']]['shoot_ability'] = 0
                if self.ubops_record[ubop['obj_id']]['can_shoot_time'] == 0:
                    self.ubops_record[ubop['obj_id']]['can_shoot_time'] = my_ai.time
            elif ubop['get_on_remain_time'] > 20 or ubop['get_off_remain_time'] > 20:
                self.ubops_record[ubop['obj_id']]['shoot_ability'] = 0
                if self.ubops_record[ubop['obj_id']]['can_shoot_time'] == 0:
                    self.ubops_record[ubop['obj_id']]['can_shoot_time'] = my_ai.time
            if ubop["move_to_stop_remain_time"] > 20:
                self.ubops_record[ubop['obj_id']]['shoot_ability'] = 0
                if self.ubops_record[ubop['obj_id']]['can_shoot_time'] == 0:
                    self.ubops_record[ubop['obj_id']]['can_shoot_time'] = my_ai.time
            elif ubop['sub_type'] == const.BopName.Soldier and ubop["keep_remain_time"] > 20:
                self.ubops_record[ubop['obj_id']]['shoot_ability'] = 0
                if self.ubops_record[ubop['obj_id']]['can_shoot_time'] == 0:
                    self.ubops_record[ubop['obj_id']]['can_shoot_time'] = my_ai.time + 75
            else:
                self.ubops_record[ubop['obj_id']]['shoot_ability'] = 1
                self.ubops_record[ubop['obj_id']]['can_shoot_time'] = 0

        if not self.ubops_record[ubop['obj_id']]['bop_record']:
            data = np.zeros((my_ai.my_map.size[0], my_ai.my_map.size[1]))
            row, col = com.cvtInt4loc2Offset(ubop['cur_hex'])
            data[row, col] = 1
            self.ubops_record[ubop['obj_id']]['pos_predict'] = data

        elif self.ubops_record[ubop['obj_id']]['bop_record'][-1][1]['cur_hex'] != ubop['cur_hex']:
            data = np.zeros((my_ai.my_map.size[0], my_ai.my_map.size[1]))
            row, col = com.cvtInt4loc2Offset(ubop['cur_hex'])
            data[row, col] = 1
            self.ubops_record[ubop['obj_id']]['pos_predict'] = data

        self.pop_bop_record(self.ubops_record[ubop['obj_id']]['bop_record'], ubop, my_ai.time)

    def update_ubop_history(self, ubop_id, ubop_record, my_ai):
        self.ubops_record[ubop_id]['be_see'] = False
        self.ubops_record[ubop_id]['time'] = my_ai.time

        time_history = ubop_record['bop_record'][-1][0]
        ubop_history = ubop_record['bop_record'][-1][1]

        if ubop_record['shoot_ability'] == 0:
            if my_ai.time - ubop_record['can_shoot_time'] >= 55:
                self.ubops_record[ubop_id]['shoot_ability'] = 0.8
                self.ubops_record[ubop_id]['can_shoot_time'] = 0
        else:
            if my_ai.time - time_history >= 55:
                self.ubops_record[ubop_id]['shoot_ability'] = 0.8
                self.ubops_record[ubop_id]['can_shoot_time'] = 0
        if my_ai.time - time_history >= 75:
            move_time = my_ai.time - time_history
            if move_time % 10 == 0 and move_time <= 200:
                self.ubop_move_range(ubop_record['sub_type'], ubop_record['serial'], ubop_history, move_time, my_ai)
            elif move_time % 10 == 0:
                time_temp = my_ai.time // 20 * 20
                self.ubops_record[ubop_id]['pos_predict'] = my_ai.replay_pos.get_replay_pos(ubop_history['color'],
                                                                                            ubop_record['sub_type'],
                                                                                            ubop_record['serial'],
                                                                                            time_temp)

    def update_ubop_our_see(self, ubop_id, ubop_record, my_ai, no_record=True):
        if my_ai.time % 10 != 0:
            return
        # 之前没有记录过这个敌方棋子
        if no_record:
            self.ubops_record[ubop_id]['be_see'] = False
            self.ubops_record[ubop_id]['time'] = my_ai.time

            self.ubops_record[ubop_id]['shoot_ability'] = 0.8
            self.ubops_record[ubop_id]['can_shoot_time'] = 0

            time = my_ai.time // 20 * 20
            pos_predict = my_ai.replay_pos.get_replay_pos(my_ai.enemy_color, ubop_record['sub_type'],
                                                          ubop_record['serial'], time)

        else:
            # 直接引用update_ubop_history(self, ubop_id, ubop_record, my_ai)已经更新之后的结果
            pos_predict = copy.deepcopy(self.ubops_record[ubop_id]['pos_predict'])

        if ubop_record['bop_record']:
            if ubop_record['bop_record'][-1][0] > my_ai.time - 200:
                # 对位置预测叠加目前观察情况, 只考虑当前同时情况
                for bop in my_ai.our_bops:
                    if bop['sub_type'] == const.BopName.Missile or bop['sub_type'] == const.BopName.UAV:
                        round_tuple = BoundedHex(bop['cur_hex']).arc([0, 5], 2, origin=True)
                        pos_predict[tuple(zip(*round_tuple))] = 0
                    else:
                        bop_LOS = my_ai.see.get_see_LOS(common.get_see_source(bop['type']),
                                                        common.subtype_to_type(ubop_record['sub_type']), bop['cur_hex'])
                        pos_predict[bop_LOS == True] = 0
        else:
            for obj_id, obop_dict in self.obops_record.items():
                for time, bop in obop_dict['bop_record']:
                    if time > my_ai.time - 300:
                        if bop['sub_type'] == const.BopName.Missile or bop['sub_type'] == const.BopName.UAV:
                            round_tuple = BoundedHex(bop['cur_hex']).arc([0, 5], 2, origin=True)
                            pos_predict[tuple(zip(*round_tuple))] = 0
                        else:
                            bop_LOS = my_ai.see.get_see_LOS(common.get_see_source(bop['type']),
                                                            common.subtype_to_type(ubop_record['sub_type']),
                                                            bop['cur_hex'])
                            pos_predict[bop_LOS == True] = 0
        self.ubops_record[ubop_id]['pos_predict'] = com.apply_temperature(1, pos_predict)

    def get_bop_record(self, obj_id):
        for id, bop_record in self.ubops_record.items():
            if id == obj_id:
                return bop_record
        for id, bop_record in self.obops_record.items():
            if id == obj_id:
                return bop_record

    def update_judge_info(self, judge_info, my_ai):
        for judge in judge_info:
            att_obj_id = judge['att_obj_id']
            target_obj_id = judge['target_obj_id']
            distance = judge['distance']
            damage = judge['damage']
            att_record = self.get_bop_record(att_obj_id)
            target_record = self.get_bop_record(target_obj_id)
            if not att_record or not target_record:
                continue

            if target_obj_id not in self.obop_ids:
                # 如果我方是巡飞弹，则巡飞弹死亡
                if att_record['sub_type'] == const.BopName.Missile:
                    att_record['live'] = False
                if len(target_record['bop_record']) >= 1:
                    ubop_history = target_record['bop_record'][-1][1]
                else:
                    ubop_history = common.get_bop_obj_id(my_ai.enemy_bops_init_all, target_obj_id)

                # 敌方棋子列表中看不到被攻击棋子，说明该棋子已经死亡
                if target_obj_id not in [ubop['obj_id'] for ubop in my_ai.enemy_bops]:
                    # if ubop_history['blood'] <= damage or ubop_history['blood'] <= 1:
                    target_record['live'] = False
                    target_record['blood'] = 0
                    target_record['be_see'] = False
                    target_record['time'] = my_ai.time
                    target_record['shoot_ability'] = 0
                    target_record['pos_predict'] = np.zeros(self.size)
                    for id in ubop_history['passenger_ids']:
                        self.ubops_record[id]['live'] = False
                        self.ubops_record[id]['blood'] = 0
                        self.ubops_record[id]['be_see'] = False
                        self.ubops_record[id]['time'] = my_ai.time
                        self.ubops_record[id]['shoot_ability'] = 0
                        self.ubops_record[id]['pos_predict'] = np.zeros(
                            (my_ai.my_map.size[0], my_ai.my_map.size[1]))
                    # 被攻击棋子没死
                else:
                    # 查找有无乘客
                    for passenger_id in ubop_history['passenger_ids']:
                        self.ubops_record[passenger_id]['blood'] -= damage
                        self.ubops_record[passenger_id]['time'] = my_ai.time
                        if self.ubops_record[passenger_id]['blood'] <= 0:
                            self.ubops_record[passenger_id]['live'] = False
            # 我方被敌方攻击
            else:
                # 我方棋子列表中没有该棋子，说明该棋子已经死亡
                if target_obj_id not in [obop['obj_id'] for obop in my_ai.our_bops]:
                    target_record['live'] = False
                    target_record['blood'] = 0
                    target_record['pos_predict'] = np.zeros(
                        (my_ai.my_map.size[0], my_ai.my_map.size[1]))
                    if len(target_record['bop_record']) >= 1:
                        obop_history = target_record['bop_record'][-1][1]
                    else:
                        obop_history = common.get_bop_obj_id(my_ai.our_bops_init_all, target_obj_id)
                    for id in obop_history['passenger_ids']:
                        if id < len(self.obops_record):
                            self.obops_record[id]['live'] = False
                            self.obops_record[id]['blood'] = 0

                att_record['time'] = my_ai.time
                att_record['shoot_ability'] = 0
                att_record['can_shoot_time'] = my_ai.time
                if 'guide_obj_id' in judge.keys():
                    if len(target_record['bop_record']) >= 1:
                        obop_history = target_record['bop_record'][-1][1]
                    else:
                        obop_history = common.get_bop_obj_id(my_ai.our_bops_init_all, target_obj_id)

                    if len(att_record['bop_record']) >= 1:
                        ubop_history = att_record['bop_record'][-1][1]
                    else:
                        ubop_history = common.get_bop_obj_id(my_ai.enemy_bops_init_all, att_obj_id)
                    ##更新引导者基本信息
                    guide_obj_id = judge['guide_obj_id']
                    if guide_obj_id in self.ubop_ids:
                        self.ubops_record[guide_obj_id]['shoot_ability'] = 0
                        self.ubops_record[guide_obj_id]['can_shoot_time'] = my_ai.time

                    ##更新被引导者位置信息
                    att_record['guiding'] = my_ai.time
                    if not att_record['be_see']:
                        obop_pos_tuple = com.cvtInt4loc2Offset(obop_history['cur_hex'])
                        enemy_arc = BoundedHex(*obop_pos_tuple).arc_line(dir=[0, 5], dis=distance)
                        enemy_arc_ele = [pos for pos in enemy_arc if
                                         my_ai.my_map.get_ele_diff(pos, obop_pos_tuple) == judge['ele_diff']]

                        enemy_arc_ele_maneuver_see = [pos for pos in enemy_arc_ele if
                                                      not self.in_my_see(pos, const.BopType.Vehicle, my_ai)]

                        data = np.zeros((my_ai.my_map.size[0], my_ai.my_map.size[1]))
                        data[tuple(zip(*enemy_arc_ele_maneuver_see))] = 1

                        time = my_ai.time // 20 * 20
                        replay_pos = my_ai.replay_pos.get_replay_pos(ubop_history['color'],
                                                                     att_record['sub_type'],
                                                                     att_record['serial'],
                                                                     time)

                        att_record['pos_predict'] = com.apply_temperature(1, data * replay_pos)



    def is_be_guide_shoot(self, bop, my_ai):
        judge_info = my_ai.judge_info
        for judge in judge_info:
            att_obj_id = judge['att_obj_id']
            target_obj_id = judge['target_obj_id']
            if att_obj_id not in self.obop_ids and bop['obj_id'] == target_obj_id:
                if 'guide_obj_id' in judge.keys():
                    return True
            return False

    @staticmethod
    def in_my_see(ubop_pos_tuple, ubop_type, my_ai):
        for obop in my_ai.our_bops:
            bop_LOS = my_ai.see.get_see_LOS(common.get_see_source(obop['type']),
                                            ubop_type, obop['cur_hex'])
            if bop_LOS[ubop_pos_tuple] == 1:
                return True
        return False

    def ubop_move_range(self, sub_type, serial, ubop, move_time, my_ai):
        maneuver_time = my_ai.see.get_maneuver_time(ubop['type'], ubop['cur_hex'])
        if ubop['sub_type'] == const.BopName.Soldier:
            maneuver_time = maneuver_time * 2
        rows, cols = np.where(maneuver_time <= move_time)

        time = my_ai.time // 20 * 20
        # 新出现的棋子，在概率表中没有记录
        if (ubop['color'], sub_type, serial, time) not in my_ai.replay_pos.replay_pos.index.values.tolist():
            replay_pos = np.zeros(self.size)
        else:
            replay_pos = my_ai.replay_pos.replay_pos.loc[(ubop['color'], sub_type, serial, time)].values.reshape(
                self.size)
        data = np.zeros((my_ai.my_map.size[0], my_ai.my_map.size[1]))
        row, col = com.cvtInt4loc2Offset(ubop['cur_hex'])
        data[rows, cols] = replay_pos[rows, cols]
        data[row, col] = 1
        if ubop['sub_type'] == const.BopName.Soldier or ubop['sub_type'] == const.BopName.Vehicle:
            self.ubops_record[ubop['obj_id']]['pos_predict'] = com.apply_temperature(1, data)
        else:
            self.ubops_record[ubop['obj_id']]['pos_predict'] = com.apply_temperature(.5, data)

    def get_attribute_array(self, bop, my_ai, attri_name, ubop_type=None):
        if not my_ai.attack_value:
            bop_around = my_ai.hex_cache.get_circle(bop['cur_hex'], 0, const.calcu_dis)
            bop_around_int4 = com.cvtOffset2Int4loc(bop_around)
            return list(zip(bop_around_int4, np.zeros(len(bop_around_int4))))
        elif bop['obj_id'] not in list(my_ai.attack_value.keys()):
            bop_around = my_ai.hex_cache.get_circle(bop['cur_hex'], 0, const.calcu_dis)
            bop_around_int4 = com.cvtOffset2Int4loc(bop_around)
            return list(zip(bop_around_int4, np.zeros(len(bop_around_int4))))

        if ubop_type == const.BopType.Infantry:
            return my_ai.attack_value[bop['obj_id']][attri_name + '_soldier']


        elif ubop_type == const.BopType.Vehicle:
            return my_ai.attack_value[bop['obj_id']][attri_name + '_vehicle']

        elif ubop_type == const.BopType.Aircraft:
            return my_ai.attack_value[bop['obj_id']][attri_name + '_Aircraft']

        else:
            attri_soldier = my_ai.attack_value[bop['obj_id']][attri_name + '_soldier']
            attri_vehicle = my_ai.attack_value[bop['obj_id']][attri_name + '_soldier']
            position_soldier, value_soldier = zip(*attri_soldier)
            position_vehicle, value_vehicle = zip(*attri_vehicle)
            if attri_name == 'attack_ability':
                return list(zip(position_soldier, max(value_soldier, value_vehicle)))
            else:
                return list(zip(position_soldier, np.array(value_soldier) + np.array(value_vehicle)))

    # 计算列表内点的被攻击度，
    def be_attacked_ability(self, bop, int4_list, my_ai, ubop_type=None):
        if not int4_list:
            return []
        elif not my_ai.attack_value:
            return np.array([0] * len(int4_list))
        elif bop['obj_id'] not in list(my_ai.attack_value.keys()):
            return np.array([0] * len(int4_list))
        else:
            result = dict(zip(int4_list, [0] * len(int4_list)))

        if ubop_type == const.BopType.Infantry:
            be_shoot_ability = my_ai.attack_value[bop['obj_id']]['be_attacked_value_soldier']
            be_shoot_ability = dict(be_shoot_ability)
            for int4 in int4_list:
                if int4 in be_shoot_ability.keys():
                    result[int4] = be_shoot_ability[int4]

        elif ubop_type == const.BopType.Vehicle:
            be_shoot_ability = my_ai.attack_value[bop['obj_id']]['be_attacked_value_vehicle']
            be_shoot_ability = dict(be_shoot_ability)
            for int4 in int4_list:
                if int4 in be_shoot_ability.keys():
                    result[int4] = be_shoot_ability[int4]

        elif ubop_type == const.BopType.Aircraft:
            be_shoot_ability = my_ai.attack_value[bop['obj_id']]['be_attacked_value_Aircraft']
            be_shoot_ability = dict(be_shoot_ability)
            for int4 in int4_list:
                if int4 in be_shoot_ability.keys():
                    result[int4] = be_shoot_ability[int4]

        else:
            be_shoot_ability_soldier = my_ai.attack_value[bop['obj_id']]['be_attacked_value_soldier']
            be_shoot_ability_vehicle = my_ai.attack_value[bop['obj_id']]['be_attacked_value_vehicle']
            be_shoot_ability_soldier = dict(be_shoot_ability_soldier)
            be_shoot_ability_vehicle = dict(be_shoot_ability_vehicle)
            for int4 in int4_list:
                if int4 in be_shoot_ability_soldier.keys():
                    result[int4] = be_shoot_ability_soldier[int4] + be_shoot_ability_vehicle[int4]
        return np.array(list(result.values()))

    # 计算某个点的攻击度，短时间内的计算，
    def attack_ability(self, bop, int4_list, my_ai, ubop_type=None):
        if not int4_list:
            return []
        elif not my_ai.attack_value:
            return np.array([0] * len(int4_list))
        elif bop['obj_id'] not in list(my_ai.attack_value.keys()):
            return np.array([0] * len(int4_list))
        else:
            result = dict(zip(int4_list, [0] * len(int4_list)))
        if ubop_type == const.BopType.Infantry:
            shoot_ability = my_ai.attack_value[bop['obj_id']]['attack_ability_soldier']
            shoot_ability = dict(shoot_ability)
            for int4 in int4_list:
                if int4 in shoot_ability.keys():
                    result[int4] = shoot_ability[int4]

        elif ubop_type == const.BopType.Vehicle:
            shoot_ability = my_ai.attack_value[bop['obj_id']]['attack_ability_vehicle']
            shoot_ability = dict(shoot_ability)
            for int4 in int4_list:
                if int4 in shoot_ability.keys():
                    result[int4] = shoot_ability[int4]
        else:
            shoot_ability_soldier = my_ai.attack_value[bop['obj_id']]['attack_ability_soldier']
            shoot_ability_vehicle = my_ai.attack_value[bop['obj_id']]['attack_ability_vehicle']
            shoot_ability_soldier = dict(shoot_ability_soldier)
            shoot_ability_vehicle = dict(shoot_ability_vehicle)
            for int4 in int4_list:
                if int4 in shoot_ability_soldier.keys():
                    result[int4] = max(shoot_ability_soldier[int4], shoot_ability_vehicle[int4])
        return np.array(list(result.values()))

    # 计算单个敌方棋子的攻击度与被攻击度比值
    def attack_proportion(self, bop, int4_list, my_ai):
        if not int4_list:
            return []
        be_attacked_ability = self.be_attacked_ability(bop, int4_list, my_ai)
        attacked_ability = self.attack_ability(bop, int4_list, my_ai)
        attack_proportion = (attacked_ability + 1e-05) * (attacked_ability + 1e-05) / (be_attacked_ability + 1e-05)
        attack_proportion = attack_proportion
        return attack_proportion

    def observe_enemy_ability(self, bop, int4_list, my_ai, ubop_type=None):
        if not int4_list:
            return []
        elif not my_ai.attack_value:
            return np.array([0] * len(int4_list))
        elif bop['obj_id'] not in list(my_ai.attack_value.keys()):
            return np.array([0] * len(int4_list))
        else:
            result = dict(zip(int4_list, [0] * len(int4_list)))
        if ubop_type == const.BopType.Infantry:
            observe_ability = my_ai.attack_value[bop['obj_id']]['observe_ability_soldier']
            observe_ability = dict(observe_ability)
            for int4 in int4_list:
                if int4 in observe_ability.keys():
                    result[int4] = observe_ability[int4]

        elif ubop_type == const.BopType.Vehicle:
            observe_ability = my_ai.attack_value[bop['obj_id']]['observe_ability_vehicle']
            observe_ability = dict(observe_ability)
            for int4 in int4_list:
                if int4 in observe_ability.keys():
                    result[int4] = observe_ability[int4]
        else:
            observe_ability_soldier = my_ai.attack_value[bop['obj_id']]['observe_ability_soldier']
            observe_ability_vehicle = my_ai.attack_value[bop['obj_id']]['observe_ability_vehicle']
            observe_ability_soldier = dict(observe_ability_soldier)
            observe_ability_vehicle = dict(observe_ability_vehicle)
            for int4 in int4_list:
                if int4 in observe_ability_soldier.keys():
                    result[int4] = observe_ability_soldier[int4] + observe_ability_vehicle[int4]
        return np.array(list(result.values()))

    def be_observed_enemy_ability(self, bop, int4_list, my_ai, ubop_type=None):
        if not int4_list:
            return []
        elif not my_ai.attack_value:
            return np.array([0] * len(int4_list))
        elif bop['obj_id'] not in list(my_ai.attack_value.keys()):
            return np.array([0] * len(int4_list))
        else:
            result = dict(zip(int4_list, [0] * len(int4_list)))
        if ubop_type == const.BopType.Infantry:
            be_observe_ability = my_ai.attack_value[bop['obj_id']]['be_observed_value_soldier']
            be_observe_ability = dict(be_observe_ability)
            for int4 in int4_list:
                if int4 in be_observe_ability.keys():
                    result[int4] = be_observe_ability[int4]

        elif ubop_type == const.BopType.Vehicle:
            be_observe_ability = my_ai.attack_value[bop['obj_id']]['be_observed_value_vehicle']
            be_observe_ability = dict(be_observe_ability)
            for int4 in int4_list:
                if int4 in be_observe_ability.keys():
                    result[int4] = be_observe_ability[int4]
        else:
            be_observe_ability_soldier = my_ai.attack_value[bop['obj_id']]['be_observed_value_soldier']
            be_observe_ability_vehicle = my_ai.attack_value[bop['obj_id']]['be_observed_value_vehicle']
            be_observe_ability_soldier = dict(be_observe_ability_soldier)
            be_observe_ability_vehicle = dict(be_observe_ability_vehicle)
            for int4 in int4_list:
                if int4 in be_observe_ability_soldier.keys():
                    result[int4] = be_observe_ability_soldier[int4] + be_observe_ability_vehicle[int4]
        return np.array(list(result.values()))

    # 敌方位置概率和
    def enemy_predict_sum(self, my_ai, sub_type=None):
        if not sub_type:
            ubops_record = [ubop_record for ubop_id, ubop_record in self.ubops_record.items() if
                            ubop_record['live'] and ubop_record['sub_type'] != const.BopName.Missile]
        else:
            ubops_record = [ubop_record for ubop_id, ubop_record in self.ubops_record.items() if
                            ubop_record['live'] and ubop_record['sub_type'] == sub_type]

        ubop_pos = np.zeros(my_ai.my_map.size)
        for ubop_record in ubops_record:
            ubop_pos += ubop_record['pos_predict']
        return ubop_pos

    def strength_compare(self, my_ai):
        if my_ai.color == const.Color.RED:
            total = my_ai.score['red_remain'] + my_ai.score['blue_attack']
            remain = my_ai.score['red_remain']

            e_total = my_ai.score['blue_remain'] + my_ai.score['red_attack']
            e_remain = my_ai.score['blue_remain']
        else:
            total = my_ai.score['blue_remain'] + my_ai.score['red_attack']
            remain = my_ai.score['blue_remain']

            e_total = my_ai.score['red_remain'] + my_ai.score['blue_attack']
            e_remain = my_ai.score['red_remain']

        strength_compare = ((remain + 1e-5) / total) / ((e_remain + 1e-5) / e_total)
        return strength_compare

    def score_compare(self, my_ai):
        if my_ai.color == const.Color.RED:
            total = my_ai.score['red_remain'] + my_ai.score['red_attack']

            e_total = my_ai.score['blue_remain'] + my_ai.score['blue_attack']
        else:
            total = my_ai.score['blue_remain'] + my_ai.score['blue_attack']

            e_total = my_ai.score['red_remain'] + my_ai.score['red_attack']

        for city in my_ai.observation['cities']:
            if city['flag'] == my_ai.color:
                total += city['value']
            else:
                e_total += city['value']
        score_compare = (total + 1e-5) / (e_total + 1e-5)
        return score_compare
