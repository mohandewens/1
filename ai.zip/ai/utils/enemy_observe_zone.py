from . import const, common
from ..hexmap import common as com
from ..hexmap.hex import BoundedHex
import numpy as np
import random



class EnemyObserveZone:
    def __init__(self, my_ai):
        self.size = my_ai.my_map.size

        # 找到敌方距离最远的两个车辆棋子
        ubops_Vehicle = common.get_bop_type(my_ai.enemy_bops_init, const.BopType.Vehicle)
        dis = []
        for ubop1 in ubops_Vehicle:
            for ubop2 in ubops_Vehicle:
                distance = com.get_distance(ubop1['cur_hex'], ubop2['cur_hex'])
                dis.append([distance, ubop1, ubop2])
        dis = sorted(dis, key=lambda x: x[0])
        ubop1 = dis[-1][1]
        ubop2 = dis[-1][2]

       # 找到距敌最近的一个夺控点
        dis_city = []
        for city_temp in my_ai.cities_init:
            for ubop in [ubop1, ubop2]:
                distance = com.get_distance(ubop['cur_hex'], city_temp['coord'])
                dis_city.append([distance, city_temp])
        dis_city = sorted(dis_city, key=lambda x: x[0])
        city = dis_city[0][1]

        #计算基准时间，即敌坦克到达主要攻击点 且增加2格的时间
        e_main_attack_tuple = com.cvtInt4loc2Offset(city['coord'])
        e_main_attack_time = my_ai.see.get_maneuver_time(ubop1['type'], ubop1['cur_hex'])[e_main_attack_tuple] + 80
        # e_main_attack_length = com.get_distance(ubop1['cur_hex'], city['coord'])

        self.continued_time = 250
        self.main_time = e_main_attack_time
        self.hexes_to_city = self.get_line_hex_to_occupy(ubop1, ubop2, city)
        self.enemy_all_zone_array = np.zeros((self.size[0], self.size[1]))
        rows, cols = zip(*self.hexes_to_city)
        self.enemy_all_zone_array[rows, cols] = 1

        enemy_tank_zone = {}
        for time in range(0, e_main_attack_time+10, 20):
            enemy_tank_zone[time] = {}
            enemy_tank_zone[time]['observe'] = self.observe_zone(ubop1, time, my_ai)
            enemy_tank_zone[time]['be_observed'] = self.be_observed_zone(ubop1, time, my_ai)
        self.enemy_tank_zone = enemy_tank_zone
        # 敌飞行器观察区域和被观察区域
        center_time = list(range(int(self.main_time * 2 / 3), int(self.main_time), 20))
        middle_time = list(range(int(self.main_time * 1 / 3), int(self.main_time * 2 / 3), 20))
        # self.center_zone = self.get_observe_zone(20)
        self.middle_zone = self.get_observe_zone(middle_time)

        # from . import util
        # for time in range(0, 600, 20):
        #     self.center_zone = self.get_observe_zone(time)
        #     rows, cols = np.where( self.center_zone==1)
        #     postion_list = list(zip(rows, cols))
        #
        #     util.plot_hex(postion_list, 53, see_int4=None, blend_level=0.9, text=[])
        # pass

    def get_observe_zone(self, time):
        if isinstance(time, list):
            time_steps = (np.array(time) // 20 * 20).tolist()
            zone_np = np.zeros((len(time_steps),self.size[0], self.size[1]), dtype=int)
            for i, time_step in enumerate(time_steps):
                if time_step > self.main_time:
                    time_step = self.main_time

                index_tuple_list = self.enemy_tank_zone[time_step]['observe']
                rows, cols = zip(*index_tuple_list)
                zone_np[i, rows, cols] = 1
            return zone_np
        else:
            time_step = time // 20 * 20
            if time_step > self.main_time:
                time_step = self.main_time
            zone_np = np.zeros(self.size, dtype=int)
            index_tuple_list = self.enemy_tank_zone[time_step]['observe']
            zone_np[tuple(zip(*index_tuple_list))] = 1
            return zone_np

    def get_be_observed_zone(self, time):
        if isinstance(time, list):
            time_steps = (np.array(time) // 20 * 20).tolist()
            zone_np = np.zeros((len(time_steps), self.size[0], self.size[1]), dtype=int)
            for i, time_step in enumerate(time_steps):
                if time_step > self.main_time:
                    time_step = self.main_time

                index_tuple_list = self.enemy_tank_zone[time_step]['be_observed']
                rows, cols = zip(*index_tuple_list)
                zone_np[i, rows, cols] = 1
            return zone_np
        else:
            time_step = time // 20 * 20
            if time_step > self.main_time:
                time_step = self.main_time
            zone_np = np.zeros(self.size, dtype=int)
            index_tuple_list = self.enemy_tank_zone[time_step]['be_observed']
            zone_np[tuple(zip(*index_tuple_list))] = 1
            return zone_np

    # 计算观察区域，给定敌方棋子的，和机动时间长度，未来敌方可能出现的区域
    def observe_zone(self, ubop, time, my_ai):
        hexes_to_city = self.hexes_to_city
        maneuver_time = my_ai.see.get_maneuver_time(ubop['type'], ubop['cur_hex'])

        if time > self.main_time - self.continued_time:
            time = self.main_time - self.continued_time

        up_rows, up_cols = np.where(maneuver_time >= time)
        down_rows, down_cols = np.where(maneuver_time <= time + self.continued_time)

        hexes_time = list(set(zip(up_rows, up_cols)) & set(zip(down_rows, down_cols)))
        return list(set(hexes_to_city) & set(hexes_time))

    # 计算观察区域，给定敌方棋子的，和机动时间长度，给出敌方可能出现的区域
    def be_observed_zone(self, ubop, time, my_ai):
        hexes_to_city = self.hexes_to_city
        maneuver_time = my_ai.see.get_maneuver_time(ubop['type'], ubop['cur_hex'])

        if time > self.main_time:
            time = self.main_time

        up_rows, up_cols = np.where(maneuver_time >= time - self.continued_time)
        down_rows, down_cols = np.where(maneuver_time <= time)

        hexes_time = list(set(zip(up_rows, up_cols)) & set(zip(down_rows, down_cols)))

        return list(set(hexes_to_city) & set(hexes_time))

    @staticmethod
    def get_angel_hex_to_occupy(int4, cities):
        city_main = common.get_city_name(cities, value=80)
        city_second = common.get_city_name(cities, value=50)
        side_main = BoundedHex(int4).occupy_to(BoundedHex(city_main['coord']))
        side_second = BoundedHex(int4).occupy_to(BoundedHex(city_second['coord']))
        # print('-----',side_main, side_second)
        dis_main = com.get_distance(int4, city_main['coord'])
        dis_second = com.get_distance(int4, city_second['coord'])
        # dis_main_second = com.get_distance(city_main['coord'], city_second['coord'])
        dis = max(dis_second, dis_main) + 2
        # print(pos, side_main, side_second)
        if max(side_main) > max(side_second):
            if max(side_main) - min(side_second) == 3:
                side_hexes = BoundedHex(int4).arc([0, 5], dis, origin=True)
            elif max(side_main) - min(side_second) < 3:
                side_hexes = BoundedHex(int4).arc([min(side_second), max(side_main)], dis, origin=True)
            else:
                side_hexes = BoundedHex(int4).arc([max(side_main), min(side_second)], dis, origin=True)
        else:
            if max(side_main) - min(side_second) == 3:
                side_hexes = BoundedHex(int4).arc([0, 5], dis, origin=True)
            elif max(side_second) - min(side_main) < 3:
                side_hexes = BoundedHex(int4).arc([min(side_main), max(side_second)], dis, origin=True)
            else:
                side_hexes = BoundedHex(int4).arc([max(side_second), min(side_main)], dis, origin=True)
        result = []
        for pos in side_hexes:
            start_origin = com.get_distance(pos, int4)
            start_main = com.get_distance(pos, city_main['coord'])
            start_second = com.get_distance(pos, city_second['coord'])
            if start_origin + start_main <= dis_main + 1 or start_origin + start_second <= dis_second + 1:
                result.append(pos)
        return result

    @staticmethod
    def get_line_hex_to_occupy(ubop1, ubop2, city):
        """
        确定敌方活动区域，敌方两个棋子分别与夺控点连线，在连线上画原，最终形成的并集
        """
        lines_cities = []
        center_city = BoundedHex(city['coord']).arc(dir=[0, 5], dis=5, origin=True)

        line_city_ubop1 = BoundedHex(ubop1['cur_hex']).line(BoundedHex(city['coord']))
        line_city_ubop2 = BoundedHex(ubop2['cur_hex']).line(BoundedHex(city['coord']))
        for (row, col) in line_city_ubop1[5:-3:3]:
            circle = BoundedHex(row, col).arc(dir=[0, 5], dis=7, origin=True)
            lines_cities.extend(circle)
        for (row, col) in line_city_ubop2[5:-3:3]:
            circle = BoundedHex(row, col).arc(dir=[0, 5], dis=7, origin=True)
            lines_cities.extend(circle)

        result = list(set(center_city) | set(lines_cities))
        return result

    @staticmethod
    def get_farest_city(city1, cities):
        dis = []
        for city in cities:
            dis_city = com.get_distance(city1['coord'], city['coord'])
            dis.append([dis_city, city])
        dis = sorted(dis, key=lambda x: x[0])
        return dis[-1][1]
