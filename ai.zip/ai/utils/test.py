# import random
#
# for i in range(20):
#     x = random.randint(0,5)
#     print(x)
#
# y = 10
# z = [10]
#
# print(z)
import random

x = {}
a = {2:[123]}
b = {1:[234,456]}
x.update(a)
x.update(b)
print(x)