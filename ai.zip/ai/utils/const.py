"""Constants used in DemoAgent.

It is a part of DemoAgent's policy and is not necessary in your code.
You can change these names in your own policy.
"""


class BopName:
    Tank, Vehicle, Soldier, Artillery, UnmannedVehicle, UAV, Helicopter, Missile,YSHelicopter,ScoutVehicle = range(0, 10)

    @classmethod
    def get_name(self, value):
        new_dict = {v: k for k, v in self.__dict__.items()}
        return (new_dict[value])


class BopType:
    Infantry, Vehicle, Aircraft = range(1, 4)

    @classmethod
    def get_name(self, value):
        new_dict = {v: k for k, v in self.__dict__.items()}
        return (new_dict[value])


class ActionType:
    Move, Shoot, GetOn, GetOff, Occupy, ChangeState, RemoveKeep, \
    JMPlan, GuideShoot, StopMove, WeaponLock, WeaponUnFold, CancelJMPlan, Fork, Union, = range(1, 16)

    @classmethod
    def get_name(self, value):
        new_dict = {v: k for k, v in self.__dict__.items()}
        return (new_dict[value])


class MoveType:
    Maneuver, March, Walk, Fly = range(4)

    @classmethod
    def get_name(self, value):
        new_dict = {v: k for k, v in self.__dict__.items()}
        return (new_dict[value])


class Color:
    RED, BLUE, GREEN = 0, 1, -1

    @classmethod
    def get_name(self, value):
        new_dict = {v: k for k, v in self.__dict__.items()}
        return (new_dict[value])


class SeeMode:
    GroundToGround, SkyToSky, SkyToGround = range(0, 3)
    GroundToSky = SkyToGround

    @classmethod
    def get_name(self, value):
        new_dict = {v: k for k, v in self.__dict__.items()}
        return (new_dict[value])


class SeeSource:
    FromGround, FromSky = range(2)


class StateMode:
    Maneuver, March, Rush_level_one, Rush_level_two, Hide = range(0, 5)

    @classmethod
    def get_name(self, value):
        new_dict = {v: k for k, v in self.__dict__.items()}
        return (new_dict[value])


top_num = 3  # 选点时备选点前多少个
select = 1  # 选几个点
beta = 3  # 非线性转换超参数，接近0相当于平均随机，接近无穷大相当于选取概率最大值
damage_num = 5  # 有多个射击目标时，模拟射击多少次，以选择最终射击目标
calcu_dis = 7  # 并行计算属性时，计算棋子周边多少格
no_calcu_sub_type = [BopName.Artillery, BopName.Missile]
no_calcu_sub_type_tank = [BopName.Artillery, BopName.Missile, BopName.UAV, BopName.Helicopter]

no_calcu_sub_type_air = [BopName.Artillery, BopName.Missile, BopName.UAV, BopName.Tank]
no_hide_sub_type = [BopName.Artillery, BopName.Missile, BopName.UAV, BopName.Helicopter]
no_guide_sub_type = [BopName.Soldier, BopName.Artillery, BopName.Missile, BopName.UAV, BopName.Helicopter]
company_game_time = 1800
group_game_time = 2880
aircraft_safe_value = 0.09

# 设置是否使用基于复盘数据的敌方位置概率
replay_mode = 2  # 0:不使用混，即使用区域信息， 1：使用， 2：综合，即使用位置概率和区域信息

if __name__ == '__main__':
    s = SeeMode()

    if not hasattr(s, 'veicle_off_point'):
        print('1111')
