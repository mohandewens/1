'''
状态机设计参考https://blog.csdn.net/StoryMonster/article/details/99443480https://blog.csdn.net/StoryMonster/article/details/99443480
'''
'''
红方状态转换：
状态一：‘放飞无人战车或者巡飞弹’RedFirstOff
条件：战车在起始点，战车上载有无人战车或者巡飞弹，满足下车条件RedFirstOffEvent
动作：放飞无人战车或者巡飞弹
完成：我方棋子列表存在无人战车和巡飞弹，且战车在起始点RedFirstOffOver
'''

from .FSM import *
from ..utils import common, const, util
from . import state, event
from . import red_action_bop

class RedFSM(FSM):
    def __init__(self, my_ai):
        super().__init__(state.GameStart(self, my_ai))
        bops_init = my_ai.our_bops_init + my_ai.our_passengers_init
        self.action_bops = []
        self.obj_id_record = []
        for bop in bops_init:
            self.init_action_bop(bop)
        self.events = []
        # if my_ai.scenario == 2010131194 or my_ai.scenario == 2010141294:
        #     self.add_transaction(state.GameStart, event.HideEvent, state.HideAttack)
        #     self.add_transaction(state.GameStart, event.NoHideEvent, state.NearAttack)
        #     self.add_transaction(state.HideAttack, event.LessEnemyEvent, state.NearAttack)
        #     self.add_transaction(state.NearAttack, event.NearOverEvent, state.Occupying)
        #     self.events.append(event.HideEvent())
        #     self.events.append(event.NoHideEvent())
        #     self.events.append(event.LessEnemyEvent())
        #     self.events.append(event.NearOverEvent())
        # elif my_ai.scenario == 2010211129:  # 连级山地通道夺控战斗想定
        #     self.add_transaction(state.GameStart, event.GameStartEvent, state.RedFarAttack)
        #     self.add_transaction(state.RedFarAttack, event.RedTimeNoEnemyEvent, state.RedMiddleFarAttack)
        #     self.add_transaction(state.RedMiddleFarAttack, event.RedLessEnemyEvent, state.RedOccupyingMain)
        #     self.add_transaction(state.RedOccupyingMain, event.RedTimeLessEnemyEvent, state.RedOccupyingSecond)
        #     self.events.append(event.GameStartEvent())
        #     self.events.append(event.RedTimeNoEnemyEvent())
        #     self.events.append(event.RedLessEnemyEvent())
        #     self.events.append(event.RedTimeLessEnemyEvent())
        # if my_ai.scenario == 2010431153:  # 连级水网稻田战斗想定
        #     self.add_transaction(state.GameStart, event.GameStartEvent, state.DTRedFarAttack)
        #     self.add_transaction(state.DTRedFarAttack, event.DTRedTimeNoEnemyEvent, state.DTRedMiddleFarAttack)
        #     self.add_transaction(state.DTRedMiddleFarAttack, event.DTRedLessEnemyEvent, state.DTRedOccupyingMain)
        #     self.events.append(event.GameStartEvent())
        #     self.events.append(event.DTRedTimeNoEnemyEvent())
        #     self.events.append(event.DTRedLessEnemyEvent())
        if my_ai.scenario == 2201010201:  #
            self.add_transaction(state.GameStart, event.GameStartEvent, state.HRRedFarAttack)
            self.add_transaction(state.HRRedFarAttack, event.HRRedMiddleEvent, state.HRRedMiddleFarAttack)
            self.add_transaction(state.HRRedMiddleFarAttack, event.HRRedOccpuyEvent, state.HRRedOccupyingMain)
            self.events.append(event.GameStartEvent())
            self.events.append(event.HRRedMiddleEvent())
            self.events.append(event.HRRedOccpuyEvent())
        if my_ai.scenario == 2201010101:  #
            self.add_transaction(state.GameStart, event.GameStartEvent, state.HRRedFarAttack)
            self.add_transaction(state.HRRedFarAttack, event.HRRedMiddleEvent, state.HRRedMiddleFarAttack)
            self.add_transaction(state.HRRedMiddleFarAttack, event.HRRedOccpuyEvent, state.HRRedOccupyingMain)
            self.events.append(event.GameStartEvent())
            self.events.append(event.HRRedMiddleEvent())
            self.events.append(event.HRRedOccpuyEvent())
        if my_ai.scenario == 20220102013:  # human_agent_mixed_city_town_resident战斗想定
            self.add_transaction(state.GameStart, event.GameStartEvent, state.HRRedFarAttack)
            self.add_transaction(state.HRRedFarAttack, event.HRRedMiddleEvent, state.HRRedMiddleFarAttack)
            self.add_transaction(state.HRRedMiddleFarAttack, event.HRRedOccpuyEvent, state.HRRedOccupyingMain)
            self.events.append(event.GameStartEvent())
            self.events.append(event.HRRedMiddleEvent())
            self.events.append(event.HRRedOccpuyEvent())
        if my_ai.scenario == 2201010202:  # human_agent_mixed_city_town_resident战斗想定
            self.add_transaction(state.GameStart, event.GameStartEvent, state.HRRedFarAttack)
            self.add_transaction(state.HRRedFarAttack, event.HRRedMiddleEvent, state.HRRedMiddleFarAttack)
            self.add_transaction(state.HRRedMiddleFarAttack, event.HRRedOccpuyEvent, state.HRRedOccupyingMain)
            self.events.append(event.GameStartEvent())
            self.events.append(event.HRRedMiddleEvent())
            self.events.append(event.HRRedOccpuyEvent())
        # elif my_ai.scenario == 2010441253:  # 连级水网稻田战斗想定
        #     self.add_transaction(state.GameStart, event.GameStartEvent, state.DT2RedFarAttack)
        #     self.add_transaction(state.DT2RedFarAttack, event.DT2RedTimeNoEnemyEvent, state.DT2RedMiddleFarAttack)
        #     self.add_transaction(state.DT2RedMiddleFarAttack, event.DT2RedLessEnemyEvent, state.DT2RedOccupyingMain)
        #     self.events.append(event.GameStartEvent())
        #     self.events.append(event.DT2RedTimeNoEnemyEvent())
        #     self.events.append(event.DT2RedLessEnemyEvent())
        #
        # else:
        #     self.add_transaction(state.GameStart, event.GameStartEvent, state.RedMoveAttack)
        #     self.add_transaction(state.RedMoveAttack, event.RedGatheringEvent, state.RedGathering)
        #     self.add_transaction(state.RedGathering, event.RedOccupyingEvent, state.RedOccupying)
        #     self.events.append(event.GameStartEvent())
        #     self.events.append(event.RedGatheringEvent())
        #     self.events.append(event.RedOccupyingEvent())
        self.add_global_transaction(event.GameOverEvent, state.ExitFSM)
        self.events.append(event.GameOverEvent())
        self.run(my_ai)

    def init_action_bop(self, bop):
        action_bop_dic = {const.BopName.Vehicle: red_action_bop.RedVehicle,
                          const.BopName.Missile: red_action_bop.RedMissile,
                          const.BopName.UnmannedVehicle: red_action_bop.RedUnmannedVehicle,
                          const.BopName.Soldier: red_action_bop.RedSoldier,
                          const.BopName.Tank: red_action_bop.RedTank,
                          const.BopName.Artillery: red_action_bop.RedArtillery,
                          const.BopName.UAV: red_action_bop.RedUAV,
                          const.BopName.ScoutVehicle: red_action_bop.RedScoutVehicle,
                          }

        if bop['obj_id'] in self.obj_id_record:
            return
        serial = 0
        for action_bop in self.action_bops:
            if bop['sub_type'] == action_bop.sub_type:
                serial += 1

        action_bop = action_bop_dic[bop['sub_type']](bop, serial_number=serial)
        self.action_bops.append(action_bop)
        self.obj_id_record.append(bop['obj_id'])

    def action(self, my_ai):
        if self.isRunning():

            for obop in my_ai.our_bops:
                self.init_action_bop(obop)
            events = self.get_event(my_ai)
            if events:
                for event in events:
                    self.process_event(event, self, my_ai)
                total_actions = self.run(my_ai)
            else:
                total_actions = self.run(my_ai)
            # if total_actions:
            #     print(
            #         "the time is {}, {} start, the total actions are ".format(my_ai.observation['time']['cur_step'],
            #                                                                   self.current_state.name), total_actions)
            #     for ubop_id, ubop_record in my_ai.enemy_predict.ubops_record.items():
                    # if ubop_record['live']:
                    # print(ubop_record['live'], ubop_record['sub_type'], ubop_record['blood'])
                #     util.plot_hot_map(ubop_record['pos_predict'])
            return total_actions
        else:
            # print('游戏结束，状态机停止')
            return list()


    def get_event(self, my_ai):
        events = []
        for event in self.events:
            if event.can_do(self, my_ai):
                events.append(event)

        return events













