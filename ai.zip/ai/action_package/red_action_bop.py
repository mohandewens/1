from .action_bop import *
import copy
import random

class RedVehicle(Vehicle):

    def __init__(self, bop, serial_number=0, group=0):
        super(RedVehicle, self).__init__()
        assert self.sub_type == bop['sub_type']
        self.obj_id = bop['obj_id']
        self.serial_number = serial_number
        self.group = group
        self.caninto = 0
        self.move_point = -1

        self.near_off = False
    '''红方战车行进到下车点并且人员下车
       战车下车点要求：
       1.敌方坦克射击范围外(暂时不实现)
       2.此点隐蔽性高，即夺控点方向被观察度低
       3.下车点3格内有人员观察点
       4.离出发点近
       '''
    def far_attack(self, my_ai, action_bops):
        vehicle = self.get_bop(my_ai)
        if vehicle:
            if not hasattr(self, 'first_attack_point'):
                self.first_attack_point = self.get_first_far_point(vehicle, my_ai,
                                                                   my_ai.attack_point['o_main_attack'], center_dis=[10, 15], bop_dis=[0, 10])
            action = self.shoot(vehicle, my_ai)
            if action:
                return action
            if vehicle['cur_hex'] != self.first_attack_point:
                action = self.move(vehicle, self.first_attack_point, my_ai)
                if action:
                    return action
            if my_ai.time > 800:
                if not self.see_enemy(vehicle) and self.can_move(vehicle, my_ai) and self.wait_time <= 0:
                    second_attack_point = self.get_second_far_point(vehicle, my_ai, my_ai.attack_point['o_second_attack'], main_dis=[15, 25], bop_dis=[0, 4])
                    if second_attack_point == vehicle['cur_hex']:
                        self.wait_time = 80
                    kwargs = {'beta': 1.5,
                              'hide_cond': 0.3,
                              'shoot_ability': 0,
                              'be_shoot_ability': 1,
                              'be_shoot_ability_aircraft': 0,
                              'observe_enemy_ability': 0,
                              'be_observed_enemy_ability': 0.5}
                    action = self.hide_move(vehicle, second_attack_point, my_ai, danger_stop=True, danger_value=0.3, **kwargs)
                    if action:
                        return action
                    else:
                        self.wait_time = 40
            action = self.hide(vehicle, my_ai)
            if action:
                return action
            self.wait_time -= 1
        return None

    def DTMoveAttack(self, my_ai, action_bops):
        vehicle = self.get_bop(my_ai)

        if vehicle:
            if not vehicle["launch_ids"]:
                return self.far_attack(my_ai, action_bops)
            if my_ai.time < 30:
                init_pos = common.get_init_pos(vehicle, my_ai.our_bops_init_all)
                if vehicle['cur_hex'] == init_pos:
                    if not self.have_passenger_number(my_ai, vehicle, sub_type=const.BopName.Soldier):
                        if self.have_passenger_number(my_ai, vehicle, sub_type=const.BopName.Missile):
                            action = self.passenger_off(vehicle, my_ai)
                            if action:
                                return action
                            else:
                                return list()

            action = self.shoot(vehicle, my_ai)
            if action:
                return action

            if not hasattr(self, 'off_point'):
                self.off_move = False
                self.off_point = self.get_off_point(vehicle, my_ai, my_ai.attack_point['o_main_attack'], center_dis=[5, 10], bop_dis=[0, 17])
                #print(f'红方下车位置:{self.off_point}')
            if not self.off_move:
                kwargs = {  'beta': 1.5,
                            'hide_cond': 0,
                            'shoot_ability': 0,
                            'be_shoot_ability': 1,
                            'be_shoot_ability_aircraft': 0,
                            'observe_enemy_ability': 0,
                            'be_observed_enemy_ability': 1}

                action = self.hide_move(vehicle, self.off_point, my_ai, number=15, danger_stop=True, danger_value=0.8, **kwargs)
                if action:
                    print(action)
                    self.off_move = True
                    return action

            enemy_tanks = common.get_bop_sub_type_under_see(my_ai.enemy_bops, const.BopName.Tank, vehicle['see_enemy_bop_ids'])
            if enemy_tanks:
                return self.vehicle_move_hide(vehicle, my_ai)

            guide_call = self.get_guide_call(vehicle, my_ai, action_bops)
            if my_ai.time > 150:
                if guide_call:
                    for ubop in guide_call:
                        shoot_dis = my_ai.damage.get_bop_attack_distance(vehicle, ubop['type'])
                        if com.get_distance(vehicle['cur_hex'], ubop['cur_hex']) <= shoot_dis and vehicle['remain_bullet_nums'][100]:
                            if not self.see_enemy(vehicle):
                            # if not hasattr(self, 'stop_command'):
                            #     self.stop_command = True
                            # if self.stop_command:
                            #     self.stop_command = False
                                return self.stop(vehicle, my_ai)
                            # else:
                            #     return self.vehicle_move_hide(vehicle, my_ai)

            if my_ai.time > 100:
                if self.have_passenger_number(my_ai, vehicle):
                    action = self.passenger_off(vehicle, my_ai)
                    if action:
                        return action

            action = self.occupy(vehicle, my_ai)
            if action:
                return action
            action = self.hide(vehicle, my_ai)
            if action:
                return action
        return None

    def DT2MoveAttack(self, my_ai, action_bops, main_dis=[13, 16], bop_dis=[5,11]):
        vehicle = self.get_bop(my_ai)
        if vehicle:
            init_pos = common.get_init_pos(vehicle, my_ai.our_bops_init_all)
            if vehicle['cur_hex'] == init_pos:
                if not self.have_passenger_number(my_ai, vehicle, sub_type=const.BopName.Soldier):
                    if self.have_passenger_number(my_ai, vehicle, sub_type=const.BopName.Missile):
                        action = self.passenger_off(vehicle, my_ai)
                        if action:
                            return action
                        else:
                            return list()

            action = self.shoot(vehicle, my_ai)
            if action:
                return action

            if not hasattr(self, 'far_guide_point'):
                self.far_guide_move = False
                self.far_hide_move = False
                self.far_guide_point = self.DT2get_far_guide_point(vehicle, my_ai, my_ai.attack_point['o_main_attack'], center_dis=main_dis, bop_dis=bop_dis)
            if not self.far_guide_move:
                action = self.move(vehicle, self.far_guide_point, my_ai)
                if action:
                    return action
                if vehicle['cur_hex'] == self.far_guide_point:
                    self.far_guide_move = True

            if not self.far_hide_move and not self.have_passenger_number(my_ai, vehicle, sub_type=const.BopName.Soldier):
                if not hasattr(self, 'far_hide_point'):
                    self.far_hide_point = self.DT2get_far_hide_point(vehicle, my_ai, my_ai.attack_point['o_main_attack'], bop_dis=[3,4])
                action = self.move(vehicle, self.far_hide_point, my_ai)
                if action:
                    return action
                if vehicle['cur_hex'] == self.far_hide_point:
                    self.far_hide_move = True

            enemy_tanks = common.get_bop_sub_type_under_see(my_ai.enemy_bops, const.BopName.Tank, vehicle['see_enemy_bop_ids'])
            if enemy_tanks:
                return self.vehicle_move_hide(vehicle, my_ai)

            guide_call = self.get_guide_call(vehicle, my_ai, action_bops)
            if guide_call:
                for ubop in guide_call:
                    shoot_dis = my_ai.damage.get_bop_attack_distance(vehicle, ubop['type'])
                    if com.get_distance(vehicle['cur_hex'], ubop['cur_hex']) <= shoot_dis and vehicle['remain_bullet_nums'][100]:
                        action = self.stop(vehicle, my_ai)
                        if action:
                            return action
                        else:
                            return None

            if self.have_passenger_number(my_ai, vehicle):
                action = self.passenger_off(vehicle, my_ai)
                if action:
                    return action

            action = self.occupy(vehicle, my_ai)
            if action:
                return action
        return None


    def DTFarAttack(self, my_ai, action_bops):
        return self.DTMoveAttack(my_ai, action_bops)

    def DT2FarAttack(self, my_ai, action_bops):
        return self.DT2MoveAttack(my_ai, action_bops, main_dis=[3, 3], bop_dis=[7,8])

    def MiddleFarAttack(self, my_ai, action_bops):
        return self.MoveAttack(my_ai, action_bops)

    def DTMiddleFarAttack(self, my_ai, action_bops):
        return self.DTMoveAttack(my_ai, action_bops)

    def DT2MiddleFarAttack(self, my_ai, action_bops):
        return self.DT2MoveAttack(my_ai, action_bops, main_dis=[3, 3], bop_dis=[7, 8])

    def OccupyingMain(self, my_ai, action_bops):
        vehicle = self.get_bop(my_ai)
        if vehicle:
            action = self.shoot(vehicle, my_ai)
            if action:
                return action

            if not common.my_city(my_ai.observation['cities'], my_ai.color, coord=my_ai.attack_point['o_main_attack']):
                action = self.occupy(vehicle, my_ai)
                if action:
                    return action

                if vehicle['cur_hex'] != my_ai.attack_point['o_main_attack']:
                    if common.can_move(vehicle, my_ai):
                        bop_int4 = self.occupy_move(vehicle, my_ai, my_ai.attack_point['o_main_attack'])
                        action = self.move(vehicle, bop_int4, my_ai)
                        if action:
                            return action
            else:
                if not self.see_enemy(vehicle):
                    action = self.occupy(vehicle, my_ai)
                    if action:
                        return action
                    if common.can_move(vehicle, my_ai):
                        if my_ai.time // 20 == 0:
                            bop_int4 = self.occupy_protect(vehicle, my_ai, my_ai.attack_point['o_main_attack'])

                            action = self.move(vehicle, bop_int4, my_ai)
                            if action:
                                return action

            if not common.my_city(my_ai.observation['cities'], my_ai.color, coord=my_ai.attack_point['e_main_attack']):
                action = self.occupy(vehicle, my_ai)
                if action:
                    return action

                if vehicle['cur_hex'] != my_ai.attack_point['e_main_attack']:
                    if common.can_move(vehicle, my_ai):
                        bop_int4 = self.occupy_move(vehicle, my_ai, my_ai.attack_point['e_main_attack'])
                        action = self.move(vehicle, bop_int4, my_ai)
                        if action:
                            return action
            else:
                if not self.see_enemy(vehicle):
                    action = self.occupy(vehicle, my_ai)
                    if action:
                        return action
                    if common.can_move(vehicle, my_ai):
                        if my_ai.time // 20 == 0:
                            bop_int4 = self.occupy_protect(vehicle, my_ai, my_ai.attack_point['e_main_attack'])

                            action = self.move(vehicle, bop_int4, my_ai)
                            if action:
                                return action
        return None

    def HRFarAttack(self, my_ai, action_bops):
        return self.newpolicy(my_ai)
        vehicle = self.get_bop(my_ai)
        if vehicle:
            # if my_ai.time < 30:
            #     if self.have_passenger_number(my_ai, vehicle, sub_type=const.BopName.Missile):
            #         action = self.passenger_off(vehicle, my_ai,sub_type=const.BopName.Missile)
            #         if action:
            #             return action
            if vehicle['obj_id'] != 15 and my_ai.hidevehicle == 0:
                my_ai.hidevehicle = vehicle['obj_id']
            if vehicle['obj_id'] == my_ai.hidevehicle:
                return self.OccupyingMain(my_ai,action_bops)
                # action = self.fork(vehicle, my_ai)
                # if action:
                #     return action
            pos_main1 = 3641
            pos_main2 = 2138
            hide_point1 = 3344
            hide_point2 = 2138
            if not hasattr(self, 'veicle_off_point'):
                pos_start = vehicle['cur_hex']
                pos_main1 = 3641
                pos_main2 = 2138
                # hexes = my_ai.hex_cache.get_circle(pos_main, 1, 1)
                # hexes_start = ai_group.hex_cache.get_circle(pos_start, 3, 10)
                # intersection_hexes = list(set(hexes_main) & set(hexes_start))
                # kwargs = {'be_observed_ability': 1,
                #           'maneuver_time': 3,
                #           'maneuver_time_main': .5,
                #           'hide_cond': 0.5,
                #           'stack': .5,
                #           'observe_enemy_ability': 0}
                #self.veicle_off_point = self.get_key_point(my_ai, vehicle, pos_main, hexes, kwargs)
                #print('veicle_off_point:', self.veicle_off_point)
                if vehicle['obj_id'] != 15:
                    self.veicle_off_point = pos_main1
                else:
                    self.veicle_off_point = pos_main2

            action = self.shoot(vehicle, my_ai)
            if action:
                return action
            if self.veicle_off_point == pos_main1:
                if self.have_passenger_number(my_ai, vehicle,sub_type=const.BopName.Soldier) and vehicle['cur_hex'] != self.veicle_off_point:
                    action = self.move(vehicle, self.veicle_off_point, my_ai)
                    if action:
                        return action
                elif self.have_passenger_number(my_ai, vehicle,sub_type=const.BopName.Soldier):
                    action = self.passenger_off(vehicle, my_ai,sub_type=const.BopName.Soldier)
                    if action:
                        return action

                if not self.have_passenger_number(my_ai, vehicle,sub_type=const.BopName.Soldier) and self.have_passenger_number(my_ai, vehicle, sub_type=const.BopName.Missile):
                    action = self.passenger_off(vehicle, my_ai,sub_type=const.BopName.Missile)
                    if action:
                        return action
                if not self.have_passenger_number(my_ai, vehicle,sub_type=const.BopName.Soldier):
                    action = self.hide(vehicle, my_ai)
                    if action:
                        return action
                if not self.have_passenger_number(my_ai,vehicle) and not hasattr(self, 'hide_point'):
                    if vehicle['cur_hex'] == pos_main1:
                        hide_point = hide_point1
                    else:
                        hide_point = hide_point2
                    self.hide_point = self.get_first_far_point(vehicle, my_ai,hide_point,center_dis=[0, 1], bop_dis=[0, 20])

                if not self.have_passenger_number(my_ai,vehicle) and  hasattr(self, 'hide_point') and vehicle['cur_hex'] != self.hide_point:
                    action = self.move(vehicle, self.hide_point, my_ai)
                    if action:
                        return action

                if self.can_move(vehicle,my_ai):
                    bops = my_ai.observation['operators']
                    for bop in bops:
                        if bop['color'] != my_ai.color and bop['sub_type'] == const.BopName.UAV:
                            dis = com.get_distance(bop['cur_hex'],vehicle['cur_hex'])
                            if dis <= 2:
                                self.hide_point = self.get_first_far_point(vehicle, my_ai, vehicle['cur_hex'],center_dis=[1, 2], bop_dis=[0, 20])
                                action = self.move(vehicle, self.hide_point, my_ai)
                                if action:
                                    return action

                action = self.hide(vehicle,my_ai)
                if action:
                    return action
            else:
                if self.have_passenger_number(my_ai, vehicle, sub_type=const.BopName.Missile) and vehicle['cur_hex'] != self.veicle_off_point:
                    action = self.move(vehicle, self.veicle_off_point, my_ai)
                    if action:
                        return action
                elif self.have_passenger_number(my_ai, vehicle, sub_type=const.BopName.Missile):
                    action = self.passenger_off(vehicle, my_ai, sub_type=const.BopName.Missile)
                    if action:
                        return action

                if not self.have_passenger_number(my_ai, vehicle,sub_type=const.BopName.Missile) and self.have_passenger_number(my_ai,vehicle,sub_type=const.BopName.Soldier):
                    action = self.passenger_off(vehicle, my_ai, sub_type=const.BopName.Soldier)
                    if action:
                        return action
                if not self.have_passenger_number(my_ai, vehicle, sub_type=const.BopName.Missile):
                    action = self.hide(vehicle, my_ai)
                    if action:
                        return action
                if not self.have_passenger_number(my_ai, vehicle) and not hasattr(self, 'hide_point'):
                    if vehicle['cur_hex'] == pos_main1:
                        hide_point = hide_point1
                    else:
                        hide_point = hide_point2
                    self.hide_point = self.get_first_far_point(vehicle, my_ai, hide_point, center_dis=[0, 1],
                                                               bop_dis=[0, 20])

                if not self.have_passenger_number(my_ai, vehicle) and hasattr(self, 'hide_point') and vehicle['cur_hex'] != self.hide_point:
                    action = self.move(vehicle, self.hide_point, my_ai)
                    if action:
                        return action

                # if self.can_move(vehicle,my_ai):
                #     bops = my_ai.observation['operators']
                #     for bop in bops:
                #         if bop['color'] != my_ai.color and bop['sub_type'] == const.BopName.UAV:
                #             dis = com.get_distance(bop['cur_hex'],vehicle['cur_hex'])
                #             if dis <= 2:
                #                 self.hide_point = self.get_first_far_point(vehicle, my_ai, vehicle['cur_hex'],center_dis=[1, 2], bop_dis=[0, 20])
                #                 action = self.move(vehicle, self.hide_point, my_ai)
                #                 if action:
                #                     return action


                action = self.hide(vehicle, my_ai)
                if action:
                    return action
        return None

    def HRMiddleFarAttack(self, my_ai, action_bops):
        return self.newpolicy(my_ai)
        if my_ai.time < 1000:
            return self.HRFarAttack(my_ai,action_bops)
        vehicle = self.get_bop(my_ai)
        if vehicle:
            if vehicle['obj_id'] != 15 and vehicle['obj_id'] != my_ai.hidevehicle:
                return self.OccupyingMain(my_ai, action_bops)
            # if not vehicle["launch_ids"]:
            #     return self.far_attack(my_ai, action_bops)
            action = self.shoot(vehicle, my_ai)
            if action:
                return action

            if not hasattr(self, 'observe_point'):
                pos_start = vehicle['cur_hex']
                pos_main = my_ai.attack_point['o_main_attack']
                hexes_start = my_ai.hex_cache.get_circle(pos_start, 1, 3)

                kwargs = {'observed_second': 1,
                          'maneuver_time': 1,
                          'maneuver_time_main': .5,
                          'hide_cond': 2,
                          'stack': .8,
                          'shoot_ability': 1.5}
                self.observe_point = self.get_key_point(my_ai, vehicle, pos_main, hexes_start, kwargs)
                # print('observe_point:', self.observe_point)
                # action = self.hide_move(vehicle, self.off_point, my_ai, number=15, danger_stop=True, danger_value=0.8,
                #                     **kwargs)
                action = self.move(vehicle, self.observe_point, my_ai)
                if action:
                    return action

            enemy_tanks = common.get_bop_sub_type_under_see(my_ai.enemy_bops, const.BopName.Tank, vehicle['see_enemy_bop_ids'])
            if enemy_tanks:
                return self.vehicle_move_hide(vehicle, my_ai)

            guide_call = self.get_guide_call(vehicle, my_ai, action_bops)
            if my_ai.time > 150:
                if guide_call:
                    for ubop in guide_call:
                        shoot_dis = my_ai.damage.get_bop_attack_distance(vehicle, ubop['type'])
                        if com.get_distance(vehicle['cur_hex'], ubop['cur_hex']) <= shoot_dis and vehicle['remain_bullet_nums'][100]:
                            if not self.see_enemy(vehicle):
                                return self.stop(vehicle, my_ai)
            action = self.occupy(vehicle, my_ai)
            if action:
                return action

            # if self.can_move(vehicle, my_ai):
            #     bops = my_ai.observation['operators']
            #     for bop in bops:
            #         if bop['color'] != my_ai.color and bop['sub_type'] == const.BopName.UAV:
            #             dis = com.get_distance(bop['cur_hex'], vehicle['cur_hex'])
            #             if dis <= 2:
            #                 self.hide_point = self.get_first_far_point(vehicle, my_ai, vehicle['cur_hex'],
            #                                                            center_dis=[1, 2], bop_dis=[0, 20])
            #                 action = self.move(vehicle, self.hide_point, my_ai)
            #                 if action:
            #                     return action

            action = self.hide(vehicle, my_ai)
            if action:
                return action
        return None

    def HROccupying(self, my_ai, action_bops):
        return self.newpolicy(my_ai)
        if my_ai.time < 1500:
            return self.HRMiddleFarAttack(my_ai,action_bops)
        vehicle = self.get_bop(my_ai)
        if vehicle:
            if vehicle['obj_id'] != 15 and vehicle['obj_id'] != my_ai.hidevehicle:
                return self.OccupyingMain(my_ai, action_bops)
            action = self.shoot(vehicle, my_ai)
            if action:
                return action

            if not common.my_city(my_ai.observation['cities'], my_ai.color, coord=my_ai.attack_point['o_main_attack']):
                action = self.occupy(vehicle, my_ai)
                if action:
                    return action

                if vehicle['cur_hex'] != my_ai.attack_point['o_main_attack']:
                    if common.can_move(vehicle, my_ai):
                        bop_int4 = self.occupy_move(vehicle, my_ai, my_ai.attack_point['o_main_attack'])
                        action = self.move(vehicle, bop_int4, my_ai)
                        if action:
                            return action
            else:
                if not self.see_enemy(vehicle):
                    action = self.occupy(vehicle, my_ai)
                    if action:
                        return action
                    if common.can_move(vehicle, my_ai):
                        if my_ai.time // 20 == 0:
                            bop_int4 = self.occupy_protect(vehicle, my_ai, my_ai.attack_point['o_main_attack'])

                            action = self.move(vehicle, bop_int4, my_ai)
                            if action:
                                return action

            if not common.my_city(my_ai.observation['cities'], my_ai.color, coord=my_ai.attack_point['e_main_attack']):
                action = self.occupy(vehicle, my_ai)
                if action:
                    return action

                if vehicle['cur_hex'] != my_ai.attack_point['e_main_attack']:
                    if common.can_move(vehicle, my_ai):
                        bop_int4 = self.occupy_move(vehicle, my_ai, my_ai.attack_point['e_main_attack'])
                        action = self.move(vehicle, bop_int4, my_ai)
                        if action:
                            return action
            else:
                if not self.see_enemy(vehicle):
                    action = self.occupy(vehicle, my_ai)
                    if action:
                        return action
                    if common.can_move(vehicle, my_ai):
                        if my_ai.time // 20 == 0:
                            bop_int4 = self.occupy_protect(vehicle, my_ai, my_ai.attack_point['e_main_attack'])

                            action = self.move(vehicle, bop_int4, my_ai)
                            if action:
                                return action

            # if self.can_move(vehicle, my_ai):
            #     bops = my_ai.observation['operators']
            #     for bop in bops:
            #         if bop['color'] != my_ai.color and bop['sub_type'] == const.BopName.UAV:
            #             dis = com.get_distance(bop['cur_hex'], vehicle['cur_hex'])
            #             if dis <= 2:
            #                 self.hide_point = self.get_first_far_point(vehicle, my_ai, vehicle['cur_hex'],
            #                                                            center_dis=[1, 2], bop_dis=[0, 20])
            #                 action = self.move(vehicle, self.hide_point, my_ai)
            #                 if action:
            #                     return action

        return None

    # def newpolicy(self,my_ai):
    #     vehicle = self.get_bop(my_ai)
    #     if vehicle:
    #         action = self.shoot(vehicle, my_ai)
    #         if action:
    #             return action
    #         if self.have_passenger_number(my_ai, vehicle, sub_type=const.BopName.Missile):
    #             action = self.passenger_off(vehicle, my_ai,sub_type=const.BopName.Missile)
    #             if action:
    #                 return action
    #         if not hasattr(self, 'first_move'):
    #             if vehicle["obj_id"] == 64:
    #                 first_move = 2141
    #             elif vehicle["obj_id"] == 66:
    #                 first_move = 3642
    #             elif vehicle["obj_id"] == 100:
    #                 first_move = 3143
    #             else:
    #                 first_move = 3330
    #             if (vehicle['cur_hex'] != first_move) and self.caninto == 0:
    #                 action = self.move(vehicle, first_move, my_ai)
    #                 if action:
    #                     self.first_move = first_move
    #                     return action
    #         if hasattr(self, 'first_move'):
    #             if vehicle['cur_hex'] == self.first_move and self.have_passenger_number(my_ai, vehicle,sub_type=const.BopName.Soldier):
    #                 action = self.passenger_off(vehicle, my_ai,sub_type=const.BopName.Soldier)
    #                 if action:
    #                     return action
    #         if not self.have_passenger_number(my_ai, vehicle) and self.caninto == 0:
    #             action = self.hide(vehicle,my_ai)
    #             if action:
    #                 self.caninto = 1
    #                 return action
    #         if not self.have_passenger_number(my_ai, vehicle) and self.caninto == 1:
    #             return self.into_hunter(my_ai, vehicle)
    #         return None

    def newpolicy(self,my_ai):
        vehicle = self.get_bop(my_ai)
        if vehicle:
            action = self.shoot(vehicle, my_ai)
            if action:
                return action
            action = self.occupy(vehicle, my_ai)
            if action:
                return action
            bop_id = vehicle["obj_id"]
            if (bop_id == my_ai.veid_100):
                if self.caninto == 1:
                    return self.into_hunter(my_ai,vehicle)
                if vehicle['cur_hex'] == 2743 and self.move_point == -1:
                    self.move_point = 2741
                if vehicle['cur_hex'] != self.move_point:
                    action = self.move(vehicle, self.move_point, my_ai, number = 1,route_mode = 2)
                    if action:
                        return action
                if vehicle['cur_hex'] == 2741:
                    self.move_point = 2733
                if vehicle['cur_hex'] == 2733:
                    self.move_point = 3430
                if vehicle['cur_hex'] == 3430 and self.have_passenger_number(my_ai, vehicle, sub_type = const.BopName.Soldier):
                    action = self.passenger_off(vehicle, my_ai, sub_type=const.BopName.Soldier)
                    if action:
                        self.caninto = 1
                        return action

            if (bop_id == my_ai.veid_101):
                if self.caninto == 1:
                    return self.into_hunter(my_ai,vehicle)
                if vehicle['cur_hex'] == 2743 and self.move_point == -1:
                    self.move_point = 2741
                if vehicle['cur_hex'] != self.move_point:
                    action = self.move(vehicle, self.move_point, my_ai, number = 1,route_mode = 2)
                    if action:
                        return action
                if vehicle['cur_hex'] == 2741:
                    self.move_point = 2732
                if vehicle['cur_hex'] == 2732:
                    self.move_point = 3429
                if vehicle['cur_hex'] == 3429 and self.have_passenger_number(my_ai, vehicle, sub_type = const.BopName.Soldier):
                    action = self.passenger_off(vehicle, my_ai, sub_type=const.BopName.Soldier)
                    if action:
                        self.caninto = 1
                        return action

            if (bop_id == my_ai.veid_102):
                if self.caninto == 1:
                    return self.into_hunter(my_ai,vehicle)
                if vehicle['cur_hex'] == 2843 and self.move_point == -1:
                    self.move_point = 2741
                if vehicle['cur_hex'] != self.move_point:
                    action = self.move(vehicle, self.move_point, my_ai, number = 1,route_mode = 2)
                    if action:
                        return action
                if vehicle['cur_hex'] == 2741:
                    self.move_point = 2731
                if vehicle['cur_hex'] == 2731:
                    self.move_point = 3328
                if vehicle['cur_hex'] == 3328 and self.have_passenger_number(my_ai, vehicle, sub_type = const.BopName.Soldier):
                    action = self.passenger_off(vehicle, my_ai, sub_type=const.BopName.Soldier)
                    if action:
                        self.caninto = 1
                        return action

            if (bop_id == 66):
                if self.caninto == 1:
                    return self.into_hunter(my_ai,vehicle)
                if vehicle['cur_hex'] == 2843 and self.move_point == -1:
                    self.move_point = 2741
                if vehicle['cur_hex'] != self.move_point:
                    action = self.move(vehicle, self.move_point, my_ai, number = 1,route_mode = 2)
                    if action:
                        return action
                if vehicle['cur_hex'] == 2741:
                    self.move_point = 2735
                if vehicle['cur_hex'] == 2735:
                    self.move_point = 3432
                if vehicle['cur_hex'] == 3432 and self.have_passenger_number(my_ai, vehicle, sub_type = const.BopName.Soldier):
                    action = self.passenger_off(vehicle, my_ai, sub_type=const.BopName.Soldier)
                    if action:
                        self.caninto = 1
                        return action

            if (bop_id == 64):
                if self.caninto == 1:
                    return self.into_hunter(my_ai,vehicle)
                if vehicle['cur_hex'] == 2743 and self.move_point == -1:
                    self.move_point = 3740
                if vehicle['cur_hex'] != self.move_point:
                    action = self.move(vehicle, self.move_point, my_ai, number = 1,route_mode = 2)
                    if action:
                        return action
                if vehicle['cur_hex'] == 3740 and self.have_passenger_number(my_ai, vehicle, sub_type = const.BopName.Soldier):
                    action = self.passenger_off(vehicle, my_ai, sub_type = const.BopName.Soldier)
                    if action:
                        self.caninto = 1
                        return action
            return None

    def into_hunter(self,my_ai,operators):
        action = self.guide_shoot(operators, my_ai)
        if action:
            return action
        action = self.shoot(operators, my_ai)
        if action:
            return action
        action = self.occupy(operators, my_ai)
        if action:
            return action
        if operators['obj_id'] not in my_ai.controllable_ops:
            return None
        if operators['obj_id'] in my_ai.huntermove.keys():
            msg_body = my_ai.huntermove[operators['obj_id']]
            if len(msg_body["hexs"]) > 1:
                if operators['cur_hex'] == msg_body["hexs"][0]:
                    target_point = msg_body["hexs"][1]
                    action = self.move(operators, target_point, my_ai, number = 1)


                    if action:
                        next_hex = action['move_path'][0]
                        msg_body["hexs"][0] = next_hex
                        if msg_body["hexs"][0] == msg_body["hexs"][1]:
                            msg_body["hexs"] = msg_body["hexs"][1:]
                        route = msg_body["hexs"]
                        #my_ai.huntermove = {}
                        return action
            else:
                del my_ai.huntermove[operators['obj_id']]
        return None

class RedSoldier(Soldier):

    def __init__(self, bop, serial_number=0, group=0):
        super(RedSoldier, self).__init__()
        assert self.sub_type == bop['sub_type']
        self.obj_id = bop['obj_id']
        self.serial_number = serial_number
        self.group = group
        self.move_point = -1
        self.caninto = 0

    def get_attack_point(self, soldier, my_ai, dis):
        hexes_main = my_ai.hex_cache.get_circle(my_ai.attack_point['o_main_attack'], dis, dis + 4)
        hexes_start = my_ai.hex_cache.get_circle(soldier['cur_hex'], 0, 4)
        circle = list(set(hexes_main) & set(hexes_start))
        if not circle:
            circle = hexes_start
        kwargs = {'observed_second': .8,
                  'maneuver_time': 1,
                  'maneuver_time_main': .3,
                  'hide_cond': 1,
                  'stack': 0.5,
                  'shoot_ability': .3,
                  'be_shoot_ability': 3,
                  'observe_enemy_ability': 2}

        attack_point = self.get_key_point(my_ai, soldier, my_ai.attack_point['e_main_attack'], circle,
                                                       kwargs)
        return attack_point

    def get_DT_attack_point(self, soldier, my_ai):
        hexes_start = my_ai.hex_cache.get_circle(soldier['cur_hex'], 0, 2)
        kwargs = {'observed_ability': 2,
                  'maneuver_time': 2,
                  'maneuver_time_main': 1,
                  'hide_cond': 1,
                  'stack': 0,
                  'shoot_ability': 0,
                  'be_shoot_ability': 0,
                  'observe_enemy_ability': 1}

        attack_point = self.get_key_point(my_ai, soldier, my_ai.attack_point['e_main_attack'], hexes_start,
                                                       kwargs)
        return attack_point

    def get_gathering_point(self, soldier, my_ai, dis):
        hexes_main = my_ai.hex_cache.get_circle(my_ai.attack_point['o_main_attack'], dis, dis + 4)
        hexes_start = my_ai.hex_cache.get_circle(soldier['cur_hex'], 0, 5)
        circle = list(set(hexes_main) & set(hexes_start))
        if not circle:
            circle = hexes_main
        kwargs = {'observed_main': .3,
                  'maneuver_time': 0.3,
                  'maneuver_time_main': 1,
                  'hide_cond': 1,
                  'stack': 0.5,
                  'shoot_ability': .3,
                  'be_shoot_ability': 0,
                  'observe_enemy_ability': 1}

        attack_point = self.get_key_point(my_ai, soldier, my_ai.attack_point['e_main_attack'], circle,
                                                       kwargs)
        return attack_point

    def FarAttack(self, my_ai, action_bops):
        self.min_attack_dis = 10
        return self.MoveAttack(my_ai)

    def MiddleFarAttack(self, my_ai, action_bops):
        self.min_attack_dis = 9
        return self.MoveAttack(my_ai)


    def DTFarAttack(self, my_ai, action_bops):
        soldier = self.get_bop(my_ai)
        if soldier:
            if my_ai.time < 30:
                init_pos = common.get_init_pos(soldier, my_ai.our_bops_init_all)
                if soldier['cur_hex'] == init_pos:
                    action = self.get_on(soldier, my_ai)
                    if action:
                        return action
                    else:
                        return list()
            # elif my_ai.time < 600:
            #     return self.NearMoveAttack(my_ai)
            else:
                return self.OccupyingMain(my_ai, action_bops, change_state=True)
                    # attack_city(my_ai, my_ai.attack_point['o_main_attack'], change_state=True)
        return None

    def DTMiddleFarAttack(self, my_ai, action_bops):
        # return self.DTFarAttack(ai_group, action_bops)
        soldier = self.get_bop(my_ai)
        if soldier:
            return self.OccupyingMain(my_ai, action_bops, change_state=True)
        return None

    def DT2FarAttack(self, my_ai, action_bops):
        return self.DTFarAttack(my_ai, action_bops)

    def DT2MiddleFarAttack(self, my_ai, action_bops):
        return self.DTFarAttack(my_ai, action_bops)

    def NearMoveAttack(self, my_ai):
        soldier = self.get_bop(my_ai)
        if soldier:
            init_pos = common.get_init_pos(soldier, my_ai.our_bops_init_all)
            if soldier['cur_hex'] == init_pos:
                action = self.get_on(soldier, my_ai)
                if action:
                    return action
                else:
                    return list()

            # 士兵能够射击时立即射击， 优先引导射击
            action = self.guide_shoot(soldier, my_ai)
            if action:
                return action
            action = self.shoot(soldier, my_ai)
            if action:
                return action
            action = self.occupy(soldier, my_ai)
            if action:
                return action

            # 转为二级冲锋状态
            action = self.change_rush_level_two(soldier, my_ai)
            if action:
                return action

            if self.see_enemy(soldier):
                action = self.stop(soldier, my_ai)
                if action:
                    return action
            if not hasattr(self, 'soldier_attack_point'):
                self.soldier_attack_point = self.get_DT_attack_point(soldier, my_ai)
                #print('人员射击点为：', self.soldier_attack_point)
            if soldier['cur_hex'] != self.soldier_attack_point:
                action = self.move(soldier, self.soldier_attack_point, my_ai)
                if action:
                    return action
            self.wait_time -= 1
        return None

    def MoveAttack(self, my_ai):
        soldier = self.get_bop(my_ai)
        if soldier:
            init_pos = common.get_init_pos(soldier, my_ai.our_bops_init_all)
            if soldier['cur_hex'] == init_pos:
                action = self.get_on(soldier, my_ai)
                if action:
                    return action
                else:
                    return list()

            # 士兵能够射击时立即射击， 优先引导射击
            action = self.guide_shoot(soldier, my_ai)
            if action:
                return action
            action = self.shoot(soldier, my_ai)
            if action:
                return action

            action = self.occupy(soldier, my_ai)
            if action:
                return action

            if self.see_enemy(soldier) and self.can_move(soldier, my_ai):
                ubops = common.get_see_enemy(soldier, my_ai.enemy_bops)
                vehicles = common.get_bop_sub_type(my_ai.our_bops, const.BopName.Vehicle)
                if vehicles:
                    vehicle = vehicles[0]
                    for ubop in ubops:
                        if ubop['sub_type'] != const.BopName.Soldier:
                            dis = com.get_distance(vehicle['cur_hex'], ubop['cur_hex'])
                            if dis <= 20:
                                self.stop_call = True
                                self.call_guide = [ubop for ubop in ubops if ubop['type'] == const.BopType.Vehicle]
                                break
                            else:
                                self.stop_call = False
                                self.call_guide = []
            else:
                self.stop_call = False
                self.call_guide = []

            # 转为二级冲锋状态
            action = self.change_rush_level_two(soldier, my_ai)
            if action:
                return action

            if self.can_move(soldier, my_ai):
                # self.soldier_attack_point = self.get_attack_point(soldier, my_ai, self.min_attack_dis)
                self.soldier_attack_point = 3630
                action = self.move(soldier, self.soldier_attack_point, my_ai)
                next_cur = action['move_path'][0]
                action['move_path'] = next_cur
                if action:
                    return action

            if my_ai.enemy_predict.be_attacked_ability(soldier, [soldier['cur_hex']], my_ai) > 0.8:
                if self.can_move(soldier, my_ai):
                    #self.soldier_attack_point = self.get_attack_point(soldier, my_ai, self.min_attack_dis)
                    self.soldier_attack_point = 3630
                    action = self.move(soldier, self.soldier_attack_point, my_ai)
                    next_cur = action['move_path'][0]
                    action['move_path'] = next_cur
                    if action:
                        return action

            # if self.stop_call:
            #     action = self.stop(soldier, my_ai)
            #     if action:
            #         return action

            if not self.stop_call and self.can_move(soldier, my_ai) and soldier['tire'] < 1 and self.wait_time <= 0:
                #self.soldier_attack_point = self.get_attack_point(soldier, my_ai, self.min_attack_dis)
                self.soldier_attack_point = 3630
                if self.soldier_attack_point == soldier['cur_hex']:
                    self.wait_time = 30
                #print('人员射击点为：', self.soldier_attack_point)
                # 人员行进到攻击点
                action = self.move(soldier, self.soldier_attack_point, my_ai)
                next_cur = action['move_path'][0]
                action['move_path'] = next_cur
                if action:
                    return action
            self.wait_time -= 1
        return None


    def HRFarAttack(self, my_ai, action_bops):
        return self.newpolicy(my_ai)
        soldier = self.get_bop(my_ai)
        if soldier:
            if my_ai.SoldierControl == 2:
                return self.into_hunter(my_ai,soldier)
            # 士兵能够射击时立即射击， 优先引导射击
            action = self.guide_shoot(soldier, my_ai)
            if action:
                return action
            action = self.shoot(soldier, my_ai)
            if action:
                return action
            action = self.occupy(soldier, my_ai)
            if action:
                return action


            # 转为二级冲锋状态
            action = self.change_rush_level_two(soldier, my_ai)
            if action:
                return action

            if self.can_move(soldier, my_ai):
                # self.soldier_attack_point = self.get_attack_point(soldier, my_ai, self.min_attack_dis)
                self.soldier_attack_point = 3630
                action = self.soldiermove(soldier, self.soldier_attack_point, my_ai)
                #action['move_path'] = action['move_path'][:1]
                if action:
                    return action


            # if my_ai.enemy_predict.be_attacked_ability(soldier, [soldier['cur_hex']], my_ai) > 0.8:
            #     if self.can_move(soldier, my_ai):
            #         # self.soldier_attack_point = self.get_attack_point(soldier, my_ai, self.min_attack_dis)
            #         self.soldier_attack_point = 3630
            #         action = self.move(soldier, self.soldier_attack_point, my_ai)
            #         next_cur = action['move_path'][0]
            #         action['move_path'] = next_cur
            #         if action:
            #             return action

            # if self.stop_call:
            #     action = self.stop(soldier, my_ai)
            #     if action:
            #         return action

            # if not self.stop_call and self.can_move(soldier, my_ai) and soldier['tire'] < 1 and self.wait_time <= 0:
            #     # self.soldier_attack_point = self.get_attack_point(soldier, my_ai, self.min_attack_dis)
            #     self.soldier_attack_point = 3630
            #     if self.soldier_attack_point == soldier['cur_hex']:
            #         self.wait_time = 30
            #     # print('人员射击点为：', self.soldier_attack_point)
            #     # 人员行进到攻击点
            #     action = self.move(soldier, self.soldier_attack_point, my_ai)
            #     next_cur = action['move_path'][0]
            #     action['move_path'] = next_cur
            #     if action:
            #         return action
            # self.wait_time -= 1
        return None

    def HRMiddleFarAttack(self, my_ai, action_bops):
        return self.newpolicy(my_ai)
        soldier = self.get_bop(my_ai)
        if soldier:
            if my_ai.SoldierControl == 2:
                return self.into_hunter(my_ai,soldier)
            # 士兵能够射击时立即射击， 优先引导射击
            action = self.guide_shoot(soldier, my_ai)
            if action:
                return action
            action = self.shoot(soldier, my_ai)
            if action:
                return action
            action = self.occupy(soldier, my_ai)
            if action:
                return action

            # if self.see_enemy(soldier) and self.can_move(soldier, my_ai):
            #     ubops = common.get_see_enemy(soldier, my_ai.enemy_bops)
            #     vehicles = common.get_bop_sub_type(my_ai.our_bops, const.BopName.Vehicle)
            #     if vehicles:
            #         vehicle = vehicles[0]
            #         for ubop in ubops:
            #             if ubop['sub_type'] != const.BopName.Soldier:
            #                 dis = com.get_distance(vehicle['cur_hex'], ubop['cur_hex'])
            #                 if dis <= 20:
            #                     self.stop_call = True
            #                     self.call_guide = [ubop for ubop in ubops if ubop['type'] == const.BopType.Vehicle]
            #                     break
            #                 else:
            #                     self.stop_call = False
            #                     self.call_guide = []
            # else:
            #     self.stop_call = False
            #     self.call_guide = []

            # 转为二级冲锋状态
            action = self.change_rush_level_two(soldier, my_ai)
            if action:
                return action

            if self.can_move(soldier, my_ai):
                # self.soldier_attack_point = self.get_attack_point(soldier, my_ai, self.min_attack_dis)
                self.soldier_attack_point = 3630
                action = self.soldiermove(soldier, self.soldier_attack_point, my_ai)
                # path = action['move_path']
                # if len(path) > 8:
                #     action['move_path'] = action['move_path'][:4]
                # else:
                #     action['move_path'] = action['move_path'][:1]
                #action['move_path'] = action['move_path'][:1]
                if action:
                    return action

            # if my_ai.enemy_predict.be_attacked_ability(soldier, [soldier['cur_hex']], my_ai) > 0.8:
            #     if self.can_move(soldier, my_ai):
            #         # self.soldier_attack_point = self.get_attack_point(soldier, my_ai, self.min_attack_dis)
            #         self.soldier_attack_point = 3630
            #         action = self.move(soldier, self.soldier_attack_point, my_ai)
            #         next_cur = action['move_path'][0]
            #         action['move_path'] = next_cur
            #         if action:
            #             return action

            # if self.stop_call:
            #     action = self.stop(soldier, my_ai)
            #     if action:
            #         return action

            # if not self.stop_call and self.can_move(soldier, my_ai) and soldier['tire'] < 1 and self.wait_time <= 0:
            #     # self.soldier_attack_point = self.get_attack_point(soldier, my_ai, self.min_attack_dis)
            #     self.soldier_attack_point = 3630
            #     if self.soldier_attack_point == soldier['cur_hex']:
            #         self.wait_time = 30
            #     # print('人员射击点为：', self.soldier_attack_point)
            #     # 人员行进到攻击点
            #     action = self.move(soldier, self.soldier_attack_point, my_ai)
            #     next_cur = action['move_path'][0]
            #     action['move_path'] = next_cur
            #     if action:
            #         return action
            # self.wait_time -= 1
        return None

    def HROccupying(self, my_ai, action_bops):
        return self.newpolicy(my_ai)
        if my_ai.time < 1600:
            return self.HRMiddleFarAttack(my_ai,action_bops)
        soldier = self.get_bop(my_ai)
        if soldier:
            if my_ai.SoldierControl == 2:
                return self.into_hunter(my_ai,soldier)
            change_state = True
            bop = self.get_bop(my_ai)
            if bop:
                guide_action = self.guide_shoot(bop, my_ai)
                if guide_action:
                    return guide_action
                action = self.shoot(bop, my_ai)
                if action:
                    return action

                if not common.my_city(my_ai.observation['cities'], my_ai.color,
                                      coord=my_ai.attack_point['o_main_attack']):
                    # 转为二级冲锋状态
                    if change_state and not (
                            bop['move_state'] == const.StateMode.Hide or bop['change_state_remain_time']):
                        action = self.change_rush_level_two(bop, my_ai)
                        if action:
                            return action

                    action = self.occupy(bop, my_ai)
                    if action:
                        return action

                    if common.can_move(bop, my_ai):
                        bop_int4 = self.occupy_move(bop, my_ai, my_ai.attack_point['o_main_attack'])

                        action = self.soldiermove(bop, bop_int4, my_ai)
                        if action:
                            return action
                else:
                    if not self.see_enemy(bop):
                        action = self.occupy(bop, my_ai)
                        if action:
                            return action
                        if common.can_move(bop, my_ai) and self.wait_time <= 0:
                            bop_int4 = self.occupy_protect(bop, my_ai, my_ai.attack_point['o_main_attack'])
                            if bop_int4 == bop['cur_hex']:
                                self.wait_time = 30
                            action = self.soldiermove(bop, bop_int4, my_ai)
                            if action:
                                return action
                action = self.hide(bop, my_ai)
                if action:
                    return action
                self.wait_time -= 1
            return None
        return None

    def newpolicy(self,my_ai):
        soldier = self.get_bop(my_ai)
        if soldier:
            action = self.shoot(soldier, my_ai)
            if action:
                return action
            action = self.occupy(soldier, my_ai)
            if action:
                return action
            bop_id = soldier["obj_id"]
            if (bop_id == my_ai.sold_200):
                if soldier['cur_hex'] == 3430:
                    action = self.change_rush_level_two(soldier, my_ai)
                    if action:
                        self.caninto = 1
                        return action
                if self.caninto == 1:
                    return self.into_hunter(my_ai,soldier)
            elif (bop_id == my_ai.sold_201):
                if soldier['cur_hex'] == 3429:
                    action = self.change_rush_level_two(soldier, my_ai)
                    if action:
                        self.caninto = 1
                        return action
                if self.caninto == 1:
                    return self.into_hunter(my_ai, soldier)
            elif (bop_id == my_ai.sold_202):
                if soldier['cur_hex'] == 3328:
                    action = self.change_rush_level_two(soldier, my_ai)
                    if action:
                        self.caninto = 1
                        return action
                if self.caninto == 1:
                    return self.into_hunter(my_ai, soldier)


            elif (bop_id == my_ai.sold_68):
                if soldier['cur_hex'] == 3740 and self.move_point == -1:
                    self.move_point = 3928
                if soldier['cur_hex'] != self.move_point:
                    if not (soldier['move_state'] == const.StateMode.Hide or soldier['change_state_remain_time']):
                        action = self.change_rush_level_two(soldier, my_ai)
                        if action:
                            return action
                    action = self.soldiermove(soldier, self.move_point, my_ai, number=1)
                    if action:
                        return action
            elif (bop_id == my_ai.sold_69):
                if soldier['cur_hex'] == 3432:
                    action = self.change_rush_level_two(soldier, my_ai)
                    if action:
                        self.caninto = 1
                        return action
                if self.caninto == 1:
                    return self.into_hunter(my_ai, soldier)
            return None

    def into_hunter(self, my_ai, operators):
        action = self.guide_shoot(operators, my_ai)
        if action:
            return action
        action = self.shoot(operators, my_ai)
        if action:
            return action
        action = self.occupy(operators, my_ai)
        if action:
            return action
        if operators['obj_id'] not in my_ai.controllable_ops:
            return None
        if operators['obj_id'] in my_ai.huntermove.keys():
            msg_body = my_ai.huntermove[operators['obj_id']]
            if len(msg_body["hexs"]) > 1:
                if operators['cur_hex'] == msg_body["hexs"][0]:
                    target_point = msg_body["hexs"][1]
                    action = self.move(operators, target_point, my_ai, number=1)


                    if action:
                        next_hex = action['move_path'][0]
                        msg_body["hexs"][0] = next_hex
                        if msg_body["hexs"][0] == msg_body["hexs"][1]:
                            msg_body["hexs"] = msg_body["hexs"][1:]
                        route = msg_body["hexs"]
                        # my_ai.huntermove = {}
                        return action
            else:
                del my_ai.huntermove[operators['obj_id']]
        return None

class RedTank(Tank):
    def __init__(self, bop, serial_number=0, group=0):
        super(RedTank, self).__init__()
        assert self.sub_type == bop['sub_type']
        self.obj_id = bop['obj_id']
        self.serial_number = serial_number
        self.group = group
        self.onattackpoint = 0
        self.linjihex = []

    def get_init_hide_point(self, tank, my_ai):
        dis = com.get_distance(tank['cur_hex'], my_ai.attack_point['o_main_attack'])
        pos_start = my_ai.hex_cache.get_circle(tank['cur_hex'], dis-4, dis)
        pos_main = my_ai.hex_cache.get_circle(my_ai.attack_point['o_main_attack'], 0, 5)
        circle = list(set(pos_start) & set(pos_main))
        if not circle:
            circle = pos_main
        ai = my_ai
        bop = tank
        be_see_type = const.BopType.Vehicle
        pos_tuple = circle
        center_int4 = my_ai.attack_point['o_main_attack']
        observe_point_dis = 2
        top_num = const.top_num
        select = const.select
        beta = const.beta
        kwargs = {'observed_ability': 0,
                  'be_observed_ability': 1,
                  'maneuver_time': 1,
                  'maneuver_time_main': 0.7,
                  'neighbor_max_observe_ability': 0.5,
                  'hide_cond': 0}

        tank_end_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                              top_num,
                                              select, beta, **kwargs)

        self.init_hide = tank_end_int4
        self.init_move = False

    def get_init_attack_point(self, tank, my_ai):
        dis = com.get_distance(tank['cur_hex'], my_ai.attack_point['e_main_attack'])
        pos_start = my_ai.hex_cache.get_circle(tank['cur_hex'], 0, dis)
        pos_main = my_ai.hex_cache.get_circle(my_ai.attack_point['e_main_attack'], 4, 8)
        circle = list(set(pos_start) & set(pos_main))
        if not circle:
            circle = pos_main
        ai = my_ai
        bop = tank
        be_see_type = const.BopType.Vehicle
        pos_tuple = circle
        center_int4 = my_ai.attack_point['o_second_attack']
        observe_point_dis = 2
        top_num = const.top_num
        select = const.select
        beta = const.beta
        kwargs = {'observed_second': 0.8,
                  'observed_ability': 0,
                  'be_observed_ability': 0,
                  'maneuver_time': 1,
                  'maneuver_time_main': 0,
                  'neighbor_max_observe_ability': 0,
                  'hide_cond': 1,
                  'stack': 0.2,
                  'replay_attack_ability': 2,
                  'replay_be_observed_ability': 1}

        tank_end_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                              top_num,
                                              select, beta, **kwargs)

        self.init_attack_point = tank_end_int4
        self.init_move = False


    def get_bop_around_point(self, tank, bop_pos, my_ai):
        # dis = com.get_distance(tank['cur_hex'], ai_group.attack_point['e_main_attack'])
        # pos_start = ai_group.hex_cache.get_circle(tank['cur_hex'], 0, dis)
        # pos_main = ai_group.hex_cache.get_circle(ai_group.attack_point['e_main_attack'], 4, 8)
        circle = my_ai.hex_cache.get_circle(bop_pos, 0, 2)

        ai = my_ai
        bop = tank
        be_see_type = const.BopType.Vehicle
        pos_tuple = circle
        center_int4 = my_ai.attack_point['o_second_attack']
        observe_point_dis = 2
        top_num = const.top_num
        select = const.select
        beta = const.beta
        kwargs = {#'observed_second': 1,
                  #'observed_ability': .5,
                  'be_observed_ability': 0.5,
                  'maneuver_time': 3,
                  'maneuver_time_main': 1,
                  'neighbor_max_observe_ability': 0,
                  'hide_cond': 1,
                  'stack': 0.2,
                  'replay_attack_ability': 0,
                  'replay_be_observed_ability': 0}

        tank_end_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                              top_num,
                                              select, beta, **kwargs)

        return tank_end_int4

    def get_middle_attack_point(self, tank, my_ai):
        no_hex = my_ai.hex_cache.get_circle(3742, 0, 3)
        hexes = my_ai.hex_cache.get_circle(tank['cur_hex'], 0, 10)
        hexes_select = list(set(hexes) - set(no_hex))

        kwargs = {'observed_ability': .5,
                  'maneuver_time': 0,
                  'maneuver_time_main': .5,
                  'hide_cond': 1,
                  'stack': 0.5,
                  'shoot_ability': 1.5,
                  'be_shoot_ability': 3,
                  'be_observed_enemy_ability': 1
                  }

        attack_point = self.get_key_point(my_ai, tank, my_ai.attack_point['o_main_attack'], hexes_select, kwargs)
        print('坦克中远攻击点为：', attack_point)
        return attack_point

    def DTFarAttack(self, my_ai, action_bops):
        tank = self.get_bop(my_ai)
        if tank:
            if my_ai.time < 700:
                action = self.shoot(tank, my_ai, tar_sub_type=[const.BopName.Vehicle])
                if action:
                    return action

                action = self.shoot(tank, my_ai, tar_sub_type=[const.BopName.ScoutVehicle])
                if action:
                    return action

                action = self.shoot(tank, my_ai,tar_sub_type=[const.BopName.Tank])
                if action:
                    return action
            else:
                action = self.shoot(tank, my_ai)
                if action:
                    return action

            action = self.occupy(tank, my_ai)
            if action:
                return action

            if my_ai.time < 700:
                action = self.tank_attack_vehicle(tank, my_ai, hide_flag=True, dis=5)
                if action:
                    return action
            else:
                # if not hasattr(self, 'first_occupy'):
                #     self.first_occupy = True
                if my_ai.time > 1650:
                    if self.city_enemy(my_ai, my_ai.attack_point['o_second_attack'], dis=1) < 0.3:
                        if not common.my_city(my_ai.observation['cities'], my_ai.color, coord=my_ai.attack_point['o_second_attack']):
                            action = self.OccupyingCity(my_ai, action_bops, my_ai.attack_point['o_second_attack'])
                            if action:
                                return action

                action = self.OccupyingCity(my_ai, action_bops, my_ai.attack_point['o_main_attack'])
                if action:
                    return action

            if my_ai.time > 100:
                action = self.hide(tank, my_ai)
                if action:
                    return action
        return []

    def DT2farattack(self, my_ai, action_bops):
        tank = self.get_bop(my_ai)
        if tank:
            if my_ai.time < 600 and self.attack_vehicle_flag:
                action = self.shoot(tank, my_ai, tar_sub_type=[const.BopName.Vehicle])
                if action:
                    return action
                action = self.shoot(tank, my_ai, tar_sub_type=[const.BopName.ScoutVehicle])
                if action:
                    return action
                action = self.shoot(tank, my_ai,tar_sub_type=[const.BopName.Tank])
                if action:
                    return action
            else:
                action = self.shoot(tank, my_ai)
                if action:
                    return action

            action = self.occupy(tank, my_ai)
            if action:
                return action

            if not common.my_city(my_ai.observation['cities'], my_ai.color, coord=my_ai.attack_point['o_main_attack']) and self.first_occupy:
                action = self.OccupyingMain(my_ai, action_bops)
                if action:
                    self.first_occupy = False
                    return action

            else:
                # 保护战车
                if my_ai.time < 600:
                    action = self.tank_around_point_attack(tank, my_ai, point=3640, dis=1)
                    if action:
                        return action
                else:
                    action = self.friend_see_shoot(tank, my_ai, dis=3)
                    if action:
                        return action

                # if not common.enemy_no_vehicle(ai_group) and self.attack_vehicle_flag:
                #     if self.see_can_shoot(tank, ai_group, sub_type=const.BopName.Soldier):
                #         self.attack_vehicle_flag = False
                #     action = self.tank_attack_vehicle(tank, ai_group, dis=2, hide_flag=True, be_attacked=2)
                #     if action:
                #         return action
                # if not self.attack_vehicle_flag:
                    if self.see_can_shoot(tank, my_ai):
                        action = self.tank_move_hide(tank, my_ai)
                        if action:
                            return action
                    elif not tank['see_enemy_bop_ids'] and tank['weapon_cool_time'] <= 30:
                        action = self.tank_move_attack_hide(tank, my_ai, center_point=tank['cur_hex'])
                        if action:
                            return action
        return []

    def DTMiddleFarAttack(self, my_ai, action_bops):
        return self.DTFarAttack(my_ai, action_bops)

    def MiddleFarAttack(self, my_ai, action_bops):
        tank = self.get_bop(my_ai)
        if tank:
            action = self.shoot(tank, my_ai)
            if action:
                return action

            if self.see_enemy(tank):
                action = self.tank_move_hide(tank, my_ai)
                if action:
                    return action

            if not self.see_enemy(tank) and self.can_move(tank, my_ai) and self.wait_time <= 0:
                attack_point = self.get_middle_attack_point(tank, my_ai)
                if attack_point == tank['cur_hex']:
                    self.wait_time = 20
                kwargs = {'beta': 1.5,
                          'hide_cond': 1,
                          'shoot_ability': 0,
                          'be_shoot_ability': 0.5,
                          'be_shoot_ability_aircraft': 0,
                          'observe_enemy_ability': 0,
                          'be_observed_enemy_ability': 0.5}
                action = self.hide_move(tank, attack_point, my_ai, danger_stop=True, danger_value=0.5,
                                        **kwargs)
                if action:
                    return action
                else:
                    self.wait_time = 20
            self.wait_time -= 1
        return None

    def FarAttack(self, my_ai, action_bops):
        tank = self.get_bop(my_ai)
        if tank:
            # 判断有无远程攻击点, 满足条件进行远程攻击
            if not hasattr(self, 'far_attack_point'):
                hexes_main = my_ai.hex_cache.get_circle(my_ai.attack_point['e_main_attack'], 9, 11)
                hexes_start = my_ai.hex_cache.get_circle(tank['cur_hex'], 10, 16)
                circle = list(set(hexes_main) & set(hexes_start))
                if not circle:
                    circle = hexes_main
                kwargs = {'be_observed_ability': 1,
                          'maneuver_time': 0.5,
                          'maneuver_time_main': .3,
                          'hide_cond': 1,
                          'stack': 0.5,
                          'shoot_ability': 0,
                          'replay_attack_ability': 0,
                          'replay_be_attacked_ability': 1,
                          }
                self.init_move = True
                self.far_attack_point = self.get_key_point(my_ai, tank, my_ai.attack_point['e_main_attack'], circle, kwargs)

            action = self.shoot(tank, my_ai)
            if action:
                return action
            if self.init_move and tank['cur_hex'] != self.far_attack_point:
                action = self.move(tank, self.far_attack_point, my_ai)
                if action:
                    return action

            action = self.friend_see_shoot(tank, my_ai)
            if action:
                return action

            if self.see_enemy(tank) and tank['weapon_cool_time'] >= 40:
                action = self.tank_move_hide(tank, my_ai)
                if action:
                    return action
            elif not tank['see_enemy_bop_ids'] and tank['weapon_cool_time'] <= 20:
                action = self.tank_move_attack(tank, my_ai, center_point=tank['cur_hex'])
                if action:
                    return action
        return []

    def DT2FarAttack(self, my_ai, action_bops):
        return self.DT2farattack(my_ai, action_bops)

    def DT2MiddleFarAttack(self, my_ai, action_bops):
        return self.DT2farattack(my_ai, action_bops)

    def MoveAttack(self, my_ai):
        tank = self.get_bop(my_ai)
        if tank:
            if not hasattr(self, 'init_hide'):
                self.get_init_hide_point(tank, my_ai)


            action = self.shoot(tank, my_ai)
            if action:
                return action

            if not self.init_move:
                action = self.move(tank, self.init_hide, my_ai)
                if action:
                    self.init_move = True
                    return action
            elif self.see_enemy(tank) and tank['weapon_cool_time'] != 0:
                action = self.tank_move_hide(tank, my_ai)
                if action:
                    return action
            elif not tank['see_enemy_bop_ids'] and tank['weapon_cool_time'] <= 20:
                action = self.tank_move_attack(tank, my_ai)
                if action:
                    return action
        return []

    def get_first_occupy_city(self, my_ai):
        ubops_record = [ubop_record for ubop_id, ubop_record in my_ai.enemy_predict.ubops_record.items() if
                        ubop_record['live']]
        hexes_around_main = my_ai.hex_cache.get_circle(my_ai.attack_point['o_main_attack'], 0, 1)
        hexes_around_second = my_ai.hex_cache.get_circle(my_ai.attack_point['o_second_attack'], 0, 1)
        ubop_pos_main = np.zeros(len(hexes_around_main))
        ubop_pos_second = np.zeros(len(hexes_around_second))
        for ubop_record in ubops_record:
            ubop_pos_main += ubop_record['pos_predict'][tuple(zip(*hexes_around_main))]
            ubop_pos_second += ubop_record['pos_predict'][tuple(zip(*hexes_around_second))]
        ubop_pos_main = ubop_pos_main.sum()
        ubop_pos_second = ubop_pos_second.sum()
        if ubop_pos_main < 0.1:
            first_occupy = my_ai.attack_point['o_main_attack']
        elif ubop_pos_second < 0.1:
            first_occupy = my_ai.attack_point['o_second_attack']
        else:
            first_occupy = my_ai.attack_point['o_main_attack']

        return first_occupy


    def Occupying(self, my_ai, action_bops):
        tank = self.get_bop(my_ai)
        if tank:
            if not hasattr(self, 'first_occupy_point'):
                self.first_occupy_point = self.get_first_occupy_city(my_ai)

            if not common.my_city(my_ai.observation['cities'], my_ai.color, coord=self.first_occupy_point) and \
                    self.first_occupy_point == my_ai.attack_point['o_main_attack']:
                return self.OccupyingMain(my_ai, action_bops)
            elif not common.my_city(my_ai.observation['cities'], my_ai.color, coord=self.first_occupy_point) and \
                    self.first_occupy_point == my_ai.attack_point['o_second_attack']:
                return self.OccupyingSecond(my_ai, action_bops)
            else:
                action = self.shoot(tank, my_ai)
                if action:
                    return action

                action = self.occupy(tank, my_ai)
                if action:
                    return action

                if self.see_enemy(tank) and tank['weapon_cool_time'] != 0:
                    action = self.tank_move_hide(tank, my_ai)
                    if action:
                        return action
                elif not tank['see_enemy_bop_ids'] and tank['weapon_cool_time'] <= 20:
                    action = self.tank_move_attack(tank, my_ai)
                    if action:
                        return action
        return []

    def HRFarAttack(self, my_ai, action_bops):
        #print('\nenter RED Tank at {}sec'.format(my_ai.observation['time']['cur_step']))
        tank = self.get_bop(my_ai)
        if tank:
            #if tank['obj_id'] == 12 or tank['obj_id'] == 13:
            return self.AIplushumantank(tank,my_ai)
            if my_ai.AITank == 1:
                return self.human_task(my_ai, tank)
            # 判断有无远程攻击点, 满足条件进行远程攻击
            # if not hasattr(self, 'far_attack_point'):
            #     hexes_main = my_ai.hex_cache.get_circle(3444, 0, 3)
            #     hexes_start = my_ai.hex_cache.get_circle(tank['cur_hex'], 1, 15)
            #     circle = list(set(hexes_main) & set(hexes_start))
            #     if not circle:
            #         circle = hexes_main
            #     kwargs = {'be_observed_ability': 1,
            #               'maneuver_time': 0.5,
            #               'maneuver_time_main': .3,
            #               'hide_cond': 1,
            #               'stack': 0.5,
            #               'shoot_ability': 0,
            #               'replay_attack_ability': 0,
            #               'replay_be_attacked_ability': 1,
            #               }
            #     self.init_move = True
            #     self.far_attack_point = self.get_key_point(my_ai, tank, my_ai.attack_point['o_main_attack'], circle, kwargs)

            hexes_main = my_ai.hex_cache.get_circle(3144, 0, 3)
            hexes_start = my_ai.hex_cache.get_circle(tank['cur_hex'], 1, 15)
            circle = list(set(hexes_main) & set(hexes_start))
            if not circle:
                circle = hexes_main
            kwargs = {'be_observed_ability': 1,
                      'maneuver_time': 0.5,
                      'maneuver_time_main': .3,
                      'hide_cond': 1,
                      'stack': 0.5,
                      'shoot_ability': 0,
                      'replay_attack_ability': 0,
                      'replay_be_attacked_ability': 1,
                      }
            self.init_move = True
            self.far_attack_point = self.get_key_point(my_ai, tank, my_ai.attack_point['o_main_attack'], circle, kwargs)

            action = self.shoot(tank, my_ai)
            if action:
                return action
            if self.init_move and tank['cur_hex'] != self.far_attack_point:
                action = self.move(tank, self.far_attack_point, my_ai)
                if action:
                    return action

            action = self.friend_see_shoot(tank, my_ai)
            if action:
                return action

            # if self.see_enemy(tank) and tank['weapon_cool_time'] >= 40:
            #     action = self.tank_move_hide(tank, my_ai)
            #     if action:
            #         return action
            # elif not tank['see_enemy_bop_ids'] and tank['weapon_cool_time'] <= 20:
            #     action = self.tank_move_attack(tank, my_ai, center_point=tank['cur_hex'])
            #     if action:
            #         return action
        return []

    def HRMiddleFarAttack(self, my_ai, action_bops):
        #print('\nenter RED Tank at {}sec'.format(my_ai.observation['time']['cur_step']))
        tank = self.get_bop(my_ai)
        if tank:
            #if tank['obj_id'] == 12 or tank['obj_id'] == 13:
            return self.AIplushumantank(tank,my_ai)
            #if (tank['obj_id']) in my_ai.Tank.keys():
            if my_ai.AITank == 1:
                return self.human_task(my_ai, tank)

            hexes_main = my_ai.hex_cache.get_circle(3345, 0, 3)
            hexes_start = my_ai.hex_cache.get_circle(tank['cur_hex'], 1, 15)
            circle = list(set(hexes_main) & set(hexes_start))
            if not circle:
                circle = hexes_main
            kwargs = {'be_observed_ability': 1,
                      'maneuver_time': 0.5,
                      'maneuver_time_main': .3,
                      'hide_cond': 1,
                      'stack': 0.5,
                      'shoot_ability': 0,
                      'replay_attack_ability': 0,
                      'replay_be_attacked_ability': 1,
                      }
            #self.init_move = True
            self.second_attack_point = self.get_key_point(my_ai, tank, my_ai.attack_point['e_main_attack'], circle, kwargs)

            action = self.shoot(tank, my_ai)
            if action:
                return action
            if tank['cur_hex'] != self.second_attack_point:
                action = self.move(tank, self.second_attack_point, my_ai)
                if action:
                    return action

            action = self.friend_see_shoot(tank, my_ai)
            if action:
                return action
        return None

    def HROccupying(self, my_ai, action_bops):
        #print('\nenter RED Tank at {}sec'.format(my_ai.observation['time']['cur_step']))
        return self.HRMiddleFarAttack(my_ai,action_bops)
        # tank = self.get_bop(my_ai)
        # if tank:
        #     if (tank['obj_id']) in my_ai.Tank.keys():
        #         return self.human_task(my_ai, tank)
        #     if not hasattr(self, 'first_occupy_point'):
        #         self.first_occupy_point = self.get_first_occupy_city(my_ai)
        #
        #     if not common.my_city(my_ai.observation['cities'], my_ai.color, coord=self.first_occupy_point) and \
        #             self.first_occupy_point == my_ai.attack_point['o_main_attack']:
        #         return self.OccupyingMain(my_ai, action_bops)
        #     elif not common.my_city(my_ai.observation['cities'], my_ai.color, coord=self.first_occupy_point) and \
        #             self.first_occupy_point == my_ai.attack_point['o_second_attack']:
        #         return self.OccupyingSecond(my_ai, action_bops)
        #     else:
        #         action = self.shoot(tank, my_ai)
        #         if action:
        #             return action
        #
        #         action = self.occupy(tank, my_ai)
        #         if action:
        #             return action
        #
        #         if self.see_enemy(tank) and tank['weapon_cool_time'] != 0:
        #             action = self.tank_move_hide(tank, my_ai)
        #             if action:
        #                 return action
        #         elif not tank['see_enemy_bop_ids'] and tank['weapon_cool_time'] <= 20:
        #             action = self.tank_move_attack(tank, my_ai)
        #             if action:
        #                 return action
        # return []

    def human_task(self,my_ai, tank):
        tank_id = tank['obj_id']
        if tank_id in my_ai.Tank.keys():
            tank_msg = my_ai.Tank[tank_id]
            # stack = self.calstack(my_ai,tank)
            if tank_msg['mission_type'] == 0:
                self.human_attack_point = tank_msg['target_pos']
                action = self.shoot(tank, my_ai)
                if action:
                    return action
                action = self.occupy(tank, my_ai)
                if action:
                    return action

                if tank['cur_hex'] != self.human_attack_point and self.can_move(tank, my_ai):
                    action = self.move(tank, self.human_attack_point, my_ai ,number = 1)
                    if action:
                        return action
                    # if tank_id == 11:
                    #     action = self.move(tank, self.human_attack_point, my_ai ,number = 1)
                    #     if action:
                    #         return action
                    # elif tank_id == 0 and stack <= 2:
                    #     action = self.move(tank, self.human_attack_point, my_ai, number=1)
                    #     if action:
                    #         return action
                    # elif tank_id == 14 and stack <= 1:
                    #     action = self.move(tank, self.human_attack_point, my_ai, number=1)
                    #     if action:
                    #         return action

                if tank['cur_hex'] == self.human_attack_point and self.can_move(tank, my_ai):
                    linjihex = self.get_linjiehex(self.human_attack_point)
                    if linjihex != []:
                        random.shuffle(linjihex)
                        action = {"actor": my_ai.seat,
                                  'obj_id': tank['obj_id'],
                                  'type': const.ActionType.Move,
                                  'move_path': linjihex,
                                  }
                        if action:
                            return action
                # if tank['cur_hex'] == self.human_attack_point and self.can_move(tank, my_ai):
                #     if self.linjihex == []:
                #         self.linjihex = self.get_linjiehex(self.human_attack_point)
                #     index = random.randint(0,5)
                #     next_hex = self.linjihex[index]
                #     action = {"actor": my_ai.seat,
                #         'obj_id': tank['obj_id'],
                #         'type': const.ActionType.Move,
                #         'move_path': [next_hex],
                #     }
                #     if action:
                #         self.onattackpoint = 1
                #         return action
                # if self.onattackpoint == 1 and self.linjihex != [] and self.can_move(tank, my_ai):
                #     index = random.randint(0, 6)
                #     if index == 6:
                #         next_hex = self.human_attack_point
                #     else:
                #         next_hex = self.linjihex[index]
                #     action = {"actor": my_ai.seat,
                #               'obj_id': tank['obj_id'],
                #               'type': const.ActionType.Move,
                #               'move_path': [next_hex],
                #               }
                #     if action:
                #         return action

            elif tank_msg['mission_type'] == 1:
                self.defense_attack_point = tank_msg['target_pos']
                self.defense_attack_point2 = tank_msg['route'][0]
                action = self.shoot(tank, my_ai)
                if action:
                    return action
                action = self.occupy(tank, my_ai)
                if action:
                    return action

                if tank['cur_hex'] != self.defense_attack_point and self.can_move(tank, my_ai) and tank['weapon_cool_time'] == 0:
                    action = self.move(tank, self.defense_attack_point, my_ai,number = 1)
                    if action:
                        return action

                if tank['cur_hex'] == self.defense_attack_point and self.can_move(tank, my_ai) and tank['weapon_cool_time'] == 0:
                    action = self.hide(tank, my_ai)
                    if action:
                        return action

                if tank['cur_hex'] == self.defense_attack_point and self.can_move(tank, my_ai) and tank['weapon_cool_time'] != 0:
                    action = self.move(tank, self.defense_attack_point2, my_ai,number = 1)
                    if action:
                        return action

                if tank['cur_hex'] == self.defense_attack_point2 and self.can_move(tank, my_ai) and tank['weapon_cool_time ']== 0:
                    action = self.move(tank, self.defense_attack_point, my_ai,number = 1)
                    if action:
                        return action
                # action = self.hide(tank, my_ai)
                # if action:
                #     return action
            else:
                self.scout_attack_point = tank_msg['target_pos']
                action = self.shoot(tank, my_ai)
                if action:
                    return action
                action = self.occupy(tank, my_ai)
                if action:
                    return action
                if tank['cur_hex'] != self.scout_attack_point and self.can_move(tank, my_ai):
                    action = self.move(tank, self.scout_attack_point, my_ai,number = 1)
                    if action:
                        return action
                action = self.hide(tank, my_ai)
                if action:
                    return action
            return []

    def get_linjiehex(self,cur_hex):
        x = cur_hex // 100
        linjiehex = []
        if (x % 2 == 0):
            linjiehex.append(cur_hex + 1)
            linjiehex.append(cur_hex - 100)
            linjiehex.append(cur_hex - 99)
            linjiehex.append(cur_hex - 1)
            linjiehex.append(cur_hex + 99)
            linjiehex.append(cur_hex + 100)
        else:
            linjiehex.append(cur_hex + 1)
            linjiehex.append(cur_hex - 99)
            linjiehex.append(cur_hex - 100)
            linjiehex.append(cur_hex - 1)
            linjiehex.append(cur_hex + 100)
            linjiehex.append(cur_hex + 101)
        return linjiehex

    def calstack(self,my_ai,tank):
        cur_hex = tank['cur_hex']
        stack = 0
        for bop in my_ai.our_jiejutank:
            if bop['obj_id'] == cur_hex:
                stack = stack + 1
        print("stack===",stack)
        return stack

    def into_hunter(self, my_ai, operators):
        action = self.guide_shoot(operators, my_ai)
        if action:
            return action
        action = self.shoot(operators, my_ai)
        if action:
            return action
        action = self.occupy(operators, my_ai)
        if action:
            return action
        if operators['obj_id'] not in my_ai.controllable_ops:
            return None
        if operators['obj_id'] in my_ai.huntermove.keys():
            msg_body = my_ai.huntermove[operators['obj_id']]
            if len(msg_body["hexs"]) > 1:
                if operators['cur_hex'] == msg_body["hexs"][0]:
                    target_point = msg_body["hexs"][1]
                    action = self.move(operators, target_point, my_ai, number=1)


                    if action:
                        next_hex = action['move_path'][0]
                        msg_body["hexs"][0] = next_hex
                        if msg_body["hexs"][0] == msg_body["hexs"][1]:
                            msg_body["hexs"] = msg_body["hexs"][1:]
                        route = msg_body["hexs"]
                        # my_ai.huntermove = {}
                        return action
            else:
                del my_ai.huntermove[operators['obj_id']]
        return None

    def AIplushumantank(self,tank,my_ai):
        if tank['obj_id'] not in my_ai.controllable_ops:
            return None
        if tank['obj_id'] in my_ai.huntermove.keys():
            msg_body = my_ai.huntermove[tank['obj_id']]
            if len(msg_body["hexs"]) > 1:
                if tank['cur_hex'] == msg_body["hexs"][0]:
                    target_point = msg_body["hexs"][1]
                    action = self.move(tank, target_point, my_ai, number = 1)
                    if action:
                        next_hex = action['move_path'][0]
                        msg_body["hexs"][0] = next_hex
                        if msg_body["hexs"][0] == msg_body["hexs"][1]:
                            msg_body["hexs"] = msg_body["hexs"][1:]
                        route = msg_body["hexs"]
                        #my_ai.huntermove = {}
                        return action
            else:
                del my_ai.huntermove[tank['obj_id']]
        action = self.shoot(tank, my_ai)
        if action:
            return action
        action = self.occupy(tank, my_ai)
        if action:
            return action
        if my_ai.tankhideid == tank['obj_id']:
            action = self.hide(tank,my_ai)
            if action:
                my_ai.tankhideid = -1
                return action
        if my_ai.tankstopid == tank['obj_id']:
            action = self.stop(tank,my_ai)
            if action:
                my_ai.tankstopid = -1
                return action
        return None


class RedUnmannedVehicle(UnmannedVehicle):

    def __init__(self, bop, serial_number=0, group=0):
        super(RedUnmannedVehicle, self).__init__()
        assert self.sub_type == bop['sub_type']
        self.obj_id = bop['obj_id']
        self.serial_number = serial_number
        self.group = group
        self.second_attack_point = 0
        self.caninto = 0
        self.fork1 = -1
        self.fork2 = -1
        self.move_point = -1

        self.call_guide = []

    def get_first_attack_point(self, unmanned, my_ai, main_dis=[18,20], bop_dis=[1, 4]):
        pos_start = my_ai.hex_cache.get_circle(unmanned['cur_hex'], bop_dis[0], bop_dis[1])
        pos_main = my_ai.hex_cache.get_circle(my_ai.attack_point['o_main_attack'], main_dis[0], main_dis[1])
        circle = list(set(pos_start) & set(pos_main))
        if not circle:
            circle = pos_main
        ai = my_ai
        bop = unmanned
        be_see_type = const.BopType.Vehicle
        pos_tuple = circle
        center_int4 = my_ai.attack_point['e_main_attack']
        observe_point_dis = 0
        top_num = const.top_num
        select = const.select
        beta = const.beta
        kwargs = {'observed_point': 0,
                'observed_main': 1,
                  'maneuver_time': .3,
                  'maneuver_time_main': .8,
                  'hide_cond': 0,
                  'stack': 1,
                  'replay_be_attacked_ability': 1,
                  'replay_observe_ability' : .5}

        unmanned_end_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                              top_num,
                                              select, beta, **kwargs)
        return unmanned_end_int4
        #print("无人战车攻击点为：", self.first_attack_point)

    def get_second_attack_point(self, unmanned, my_ai):
        pos_start = my_ai.hex_cache.get_circle(unmanned['cur_hex'], 0, 3)
        ai = my_ai
        bop = unmanned
        be_see_type = const.BopType.Vehicle
        pos_tuple = pos_start
        center_int4 = my_ai.attack_point['e_main_attack']
        observe_point_dis = 0
        top_num = const.top_num
        select = const.select
        beta = const.beta
        kwargs = {'observed_ability': 2,
                  'maneuver_time': 0.4,
                  'maneuver_time_main': 0.1,
                  'hide_cond': 5,
                  'stack': 1,
                  'shoot_ability': 0,
                  'be_shoot_ability': 3,
                  'observe_enemy_ability': 1.5}

        unmanned_end_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                                  top_num, select, beta, **kwargs)
        #print("无人战车第二攻击点为：", unmanned_end_int4)
        return unmanned_end_int4

    def get_DT_attack_point(self, unmanned, my_ai, main_dis=[17, 19], bop_dis=[1, 5]):
        pos_start = my_ai.hex_cache.get_circle(unmanned['cur_hex'], bop_dis[0], bop_dis[1])
        pos_main = my_ai.hex_cache.get_circle(my_ai.attack_point['o_main_attack'], main_dis[0], main_dis[1])
        circle = list(set(pos_start) & set(pos_main))
        if not circle:
            circle = pos_main
        ai = my_ai
        bop = unmanned
        be_see_type = const.BopType.Vehicle
        pos_tuple = circle
        center_int4 = my_ai.attack_point['e_main_attack']
        observe_point_dis = 0
        top_num = const.top_num
        select = const.select
        beta = const.beta
        kwargs = {'observed_point': 0,
                  'observed_main': 1,
                  'maneuver_time': .3,
                  'maneuver_time_main': .8,
                  'hide_cond': 0,
                  'stack': 1,
                  'replay_be_attacked_ability': 1,
                  'replay_observe_ability': .5}

        unmanned_end_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                                  top_num,
                                                  select, beta, **kwargs)
        return unmanned_end_int4

    def get_DT2_attack_point(self, unmanned, my_ai, main_dis=[16,18], bop_dis=[1, 5]):
        pos_start = my_ai.hex_cache.get_circle(unmanned['cur_hex'], bop_dis[0], bop_dis[1])
        pos_main = my_ai.hex_cache.get_circle(my_ai.attack_point['o_main_attack'], main_dis[0], main_dis[1])
        circle = list(set(pos_start) & set(pos_main))
        if not circle:
            circle = pos_main
        ai = my_ai
        bop = unmanned
        be_see_type = const.BopType.Vehicle
        pos_tuple = circle
        center_int4 = my_ai.attack_point['e_main_attack']
        observe_point_dis = 0
        top_num = const.top_num
        select = const.select
        beta = const.beta
        kwargs = {'observed_city': 2,
                  'maneuver_time': 1,
                  'maneuver_time_main': .5,
                  'hide_cond': 1.5,
                  'stack': 0,
                  'shoot_ability': 0,
                  'be_shoot_ability': 4,
                  'observe_enemy_ability': 3}

        unmanned_end_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                              top_num,
                                              select, beta, **kwargs)
        print("无人战车第二攻击点为：", unmanned_end_int4)
        return unmanned_end_int4

    def get_protect_point(self, unmanned, my_ai):
        pos_start = my_ai.hex_cache.get_circle(unmanned['cur_hex'], 0, 1)

        ai = my_ai
        bop = unmanned
        be_see_type = const.BopType.Vehicle
        pos_tuple = pos_start
        center_int4 = my_ai.attack_point['e_main_attack']
        observe_point_dis = 0
        top_num = const.top_num
        select = const.select
        beta = const.beta
        kwargs = {'observed_second': -0.7,
                  'hide_cond': 1,
                  'stack': 0.5,
                  'be_shoot_ability': 1}

        unmanned_end_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                                  top_num,
                                                  select, beta, **kwargs)
        print("无人战车保卫点为：", unmanned_end_int4)
        return unmanned_end_int4

    def DTMiddleFarAttack(self, my_ai, action_bops):
        return self.DTmiddlefarattack(my_ai, action_bops)

    def DT2MiddleFarAttack(self, my_ai, action_bops):
        return self.DTmiddlefarattack(my_ai, action_bops)

    def MiddleFarAttack(self, my_ai, action_bops):
        unmanned = self.get_bop(my_ai)
        if unmanned:
            # if not hasattr(self, 'second_attack_point'):
            #     self.get_second_attack_point(unmanned, ai_group)

            # 无人战车能够射击时立即射击， 优先引导射击
            action = self.guide_shoot(unmanned, my_ai)
            if action:
                return action
            action = self.shoot(unmanned, my_ai)
            if action:
                return action

            if self.see_enemy(unmanned):# and self.can_move(unmanned, ai_group):
                be_shoot_ability = my_ai.enemy_predict.be_attacked_ability(unmanned, [unmanned['cur_hex']], my_ai)
                if be_shoot_ability < 0.6:
                    ubops = common.get_see_enemy(unmanned, my_ai.enemy_bops)
                    for ubop in ubops:
                        if ubop['type'] == const.BopType.Vehicle:
                            self.call_guide = [ubop for ubop in ubops if ubop['type'] == const.BopType.Vehicle]
                            action = self.stop(unmanned, my_ai)
                            if action:
                                return action
                else:
                    action = self.move_hide(unmanned, my_ai)
                    if action:
                        return action
            else:
                self.call_guide = []

            if not self.see_enemy(unmanned) and self.can_move(unmanned, my_ai) and self.wait_time <= 0:
                second_attack_point = self.get_observe_point(unmanned, my_ai, dis=4)
                if second_attack_point == unmanned['cur_hex']:
                    self.wait_time = 20
                kwargs = {'beta': 1.5,
                          'hide_cond': 0.3,
                          'shoot_ability': 0,
                          'be_shoot_ability': 1,
                          'be_shoot_ability_aircraft': 0,
                          'observe_enemy_ability': 0,
                          'be_observed_enemy_ability': 0.5}
                action = self.hide_move(unmanned, second_attack_point, my_ai, danger_stop=True, danger_value=0.3,
                                        **kwargs)
                if action:
                    return action
                else:
                    self.wait_time = 20
            action = self.hide(unmanned, my_ai)
            if action:
                return action

            self.wait_time -= 1
        return list()

    def DTmiddlefarattack(self, my_ai, action_bops):
        unmanned = self.get_bop(my_ai)
        if unmanned:
            # if not hasattr(self, 'second_attack_point'):
            #     self.get_second_attack_point(unmanned, ai_group)

            # 无人战车能够射击时立即射击， 优先引导射击
            action = self.guide_shoot(unmanned, my_ai)
            if action:
                return action
            action = self.shoot(unmanned, my_ai)
            if action:
                return action

            if self.see_enemy(unmanned):
                be_shoot_ability = my_ai.enemy_predict.be_attacked_ability(unmanned, [unmanned['cur_hex']], my_ai)
                if be_shoot_ability < 0.5:
                    ubops = common.get_see_enemy(unmanned, my_ai.enemy_bops)
                    for ubop in ubops:
                        if ubop['type'] == const.BopType.Vehicle:
                            self.call_guide = [ubop for ubop in ubops if ubop['type'] == const.BopType.Vehicle]
                            action = self.stop(unmanned, my_ai)
                            if action:
                                return action
                else:
                    action = self.move_hide(unmanned, my_ai)
                    if action:
                        return action
            else:
                self.call_guide = []

            if not self.see_enemy(unmanned) and self.can_move(unmanned, my_ai) and self.wait_time <= 0:
                second_attack_point = self.get_second_attack_point(unmanned, my_ai)
                if second_attack_point == unmanned['cur_hex']:
                    self.wait_time = 80
                kwargs = {'beta': 3,
                          'hide_cond': 0.3,
                          'shoot_ability': 0,
                          'be_shoot_ability': 1,
                          'be_shoot_ability_aircraft': 0,
                          'observe_enemy_ability': 0,
                          'be_observed_enemy_ability': 0.5}
                action = self.hide_move(unmanned, second_attack_point, my_ai, danger_stop=True, danger_value=0.3, **kwargs)
                if action:
                    return action
                else:
                    self.wait_time = 40
            action = self.hide(unmanned, my_ai)
            if action:
                return action
            self.wait_time -= 1
        return list()

    def FarAttack(self, my_ai, action_bops):
        return self.MoveAttack(my_ai)

    def DTFarAttack(self, my_ai, action_bops):
        unmanned = self.get_bop(my_ai)
        if unmanned:
            if not hasattr(self, 'first_attack_point'):
                self.first_attack_point = self.get_DT_attack_point(unmanned, my_ai, main_dis=[13, 20], bop_dis=[0, 18])

            # 无人战车能够射击时立即射击， 优先引导射击
            action = self.guide_shoot(unmanned, my_ai)
            if action:
                return action
            action = self.shoot(unmanned, my_ai)
            if action:
                return action

            if self.see_enemy(unmanned):  # and self.can_move(unmanned, ai_group):
                be_shoot_ability = my_ai.enemy_predict.be_attacked_ability(unmanned, [unmanned['cur_hex']], my_ai)
                if be_shoot_ability < 0.6:
                    ubops = common.get_see_enemy(unmanned, my_ai.enemy_bops)
                    for ubop in ubops:
                        if ubop['type'] == const.BopType.Vehicle and 0 < ubop['move_to_stop_remain_time'] < 75:
                            self.call_guide = [ubop for ubop in ubops if ubop['type'] == const.BopType.Vehicle]
                            action = self.stop(unmanned, my_ai)
                            if action:
                                return action
                else:
                    action = self.move_hide(unmanned, my_ai)
                    if action:
                        return action
            else:
                self.call_guide = []

            if unmanned['cur_hex'] != self.first_attack_point:
                action = self.move(unmanned, self.first_attack_point, my_ai)
                if action:
                    return action

            action = self.hide(unmanned, my_ai)
            if action:
                return action
        return None

    def DT2FarAttack(self, my_ai, action_bops):
        unmanned = self.get_bop(my_ai)
        if unmanned:
            if not hasattr(self, 'first_attack_point1'):
                self.first_move = True
                self.first_attack_point1 = self.get_DT2_attack_point(unmanned, my_ai, main_dis=[13,13], bop_dis=[6, 6])

            action = self.guide_shoot(unmanned, my_ai)
            if action:
                return action
            action = self.shoot(unmanned, my_ai)
            if action:
                return action

            if self.see_enemy(unmanned):# and self.can_move(unmanned, ai_group):
                be_shoot_ability = my_ai.enemy_predict.be_attacked_ability(unmanned, [unmanned['cur_hex']], my_ai)
                if be_shoot_ability < 0.6:
                    ubops = common.get_see_enemy(unmanned, my_ai.enemy_bops)
                    for ubop in ubops:
                        if ubop['type'] == const.BopType.Vehicle:
                            self.call_guide = [ubop for ubop in ubops if ubop['type'] == const.BopType.Vehicle]
                            action = self.stop(unmanned, my_ai)
                            if action:
                                return action
                else:
                    action = self.move_hide(unmanned, my_ai)
                    if action:
                        return action
            else:
                self.call_guide = []

            if self.first_move:
                if unmanned['cur_hex'] != self.first_attack_point1:
                    action = self.move(unmanned, self.first_attack_point1, my_ai)
                    if action:
                        self.first_move = False
                        return action

        else:
            return list()

    def MoveAttack(self, my_ai):
        unmanned = self.get_bop(my_ai)
        if unmanned:
            if not hasattr(self, 'first_attack_point'):
                self.get_first_attack_point(unmanned, my_ai)

            # 无人战车能够射击时立即射击， 优先引导射击
            action = self.guide_shoot(unmanned, my_ai)
            if action:
                return action
            action = self.shoot(unmanned, my_ai)
            if action:
                return action

            if unmanned['cur_hex'] != self.first_attack_point:
                action = self.move(unmanned, self.first_attack_point, my_ai)
                if action:
                    return action
            action = self.hide(unmanned, my_ai)
            if action:
                return action
        return list()

    def HRFarAttack(self, my_ai,action_bops):
        return self.newpolicy(my_ai)
        unmanned = self.get_bop(my_ai)
        if unmanned:
            action = self.fork(unmanned, my_ai)
            if action:
                return action
            if self.fork1 == -1 and unmanned['cur_hex'] == 2238 and unmanned['obj_id'] != 72:
                self.fork1 = unmanned['obj_id']
            if self.fork2 == -1 and unmanned['cur_hex'] == 3244 and unmanned['obj_id'] != 73:
                self.fork2 = unmanned['obj_id']
            if not hasattr(self, 'first_attack_point'):
                if unmanned["obj_id"] == 72:
                    self.first_attack_point  = 2238
                elif unmanned["obj_id"] == 73:
                    self.first_attack_point = 3344
                elif unmanned["obj_id"] == my_ai.unveid1:
                    self.first_attack_point = 2547
                elif unmanned["obj_id"] == my_ai.unveid2:
                    self.first_attack_point = 2544
                elif unmanned["obj_id"] == self.fork1:
                    self.first_attack_point = 1928
                else:
                    self.first_attack_point = 3541
            if unmanned['cur_hex'] != self.first_attack_point and self.caninto == 0:
                action = self.move(unmanned, self.first_attack_point, my_ai)
                if action:
                    return action

            if unmanned['cur_hex'] == self.first_attack_point and self.caninto == 0:
                action = self.hide(unmanned,my_ai)
                if action:
                    self.caninto = 1
                    return action


            # 无人战车能够射击时立即射击， 优先引导射击
            action = self.guide_shoot(unmanned, my_ai)
            if action:
                return action
            action = self.shoot(unmanned, my_ai)
            if action:
                return action
            if self.caninto == 1:
                return self.into_hunter(my_ai, unmanned)

        return list()

    def HRMiddleFarAttack(self, my_ai,action_bops):
        return self.newpolicy(my_ai)
        unmanned = self.get_bop(my_ai)
        if unmanned:
            if self.caninto == 1:
                return self.into_hunter(my_ai, unmanned)
            # if not hasattr(self, 'second_move'):
            #     second_move = 0
            #     if unmanned["obj_id"] == 26:
            #         second_move = 2238
            #     elif unmanned["obj_id"] == 400:
            #         second_move = 2339
            #     else:
            #         second_move = 2137
            #     if (second_move != 0) and (unmanned['cur_hex'] != second_move):
            #         action = self.move(unmanned, second_move, my_ai)
            #         if action:
            #             self.second_move = second_move
            #             return action

            # 无人战车能够射击时立即射击， 优先引导射击
            action = self.guide_shoot(unmanned, my_ai)
            if action:
                return action
            action = self.shoot(unmanned, my_ai)
            if action:
                return action

            action = self.hide(unmanned, my_ai)
            if action:
                return action

        return list()

    def HROccupying(self, my_ai,action_bops):
        return self.newpolicy(my_ai)
        unmanned = self.get_bop(my_ai)
        if unmanned:
            if self.caninto == 1:
                return self.into_hunter(my_ai, unmanned)
            if my_ai.UnmannedVehicle:
                if not my_ai.UV_not_exe:
                    return self.final_defense(my_ai,action_bops)
                else:
                    task = my_ai.UnmannedVehicle
                    if task['mission_type'] == 0:
                        my_ai.UV_not_exe = False
                        if task['target_pos']:
                            return self.final_attack(my_ai,action_bops,task['target_pos'])
                        else:
                            return self.final_attack(my_ai, action_bops)
                    elif task['mission_type'] == 1:
                        if task['target_pos']:
                            return self.final_run(my_ai,action_bops,task['target_pos'])
                        else:
                            return self.final_run(my_ai, action_bops)
            else:
                return self.HRMiddleFarAttack(my_ai,action_bops)
            return list()

    def newpolicy(self,my_ai):
        unmanned = self.get_bop(my_ai)
        if unmanned:
            action = self.guide_shoot(unmanned, my_ai)
            if action:
                return action
            action = self.shoot(unmanned, my_ai)
            if action:
                return action
            action = self.occupy(unmanned,my_ai)
            if action:
                return action
            bop_id = unmanned["obj_id"]
            if (bop_id == 72):
                if self.caninto == 1:
                    return self.into_hunter(my_ai, unmanned)
                if unmanned['cur_hex'] == 2743 and self.move_point == -1:
                    self.move_point = 2741
                if unmanned['cur_hex'] != self.move_point:
                    action = self.move(unmanned, self.move_point, my_ai, number=1, route_mode=2)
                    if action:
                        return action
                if unmanned['cur_hex'] == 2741:
                    self.move_point = 2733
                if unmanned['cur_hex'] == 2733:
                    self.move_point = 3529
                if unmanned['cur_hex'] == 3529:
                    self.caninto = 1

            if (bop_id == 73):
                if my_ai.time == 1:
                    self.caninto = 0
                    self.move_point = 4142
                elif my_ai.time == 450:
                    self.caninto = 0
                    self.move_point = 4241
                elif my_ai.time == 650:
                    self.caninto = 0
                    self.move_point = 4238
                elif my_ai.time == 900:
                    self.caninto = 0
                    self.move_point = 4332
                elif my_ai.time == 1350:
                    self.caninto = 0
                    self.move_point = 4029
                if unmanned['cur_hex'] != self.move_point and self.caninto == 0 and self.move_point != -1:
                    action = self.move(unmanned, self.move_point, my_ai, number=1)
                    if action:
                        self.caninto = 0
                        return action
                if unmanned['cur_hex'] == self.move_point:
                    self.caninto = 1
                if self.caninto == 1:
                    return self.into_hunter(my_ai, unmanned)

            if (bop_id == my_ai.uveid_400):
                if self.caninto == 1:
                    return self.into_hunter(my_ai, unmanned)
                if unmanned['cur_hex'] == 2843 and self.move_point == -1:
                    self.move_point = 3844
                if unmanned['cur_hex'] != self.move_point:
                    action = self.move(unmanned, self.move_point, my_ai, number=1, route_mode=2)
                    if action:
                        return action
                if unmanned['cur_hex'] == 3844:
                    self.move_point = 5147
                if unmanned['cur_hex'] == 5147:
                    self.move_point = 5325
                if unmanned['cur_hex'] == 5325:
                    self.move_point = 5323
                if unmanned['cur_hex'] == 5323:
                    self.move_point = 5320
                if unmanned['cur_hex'] == 5320:
                    self.move_point = 5319
                if unmanned['cur_hex'] == 5319 :
                    self.caninto = 1

        return list()

    def final_attack(self,my_ai,action_bops,final_hex = None):
        unmanned = self.get_bop(my_ai)
        if unmanned:
            action = self.guide_shoot(unmanned, my_ai)
            if action:
                return action
            action = self.shoot(unmanned, my_ai)
            if action:
                return action
            if not hasattr(self, 'final_hide_point'):
                if final_hex:
                    self.final_hide_point = final_hex
                else:
                    self.final_hide_point = self.get_first_attack_point(unmanned, my_ai,main_dis=[10,15], bop_dis=[1, 10])
            if unmanned['cur_hex'] != self.final_hide_point:
                action = self.move(unmanned, self.final_hide_point, my_ai)
                if action:
                    return action
        return list()

    def final_run(self,my_ai,action_bops,final_hex = None):
        unmanned = self.get_bop(my_ai)
        if unmanned:
            action = self.guide_shoot(unmanned, my_ai)
            if action:
                return action
            action = self.shoot(unmanned, my_ai)
            if action:
                return action
            if not hasattr(self, 'final_hide_point'):
                if final_hex:
                    self.final_hide_point = final_hex
                else:
                    self.final_hide_point = 1050
            if unmanned['cur_hex'] != self.final_hide_point:
                action = self.move(unmanned, self.final_hide_point, my_ai)
                if action:
                    return action
        return list()

    def final_defense(self,my_ai,action_bops):
        unmanned = self.get_bop(my_ai)
        if unmanned:
            action = self.guide_shoot(unmanned, my_ai)
            if action:
                return action
            action = self.shoot(unmanned, my_ai)
            if action:
                return action
            action = self.hide(unmanned, my_ai)
            if action:
                return action
        return list()

    def into_hunter(self,my_ai,operators):
        action = self.guide_shoot(operators, my_ai)
        if action:
            return action
        action = self.shoot(operators, my_ai)
        if action:
            return action
        action = self.occupy(operators, my_ai)
        if action:
            return action
        if operators['obj_id'] not in my_ai.controllable_ops:
            return None
        if operators['obj_id'] in my_ai.huntermove.keys():
            msg_body = my_ai.huntermove[operators['obj_id']]
            if len(msg_body["hexs"]) > 1:
                if operators['cur_hex'] == msg_body["hexs"][0]:
                    target_point = msg_body["hexs"][1]
                    action = self.move(operators, target_point, my_ai, number = 1)


                    if action:
                        next_hex = action['move_path'][0]
                        msg_body["hexs"][0] = next_hex
                        if msg_body["hexs"][0] == msg_body["hexs"][1]:
                            msg_body["hexs"] = msg_body["hexs"][1:]
                        route = msg_body["hexs"]
                        #my_ai.huntermove = {}
                        return action
            else:
                del my_ai.huntermove[operators['obj_id']]
        return None

class RedUAV(UAV):
    def __init__(self, bop, serial_number=0, group=0):
        super(RedUAV, self).__init__()
        assert self.sub_type == bop['sub_type']
        self.obj_id = bop['obj_id']
        self.serial_number = serial_number
        self.group = group
        self.last_observe_point = []
        self.round_hexes = None
        self.through_mark_point = 0
        self.allow_new_tarhex = True

    # # 夺控点右侧
    # def get_first_attack_point1(self, uav, my_ai, main_dis=[9,11], bop_dis=[17, 18]):
    #
    #
    #     unmanned_end_int4 =  np.random.choice([3540, 3541, 3642, 3643, 3644])
    #
    #     # print("蓝方无人机侦查点为：", self.first_attack_point)
    #     return unmanned_end_int4
    #
    # # 夺控点下侧
    # def get_first_attack_point2(self, uav, my_ai, main_dis=[9,11], bop_dis=[17, 18]):
    #
    #     unmanned_end_int4 = np.random.choice([4428, 4527, 4528, 4529, 4628, 4726])
    #     # print("蓝方无人机侦查点为：", self.first_attack_point)
    #     return unmanned_end_int4
    #
    # # 夺控点左侧
    # def get_first_attack_point3(self, uav, my_ai, main_dis=[9,11], bop_dis=[17, 18]):
    #
    #     unmanned_end_int4 = np.random.choice([3320, 3321, 3322])
    #     # print("蓝方无人机侦查点为：", self.first_attack_point)
    #     return unmanned_end_int4


    # 夺控点右侧
    def get_first_attack_point1(self, uav, my_ai, main_dis=[9,11], bop_dis=[17, 18]):


        unmanned_end_int4 =  np.random.choice([3627, 3727])

        # print("蓝方无人机侦查点为：", self.first_attack_point)
        return unmanned_end_int4

    # 夺控点下侧
    def get_first_attack_point2(self, uav, my_ai, main_dis=[9,11], bop_dis=[17, 18]):

        unmanned_end_int4 = np.random.choice([3928])
        # print("蓝方无人机侦查点为：", self.first_attack_point)
        return unmanned_end_int4

    # 夺控点左侧
    def get_first_attack_point3(self, uav, my_ai, main_dis=[9,11], bop_dis=[17, 18]):

        unmanned_end_int4 = np.random.choice([3527, 3427, 3428, 3528])
        # print("蓝方无人机侦查点为：", self.first_attack_point)
        return unmanned_end_int4


    def get_attack_point(self, UAV, my_ai):
        enemy_probably = my_ai.enemy_predict.enemy_predict_sum(my_ai, sub_type=const.BopName.Vehicle)
        if not enemy_probably.all():
            enemy_probably = my_ai.enemy_predict.enemy_predict_sum(my_ai, sub_type=const.BopName.ScoutVehicle)
        if not enemy_probably.all():
            enemy_probably = my_ai.enemy_predict.enemy_predict_sum(my_ai, sub_type=const.BopName.Tank)
        if not enemy_probably.all():
            enemy_probably = my_ai.enemy_predict.enemy_predict_sum(my_ai, sub_type=const.BopName.Soldier)
        index_flatten = np.argsort(enemy_probably, axis=None)[-1]
        index_tuple = (index_flatten // my_ai.my_map.size[1], index_flatten % my_ai.my_map.size[1])
        index_int4 = com.cvtOffset2Int4loc(index_tuple)
        return index_int4

    def get_observe_point(self, UAV, my_ai):
        ubops_record = [ubop_record for ubop_id, ubop_record in my_ai.enemy_predict.ubops_record.items() if
                        ubop_record['live'] and not ubop_record['be_see']]

        if ubops_record:
            ubop_record = random.choice(ubops_record)
            ubop_pos = copy.deepcopy(ubop_record['pos_predict'])
        else:
            ubop_pos = np.zeros(my_ai.my_map.size)

        if not self.see_enemy(UAV):
            self.last_observe_point.extend(my_ai.hex_cache.get_circle(UAV['cur_hex'], 0, 2))
            self.last_observe_point = list(set(self.last_observe_point))

        ubop_pos[tuple(zip(*self.last_observe_point))] = 0
        index_flatten = np.argmax(ubop_pos, axis=None)
        index_tuple = (index_flatten // my_ai.my_map.size[1], index_flatten % my_ai.my_map.size[1])
        index_int4 = com.cvtOffset2Int4loc(index_tuple)
        # print(index_int4)
        if com.get_distance(index_int4, my_ai.attack_point['o_main_attack']) >= 7 or \
                com.get_distance(index_int4, my_ai.attack_point['o_second_attack']) >= 7:
            if ubops_record:
                # 求当前可观察点
                observe_hexes = []
                for bop in my_ai.our_bops:
                    if bop['type'] != const.BopType.Aircraft:
                        bop_LOS = my_ai.see.get_see_LOS(common.get_see_source(bop['type']),
                                                        const.BopType.Vehicle, bop['cur_hex'])
                        rows, cols = np.where(bop_LOS == True)
                        observe_hexes.extend(list(zip(rows, cols)))
                observe_hexes = list(set(observe_hexes))

                if not self.round_hexes:
                    round_main = my_ai.hex_cache.get_circle(my_ai.attack_point['o_main_attack'], 0, 3)
                    round_second = my_ai.hex_cache.get_circle(my_ai.attack_point['o_second_attack'], 0, 3)
                    self.round_hexes = list(set(round_main) | set(round_second))

                observe_hexes = list(set(self.round_hexes) - set(self.last_observe_point) - set(observe_hexes))
                if not observe_hexes or my_ai.time > 1350:
                    # self.last_observe_point = []
                    index_int4 = random.choice([my_ai.attack_point['o_main_attack'], my_ai.attack_point['o_second_attack']])
                else:
                    index_hex = random.choice(observe_hexes)
                    index_int4 = com.cvtOffset2Int4loc(index_hex)
            else:
                enemy_pos = [ubop['cur_hex'] for ubop in my_ai.enemy_bops]
                if enemy_pos:
                    index_int4 = random.choice(enemy_pos)
                else:
                    index_int4 = UAV['cur_hex']
        return index_int4


    def stop_and_shoot(self, UAV, my_ai):
        # 看到敌人立即停止机动
        if self.see_enemy(UAV):
            action = self.stop(UAV, my_ai)
            if action:
                return action
            action = self.shoot(UAV, my_ai)
            if action:
                return action
        return list()

    # 跟踪射击，当看到敌人的特定棋子后，立即停止
    # 20221103被替换
    # def trace_guide(self, UAV, my_ai, sub_type_list):
    #     action = self.guide_shoot(UAV, my_ai)
    #     if action:
    #         print('发生红方无人机引导射击动作')
    #         return action
    #
    #
    #     e_bops = []
    #     if sub_type_list != None:    # 明确了需要打击的算子类型，0：坦克，1：战车
    #         for sub_type in sub_type_list:
    #             e_bops += common.get_bop_sub_type_under_see(my_ai.enemy_bops, sub_type,
    #                                                    UAV['see_enemy_bop_ids'])
    #         if 0 in [bop['sub_type'] for bop in my_ai.enemy_bops] or 1 in [bop['sub_type'] for bop in my_ai.enemy_bops]:
    #             if not hasattr(self, 'chasing_tar_hex'):
    #                 try:
    #                     self.chasing_tar_hex = common.get_bop_sub_type(my_ai.enemy_bops, 0)[0]['cur_hex']
    #                 except:
    #                     self.chasing_tar_hex = common.get_bop_sub_type(my_ai.enemy_bops, 1)[0]['cur_hex']
    #             # 若无人机看到蓝方坦克或车辆立即停止机动，能停就停
    #             if 0 in [bop['sub_type'] for bop in my_ai.enemy_bops if
    #                      bop['obj_id'] in UAV['see_enemy_bop_ids']] or 1 in [bop['sub_type'] for bop in
    #                                                                          my_ai.enemy_bops
    #                                                                          if
    #                                                                          bop['obj_id'] in UAV[
    #                                                                              'see_enemy_bop_ids']]:
    #                 if hasattr(self, 'chasing_chance'): # 下次继续追该目标
    #                     delattr(self, 'chasing_chance')
    #                 self.chasing_tar_hex = [bop['cur_hex'] for bop in my_ai.enemy_bops if
    #                                         bop['obj_id'] in UAV['see_enemy_bop_ids']][0]
    #                 action = self.stop(UAV, my_ai)
    #                 self.middle_point_crusier = 0
    #                 if action:
    #                     return action
    #             # 追踪。当前无人机能自己看到的敌方棋子优先。无人机已经停下，正在停下
    #             if [bop['cur_hex'] for bop in e_bops if bop['obj_id'] in UAV['see_enemy_bop_ids']]:
    #
    #                 follow_point = [bop['cur_hex'] for bop in e_bops if bop['obj_id'] in UAV['see_enemy_bop_ids']][0]
    #                 self.chasing_tar_hex = follow_point
    #                 if self.middle_point_crusier == 1:
    #                     self.middle_point_crusier = 0
    #                     action = self.stop(UAV, my_ai)
    #                     if action:
    #                         return action
    #             else:   # 追踪。我方其他算子看到的敌方棋子。
    #                 try:
    #                     follow_point = common.get_bop_sub_type(my_ai.enemy_bops, 0)[0]['cur_hex']  # todo 选择最近的坦克，未完成
    #                 except:
    #                     follow_point = common.get_bop_sub_type(my_ai.enemy_bops, 1)[0]['cur_hex']  # todo 选择最近的战车，未完成
    #                 self.chasing_tar_hex = follow_point
    #                 if self.middle_point_crusier == 1:
    #                     self.middle_point_crusier = 0
    #                     action = self.stop(UAV, my_ai)
    #                     if action:
    #                         return action
    #                     else:
    #                         self.middle_point_crusier = 0   # 已经停下
    #             # 红方其他算子看到对方坦克、车辆，红方无人机停止时间内，不能返回空，要返回'stay_still'
    #             self.chasing_tar_hex = follow_point
    #             if com.get_distance(UAV['cur_hex'], follow_point) == 0:
    #                 return 'stay_still'
    #             elif com.get_distance(UAV['cur_hex'], follow_point) <= 3:
    #                 action = self.move(UAV, follow_point, my_ai, number=1)
    #                 if action:
    #                     return action
    #                 else:
    #                     return 'stay_still'
    #             else:
    #                 action = self.move(UAV, follow_point, my_ai, number=5)
    #                 if action:
    #                     return action
    #                 else:
    #                     return 'stay_still'
    #         else:
    #             # 看不到敌方算子，曾经看到过，不知道敌方是否活着，
    #             # 如果没有其他敌方算子，去算子最近一次出现的位置（消失的位置）,只去一次
    #             # if hasattr(self, 'chasing_tar_hex'):  # todo 敌方算子是否存活,未完成
    #             #     if not hasattr(self, 'chasing_chance'):
    #             #         self.chasing_chance = 1
    #             #         follow_point =  (self.chasing_tar_hex//100*2 - UAV['cur_hex']//100)*100 +  (self.chasing_tar_hex%100*2 - UAV['cur_hex']%100)
    #             #         return self.move(UAV, follow_point, my_ai, number=4)
    #             if not hasattr(self, 'chasing_chance'):
    #                 if hasattr(self, 'chasing_tar_hex'):  # todo 敌方算子是否存活,未完成
    #                     self.chasing_chance = 1
    #                     follow_point =(self.chasing_tar_hex//100*2 - UAV['cur_hex']//100)*100 +  (self.chasing_tar_hex%100*2 - UAV['cur_hex']%100)
    #                     return self.move(UAV, follow_point, my_ai, number=4)
    #             else:
    #                 self.chasing_chance = 0
    #                 # self.middle_point_crusier = 1
    #                 delattr(self, 'chasing_chance')
    #
    #                 observe_point = self.get_observe_point(UAV, my_ai)
    #                 if com.get_distance(UAV['cur_hex'], observe_point) <= 3:
    #                     return self.move(UAV, observe_point, my_ai, number=1)  # 1格1格走
    #                 else:
    #                     return self.move(UAV, observe_point, my_ai, number=5)
    #                 return None  # 去下一个巡逻点
    def partener_guided_UAV_move(self, bop, destination_int4, my_ai, number=None):
        move_actions = common.get_bop_action_id_name(my_ai.observation['valid_actions'], bop['obj_id'],
                                                     const.ActionType.Move)
        if move_actions and bop and bop['cur_hex'] != destination_int4:
            move_type = self.get_move_type(bop)
            march_mode = self.is_march_mode(move_type)
            # route = my_ai.map.gen_move_route(bop['cur_hex'], destination_int4, move_type)
            route = astar(bop, bop['cur_hex'], destination_int4, my_ai, time_mode=True, no_pass=my_ai.land_marks,
                          march_mode=march_mode, maxsteps=2000)

            if my_ai.map.basic[destination_int4//100][destination_int4%100]['cond'] in [1,2]:
                number = -1
            else:
                number = -2

            if route:
                if number:
                    if len(route) > number:
                        route = route[0:number]
                ##更新我方未来位置，减小同格
                my_ai.enemy_predict.update_future_hex(bop['obj_id'], route[-1], my_ai)
                return {"actor": my_ai.seat,
                        'obj_id': bop['obj_id'],
                        'type': const.ActionType.Move,
                        'move_path': route,
                        }
        return None

    def trace_guide(self, UAV, my_ai, sub_type_list):
        action = self.guide_shoot(UAV, my_ai, [0, 1])
        if action:
            print('发生红方无人机引导射击动作')
            return action


        e_bops = []
        if sub_type_list != None:    # 明确了需要打击的算子类型，0：坦克，1：战车，4：无人战车
            for sub_type in sub_type_list:
                e_bops += common.get_bop_sub_type_under_see(my_ai.enemy_bops, sub_type,
                                                       UAV['see_enemy_bop_ids'])
            if 0 in [bop['sub_type'] for bop in my_ai.enemy_bops] or 1 in [bop['sub_type'] for bop in
                                                                           my_ai.enemy_bops]:
                # if not hasattr(self, 'chasing_tar_hex'):
                #     try:
                #
                #         self.chasing_tar_hex = common.get_bop_sub_type(my_ai.enemy_bops, 1)[0]['cur_hex']
                #
                #     except:
                #         self.chasing_tar_hex = common.get_bop_sub_type(my_ai.enemy_bops, 0)[0]['cur_hex']
                # 若无人机看到蓝方战车或无人战车或坦克立即停止机动，能停就停
                if 0 in [bop['sub_type'] for bop in my_ai.enemy_bops if
                         bop['obj_id'] in UAV['see_enemy_bop_ids']] or 1 in [bop['sub_type'] for bop in
                                                                             my_ai.enemy_bops
                                                                             if
                                                                             bop['obj_id'] in UAV[
                                                                                 'see_enemy_bop_ids']]:
                    if hasattr(self, 'chasing_chance'): # 下次继续追该目标
                        delattr(self, 'chasing_chance')
                    if hasattr(self, 'PartenerSeen_move_step_by_step'):
                        delattr(self, 'PartenerSeen_move_step_by_step')
                    if hasattr(self, 'UAV_pos_when_lost_tar'):
                        delattr(self, 'UAV_pos_when_lost_tar')
                    if hasattr(self, 'move_step_by_step'):
                        delattr(self, 'move_step_by_step')

                    self.chasing_tar_hex = [bop['cur_hex'] for bop in my_ai.enemy_bops if
                                            bop['obj_id'] in UAV['see_enemy_bop_ids'] if bop['sub_type'] in [0,1]][0]
                    # action = self.stop(UAV, my_ai)
                    self.allow_new_tarhex = False  # 如果无人机自己看到，则暂时不追其他目标
                    self.middle_point_crusier = 0
                    # if action:
                    #     return action
                    # else:
                    #     return 'stay_still'
                # 追踪。当前无人机能自己看到的敌方棋子优先。无人机已经停下，正在停下
                # 或无人机没看到，仅有我方其他棋子看到
                # if [bop['cur_hex'] for bop in e_bops if bop['obj_id'] in UAV['see_enemy_bop_ids']]:
                #     try:
                #         zhanche_hex = [bop['cur_hex'] for bop in e_bops if
                #                    bop['obj_id'] in UAV['see_enemy_bop_ids'] and bop['sub_type'] == 1][0]
                #     except:
                #         zhanche_hex = []
                #     # try:
                #     #     unmanned_viechle_hex = [bop['cur_hex'] for bop in e_bops if
                #     #                         bop['obj_id'] in UAV['see_enemy_bop_ids'] and bop['sub_type'] == 4][0]
                #     # except:
                #     #     unmanned_viechle_hex = []
                #     try:
                #         tank_hex = [bop['cur_hex'] for bop in e_bops if
                #                 bop['obj_id'] in UAV['see_enemy_bop_ids'] and bop['sub_type'] == 0][0]
                #     except:
                #         tank_hex = []
                #     if zhanche_hex:
                #         follow_point = zhanche_hex
                #     # elif unmanned_viechle_hex:
                #     #     follow_point = unmanned_viechle_hex
                #     elif tank_hex:
                #         follow_point = tank_hex
                #     self.chasing_tar_hex = follow_point
                #     # if self.middle_point_crusier == 1:
                #     self.middle_point_crusier = 0
                #     return 'stay_still'
                #     # action = self.stop(UAV, my_ai)
                #     # if action:
                #     #     return action
                else:   # 追踪。我方其他算子看到的敌方棋子。追新目标
                    # 无人机没有看到过棋子，或见到过棋子，但棋子挂了
                    if self.allow_new_tarhex == True:
                        if hasattr(self, 'PartenerSeen_move_step_by_step'):
                            delattr(self, 'PartenerSeen_move_step_by_step')

                        try:
                            # try:
                            follow_point = common.get_bop_sub_type(my_ai.enemy_bops, 1)[0]['cur_hex']  # todo 选择最近的战车，未完成
                            # except:
                            #     follow_point = common.get_bop_sub_type(my_ai.enemy_bops, 4)[0][
                            #         'cur_hex']  # todo 选择最近的无人车，未完成
                        except:
                            follow_point = common.get_bop_sub_type(my_ai.enemy_bops, 0)[0]['cur_hex']  # todo 选择最近的坦克，未完成
                        self.chasing_tar_hex = follow_point
                        if self.middle_point_crusier == 1:
                            self.middle_point_crusier = 0
                            action = self.stop(UAV, my_ai)
                            if action:
                                return action
                            else:
                                self.middle_point_crusier = 0   # 已经停下
                        # 红方其他算子看到对方坦克、车辆，蓝方无人车停止时间内，不能返回空，要返回'stay_still'
                        self.chasing_tar_hex = follow_point
                        if com.get_distance(UAV['cur_hex'], follow_point) == 0: # 其他棋子发现的，不会这么近
                            return 'stay_still'
                        elif com.get_distance(UAV['cur_hex'], follow_point) <= 3:
                            action = self.move(UAV, follow_point, my_ai, number=1)
                            if action:
                                return action
                            # else:
                            #     return 'stay_still'
                        else:
                            action = self.partener_guided_UAV_move(UAV, follow_point, my_ai, number=1)
                            if action:
                                return action
                            # else:
                            #     return 'stay_still'
                    # 无人机看到过棋子，且棋子没挂
                    else: # 无人机先追旧棋子，再追新棋子，期间不更新目标位置
                        # 防止停下的过程中，对方棋子就已经消失，浪费了追踪机会
                        # if my_ai.observation:
                        #     self.allow_new_tarhex = True
                        #     return None

                        if not hasattr(self, 'PartenerSeen_move_step_by_step'):
                            self.PartenerSeen_move_step_by_step = 0
                        if not hasattr(self, 'UAV_pos_when_lost_tar'):
                            self.UAV_pos_when_lost_tar =  UAV['cur_hex']

                        if self.PartenerSeen_move_step_by_step == 7:
                            # self.chasing_chance = 1
                            self.allow_new_tarhex == True
                            delattr(self, 'PartenerSeen_move_step_by_step')
                            delattr(self, 'UAV_pos_when_lost_tar')

                        if hasattr(self, 'PartenerSeen_move_step_by_step'):
                            print('RedUAV chases the once seen enemy inspite of the enemy seen by parterner move_step_by_step:', self.PartenerSeen_move_step_by_step)
                        # follow_point 必须要在地图尺度内
                        try:
                            assert (self.chasing_tar_hex // 100 * 2 - self.UAV_pos_when_lost_tar // 100) >= 0
                            assert (self.chasing_tar_hex // 100 * 2 - self.UAV_pos_when_lost_tar // 100) < my_ai.my_map.size[0]
                            assert (self.chasing_tar_hex % 100 * 2 - self.UAV_pos_when_lost_tar % 100) >= 0
                            assert (self.chasing_tar_hex % 100 * 2 - self.UAV_pos_when_lost_tar % 100) < my_ai.my_map.size[1]
                            follow_point = (self.chasing_tar_hex // 100 * 2 - self.UAV_pos_when_lost_tar // 100) * 100 + (
                                    self.chasing_tar_hex % 100 * 2 - self.UAV_pos_when_lost_tar % 100)



                            action = self.move(UAV, follow_point, my_ai, number=1)
                            if action:
                                self.PartenerSeen_move_step_by_step += 1
                                # return action
                            if UAV['cur_hex'] == follow_point:
                                self.allow_new_tarhex == True
                                delattr(self, 'PartenerSeen_move_step_by_step')
                                delattr(self, 'UAV_pos_when_lost_tar')

                            if action:
                                # self.PartenerSeen_move_step_by_step += 1
                                return action
                        except:
                            row = (self.chasing_tar_hex // 100 * 2 - self.UAV_pos_when_lost_tar // 100)
                            col = (self.chasing_tar_hex % 100 * 2 - self.UAV_pos_when_lost_tar % 100)
                            print('红方追踪地图外算子坐标——————————————————————————————')
                            if row <= 0:
                                row = 0
                            if row >= my_ai.my_map.size[0]:
                                row = my_ai.my_map.size[0] - 1
                            if col <= 0:
                                col = 0
                            if col >= my_ai.my_map.size[1]:
                                col = my_ai.my_map.size[1] - 1

                            if UAV['cur_hex'] == row * 100 + col:
                                self.allow_new_tarhex == True
                                delattr(self, 'PartenerSeen_move_step_by_step')
                                delattr(self, 'UAV_pos_when_lost_tar')
                            action = self.move(UAV, row * 100 + col, my_ai, number=1)
                            if action:
                                self.PartenerSeen_move_step_by_step += 1
                                return action
            else:
                # 看不到敌方算子，曾经看到过，不知道敌方是否活着，
                # 如果没有其他敌方算子，去算子最近一次出现的位置（消失的位置）,只去一次
                # if hasattr(self, 'chasing_tar_hex'):  # todo 敌方算子是否存活,未完成
                #     if not hasattr(self, 'chasing_chance'):
                #         self.chasing_chance = 1
                #         follow_point =  (self.chasing_tar_hex//100*2 - UAV['cur_hex']//100)*100 +  (self.chasing_tar_hex%100*2 - UAV['cur_hex']%100)
                #         return self.move(UAV, follow_point, my_ai, number=4)
                if not hasattr(self, 'chasing_chance'):
                    # 初始巡逻阶段，还能追，没目标。返回空，继续进行后续巡逻
                    if hasattr(self, 'chasing_tar_hex'):  # todo 敌方算子是否存活,未完成
                        # 停下的过程中，对方棋子就已经消失，浪费了追踪机会
                        if not hasattr(self, 'move_step_by_step'):
                            self.move_step_by_step = 0
                        if not hasattr(self, 'UAV_pos_when_lost_tar'):
                            self.UAV_pos_when_lost_tar = UAV['cur_hex']
                        if self.move_step_by_step == 7:
                            self.chasing_chance = 1
                            delattr(self, 'move_step_by_step')
                        # print('RedUAV move_step_by_step:', self.move_step_by_step)
                        # follow_point 必须要在地图尺度内
                        try:
                            assert (self.chasing_tar_hex // 100 * 2 - self.UAV_pos_when_lost_tar // 100)>=0
                            assert (self.chasing_tar_hex // 100 * 2 - self.UAV_pos_when_lost_tar // 100)< my_ai.my_map.size[0]
                            assert (self.chasing_tar_hex%100*2 - self.UAV_pos_when_lost_tar%100)>=0
                            assert (self.chasing_tar_hex % 100 * 2 - self.UAV_pos_when_lost_tar % 100) < my_ai.my_map.size[1]
                            follow_point = (self.chasing_tar_hex // 100 * 2 - self.UAV_pos_when_lost_tar // 100) * 100 + (
                                        self.chasing_tar_hex % 100 * 2 - self.UAV_pos_when_lost_tar % 100)



                            action = self.move(UAV, follow_point, my_ai, number=1)
                            if action:
                                self.move_step_by_step += 1
                                # print('\n红方无人机和队友看不到敌方任何战车、坦克，向曾看到过目标位置机动')
                                # return action

                            if UAV['cur_hex'] == follow_point:
                                self.chasing_chance = 1
                                delattr(self, 'move_step_by_step')
                                delattr(self, 'UAV_pos_when_lost_tar')

                            if action:
                                # self.move_step_by_step += 1
                                # print('\n红方无人机和队友看不到敌方任何战车、坦克，向曾看到过目标位置机动')
                                return action

                            # return self.move(UAV, follow_point, my_ai, number=1)
                        except:
                            row = (self.chasing_tar_hex // 100 * 2 - UAV['cur_hex'] // 100)
                            col = (self.chasing_tar_hex % 100 * 2 - UAV['cur_hex'] % 100)
                            print('红方追踪地图外算子坐标——————————————————————————————')
                            if row <= 0:
                                row = 0
                            if row >= my_ai.my_map.size[0]:
                                row = my_ai.my_map.size[0]-1
                            if col <= 0:
                                col = 0
                            if col >= my_ai.my_map.size[1]:
                                col = my_ai.my_map.size[1]-1

                            action = self.move(UAV, row * 100 + col, my_ai, number=1)
                            if action:
                                self.move_step_by_step += 1
                                print('\n红方无人机和队友看不到敌方任何战车、坦克，向曾看到过目标位置机动')
                                return action
                else:
                    # self.chasing_chance = 0


                    observe_point = self.get_observe_point(UAV, my_ai)
                    if com.get_distance(UAV['cur_hex'], observe_point) <= 3:
                        action = self.move(UAV, observe_point, my_ai, number=1)  # 1格1格走
                        if action:
                            # delattr(self, 'move_step_by_step')
                            self.allow_new_tarhex = True
                            # self.middle_point_crusier = 1
                            delattr(self, 'chasing_chance')
                            return action  # 1格1格走
                    else:

                        action = self.move(UAV, observe_point, my_ai, number=1)
                        if action:
                            # delattr(self, 'move_step_by_step')
                            self.allow_new_tarhex = True
                            # self.middle_point_crusier = 1
                            delattr(self, 'chasing_chance')
                            return action  # 1格1格走

                    return None  # 去下一个巡逻点




    # def MoveAttack(self, my_ai):
    #     # todo 引导射击没加，加步兵的引导射击
    #     UAV = self.get_bop(my_ai)
    #     if UAV:
    #         # 与巡飞弹不同，只有一个无人机
    #         return self.Observe(UAV, my_ai)
    #         # if not hasattr(self, 'first_UAV'):
    #         #     self.get_first_UAV(UAV, my_ai)
    #         # if self.first_UAV:
    #         #     return self.Attack(UAV, my_ai, const.BopName.Vehicle)
    #         # else:
    #         #     return self.Observe(UAV, my_ai)
    #     else:
    #         return None
    def MoveAttack(self, my_ai):

        # todo 引导射击没加，加步兵的引导射击
        UAV = self.get_bop(my_ai)
        if UAV:
            if my_ai.UAVControl == 2:
                return self.into_hunter(my_ai, UAV)
            if hasattr(my_ai, 'UAVmsg'):
                if not hasattr(my_ai, 'last_processed_UAV_msg'): # 首次接收到人工干预的无人机机动命令
                    task = my_ai.UAVmsg
                    print('processing first UAVmsg')
                    # my_ai.last_processed_UAV_msg = my_ai.UAVmsg
                    return self.humancontrol(UAV, my_ai, task)

                elif hasattr(my_ai, 'last_processed_UAV_msg') and my_ai.last_processed_UAV_msg["target_pos"] != my_ai.UAVmsg["target_pos"]: # 处理过，但又来了新的
                    delattr(my_ai, 'last_processed_UAV_msg')
                    print('receive new UAVmsg, start process_________________________________________________________')
                    return None

            # 与巡飞弹不同，只有一个无人机
            return self.Observe(UAV, my_ai)
            # if not hasattr(self, 'first_UAV'):
            #     self.get_first_UAV(UAV, my_ai)
            # if self.first_UAV:
            #     return self.Attack(UAV, my_ai, const.BopName.Vehicle)
            # else:
            #     return self.Observe(UAV, my_ai)
        else:
            return None

    def humancontrol(self, UVA, my_ai, task):
        if task['target_pos']:
            goal_hex = task['target_pos']
        else:
            goal_hex = my_ai.attack_point['o_main_attack']
        # action = self.stop(UAV, my_ai)
        # if action:
        #     return action

        if UVA['cur_hex'] != goal_hex:
            action = self.move(UVA, goal_hex, my_ai)
            if action:
                # my_ai.UAVmsg = {}
                return action
        else:
            my_ai.last_processed_UAV_msg = task
            print('first UAVmsg processed')

        return None


    def into_hunter(self, my_ai, operators):
        action = self.guide_shoot(operators, my_ai)
        if action:
            return action
        action = self.shoot(operators, my_ai)
        if action:
            return action
        if operators['obj_id'] not in my_ai.controllable_ops:
            return None
        if operators['obj_id'] in my_ai.huntermove.keys():
            msg_body = my_ai.huntermove[operators['obj_id']]
            if len(msg_body["hexs"]) > 1:
                if operators['cur_hex'] == msg_body["hexs"][0]:
                    target_point = msg_body["hexs"][1]
                    action = self.move(operators, target_point, my_ai, number=1)


                    if action:
                        next_hex = action['move_path'][0]
                        msg_body["hexs"][0] = next_hex
                        if msg_body["hexs"][0] == msg_body["hexs"][1]:
                            msg_body["hexs"] = msg_body["hexs"][1:]
                        route = msg_body["hexs"]
                        # my_ai.huntermove = {}
                        return action
            else:
                del my_ai.huntermove[operators['obj_id']]
        return None

    def ControlPointAttack(self, my_ai):
        # todo 引导射击没加，加步兵的引导射击
        UAV = self.get_bop(my_ai)
        if UAV:
            # 与巡飞弹不同，只有一个无人机
            return self.Attack(UAV, my_ai)
            # if not hasattr(self, 'first_UAV'):
            #     self.get_first_UAV(UAV, my_ai)
            # if self.first_UAV:
            #     return self.Attack(UAV, my_ai, const.BopName.Vehicle)
            # else:
            #     return self.Observe(UAV, my_ai)
        else:
            return None

    def Attack(self, UAV, my_ai):
        action = self.trace_guide(UAV, my_ai, sub_type=0)
        # 防止无人机奔向错误坦克的方法有点简单粗暴，没判断当前追踪坦克的id
        if action == "stay_still":
            return None
        elif action:
            return action

        if common.can_move(UAV, my_ai):
            attack_point = self.get_observe_point(UAV, my_ai)   # 无人机攻击点，具有随机性
            if com.get_distance(UAV['cur_hex'], attack_point) <= 3:
                return self.move(UAV, attack_point, my_ai, number=1)  # 巡航，发现敌方战车则射击
            else:

                return self.move(UAV, attack_point, my_ai, number=4)

        return list()

    def Observe(self, UAV, my_ai):
        if not hasattr(self, 'middle_point_crusier'):
            self.middle_point_crusier = 1

        action = self.trace_guide(UAV, my_ai, [0,1])  # subtype: 0_坦克, 1_战车
        if action == "stay_still":
            self.middle_point_crusier = 0
            return None
        elif action:
            self.middle_point_crusier = 0
            return action
        if self.middle_point_crusier == 1:
        # if UAV['alive_remain_time'] < 150 or my_ai.time > 1650:
        #     action = self.trace_shoot(UAV, my_ai)
        #     if action:
        #         return action
            if not hasattr(self, 'middle_poiont1'):
                self.middle_poiont1 = int(self.get_first_attack_point1(UAV, my_ai))
            if not hasattr(self, 'middle_poiont2'):
                self.middle_poiont2 = int(self.get_first_attack_point2(UAV, my_ai))
            if not hasattr(self, 'middle_poiont3'):
                self.middle_poiont3 = int(self.get_first_attack_point3(UAV, my_ai))

            if UAV['cur_hex'] == self.middle_poiont1:
                self.through_mark_point = 1
            if UAV['cur_hex'] == self.middle_poiont2:
                self.through_mark_point = 2
            if UAV['cur_hex'] == self.middle_poiont3:
                self.through_mark_point = 3
            if UAV['cur_hex'] == my_ai.attack_point['e_main_attack']:
                self.through_mark_point = 4

            if common.can_move(UAV, my_ai):
                if self.through_mark_point == 0: # 尚未经过主夺控点右上角巡逻点
                    if com.get_distance(UAV['cur_hex'], self.middle_poiont1) <= 5:
                        return self.move(UAV, self.middle_poiont1, my_ai, number=1)
                    else:
                        return self.move(UAV, self.middle_poiont1, my_ai, number=1)
                elif self.through_mark_point == 1: # 尚未经过主夺控点下角巡逻点
                    if com.get_distance(UAV['cur_hex'], self.middle_poiont2) <= 5:
                        return self.move(UAV, self.middle_poiont2, my_ai, number=1)
                    else:
                        return self.move(UAV, self.middle_poiont2, my_ai, number=1)
                elif self.through_mark_point == 2: # 尚未经过主夺控点左角巡逻点
                    if com.get_distance(UAV['cur_hex'], self.middle_poiont3) <= 5:
                        return self.move(UAV, self.middle_poiont3, my_ai, number=1)
                    else:
                        return self.move(UAV, self.middle_poiont3, my_ai, number=1)
                elif self.through_mark_point == 3: # 尚未经过主夺控点
                    if com.get_distance(UAV['cur_hex'], my_ai.attack_point['e_main_attack']) <= 5:
                        return self.move(UAV, my_ai.attack_point['e_main_attack'], my_ai, number=1)
                    else:
                        return self.move(UAV, my_ai.attack_point['e_main_attack'], my_ai, number=1)
                elif self.through_mark_point == 4:  # 已回主夺控点
                    observe_point = self.get_observe_point(UAV, my_ai)
                    if com.get_distance(UAV['cur_hex'], observe_point) <= 3:
                        return self.move(UAV, observe_point, my_ai, number=1)  # 1格1格走
                    else:
                        return self.move(UAV, observe_point, my_ai, number=1)

            return list()

    def Gathering(self, my_ai, city_coord=None):
        missile = self.get_bop(my_ai)
        if missile:
            if common.can_move(missile, my_ai):
                attack_point = my_ai.attack_point['o_main_attack']
                if com.get_distance(missile['cur_hex'], attack_point) <= 3:
                    return self.move(missile, attack_point, my_ai, number=1)  # 巡航，发现敌方战车则射击
                else:
                    return self.move(missile, attack_point, my_ai, number=4)

            return list()

    def DTFarAttack(self, my_ai, action_bops):
        return self.MoveAttack(my_ai)

    def DTMiddleFarAttack(self, my_ai, action_bops):
        # missile = self.get_bop(ai_group)
        # if missile:
        #     return self.Observe(missile, ai_group)
        return self.MoveAttack(my_ai)

    def DT2FarAttack(self, my_ai, action_bops):
        missile = self.get_bop(my_ai)
        if missile:
            return self.Attack(missile, my_ai, const.BopName.Vehicle)

    def DT2MiddleFarAttack(self, my_ai, action_bops):
        # missile = self.get_bop(ai_group)
        # if missile:
        #     return self.Observe(missile, ai_group)
        return self.MoveAttack(my_ai)

    def FarAttack(self, my_ai, action_bops):
        # missile = self.get_bop(ai_group)
        # if missile:
        #     return self.Attack(missile, ai_group, const.BopName.Vehicle)
        return self.MoveAttack(my_ai)

    def MiddleFarAttack(self, my_ai, action_bops):
        # missile = self.get_bop(ai_group)
        # if missile:
        #     return self.Observe(missile, ai_group)
        return self.MoveAttack(my_ai)

    def OccupyingMain(self, my_ai, action_bops):
        missile = self.get_bop(my_ai)
        if missile:
            return self.Attack(missile, my_ai, const.BopName.Soldier)

    def OccupyingSecond(self, my_ai, action_bops):
        missile = self.get_bop(my_ai)
        if missile:
            return self.Attack(missile, my_ai, const.BopName.Soldier)

    def HRFarAttack(self, my_ai, action_bops):  # todo 红方无人机第一阶段动作
        # missile = self.get_bop(ai_group)
        # if missile:
        #     return self.Attack(missile, ai_group, const.BopName.Vehicle)
        # print('\nenter RED UAV at {}sec'.format(my_ai.observation['time']['cur_step']))
        return self.MoveAttack(my_ai)

    def HRMiddleFarAttack(self, my_ai, action_bops):
        # missile = self.get_bop(ai_group)
        # if missile:
        #     return self.Observe(missile, ai_group)
        # print('\nenter RED UAV at {}sec'.format(my_ai.observation['time']['cur_step']))
        return self.MoveAttack(my_ai)

    def HROccupying(self, my_ai, action_bops):
        # print('\nenter RED UAV at {}sec'.format(my_ai.observation['time']['cur_step']))
        return self.MoveAttack(my_ai)


class RedArtillery(Artillery):

    def __init__(self, bop, serial_number=0, group=0):
        super(RedArtillery, self).__init__()
        assert self.sub_type == bop['sub_type']
        self.obj_id = bop['obj_id']
        self.serial_number = serial_number
        self.group = group

    def DTFarAttack(self, my_ai, action_bops):
        artillery = self.get_bop(my_ai)
        if artillery:
            if self.can_jm(artillery, my_ai):
                action_bops = sorted(action_bops, key=lambda x: x.sub_type, reverse=True)
                for action_bop in action_bops:
                    for ubop_record in action_bop.artillery_call:
                        if ubop_record and self.random_jm:
                            action = self.cancel_jm(artillery, my_ai)
                            if action:
                                self.random_jm = False
                                return action

                        bop = action_bop.get_bop(my_ai)
                        if bop:
                            if ubop_record['sub_type'] == const.BopName.Soldier:
                                # action_bop.artillery_call.remove(ubop_record)
                                action = self.jm_plan(artillery, ubop_record['cur_hex'], my_ai)
                                if action:
                                    return action
                        else:
                            action_bop.artillery_call = []

                    for ubop_record in action_bop.artillery_call:
                        bop = action_bop.get_bop(my_ai)
                        if bop:
                            if ubop_record['sub_type'] == const.BopName.Vehicle:
                                # action_bop.artillery_call.remove(ubop_record)
                                action = self.jm_plan(artillery, ubop_record['cur_hex'], my_ai)
                                if action:
                                    return action
                        else:
                            action_bop.artillery_call = []

                    for ubop_record in action_bop.artillery_call:
                        bop = action_bop.get_bop(my_ai)
                        if bop:
                            if ubop_record['sub_type'] == const.BopName.Tank:
                                # action_bop.artillery_call.remove(ubop_record)
                                action = self.jm_plan(artillery, ubop_record['cur_hex'], my_ai)
                                if action:
                                    return action
                        else:
                            action_bop.artillery_call = []

                action = self.jm_city(artillery, my_ai)
                if action:
                    return action
        return None

    def DTMiddleFarAttack(self, my_ai, action_bops):
        return self.DTFarAttack(my_ai, action_bops)

    def DT_Occupying(self, my_ai, action_bops):
        return self.DTFarAttack(my_ai, action_bops)

    def HRFarAttack(self, my_ai, action_bops):
        artillery = self.get_bop(my_ai)
        if artillery:
            if self.can_jm(artillery, my_ai):
                action_bops = sorted(action_bops, key=lambda x: x.sub_type, reverse=True)
                for action_bop in action_bops:
                    for ubop_record in action_bop.artillery_call:
                        if ubop_record and self.random_jm:
                            action = self.cancel_jm(artillery, my_ai)
                            if action:
                                self.random_jm = False
                                return action

                        bop = action_bop.get_bop(my_ai)
                        if bop:
                            if ubop_record['sub_type'] == const.BopName.Soldier:
                                # action_bop.artillery_call.remove(ubop_record)
                                action = self.jm_plan(artillery, ubop_record['cur_hex'], my_ai)
                                if action:
                                    return action
                        else:
                            action_bop.artillery_call = []

                    for ubop_record in action_bop.artillery_call:
                        bop = action_bop.get_bop(my_ai)
                        if bop:
                            if ubop_record['sub_type'] == const.BopName.Vehicle:
                                # action_bop.artillery_call.remove(ubop_record)
                                action = self.jm_plan(artillery, ubop_record['cur_hex'], my_ai)
                                if action:
                                    return action
                        else:
                            action_bop.artillery_call = []

                    for ubop_record in action_bop.artillery_call:
                        bop = action_bop.get_bop(my_ai)
                        if bop:
                            if ubop_record['sub_type'] == const.BopName.Tank:
                                # action_bop.artillery_call.remove(ubop_record)
                                action = self.jm_plan(artillery, ubop_record['cur_hex'], my_ai)
                                if action:
                                    return action
                        else:
                            action_bop.artillery_call = []

                action = self.jm_city(artillery, my_ai)
                if action:
                    return action
        return None

    def HRMiddleFarAttack(self, my_ai, action_bops):
        return self.HRFarAttack(my_ai, action_bops)

    def HROccupying(self, my_ai, action_bops):
        return self.HRFarAttack(my_ai, action_bops)


class RedMissile(Missile):
    def __init__(self, bop, serial_number=0, group=0):
        super(RedMissile, self).__init__()
        assert self.sub_type == bop['sub_type']
        self.obj_id = bop['obj_id']
        self.serial_number = serial_number
        self.group = group
        self.last_observe_point = []
        self.round_hexes = None


    def get_attack_point(self, missile, my_ai):
        enemy_probably = my_ai.enemy_predict.enemy_predict_sum(my_ai, sub_type=const.BopName.Vehicle)
        if not enemy_probably.all():
            enemy_probably = my_ai.enemy_predict.enemy_predict_sum(my_ai, sub_type=const.BopName.ScoutVehicle)
        if not enemy_probably.all():
            enemy_probably = my_ai.enemy_predict.enemy_predict_sum(my_ai, sub_type=const.BopName.Tank)
        if not enemy_probably.all():
            enemy_probably = my_ai.enemy_predict.enemy_predict_sum(my_ai, sub_type=const.BopName.Soldier)
        index_flatten = np.argsort(enemy_probably, axis=None)[-1]
        index_tuple = (index_flatten // my_ai.my_map.size[1], index_flatten % my_ai.my_map.size[1])
        index_int4 = com.cvtOffset2Int4loc(index_tuple)
        return index_int4

    def get_observe_point(self, missile, my_ai):
        ubops_record = [ubop_record for ubop_id, ubop_record in my_ai.enemy_predict.ubops_record.items() if
                        ubop_record['live'] and not ubop_record['be_see']]

        if ubops_record:
            ubop_record = random.choice(ubops_record)
            ubop_pos = copy.deepcopy(ubop_record['pos_predict'])
        else:
            ubop_pos = np.zeros(my_ai.my_map.size)

        if not self.see_enemy(missile):
            self.last_observe_point.extend(my_ai.hex_cache.get_circle(missile['cur_hex'], 0, 2))
            self.last_observe_point = list(set(self.last_observe_point))

        ubop_pos[tuple(zip(*self.last_observe_point))] = 0
        index_flatten = np.argmax(ubop_pos, axis=None)
        index_tuple = (index_flatten // my_ai.my_map.size[1], index_flatten % my_ai.my_map.size[1])
        index_int4 = com.cvtOffset2Int4loc(index_tuple)
        # print(index_int4)
        if com.get_distance(index_int4, my_ai.attack_point['o_main_attack']) >= 7 or \
                com.get_distance(index_int4, my_ai.attack_point['o_second_attack']) >= 7:
            if ubops_record:
                # 求当前可观察点
                observe_hexes = []
                for bop in my_ai.our_bops:
                    if bop['type'] != const.BopType.Aircraft:
                        bop_LOS = my_ai.see.get_see_LOS(common.get_see_source(bop['type']),
                                                        const.BopType.Vehicle, bop['cur_hex'])
                        rows, cols = np.where(bop_LOS == True)
                        observe_hexes.extend(list(zip(rows, cols)))
                observe_hexes = list(set(observe_hexes))

                if not self.round_hexes:
                    round_main = my_ai.hex_cache.get_circle(my_ai.attack_point['o_main_attack'], 0, 3)
                    round_second = my_ai.hex_cache.get_circle(my_ai.attack_point['o_second_attack'], 0, 3)
                    self.round_hexes = list(set(round_main) | set(round_second))

                observe_hexes = list(set(self.round_hexes) - set(self.last_observe_point) - set(observe_hexes))
                if not observe_hexes or my_ai.time > 1350:
                    # self.last_observe_point = []
                    index_int4 = random.choice([my_ai.attack_point['o_main_attack'], my_ai.attack_point['o_second_attack']])
                else:
                    index_hex = random.choice(observe_hexes)
                    index_int4 = com.cvtOffset2Int4loc(index_hex)
            else:
                enemy_pos = [ubop['cur_hex'] for ubop in my_ai.enemy_bops]
                if enemy_pos:
                    index_int4 = random.choice(enemy_pos)
                else:
                    index_int4 = missile['cur_hex']
        return index_int4

    def stop_and_shoot(self, missile, my_ai):
        # 看到敌人立即停止机动
        if self.see_enemy(missile):
            action = self.stop(missile, my_ai)
            if action:
                return action
            action = self.shoot(missile, my_ai)
            if action:
                return action
        return list()

    # 跟踪射击，当看到敌人的特定棋子后，先追踪，等其停止后再进行射击，这样可以增加毁伤效果
    # todo observe函数目前尚未明确巡飞弹射击何种算子。可打击战车
    def trace_shoot(self, missile, my_ai, sub_type=None):
        if sub_type:
            e_bops = common.get_bop_sub_type_under_see(my_ai.enemy_bops, sub_type,
                                                       missile['see_enemy_bop_ids'])
            if e_bops:
                e_bop = e_bops[0]
                if e_bop['stop'] == 1:
                    action = self.stop(missile, my_ai)
                    if action:
                        return action
                    action = self.shoot(missile, my_ai, tar_sub_type=[sub_type])
                    if action:
                        return action
                else:
                    pos_tuple = random.choice(my_ai.hex_cache.get_circle(e_bop['cur_hex'], 1, 1))
                    pos_int4 = com.cvtOffset2Int4loc(pos_tuple)
                    if pos_int4 == missile['cur_hex']:
                        pos_int4 = e_bop['cur_hex']
                    action = self.move(missile, pos_int4, my_ai, number=1)
                    if action:
                        return action

        if missile['alive_remain_time'] < 150 or my_ai.time > 1650:
            return self.stop_and_shoot(missile, my_ai)
        else:
            return None

    def get_first_missile(self, missile, my_ai):
        missiles_live = [obop_record['live'] for obop_id, obop_record in my_ai.enemy_predict.obops_record.items() if
                        obop_record['sub_type']==const.BopName.Missile]
        if False in missiles_live:
            self.first_missile = False
        else:
            self.first_missile = True

    def MoveAttack(self, my_ai):
        missile = self.get_bop(my_ai)
        if missile:
            if my_ai.MissileControl == 2:
                return self.into_hunter(my_ai,missile)
            # 红方仅有一个巡飞弹，等到巡飞弹寿命将近或接近比赛结束再打击
            return self.Observe(missile, my_ai)
            # if not hasattr(self, 'first_missile'):
            #     self.get_first_missile(missile, my_ai)
            # if self.first_missile:
            #     return self.Attack(missile, my_ai, const.BopName.Missile)
            # else:
            #     return self.Observe(missile, my_ai)
        else:
            return None

    def into_hunter(self, my_ai, operators):
        action = self.guide_shoot(operators, my_ai)
        if action:
            return action
        action = self.shoot(operators, my_ai)
        if action:
            return action
        if operators['obj_id'] not in my_ai.controllable_ops:
            return None
        if operators['obj_id'] in my_ai.huntermove.keys():
            msg_body = my_ai.huntermove[operators['obj_id']]
            if len(msg_body["hexs"]) > 1:
                if operators['cur_hex'] == msg_body["hexs"][0]:
                    target_point = msg_body["hexs"][1]
                    action = self.move(operators, target_point, my_ai, number=1)


                    if action:
                        next_hex = action['move_path'][0]
                        msg_body["hexs"][0] = next_hex
                        if msg_body["hexs"][0] == msg_body["hexs"][1]:
                            msg_body["hexs"] = msg_body["hexs"][1:]
                        route = msg_body["hexs"]
                        # my_ai.huntermove = {}
                        return action
            else:
                del my_ai.huntermove[operators['obj_id']]
        return None

    def Attack(self, missile, my_ai, sub_type):
        action = self.trace_shoot(missile, my_ai, sub_type=sub_type)
        if action:
            return action

        if common.can_move(missile, my_ai):
            attack_point = self.get_observe_point(missile, my_ai)
            if com.get_distance(missile['cur_hex'], attack_point) <= 3:
                return self.move(missile, attack_point, my_ai, number=1)  # 巡航，发现敌方战车则射击
            else:

                return self.move(missile, attack_point, my_ai, number=4)

        return list()

    def Observe(self, missile, my_ai):
        # 巡飞弹寿命1200秒，巡飞弹下车花费75秒，1200+75-150= 1125，射击发生在1125到1275之间，大约发生在1134秒
        if missile['alive_remain_time'] < 150 or my_ai.time > 1650:
            action = self.trace_shoot(missile, my_ai)
            if action:
                return action

        if common.can_move(missile, my_ai):
            observe_point = self.get_observe_point(missile, my_ai)
            if com.get_distance(missile['cur_hex'], observe_point) <= 3:
                return self.move(missile, observe_point, my_ai, number=1)  # 巡航，发现敌方战车则射击
            # todo 发现敌方战车则射击的部分没完善。

            else:
                return self.move(missile, observe_point, my_ai, number=1)

        return list()

    def Gathering(self, my_ai, city_coord=None):
        missile = self.get_bop(my_ai)
        if missile:
            if common.can_move(missile, my_ai):
                attack_point = my_ai.attack_point['o_main_attack']
                if com.get_distance(missile['cur_hex'], attack_point) <= 3:
                    return self.move(missile, attack_point, my_ai, number=1)  # 巡航，发现敌方战车则射击
                else:
                    return self.move(missile, attack_point, my_ai, number=4)

            return list()

    def DTFarAttack(self, my_ai, action_bops):
        return self.MoveAttack(my_ai)

    def DTMiddleFarAttack(self, my_ai, action_bops):
        # missile = self.get_bop(ai_group)
        # if missile:
        #     return self.Observe(missile, ai_group)
        return self.MoveAttack(my_ai)

    def DT2FarAttack(self, my_ai, action_bops):
        missile = self.get_bop(my_ai)
        if missile:
            return self.Attack(missile, my_ai, const.BopName.Vehicle)

    def DT2MiddleFarAttack(self, my_ai, action_bops):
        # missile = self.get_bop(ai_group)
        # if missile:
        #     return self.Observe(missile, ai_group)
        return self.MoveAttack(my_ai)

    def OccupyingMain(self, my_ai, action_bops):
        missile = self.get_bop(my_ai)
        if missile:
            return self.Attack(missile, my_ai, const.BopName.Soldier)

    def OccupyingSecond(self, my_ai, action_bops):
        missile = self.get_bop(my_ai)
        if missile:
            return self.Attack(missile, my_ai, const.BopName.Soldier)

    def HRFarAttack(self, my_ai, action_bops):   # todo 红方巡飞弹第一阶段动作
        # missile = self.get_bop(ai_group)
        # if missile:
        #     return self.Attack(missile, ai_group, const.BopName.Vehicle)
        return self.MoveAttack(my_ai)

    def HRMiddleFarAttack(self, my_ai, action_bops):
        # missile = self.get_bop(ai_group)
        # if missile:
        #     return self.Observe(missile, ai_group)
        return self.MoveAttack(my_ai)

    def HROccupying(self, my_ai, action_bops):
        return self.MoveAttack(my_ai)

class RedScoutVehicle(ScoutVehicle):

    def __init__(self, bop, serial_number=0, group=0):
        super(ScoutVehicle, self).__init__()
        assert self.sub_type == bop['sub_type']
        self.obj_id = bop['obj_id']
        self.serial_number = serial_number
        self.group = group

        self.near_off = False

    def HRFarAttack(self, my_ai, action_bops):  # todo 红方侦察战车第一阶段动作
        ScoutVehicle = self.get_bop(my_ai)
        if ScoutVehicle:
            action = self.shoot(ScoutVehicle, my_ai)
            if action:
                return action

            hide_point = self.find_hide_point(ScoutVehicle, my_ai)
            kwargs = {'beta': 3,
                      'hide_cond': 0.3,
                      'shoot_ability': 0,
                      'be_shoot_ability': 1,
                      'be_shoot_ability_aircraft': 0,
                      'observe_enemy_ability': 0,
                      'be_observed_enemy_ability': 0.5}
            action = self.hide_move(ScoutVehicle, hide_point, my_ai, number=15, danger_stop=True, danger_value=0.8,
                                    **kwargs)
            if action:
                return action

            enemy_tanks = common.get_bop_sub_type_under_see(my_ai.enemy_bops, const.BopName.Tank, ScoutVehicle['see_enemy_bop_ids'])
            if enemy_tanks:
                return self.move_hide(ScoutVehicle, my_ai)

            guide_call = self.get_guide_call(ScoutVehicle, my_ai, action_bops)
            if my_ai.time > 150:
                if guide_call:
                    for ubop in guide_call:
                        shoot_dis = my_ai.damage.get_bop_attack_distance(ScoutVehicle, ubop['type'])
                        if com.get_distance(ScoutVehicle['cur_hex'], ubop['cur_hex']) <= shoot_dis and ScoutVehicle['remain_bullet_nums'][100]:
                            if not self.see_enemy(ScoutVehicle):
                            # if not hasattr(self, 'stop_command'):
                            #     self.stop_command = True
                            # if self.stop_command:
                            #     self.stop_command = False
                                return self.stop(ScoutVehicle, my_ai)
                            # else:
                            #     return self.vehicle_move_hide(vehicle, my_ai)
        return None

    def HRMiddleFarAttack(self, my_ai, action_bops):
        return self.HRFarAttack(my_ai,action_bops)

    def HROccupying(self, my_ai, action_bops):
        return self.HRFarAttack(my_ai, action_bops)
