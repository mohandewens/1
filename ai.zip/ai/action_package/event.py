from .FSMEvent import FsmEvent
from ..utils import common, const
from . import red_action_bop
import numpy as np


class GameStartEvent(FsmEvent):
    def __init__(self):
        super(GameStartEvent, self).__init__()

    def can_do(self, FSM, my_ai):
        if my_ai.observation['time']['cur_step'] <= 100:
            return True
        else:
            return False


class GameOverEvent(FsmEvent):
    def __init__(self):
        super(GameOverEvent, self).__init__()

    def can_do(self, FSM, my_ai):
        if self.get_GameOver(my_ai):
            return True
        else:
            return False


class RedGatheringEvent(FsmEvent):
    @staticmethod
    def can_do(FSM, my_ai):
        if my_ai.observation['time']['cur_step'] == 1200:
            return True
        else:
            return False


class RedOccupyingEvent(FsmEvent):
    @staticmethod
    def can_do(FSM, my_ai):
        bops = common.get_bop_type(my_ai.our_bops, const.BopType.Vehicle)
        if bops:
            if 'gathering_point' in FSM.current_state.__dict__:
                gathering_point = FSM.current_state.gathering_point
                pos = [bop['cur_hex'] == gathering_point for bop in bops]
                return np.array(pos).all()
        else:
            return False

class BlueOccupyingEvent(FsmEvent):
    @staticmethod
    def can_do(FSM, my_ai):
        if common.my_city(my_ai.observation['cities'], my_ai.color, coord=my_ai.attack_point['o_main_attack']):
                return True
        else:
            return False


class BlueSuperiorEvent(FsmEvent):
    @staticmethod
    def can_do(FSM, my_ai):
        if my_ai.observation['time']['cur_step'] >= 1500:
            return True
        else:
            return False

class HideEvent(FsmEvent):
    def __init__(self):
        super(HideEvent, self).__init__()


    def can_do(self, FSM, my_ai):
        if not hasattr(self, 'RedNoHideEvent'):
            self.get_NoHide(my_ai)
        if self.NoHide:
            return False
        else:
            return True

class NoHideEvent(FsmEvent):
    def __init__(self):
        super(NoHideEvent, self).__init__()


    def can_do(self, FSM, my_ai):
        if not hasattr(self, 'RedNoHideEvent'):
            self.get_NoHide(my_ai)
        if self.NoHide:
            return True
        else:
            return False

class LessEnemyEvent(FsmEvent):
    def __init__(self):
        super(LessEnemyEvent, self).__init__()


    def can_do(self, FSM, my_ai):
        if self.get_LessEnemy(my_ai, multiple=4):
            return True
        else:
            return False

class NearOverEvent(FsmEvent):
    def __init__(self):
        super(NearOverEvent, self).__init__()


    def can_do(self, FSM, my_ai):
        if self.get_NearOver(my_ai):
            return True
        else:
            return False


########2010211129:  # 连级山地通道夺控战斗想定

class RedTimeNoEnemyEvent(FsmEvent):
    def __init__(self):
        super(RedTimeNoEnemyEvent, self).__init__()

    def can_do(self, FSM, my_ai):
        if self.get_time(my_ai, 400):
            return True
        else:
            return False

class RedLessEnemyEvent(FsmEvent):
    def __init__(self):
        super(RedLessEnemyEvent, self).__init__()

    def can_do(self, FSM, my_ai):
        if ((self.get_TimeLessEnemy(my_ai, 900, 4.5) or self.only_soldier(my_ai)) and my_ai.time < 1400) or \
                (my_ai.time > 1450 and (self.main_city_safe(my_ai) or self.second_city_safe(my_ai))):
            if not self.more_score(my_ai) or self.soldier_less_one(my_ai):
                return True
        # if ai_group.time > 1000 and not self.more_score(ai_group):
        #     return True
        return False

class RedTimeLessEnemyEvent(FsmEvent):
    def __init__(self):
        super(RedTimeLessEnemyEvent, self).__init__()

    def can_do(self, FSM, my_ai):
        if (self.get_TimeLessEnemy(my_ai, 1500, 4) and self.occupy_main_city(my_ai)) and my_ai.time < 1700:
            if not self.more_score(my_ai) or self.soldier_less_one(my_ai):
                return True
        return False

class BlueLessEnemyEvent(FsmEvent):
    def __init__(self):
        super(BlueLessEnemyEvent, self).__init__()


    def can_do(self, FSM, my_ai):
        if self.get_TimeLessEnemy(my_ai, 1700, 0.2) and not self.occupy_main_city(my_ai):
            return True
        else:
            return False


class BlueTimeLessEnemyEvent(FsmEvent):
    def __init__(self):
        super(BlueTimeLessEnemyEvent, self).__init__()


    def can_do(self, FSM, my_ai):
        if self.get_TimeLessEnemy(my_ai, 1700, 0.2) and not self.occupy_second_city(my_ai):
            return True
        else:
            return False
####################



class DTRedTimeNoEnemyEvent(FsmEvent):
    def __init__(self):
        super(DTRedTimeNoEnemyEvent, self).__init__()

    def can_do(self, FSM, my_ai):
        if self.get_time(my_ai, 800):
            return True
        else:
            return False

class DTRedLessEnemyEvent(FsmEvent):
    def __init__(self):
        super(DTRedLessEnemyEvent, self).__init__()

    def can_do(self, FSM, my_ai):
        if self.get_TimeLessEnemy(my_ai, 1300, 3) and (self.main_city_safe(my_ai) or self.second_city_safe(my_ai)):
            if self.soldier_less_one(my_ai):
                return True
        return False


class DTBlueLessEnemyEvent(FsmEvent):
    def __init__(self):
        super(DTBlueLessEnemyEvent, self).__init__()


    def can_do(self, FSM, my_ai):
        if my_ai.time > 1200:
            if not self.occupy_main_city(my_ai):
               # if self.main_city_safe(my_ai):
                return True
        return False


class DTBlueTimeLessEnemyEvent(FsmEvent):
    def __init__(self):
        super(DTBlueTimeLessEnemyEvent, self).__init__()

    def can_do(self, FSM, my_ai):
        if my_ai.time > 1600:
            if not self.occupy_second_city(my_ai):
                if self.get_TimeLessEnemy(my_ai, 1600, 2.5) or self.second_city_safe(my_ai):
                    return True
        return False


'''
2010441253: 连级水网稻田地形遭遇战斗想定Ⅱ,53
'''

class DT2RedTimeNoEnemyEvent(FsmEvent):
    def __init__(self):
        super(DT2RedTimeNoEnemyEvent, self).__init__()

    def can_do(self, FSM, my_ai):
        if self.get_time(my_ai, 500):
            return True
        else:
            return False

class DT2RedLessEnemyEvent(FsmEvent):
    def __init__(self):
        super(DT2RedLessEnemyEvent, self).__init__()

    def can_do(self, FSM, my_ai):
        if ((self.get_TimeLessEnemy(my_ai, 900, 4.5) or self.only_soldier(my_ai)) and my_ai.time < 1450) or \
                (1550 > my_ai.time > 1450 and (self.main_city_safe(my_ai) or self.second_city_safe(my_ai))):
            if not self.more_score(my_ai) or self.soldier_less_one(my_ai):
                return True
        return False


class DT2BlueLessEnemyEvent(FsmEvent):
    def __init__(self):
        super(DT2BlueLessEnemyEvent, self).__init__()


    def can_do(self, FSM, my_ai):
        if self.get_TimeLessEnemy(my_ai, 1300, 1.0) and not self.occupy_main_city(my_ai):
            return True
        else:
            return False


class DT2BlueTimeLessEnemyEvent(FsmEvent):
    def __init__(self):
        super(DT2BlueTimeLessEnemyEvent, self).__init__()


    def can_do(self, FSM, my_ai):
        if self.get_TimeLessEnemy(my_ai, 1600, .7) and not self.occupy_second_city(my_ai):
            return True
        else:
            return False


####人机混合想定
class HRRedMiddleEvent(FsmEvent):
    def __init__(self):
        super(HRRedMiddleEvent, self).__init__()

    def can_do(self, FSM, my_ai):
        if my_ai.observation['time']['cur_step'] > 600:
            return True
        else:
            return False


class HRRedOccpuyEvent(FsmEvent):
    def __init__(self):
        super(HRRedOccpuyEvent, self).__init__()

    def can_do(self, FSM, my_ai):
        # if self.get_TimeLessEnemy(my_ai, 1300, 3) and (self.main_city_safe(my_ai) or self.second_city_safe(my_ai)):
        #     if self.soldier_less_one(my_ai):
        #         return True
        if my_ai.observation['time']['cur_step'] > 1200:
            return True
        return False


class HRBlueOccupyEvent(FsmEvent):
    def __init__(self):
        super(HRBlueOccupyEvent, self).__init__()


    def can_do(self, FSM, my_ai):
        # if my_ai.time > 1200:
        #     if not self.occupy_main_city(my_ai):
        #        # if self.main_city_safe(my_ai):
        #         return True
        if my_ai.observation['time']['cur_step'] > 600:
            return True
        return False


class HRProtectEvent(FsmEvent):
    def __init__(self):
        super(HRProtectEvent, self).__init__()

    def can_do(self, FSM, my_ai):
        # if my_ai.time > 1600:
        #     if not self.occupy_second_city(my_ai):
        #         if self.get_TimeLessEnemy(my_ai, 1600, 2.5) or self.second_city_safe(my_ai):
        #             return True
        if my_ai.observation['time']['cur_step'] > 1200:
            return True
        return False