from ..utils import const
from ..utils import common
from ..hexmap import common as com
import numpy as np

class FsmEvent:

    def __init__(self):
        self.last_see_time = 0
        pass

    def get_NoHide(self, my_ai):
        tanks = common.get_bop_sub_type(my_ai.our_bops_init_all, const.BopName.Tank)
        if tanks[0]:
            tank = tanks[0]
            pos_start = tank['cur_hex']
            pos_main = my_ai.attack_point['o_main_attack']
            hexes_main = my_ai.hex_cache.get_circle(pos_main, 5, 13)
            hexes_start = my_ai.hex_cache.get_circle(pos_start, 1, 13)

            intersection_hexes = list(set(hexes_main) & set(hexes_start))
            hide_array = my_ai.my_map.get_hide_array(const.BopType.Infantry)[tuple(zip(*intersection_hexes))]
            hide_sum = hide_array.sum()
            if hide_sum >= 2:
                self.NoHide = False
        else:
            self.NoHide = True

    '''距比赛结束还有4倍距主攻击点机动时间或者敌我力量比小于0
    .4（转移到双坦克协同近距离攻击）'''
    def get_LessEnemy(self, my_ai, multiple=4):
        tanks = common.get_bop_sub_type(my_ai.our_bops_init_all, const.BopName.Tank)
        time_to_main = 0
        main_tuple = com.cvtInt4loc2Offset(my_ai.attack_point['o_main_attack'])
        for bop in tanks:
            maneuver_time = my_ai.see.get_maneuver_time(bop['type'], bop['cur_hex'])[main_tuple[0], main_tuple[1]]
            time_to_main += maneuver_time

        time_to_main = time_to_main / len(tanks)
        # print(f'{ai_group.color}, {time_to_main}, {1800 - ai_group.time}')
        if (1800 - my_ai.time) < (multiple * time_to_main):
            return True

        if my_ai.enemy_predict.strength_compare(my_ai) > 2.5 :
            return True

        return False


    def get_NearOver(self, my_ai):
        if my_ai.time > 1700:
            return True

        if my_ai.enemy_predict.strength_compare(my_ai) > 3:
            return True

        return False

    def get_GameOver(self, my_ai):
        if my_ai.time >= 1800:
            return True

        obops_lives = [bop_record['live'] for bop_id, bop_record in my_ai.enemy_predict.obops_record.items()]
        enemys_lives = [bop_record['live'] for bop_id, bop_record in my_ai.enemy_predict.ubops_record.items()]

        if (not True in obops_lives): # or (not True in enemys_lives)
            return True

        if not (False in common.my_city(my_ai.observation['cities'], my_ai.color)) and (not (True in enemys_lives)):
            return True
        return False

    def get_time(self, my_ai, time):
        if my_ai.time > time:
            return True
        else:
            return False

    #在比赛时间game_time之后，持续continue_time没有看到敌方车辆单位
    def get_TimeNoEnemy(self, my_ai, game_time, continue_time):
        if my_ai.time > game_time:
            enemy_cars = common.get_bop_type(my_ai.enemy_bops, const.BopType.Vehicle)
            if enemy_cars:
                self.last_see_time = my_ai.time

            else:
                if my_ai.time - self.last_see_time > continue_time :
                    return True
        return False


    def get_TimeLessEnemy(self, my_ai, game_time, compare_value):
        if my_ai.time > game_time:
            if my_ai.enemy_predict.strength_compare(my_ai) > compare_value:
                return True

        return False

    def only_soldier(self, my_ai):
        enemys_lives_vehicle = [bop_record['live'] for bop_id, bop_record in my_ai.enemy_predict.ubops_record.items() \
                                 if (bop_record['sub_type'] == const.BopName.Vehicle or bop_record['sub_type'] == const.BopName.Tank or bop_record['sub_type'] == const.BopName.ScoutVehicle)]
        if not True in enemys_lives_vehicle:
            return True
        else:
            return False

    def soldier_less_one(self, my_ai):
        enemys_lives = [bop_record['live'] for bop_id, bop_record in my_ai.enemy_predict.ubops_record.items()]
        if len(enemys_lives) <= 1:
            return True
        else:
            return False

    def occupy_main_city(self, my_ai):
        if common.my_city(my_ai.observation['cities'], my_ai.color, coord=my_ai.attack_point['o_main_attack']):
            return True
        else:
            return False

    def occupy_second_city(self, my_ai):
        if common.my_city(my_ai.observation['cities'], my_ai.color, coord=my_ai.attack_point['o_second_attack']):
            return True
        else:
            return False

    def main_city_safe(self, my_ai):
        if my_ai.our_bops:
            bop = my_ai.our_bops[0]
            be_shoot_ability = my_ai.enemy_predict.be_attacked_ability(bop, [my_ai.attack_point['o_main_attack']], my_ai)

            ubops_record = [ubop_record for ubop_id, ubop_record in my_ai.enemy_predict.ubops_record.items() if
                            ubop_record['live']]
            hexes_around_main = my_ai.hex_cache.get_circle(my_ai.attack_point['o_main_attack'], 0, 2)
            ubop_pos_main = np.zeros(len(hexes_around_main))
            for ubop_record in ubops_record:
                ubop_pos_main += ubop_record['pos_predict'][tuple(zip(*hexes_around_main))]
            ubop_pos_main = ubop_pos_main.sum()

            if be_shoot_ability < 0.1 and ubop_pos_main < 0.1:
                return True
        return False

    def second_city_safe(self, my_ai):
        if my_ai.our_bops:
            bop = my_ai.our_bops[0]
            be_shoot_ability = my_ai.enemy_predict.be_attacked_ability(bop, [my_ai.attack_point['o_second_attack']], my_ai)
            ubops_record = [ubop_record for ubop_id, ubop_record in my_ai.enemy_predict.ubops_record.items() if
                            ubop_record['live']]
            hexes_around_second = my_ai.hex_cache.get_circle(my_ai.attack_point['o_second_attack'], 0, 2)
            ubop_pos_second = np.zeros(len(hexes_around_second))
            for ubop_record in ubops_record:
                ubop_pos_second += ubop_record['pos_predict'][tuple(zip(*hexes_around_second))]
            ubop_pos_second = ubop_pos_second.sum()
            if be_shoot_ability < 0.1 and ubop_pos_second < 0.1:
                return True
        return False

    def more_score(self, my_ai):
        if my_ai.color == const.Color.RED:
            total = my_ai.score['red_remain'] + my_ai.score['red_attack']

            e_total = my_ai.score['blue_remain'] + my_ai.score['blue_attack']
        else:
            total = my_ai.score['blue_remain'] +  my_ai.score['blue_attack']

            e_total = my_ai.score['red_remain'] + my_ai.score['red_attack']

        for city in my_ai.observation['cities']:
            if city['flag'] == my_ai.color:
                total += city['value']
            else:
                e_total += city['value']
        score_compare = (total + 1e-5) / (e_total + 1e-5)
        if score_compare > 1:
            return True
        else:
            return False

