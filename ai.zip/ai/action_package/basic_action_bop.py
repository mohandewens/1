import numpy as np
from ..utils import common, const
from ..hexmap.hex import BoundedHex
from ..utils import util, rule
from ..hexmap import common as com
from ..hexmap.astar import astar



class Bop(object):
    def __init__(self):
        self.wait_time = 0
        self.defense_guide = True
        # self.far_attack_flag = True
        # self.attack_vehicle_flag = True
        self.artillery_call = []



    def get_bop(self, my_ai):
        return common.get_bop_obj_id(my_ai.our_bops, self.obj_id)

    def is_live(self, my_ai):
        bop = self.get_bop(my_ai)
        if not bop:
            return False
        else:
            return True

    @staticmethod
    def see_enemy(bop):
        if bop['see_enemy_bop_ids']:
            return True
        else:
            return False

    def produce_artillery_call(self, my_ai):
        bop = self.get_bop(my_ai)
        self.artillery_call = []
        if bop:
            if bop['sub_type'] in [const.BopName.Soldier, const.BopName.Vehicle, const.BopName.Tank, const.BopName.UnmannedVehicle, const.BopName.ScoutVehicle]:
                if self.see_enemy(bop) and (bop['stop'] or bop['move_to_stop_remain_time'] or bop['sub_type'] == const.BopName.Soldier):
                    ubops = common.get_see_enemy(bop, my_ai.enemy_bops)
                    self.artillery_call = [ubop for ubop in ubops if ubop['type'] != const.BopType.Aircraft]


    def see_can_not_shoot(self, bop, my_ai):
        if self.see_enemy(bop):
            ubops = common.get_see_enemy(bop, my_ai.enemy_bops)
            if ubops:
                for ubop in ubops:
                    if ubop['sub_type'] != const.BopName.Missile:
                        max_shoot_dis = my_ai.damage.get_bop_attack_distance(bop, ubop['type'])
                        dis = com.get_distance(bop['cur_hex'], ubop['cur_hex'])
                        if dis > max_shoot_dis:
                            return True
        return False

    def see_can_shoot(self, bop, my_ai, sub_type=None):
        if self.see_enemy(bop):
            ubops = common.get_see_enemy(bop, my_ai.enemy_bops)
            if ubops:
                for ubop in ubops:
                    max_shoot_dis = my_ai.damage.get_bop_attack_distance(bop, ubop['type'])
                    dis = com.get_distance(bop['cur_hex'], ubop['cur_hex'])
                    if sub_type:
                        if ubop['sub_type'] == sub_type:
                            if dis <= max_shoot_dis:
                                return True
                    else:
                        if dis <= max_shoot_dis:
                            return True
        return False

    @staticmethod
    def can_move(bop, my_ai):
        move_actions = common.get_bop_action_id_name(my_ai.observation['valid_actions'], bop['obj_id'],
                                                     const.ActionType.Move)
        if move_actions:
            return True
        else:
            return False

    def hide(self, bop, my_ai):
        state_actions = common.get_bop_action_id_name(my_ai.observation['valid_actions'], bop['obj_id'],
                                                      const.ActionType.ChangeState)
        if state_actions:
            state_action = state_actions[const.ActionType.ChangeState]
            target_state_list = [state['target_state'] for state in state_action]
            if const.StateMode.Hide in target_state_list:
                return {"actor": my_ai.seat,
                    'obj_id': bop['obj_id'],
                    'type': const.ActionType.ChangeState,
                    'target_state': const.StateMode.Hide,
                }

        else:
            return None

    def occupy(self, bop, my_ai):
        """Generate occupy action."""
        occupy_action = common.get_bop_action_id_name(my_ai.observation['valid_actions'], bop['obj_id'],
                                                     const.ActionType.Occupy)
        if occupy_action:
            return {"actor": my_ai.seat,
                'obj_id': bop['obj_id'],
                'type': const.ActionType.Occupy,
            }
        else:
            return None

    def stop(self, bop, my_ai):
        stop_actions = common.get_bop_action_id_name(my_ai.observation['valid_actions'], bop['obj_id'],
                                                     const.ActionType.StopMove)
        if stop_actions:
            return {"actor": my_ai.seat,
                'obj_id': bop['obj_id'],
                'type': const.ActionType.StopMove,
            }
        return None

    def move(self, bop, destination_int4, my_ai, number=None ,route_mode = 1):
        move_actions = common.get_bop_action_id_name(my_ai.observation['valid_actions'], bop['obj_id'],
                                                     const.ActionType.Move)
        if move_actions and bop and bop['cur_hex'] != destination_int4:
            move_type = self.get_move_type(bop)
            march_mode = self.is_march_mode(move_type)
            # route = my_ai.map.gen_move_route(bop['cur_hex'], destination_int4, move_type)
            if route_mode == 1:
                route = astar(bop, bop['cur_hex'], destination_int4, my_ai, time_mode=True, no_pass=my_ai.land_marks, march_mode=march_mode, maxsteps=2000)
            else:
                if bop['sub_type'] == const.BopName.Soldier:
                    mode = 2
                elif bop['sub_type'] == const.BopName.UAV or bop['sub_type'] == const.BopName.Missile:
                    mode = 3
                else:
                    mode = 0
                route = my_ai.map.gen_move_route(bop['cur_hex'],destination_int4,mode)
            if route:
                if number:
                    if len(route) > number:
                        route = route[0:number]
                ##更新我方未来位置，减小同格
                my_ai.enemy_predict.update_future_hex(bop['obj_id'], route[-1], my_ai)
                return {"actor": my_ai.seat,
                    'obj_id': bop['obj_id'],
                    'type': const.ActionType.Move,
                    'move_path': route,
                }
        return None

    def soldiermove(self, bop, destination_int4, my_ai, number=None):
        move_actions = common.get_bop_action_id_name(my_ai.observation['valid_actions'], bop['obj_id'],
                                                     const.ActionType.Move)
        if move_actions and bop and bop['cur_hex'] != destination_int4:
            move_type = self.get_move_type(bop)
            march_mode = self.is_march_mode(move_type)
            # route = my_ai.map.gen_move_route(bop['cur_hex'], destination_int4, move_type)
            route = astar(bop, bop['cur_hex'], destination_int4, my_ai, time_mode=True, no_pass=my_ai.land_marks, march_mode=march_mode, maxsteps=2000)
            if route:
                route = route[:1]
                if number:
                    if len(route) > number:
                        route = route[0:number]
                ##更新我方未来位置，减小同格
                my_ai.enemy_predict.update_future_hex(bop['obj_id'], route[-1], my_ai)
                return {"actor": my_ai.seat,
                    'obj_id': bop['obj_id'],
                    'type': const.ActionType.Move,
                    'move_path': route,
                }
        return None

    def hide_move(self, bop, destination_int4, my_ai, number=5, danger_stop=False, danger_value=0.5, **kwargs):
        move_actions = common.get_bop_action_id_name(my_ai.observation['valid_actions'], bop['obj_id'],
                                                     const.ActionType.Move)
        if move_actions and bop and bop['cur_hex'] != destination_int4:
            move_type = self.get_move_type(bop)
            march_mode = self.is_march_mode(move_type)

            route = astar(bop, bop['cur_hex'], destination_int4, my_ai, time_mode=True, no_pass=my_ai.land_marks, march_mode=march_mode, maxsteps=2000)
            if route:
                if not danger_stop:
                    ##更新我方未来位置，减小同格
                    if len(route) > number:
                        route = route[0:number]
                    my_ai.enemy_predict.update_future_hex(bop['obj_id'], route[-1], my_ai)
                    return {"actor": my_ai.seat,
                        'obj_id': bop['obj_id'],
                        'type': const.ActionType.Move,
                        'move_path': route,
                    }
                else:
                    if len(route) > number:
                        route = route[0:number]
                    be_shoot_ability = my_ai.enemy_predict.be_attacked_ability(bop, route, my_ai, ubop_type=None)
                    for i, value in enumerate(be_shoot_ability):
                        if value >= danger_value:
                            route = route[:i]
                            break
                    if route:
                        my_ai.enemy_predict.update_future_hex(bop['obj_id'], route[-1], my_ai)
                        return {"actor": my_ai.seat,
                                'obj_id': bop['obj_id'],
                                'type': const.ActionType.Move,
                                'move_path': route,
                                }
        return None


    @staticmethod
    def is_march_mode(move_type):
        if move_type == const.MoveType.March:
            return True
        else:
            return False

    @staticmethod
    def get_move_type(bop):
        """Get appropriate move type for a bop."""
        bop_type = bop['type']
        if bop_type == const.BopType.Vehicle:
            if bop['move_state'] == const.MoveType.March:
                move_type = const.MoveType.March
            else:
                move_type = const.MoveType.Maneuver
        elif bop_type == const.BopType.Infantry:
            move_type = const.MoveType.Walk
        else:
            move_type = const.MoveType.Fly
        return move_type

    def change_rush_level_two(self, soldier, my_ai):
        state_actions = common.get_bop_action_id_name(my_ai.observation['valid_actions'], soldier['obj_id'],
                                                     const.ActionType.ChangeState)
        if state_actions:
            state_action = state_actions[const.ActionType.ChangeState]
            target_state_list = [state['target_state'] for state in state_action]
            if const.StateMode.Rush_level_two in target_state_list:
                return {"actor": my_ai.seat,
                    'obj_id': soldier['obj_id'],
                    'type': const.ActionType.ChangeState,
                    'target_state': const.StateMode.Rush_level_two,
                }

        else:
            return None

    def sort_shoot_target(self, bop, candidate_bop, my_ai):
        if len(candidate_bop) == 1:
            my_ai.shoot_target_record.append(candidate_bop[0][1]['obj_id'])
            return candidate_bop[0][0]
        else:
            candidate_bop_value = []
            for candidate, ubop in candidate_bop:
                can_shoot_value = rule.get_can_shoot_value(ubop)
                if can_shoot_value >= 0.93:
                    if ubop['obj_id'] not in my_ai.shoot_target_record and ubop['sub_type'] != const.BopName.Soldier:
                        my_ai.shoot_target_record.append(ubop['obj_id'])
                        return candidate
                damages = []
                for i in range(const.damage_num):
                    dam = my_ai.damage.get_zhimiao_damage(bop, ubop, candidate['weapon_id'], my_ai.my_map)
                    damages.append(dam)
                damage = np.mean(damages) + can_shoot_value
                candidate_bop_value.append((candidate, ubop, damage))
            candidate_bop_value = sorted(candidate_bop_value, key=lambda x: x[2], reverse=True)  # 按生命力降序排
            my_ai.shoot_target_record.append(candidate_bop_value[0][1]['obj_id'])
        return candidate_bop_value[0][0]

    def sort_guide_shoot_target(self, bop, candidate_bop, my_ai):

        if len(candidate_bop) == 1:
            my_ai.shoot_target_record.append(candidate_bop[0][1]['obj_id'])
            return candidate_bop[0][0]
        else:
            candidate_bop_value = []
            for candidate, ubop in candidate_bop:
                # can_shoot_value = rule.get_can_shoot_value(ubop)
                # if can_shoot_value >= 0.93:
                #     if ubop['obj_id'] not in ai_group.shoot_target_record:
                #         ai_group.shoot_target_record.append(ubop['obj_id'])
                #         return candidate
                guide_bop = common.get_bop_obj_id(my_ai.our_bops, candidate['guided_obj_id'])
                damages = []
                for i in range(const.damage_num):
                    dam = my_ai.damage.get_guide_damage(bop, ubop, guide_bop, candidate['weapon_id'], my_ai.my_map)
                    damages.append(dam)
                damage = np.mean(damages) #+ can_shoot_value
                candidate_bop_value.append((candidate, ubop, damage))
            candidate_bop_value = sorted(candidate_bop_value, key=lambda x: x[2], reverse=True)  # 按攻击力降序排
            my_ai.shoot_target_record.append(candidate_bop_value[0][1]['obj_id'])
        return candidate_bop_value[0][0]


    def shoot(self, bop, my_ai, tar_sub_type=[num for num in const.BopName.__dict__.values() if isinstance(num, int)]):
        # 遇到载人战车立即射击
        shoot_actions = common.get_bop_action_id_name(my_ai.observation['valid_actions'], bop['obj_id'],
                                                      const.ActionType.Shoot)
        if shoot_actions:
            shoot_action = shoot_actions[const.ActionType.Shoot]
            candidate_bop = [(dic, common.get_bop_obj_id(my_ai.enemy_bops, dic['target_obj_id'])) for dic in shoot_action]

            candidate_bop = [(dic, bop) for (dic,bop) in candidate_bop if bop['sub_type'] in tar_sub_type] #剔除不攻击算子类型
            if candidate_bop:
                candidate = self.sort_shoot_target(bop, candidate_bop, my_ai)

                # print(candidate['weapon_id'])
                # dam = ai_group.damage.get_zhimiao_damage(bop, candidate_bop[0][1], candidate['weapon_id'], ai_group.my_map)

                return {"actor": my_ai.seat,
                'obj_id': bop['obj_id'],
                'type': const.ActionType.Shoot,
                'target_obj_id': candidate['target_obj_id'],
                'weapon_id': candidate['weapon_id'],}
        return None

    def guide_shoot(self, bop, my_ai, tar_sub_type=[num for num in const.BopName.__dict__.values() if isinstance(num, int)]):
        # 遇到载人战车立即射击
        guide_shoot_actions = common.get_bop_action_id_name(my_ai.observation['valid_actions'], bop['obj_id'],
                                                      const.ActionType.GuideShoot)
        if guide_shoot_actions:
            guide_shoot_action = guide_shoot_actions[const.ActionType.GuideShoot]
            candidate_bop = [(dic, common.get_bop_obj_id(my_ai.enemy_bops, dic['target_obj_id'])) for dic in
                             guide_shoot_action]

            candidate_bop = [(dic, bop) for (dic, bop) in candidate_bop if bop['sub_type'] in tar_sub_type]  # 剔除不攻击算子类型
            if candidate_bop:
                candidate = self.sort_guide_shoot_target(bop, candidate_bop, my_ai)
                return {"actor": my_ai.seat,
                    'obj_id': bop['obj_id'],
                    'type': const.ActionType.GuideShoot,
                    'target_obj_id': candidate['target_obj_id'],
                    'weapon_id': candidate['weapon_id'],
                    'guided_obj_id': candidate['guided_obj_id'],}
        return None

    def fork(self, bop, my_ai):
        observation = my_ai.observation
        for obj_id, valid_actions in observation["valid_actions"].items():
            if bop["obj_id"] == obj_id and const.ActionType.Fork in valid_actions:
                action ={
                        "actor": my_ai.seat,
                        "obj_id": obj_id,
                        "type": 14,
                    }
                return action
        return None



    def get_key_point(self, my_ai, bop, main_point, hexes, kwargs):
        be_see_type = const.BopType.Vehicle
        pos_tuple = hexes
        center_int4 = main_point
        observe_point_dis = 2
        top_num = const.top_num
        select = const.select
        beta = const.beta

        int4 = util.select_key_point(my_ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                                 top_num, select, beta, **kwargs)
        return int4


    def occupy_move(self, bop, my_ai, occupy_point):
        if bop['sub_type'] == const.BopName.Tank:
            dis = 2
        else:
            dis = 1
        circle = my_ai.hex_cache.get_circle(occupy_point, 0, dis)
        ai = my_ai
        bop = bop
        be_see_type = const.BopType.Vehicle
        pos_tuple = circle
        center_int4 = occupy_point
        observe_point_dis = 0
        top_num = const.top_num
        select = const.select
        beta = const.beta
        kwargs = {'maneuver_time': 1,
                  'maneuver_time_main': 4,
                  'shoot_ability': .7,
                  'hide_cond': .8,
                  'stack': 2}
        int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                               top_num,
                                               select, beta, **kwargs)
        return int4

    def occupy_protect(self, bop, my_ai, occupy_point):
        if bop['sub_type'] == const.BopName.Tank:
            dis = 4
        elif bop['sub_type'] == const.BopName.Soldier:
            dis = 1
        else:
            dis = 2
        # if occupy_point == my_ai.attack_point['o_main_attack']:
        #     observed_main, observed_second = 1, 0
        # else:
        #     observed_main, observed_second = 0, 1

        if bop['sub_type'] == const.BopName.Soldier:
            circle = my_ai.hex_cache.get_circle(occupy_point, 0, dis)
            ai = my_ai
            bop = bop
            be_see_type = const.BopType.Vehicle
            pos_tuple = circle
            center_int4 = occupy_point
            observe_point_dis = 0
            top_num = const.top_num
            select = const.select
            beta = const.beta
            kwargs = {'observed_city': 1,
                      'observed_ability': 1,
                      'maneuver_time': .5,
                      'maneuver_time_main': .5,
                      'shoot_ability': 1,
                      'hide_cond': 1,
                      'stack': .5}
            int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                         top_num,
                                         select, beta, **kwargs)
        else:
            circle = my_ai.hex_cache.get_circle(occupy_point, 0, dis)
            ai = my_ai
            bop = bop
            be_see_type = const.BopType.Vehicle
            pos_tuple = circle
            center_int4 = occupy_point
            observe_point_dis = 0
            top_num = const.top_num
            select = const.select
            beta = const.beta
            kwargs = {'observed_city': 1,
                      'be_observed_ability': .5,
                      'maneuver_time': .5,
                      'maneuver_time_main': 1.5,
                      'shoot_ability': 1,
                      'hide_cond': 1.5,
                      'stack': .7}
            int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                                   top_num,
                                                   select, beta, **kwargs)
        return int4

    def OccupyingMain(self, my_ai, action_bops, change_state=True):
        bop = self.get_bop(my_ai)
        if bop:
            guide_action = self.guide_shoot(bop, my_ai)
            if guide_action:
                return guide_action
            action = self.shoot(bop, my_ai)
            if action:
                return action

            if not common.my_city(my_ai.observation['cities'], my_ai.color, coord=my_ai.attack_point['o_main_attack']):
                # 转为二级冲锋状态
                if change_state and not (bop['move_state'] == const.StateMode.Hide or bop['change_state_remain_time']):
                    action = self.change_rush_level_two(bop, my_ai)
                    if action:
                        return action

                action = self.occupy(bop, my_ai)
                if action:
                    return action

                if common.can_move(bop, my_ai):
                    bop_int4 = self.occupy_move(bop, my_ai, my_ai.attack_point['o_main_attack'])

                    action = self.move(bop, bop_int4, my_ai)
                    if action:
                        return action
            else:
                if not self.see_enemy(bop):
                    action = self.occupy(bop, my_ai)
                    if action:
                        return action
                    if common.can_move(bop, my_ai) and self.wait_time <= 0:
                        bop_int4 = self.occupy_protect(bop, my_ai, my_ai.attack_point['o_main_attack'])
                        if bop_int4 == bop['cur_hex']:
                            self.wait_time = 30
                        action = self.move(bop, bop_int4, my_ai)
                        if action:
                            return action
            action = self.hide(bop, my_ai)
            if action:
                return action
            self.wait_time -= 1
        return None

    def OccupyingSecond(self, my_ai, action_bops, change_state=True):
        bop = self.get_bop(my_ai)
        if bop:
            guide_action = self.guide_shoot(bop, my_ai)
            if guide_action:
                return guide_action
            action = self.shoot(bop, my_ai)
            if action:
                return action
            if change_state:
                action = self.change_rush_level_two(bop, my_ai)
                if action:
                    return action

            if not common.my_city(my_ai.observation['cities'], my_ai.color, coord=my_ai.attack_point['o_second_attack']):
                action = self.occupy(bop, my_ai)
                if action:
                    return action

                if common.can_move(bop, my_ai):
                    bop_int4 = self.occupy_move(bop, my_ai, my_ai.attack_point['o_second_attack'])

                    action = self.move(bop, bop_int4, my_ai,number = 1)
                    if action:
                        return action

            else:
                if not self.see_enemy(bop):
                    action = self.occupy(bop, my_ai)
                    if action:
                        return action
                    if common.can_move(bop, my_ai) and self.wait_time <= 0:
                        bop_int4 = self.occupy_protect(bop, my_ai, my_ai.attack_point['o_second_attack'])
                        if bop_int4 == bop['cur_hex']:
                            self.wait_time = 30
                        action = self.move(bop, bop_int4, my_ai,number = 1)
                        if action:
                            return action
                action = self.hide(bop, my_ai)
                if action:
                    return action
                self.wait_time -= 1
        return None

    def get_defense_guide_point(self, bop, my_ai, center_point, dis):
        # pos_start = bop['cur_hex']
        pos_main = my_ai.attack_point['o_second_attack']
        # hexes_main = ai_group.hex_cache.get_circle(pos_main, 1, 5)
        hexes = my_ai.hex_cache.get_circle(center_point, 0, dis)
        # intersection_hexes = list(set(hexes_main) & set(hexes_start))
        kwargs = {'be_observed_ability': 0.3,
                  'maneuver_time': 0.1,
                  'maneuver_time_main': 0,
                  'hide_cond': 1,
                  'stack': .1,
                  'replay_be_observed_ability': 1,
                  'be_observed_enemy_ability': 3}
        defense_guide_point = self.get_key_point(my_ai, bop, pos_main, hexes, kwargs)
        print('躲避引导射击点:', defense_guide_point)
        return defense_guide_point

    def defense_guide_move(self, bop, my_ai, init_center=None, dis=2):
        action = self.shoot(bop, my_ai)
        if action:
            return action
        if bop['sub_type'] != const.BopName.Tank:
            if self.see_can_shoot(bop, my_ai):
                action = self.stop(bop, my_ai)
                if action:
                    return action

        if not init_center:
            init_center = my_ai.attack_point['o_second_attack']
        if not hasattr(self, 'defense_point'):
            hexes = my_ai.hex_cache.get_circle(init_center, 0, dis)
            kwargs = {'be_observed_ability': 1.5,
                      'maneuver_time': 2,
                      'maneuver_time_main': 0,
                      'hide_cond': 1,
                      'stack': .1,
                      'replay_be_observed_ability': 0,
                      'be_observed_enemy_ability': 1}
            self.defense_point = self.get_key_point(my_ai, bop, init_center, hexes, kwargs)
            self.init_defense_guide_move = True

        if self.init_defense_guide_move and bop['cur_hex'] != self.defense_point:
            kwargs = {'beta': 1,
                      'hide_cond': 0.2,
                      'shoot_ability': 0,
                      'be_shoot_ability': 1,
                      'be_observed_enemy_ability': 0
                      }
            action = self.hide_move(bop, self.defense_point, my_ai, number=5, danger_stop=True,
                                    danger_value=0.7, **kwargs)
            if action:
                self.init_defense_guide_move = False
                return action

        be_see_by_soldier = my_ai.enemy_predict.be_observed_enemy_ability(bop, [bop['cur_hex']], my_ai,
                                                      ubop_type=const.BopName.Soldier) > 0.3
        be_see_by_unmanned = my_ai.enemy_predict.be_observed_enemy_ability(bop, [bop['cur_hex']], my_ai,
                                                                          ubop_type=const.BopName.UnmannedVehicle) > 0.3
        if my_ai.enemy_predict.is_be_guide_shoot(bop, my_ai) or \
                be_see_by_soldier > 0.3 or be_see_by_unmanned > 0.3:
            if self.can_move(bop, my_ai) and self.wait_time <= 0:
                defense_guide_point = self.get_defense_guide_point(bop, my_ai, bop['cur_hex'], 3)
                if defense_guide_point == bop['cur_hex']:
                    self.wait_time = 20
                kwargs = {'beta': 1,
                          'hide_cond': 0.2,
                          'shoot_ability': 0,
                          'be_shoot_ability': 1,
                          'be_observed_enemy_ability': 0
                          }
                action = self.hide_move(bop, defense_guide_point, my_ai, number=5, danger_stop=True,
                                        danger_value=0.7, **kwargs)
                if action:
                    return action

        self.wait_time -= 1

        action = self.hide(bop, my_ai)
        if action:
            return action

        return None

    def long_time_no_enemy(self, my_ai, continue_time, enemy_type):
        enemys = common.get_bop_type(my_ai.enemy_bops, enemy_type)
        if not hasattr(self, 'last_see_time'):
            self.last_see_time = my_ai.time
        if enemys:
            self.last_see_time = my_ai.time
        else:
            if my_ai.time - self.last_see_time > continue_time:
                return True
        return False

    def wait(self, name, time, my_ai):
        if not hasattr(self, f'time_{name}'):
            setattr(self, "time_{}".format(name), my_ai.time)
        time_diff = my_ai.time - getattr(self, "time_{}".format(name))
        if time_diff > time:
            return False
        else:
            return True

    def DT_Occupying(self, my_ai, action_bops, city_coord=None):
        if not city_coord:
            city_coord = my_ai.attack_point['o_main_attack']

        if city_coord == my_ai.attack_point['o_main_attack']:
            return self.OccupyingMain(my_ai, action_bops)
        else:
            return self.OccupyingSecond(my_ai, action_bops)

    def city_enemy(self, my_ai, city, dis=1):
        ubops_record = [ubop_record for ubop_id, ubop_record in my_ai.enemy_predict.ubops_record.items() if
                        ubop_record['live'] and ubop_record['sub_type']!=const.BopName.Missile]
        hexes_around_city = my_ai.hex_cache.get_circle(city, 0, dis)
        ubop_pos_city = np.zeros(len(hexes_around_city))
        for ubop_record in ubops_record:
            ubop_pos_city += ubop_record['pos_predict'][tuple(zip(*hexes_around_city))]
        ubop_pos_city = ubop_pos_city.sum()
        return ubop_pos_city

