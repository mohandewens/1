import random
import numpy as np
from ..utils import common, const
from ..hexmap.hex import BoundedHex, HEX_CUBE
from ..utils import util
from ..hexmap import common as com
from ..hexmap.astar import astar
from .basic_action_bop import Bop


class Vehicle(Bop):
    sub_type = const.BopName.Vehicle

    def __init__(self):
        super(Vehicle, self).__init__()

    def get_first_far_point(self, vehicle, my_ai, center_point, center_dis=[6, 10], bop_dis=[3, 8]):
        hexes_start = my_ai.hex_cache.get_circle(vehicle['cur_hex'], bop_dis[0], bop_dis[1])
        hexes_occupy = my_ai.hex_cache.get_circle(center_point, center_dis[0], center_dis[1])
        circle = list(set(hexes_start) & set(hexes_occupy))
        if not circle:
            circle = hexes_start
        ai = my_ai
        bop = vehicle
        be_see_type = const.BopType.Vehicle
        pos_tuple = circle
        center_int4 = center_point
        observe_point_dis = 1
        top_num = const.top_num
        select = const.select
        beta = const.beta

        kwargs = {'observed_ability': 1,
                  'observed_city': 2,
                  'maneuver_time': 1,
                  'maneuver_time_main': .3,
                  'neighbor_max_observe_ability': 0,
                  'hide_cond': 2,
                  'stack': 1,
                  'observe_enemy_time': 0,
                  'be_shoot_ability_time': 0}

        end_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                         top_num,
                                         select, beta, **kwargs)
        # print("战车第一攻击点为：", end_int4)
        return end_int4

    def get_second_far_point(self, vehicle, my_ai, center_point, main_dis=[18,25], bop_dis=[11, 12]):
        pos_start = my_ai.hex_cache.get_circle(vehicle['cur_hex'], bop_dis[0], bop_dis[1])
        # pos_main = my_ai.hex_cache.get_circle(center_point, main_dis[0], main_dis[1])
        # circle = list(set(pos_start) & set(pos_main))
        # if not circle:
        #     circle = pos_main
        ai = my_ai
        bop = vehicle
        be_see_type = const.BopType.Vehicle
        pos_tuple = pos_start
        center_int4 = my_ai.attack_point['e_main_attack']
        observe_point_dis = 0
        top_num = const.top_num
        select = const.select
        beta = const.beta
        kwargs = {'observed_city': 2,
                  'maneuver_time': 1,
                  'maneuver_time_main': .5,
                  'hide_cond': 1.5,
                  'stack': 0,
                  'shoot_ability': 1,
                  'be_shoot_ability': 3,
                  'observe_enemy_ability': 2}

        end_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                              top_num,
                                              select, beta, **kwargs)
        # print("战车第二攻击点为：", end_int4)
        return end_int4


    def get_off_point(self, vehicle, my_ai, center_point, center_dis=[6, 10], bop_dis=[3, 8]):
        hexes_start = my_ai.hex_cache.get_circle(vehicle['cur_hex'], bop_dis[0], bop_dis[1])
        hexes_occupy = my_ai.hex_cache.get_circle(center_point, center_dis[0], center_dis[1])
        circle = list(set(hexes_start) & set(hexes_occupy))
        if not circle:
            circle = hexes_start
        ai = my_ai
        bop = vehicle
        be_see_type = const.BopType.Vehicle
        pos_tuple = circle
        center_int4 = center_point
        observe_point_dis = 1
        top_num = const.top_num
        select = const.select
        beta = const.beta

        kwargs = {'observed_ability': 0,
                  'be_observed_ability': 2,
                  'maneuver_time': 1.5,
                  'maneuver_time_main': 1,
                  'neighbor_max_observe_ability': .5,
                  'hide_cond': 0.2,
                  'stack': 0.2,
                  'observe_enemy_time': 0,
                  'be_shoot_ability_time': 0}

        end_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                         top_num,
                                         select, beta, **kwargs)
        return end_int4

    def DT2get_far_guide_point(self, vehicle, my_ai, center_point, center_dis=[6, 10], bop_dis=[3, 8]):
        hexes_start = my_ai.hex_cache.get_circle(vehicle['cur_hex'], bop_dis[0], bop_dis[1])
        hexes_occupy = my_ai.hex_cache.get_circle(center_point, center_dis[0], center_dis[1])
        circle = list(set(hexes_start) & set(hexes_occupy))
        if not circle:
            circle = hexes_start
        ai = my_ai
        bop = vehicle
        be_see_type = const.BopType.Vehicle
        pos_tuple = circle
        center_int4 = center_point
        observe_point_dis = 1
        top_num = const.top_num
        select = const.select
        beta = const.beta
        kwargs = {'observed_ability': 0,
                  'be_observed_ability': 1.5,
                  'maneuver_time': 2,
                  'maneuver_time_main': 1,
                  'neighbor_max_observe_ability': 0,
                  'hide_cond': 0,
                  'stack': 0.2,
                  'replay_be_attacked_ability': 1, }

        end_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                         top_num,
                                         select, beta, **kwargs)
        return end_int4

    def DT2get_far_hide_point(self, vehicle, my_ai, center_point, bop_dis=[3, 8]):
        hexes_start = my_ai.hex_cache.get_circle(vehicle['cur_hex'], bop_dis[0], bop_dis[1])

        ai = my_ai
        bop = vehicle
        be_see_type = const.BopType.Vehicle
        pos_tuple = hexes_start
        center_int4 = center_point
        observe_point_dis = 0
        top_num = const.top_num
        select = const.select
        beta = const.beta
        kwargs = {'observed_ability': 0,
                  'be_observed_ability': 5,
                  'maneuver_time': 1,
                  'maneuver_time_main': 0,
                  'neighbor_max_observe_ability': 0,
                  'hide_cond': 0,
                  'stack': 0,
                  'replay_be_attacked_ability': 1, }

        end_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                         top_num,
                                         select, beta, **kwargs)
        return end_int4

    def find_hide_point(self, vehicle, my_ai):
        if my_ai.enemy_bops:
            ubops_pos = [ubop['cur_hex'] for ubop in my_ai.enemy_bops]
            ubops_pos = list(set(ubops_pos))

            see_np = my_ai.see.get_see_LOS(const.SeeSource.FromGround, vehicle['type'], ubops_pos)
            see_np = np.max(see_np, axis=0)
            rows, cols = np.where(see_np != 1)

            pos_tuple = BoundedHex(vehicle['cur_hex']).arc([0, 5], 3)
            pos_unsee = [pos for pos in pos_tuple if pos in list(zip(rows, cols))]
            if pos_unsee:
                ai = my_ai
                bop = vehicle
                be_see_type = const.BopType.Vehicle
                pos_tuple = pos_unsee
                center_int4 = my_ai.attack_point['o_main_attack']
                observe_point_dis = 0
                top_num = const.top_num
                select = const.select
                beta = const.beta
                kwargs = {'maneuver_time': 1.5,
                          'maneuver_time_main': .5,
                          'hide_cond': 1.2,
                          'stack': 0.5,
                          'be_shoot_ability': 1}

                vehicle_hide_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4,
                                                          observe_point_dis,
                                                          top_num,
                                                          select, beta, **kwargs)

                #print('有敌人时找到隐蔽点为：', vehicle_hide_int4)
            else:  # 没有可隐蔽的点
                ai = my_ai
                bop = vehicle
                be_see_type = const.BopType.Vehicle
                pos_tuple = pos_tuple
                center_int4 = my_ai.attack_point['o_main_attack']
                observe_point_dis = 0
                top_num = const.top_num
                select = const.select
                beta = const.beta
                kwargs = {'maneuver_time': 2,
                          'hide_cond': 1.5,
                          'stack': 0.5,
                          }

                vehicle_hide_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4,
                                                          observe_point_dis,
                                                          top_num,
                                                          select, beta, **kwargs)

                print('无躲避点时找到隐蔽点为：', vehicle_hide_int4)

        else:
            circle = BoundedHex(vehicle['cur_hex']).arc([0, 5], 3)

            ai = my_ai
            bop = vehicle
            be_see_type = const.BopType.Vehicle
            pos_tuple = circle
            center_int4 = my_ai.attack_point['o_main_attack']
            observe_point_dis = 0
            top_num = const.top_num
            select = const.select
            beta = const.beta

            kwargs = {'be_observed_ability': 1,
                      'maneuver_time': 2,
                      'maneuver_time_main': 0.5,
                      'neighbor_max_observe_ability': 0,
                      'hide_cond': 1,
                      'stack': .5,
                      }

            vehicle_hide_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                                      top_num,
                                                      select, beta, **kwargs)

            #print('zhance看不见任何敌人时，选择的隐蔽点为：', vehicle_hide_int4)
        return vehicle_hide_int4

    def passenger_off(self, bop, my_ai, sub_type=None):
        """Generate get off action only if the bop is within some distance of a random city."""
        off_actions = common.get_bop_action_id_name(my_ai.observation['valid_actions'], bop['obj_id'],
                                                    const.ActionType.GetOff)
        if off_actions:
            off_action = off_actions[const.ActionType.GetOff]
            if sub_type:
                for dic in off_action:
                    passenger = common.get_passenger_bop_obj_id(my_ai.our_passengers, dic['target_obj_id'])
                    if passenger['sub_type'] == sub_type:
                        target_obj_id = dic['target_obj_id']
                        return {"actor": my_ai.seat,
                                'obj_id': bop['obj_id'],
                                'type': const.ActionType.GetOff,
                                'target_obj_id': target_obj_id,
                                }
            else:
                target_obj_id = random.choice(off_action)['target_obj_id']
                return {"actor": my_ai.seat,
                        'obj_id': bop['obj_id'],
                        'type': const.ActionType.GetOff,
                        'target_obj_id': target_obj_id,
                        }
        else:
            return None

    def have_passenger_number(self, my_ai, vehicle, sub_type=None):
        if sub_type:
            number = common.get_passenger_number(vehicle, my_ai.our_passengers, sub_type=sub_type)
            return number
        else:
            number = common.get_passenger_number(vehicle, my_ai.our_passengers)
            return number

    def vehicle_move_hide(self, vehicle, my_ai):
        # 坦克行进到隐蔽点
        move_action = common.get_bop_action_id_name(my_ai.observation['valid_actions'], vehicle['obj_id'],
                                                    const.ActionType.Move)
        if move_action:
            hide_point = self.find_hide_point(vehicle, my_ai)
            if hide_point:
                kwargs = {'beta': 1.5,
                          'hide_cond': 1,
                          'shoot_ability': 0,
                          'be_shoot_ability': 1,
                          'be_shoot_ability_aircraft': 0,
                          'observe_enemy_ability': 0,
                          'be_observed_enemy_ability': 1}
                action = self.hide_move(vehicle, hide_point, my_ai, danger_stop=False, **kwargs)
                return action
        return None

    def get_guide_call(self, vehicle, my_ai, action_bops):
        launch_ids = vehicle['launch_ids']
        launch_bops = [common.get_bop_obj_id(my_ai.our_bops, obj_id) for obj_id in launch_ids]
        guide_obj_ids = [bop['obj_id'] for bop in launch_bops if bop['guide_ability']]
        guide_call = []
        for guide_obj_id in guide_obj_ids:
            action_bop = common.get_action_bop_obj_id(action_bops, guide_obj_id)
            guide_call.extend(action_bop.call_guide)

        return guide_call


class Soldier(Bop):
    sub_type = const.BopName.Soldier

    def __init__(self):
        super(Soldier, self).__init__()
        self.call_guide = []
        self.stop_call = False

    def get_on(self, soldier, my_ai):
        """Generate get on action with some probability."""
        on_actions = common.get_bop_action_id_name(my_ai.observation['valid_actions'], soldier['obj_id'],
                                                   const.ActionType.GetOn)
        if on_actions:
            on_action = on_actions[const.ActionType.GetOn]
            target_obj_id = random.choice(on_action)['target_obj_id']
            return {"actor": my_ai.seat,
                    'obj_id': soldier['obj_id'],
                    'type': const.ActionType.GetOn,
                    'target_obj_id': target_obj_id,
                    }

        return None

    def change_rush_level_two(self, soldier, my_ai):
        state_actions = common.get_bop_action_id_name(my_ai.observation['valid_actions'], soldier['obj_id'],
                                                      const.ActionType.ChangeState)
        if state_actions:
            state_action = state_actions[const.ActionType.ChangeState]
            target_state_list = [state['target_state'] for state in state_action]
            if const.StateMode.Rush_level_two in target_state_list:
                return {"actor": my_ai.seat,
                        'obj_id': soldier['obj_id'],
                        'type': const.ActionType.ChangeState,
                        'target_state': const.StateMode.Rush_level_two,
                        }

        else:
            return None

    def attack_city(self, my_ai, city, change_state=True):
        bop = self.get_bop(my_ai)
        if bop:
            guide_action = self.guide_shoot(bop, my_ai)
            if guide_action:
                return guide_action

            action = self.shoot(bop, my_ai)
            if action:
                return action
            if my_ai.time < 1000:
                if change_state:
                    if bop['move_state'] != const.StateMode.Rush_level_two:
                        action = self.change_rush_level_two(bop, my_ai)
                        if action:
                            return action

            if self.see_enemy(bop) and self.can_move(bop, my_ai):
                ubops = common.get_see_enemy(bop, my_ai.enemy_bops)
                vehicles = common.get_bop_sub_type(my_ai.our_bops, const.BopName.Vehicle)
                if vehicles:
                    vehicle = vehicles[0]
                    for ubop in ubops:
                        if ubop['sub_type'] != const.BopName.Soldier:
                            dis = com.get_distance(vehicle['cur_hex'], ubop['cur_hex'])
                            if dis <= 20:
                                self.stop_call = True
                                self.call_guide = [ubop for ubop in ubops if ubop['type'] == const.BopType.Vehicle]
                                break
                            else:
                                self.stop_call = False
                                self.call_guide = []
                elif self.see_can_shoot(bop, my_ai):
                    self.stop_call = True
            else:
                self.stop_call = False
                self.call_guide = []

            # 看到敌人立即停止机动
            if self.stop_call:
                action = self.stop(bop, my_ai)
                if action:
                    return action

            # self.OccupyingMain(my_ai, action_bops, change_state=True)
            if not common.my_city(my_ai.observation['cities'], my_ai.color,
                                  coord=city):
                action = self.occupy(bop, my_ai)
                if action:
                    return action
                if self.city_enemy(my_ai, city, dis=1) > 0.2:
                    if common.can_move(bop, my_ai) and self.wait_time <= 0:
                        bop_int4 = self.occupy_near_attack(bop, my_ai, city, dis=1)
                        if bop['cur_hex'] == bop_int4:
                            self.wait_time = 30

                        action = self.move(bop, bop_int4, my_ai)
                        if action:
                            return action
                else:
                    if bop['cur_hex'] != city:
                        if common.can_move(bop, my_ai) and self.wait_time <= 0:
                            bop_int4 = self.occupy_move(bop, my_ai, city)
                            if bop['cur_hex'] == bop_int4:
                                self.wait_time = 30

                            action = self.move(bop, bop_int4, my_ai)
                            if action:
                                return action

            else:
                if not self.stop_call:
                    action = self.occupy(bop, my_ai)
                    if action:
                        return action
                    if common.can_move(bop, my_ai) and self.wait_time <= 0:
                        bop_int4 = self.occupy_protect(bop, my_ai, city)
                        if bop_int4 == bop['cur_hex']:
                            self.wait_time = 30
                        action = self.move(bop, bop_int4, my_ai)
                        if action:
                            return action
            self.wait_time -= 1
        return None


class Tank(Bop):
    sub_type = const.BopName.Tank

    def __init__(self):
        super(Tank, self).__init__()
        self.wait_friend_see_shoot = 0

    def find_shoot_point(self, tank, my_ai, center_point):
        circle = my_ai.hex_cache.get_circle(center_point, 0, 3)

        ai = my_ai
        bop = tank
        be_see_type = const.BopType.Vehicle
        pos_tuple = circle
        center_int4 = my_ai.attack_point['o_main_attack']
        observe_point_dis = 0
        top_num = const.top_num
        select = const.select
        beta = const.beta
        kwargs = {'observed_ability': 0.2,
                  'maneuver_time': 1,
                  'maneuver_time_main': .3,
                  'hide_cond': 1.5,
                  'stack': .5,
                  'shoot_ability': 2,
                  'be_observed_enemy_ability': 1}

        tank_shoot_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                                top_num,
                                                select, beta, **kwargs)
        return tank_shoot_int4

    def find_hide_point(self, tank, my_ai, dis=3):
        if my_ai.enemy_bops:
            ubops_pos = [ubop['cur_hex'] for ubop in my_ai.enemy_bops]
            ubops_pos = list(set(ubops_pos))

            see_np = my_ai.see.get_see_LOS(const.SeeSource.FromGround, tank['type'], ubops_pos)
            see_np = np.max(see_np, axis=0)
            rows, cols = np.where(see_np != 1)

            pos_tuple = BoundedHex(tank['cur_hex']).arc([0, 5], dis)
            pos_unsee = [pos for pos in pos_tuple if pos in list(zip(rows, cols))]
            if pos_unsee:
                ai = my_ai
                bop = tank
                be_see_type = const.BopType.Vehicle
                pos_tuple = pos_unsee
                center_int4 = my_ai.attack_point['o_main_attack']
                observe_point_dis = 0
                top_num = const.top_num
                select = const.select
                beta = const.beta
                kwargs = {'maneuver_time': 1.5,
                          'maneuver_time_main': .5,
                          'stack': 0.5,
                          'hide_cond': 1.5,
                          'be_shoot_ability': 0,
                          'be_observed_enemy_ability': 0}
                tank_hide_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                                       top_num,
                                                       select, beta, **kwargs)
                #print('有敌人时找到隐蔽点为：', tank_hide_int4)
            else:  # 没有可隐蔽的点
                ai = my_ai
                bop = tank
                be_see_type = const.BopType.Vehicle
                pos_tuple = pos_tuple
                center_int4 = my_ai.attack_point['o_main_attack']
                observe_point_dis = 0
                top_num = const.top_num
                select = const.select
                beta = const.beta
                kwargs = {'maneuver_time': .2,
                          'hide_cond': 1.5,
                          'stack': 0.5,
                          'be_shoot_ability': 0.5,
                          'be_observed_enemy_ability': 1.5}

                tank_hide_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                                       top_num,
                                                       select, beta, **kwargs)

                print('无躲避点时找到隐蔽点为：', tank_hide_int4)

        else:
            circle = BoundedHex(tank['cur_hex']).arc([0, 5], dis)
            ai = my_ai
            bop = tank
            be_see_type = const.BopType.Vehicle
            pos_tuple = circle
            center_int4 = my_ai.attack_point['o_main_attack']
            observe_point_dis = 0
            top_num = const.top_num
            select = const.select
            beta = const.beta
            kwargs = {'be_observed_ability': 0.5,
                      'maneuver_time': 0,
                      'maneuver_time_main': 1,
                      'neighbor_max_observe_ability': 0,
                      'hide_cond': 1.5,
                      'stack': .5,
                      'be_shoot_ability': 1,
                      'be_observed_enemy_ability': 1}

            tank_hide_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                                   top_num,
                                                   select, beta, **kwargs)

            print('坦克看不见任何敌人时，选择的隐蔽点为：', tank_hide_int4)
        return tank_hide_int4

    def tank_move_hide(self, tank, my_ai):
        # 坦克行进到隐蔽点
        move_action = common.get_bop_action_id_name(my_ai.observation['valid_actions'], tank['obj_id'],
                                                    const.ActionType.Move)
        if move_action and self.wait_time <= 0:
            hide_point = self.find_hide_point(tank, my_ai, dis=3)
            if hide_point == tank['cur_hex']:
                self.wait_time = 20
            if hide_point:
                kwargs = {'beta': 5,
                          'hide_cond': 1,
                          'shoot_ability': 0,
                          'be_shoot_ability': 1,
                          'be_observed_enemy_ability': 0.5
                          }
                action = self.hide_move(tank, hide_point, my_ai, number=5, **kwargs)
                return action
        self.wait_time -= 1
        return None

    def tank_move_attack(self, tank, my_ai, center_point=None):
        if not center_point:
            center_point = my_ai.attack_point['o_main_attack']
        # 坦克行进到观察点
        move_action = common.get_bop_action_id_name(my_ai.observation['valid_actions'], tank['obj_id'],
                                                    const.ActionType.Move)
        if move_action and self.wait_time <= 0:
            shoot_point = self.find_shoot_point(tank, my_ai, center_point)
            if tank['cur_hex'] == shoot_point:
                self.wait_time = 20
            if shoot_point:
                kwargs = {'beta': 4,
                          'hide_cond': 1.5,
                          'shoot_ability': 1.5,
                          'be_shoot_ability': 0,
                          'be_observed_enemy_ability': 1
                          }
                action = self.hide_move(tank, shoot_point, my_ai, number=5, danger_stop=True, danger_value=self.get_top_attack_value(my_ai), **kwargs)
                if action:
                    return action

        self.wait_time -= 1
        return None

    def tank_hide_and_attack(self, tank, my_ai):
        if self.see_enemy(tank) and tank['weapon_cool_time'] >= 40:
            action = self.tank_move_hide(tank, my_ai, )
            if action:
                return action
        elif not tank['see_enemy_bop_ids'] and tank['weapon_cool_time'] <= 20:
            action = self.tank_move_attack(tank, my_ai, center_point=tank['cur_hex'])
            if action:
                return action
        else:
            return None

    def friend_see_shoot(self, tank, my_ai, dis=3):
        if my_ai.enemy_bops:
            if common.can_move(tank, my_ai) and not tank['see_enemy_bop_ids'] and tank[
                'weapon_cool_time'] <= 20 and self.wait_friend_see_shoot <= 0:
                pos_tuple = my_ai.hex_cache.get_circle(tank['cur_hex'], 1, dis)
                pos_int4 = com.cvtOffset2Int4loc(pos_tuple)
                pos_see = []
                for pos in pos_int4:
                    for ubop in my_ai.enemy_bops:
                        if ubop['sub_type'] != const.BopName.Soldier:
                            if my_ai.my_map.can_see(pos, ubop['cur_hex'], const.SeeMode.GroundToGround):
                                shoot_dis = my_ai.damage.get_bop_attack_distance(tank, ubop['type'])
                                dis = com.get_distance(pos, ubop['cur_hex'])
                                if dis < shoot_dis:
                                    pos_see.append(pos)
                if pos_see:
                    ai = my_ai
                    bop = tank
                    be_see_type = const.BopType.Vehicle
                    pos_list = list(set(pos_see))
                    center_int4 = my_ai.attack_point['o_main_attack']
                    observe_point_dis = 2
                    top_num = const.top_num
                    select = const.select
                    beta = const.beta
                    kwargs = {'observed_ability': 0,
                              'be_observed_ability': 0,
                              'maneuver_time': 2,
                              'maneuver_time_main': 0,
                              'neighbor_max_observe_ability': 0,
                              'hide_cond': 1.5,
                              'stack': 0,
                              'shoot_ability': 1.5,
                              'be_shoot_ability': 1}

                    tank_end_int4 = util.select_key_point(ai, bop, be_see_type, pos_list, center_int4,
                                                          observe_point_dis,
                                                          top_num,
                                                          select, beta, **kwargs)
                    kwargs = {'beta': 2,
                              'hide_cond': 1,
                              'shoot_ability': 1,
                              'be_shoot_ability': 0,
                              'be_observed_enemy_ability': 1.5
                              }
                    action = self.hide_move(tank, tank_end_int4, my_ai, number=5, danger_stop=True,
                                            danger_value=self.get_top_attack_value(my_ai), **kwargs)
                    if action:
                        #print(f'坦克友邻通视射击, 机动点为{tank_end_int4}')
                        return action
                    else:
                        self.wait_friend_see_shoot = 10
                        #print(f'坦克友邻通视射击目标点的被攻击度,不出动射击')
        self.wait_friend_see_shoot -= 1
        return list()

    def get_top_attack_value(self, my_ai):
        if my_ai.time < 500 or my_ai.time > 1400:
            top_attack_value = 2.5
        else:
            if my_ai.color == const.Color.RED:
                top_attack_value = 1.8
            else:
                top_attack_value = 2.5
        return top_attack_value

    def OccupyingCity(self, my_ai, action_bops, city_coord):
        tank = self.get_bop(my_ai)
        if tank:
            action = self.shoot(tank, my_ai)
            if action:
                return action

            action = self.occupy(tank, my_ai)
            if action:
                return action

            if not common.my_city(my_ai.observation['cities'], my_ai.color, coord=city_coord):
                if common.can_move(tank, my_ai):
                    tank_int4 = self.occupy_move(tank, my_ai, city_coord)
                    kwargs = {'beta': 3,
                              'hide_cond': 1,
                              'shoot_ability': 1.5,
                              'be_shoot_ability': 1,
                              'be_observed_enemy_ability': 0
                              }
                    action = self.hide_move(tank, tank_int4, my_ai, number=5, danger_stop=False, danger_value=self.get_top_attack_value(my_ai), **kwargs)
                    if action:
                        return action
            else:
                dis = com.get_distance(tank['cur_hex'], city_coord)
                if dis >= 6:
                    end_point = self.occupy_protect(tank, my_ai, city_coord)
                    kwargs = {'beta': 3,
                              'hide_cond': 1,
                              'shoot_ability': 1.5,
                              'be_shoot_ability': 0,
                              'be_observed_enemy_ability': 1
                              }
                    action = self.hide_move(tank, end_point, my_ai, number=5, danger_stop=False,
                                            danger_value=self.get_top_attack_value(my_ai), **kwargs)
                    if action:
                        return action

                action = self.friend_see_shoot(tank, my_ai)
                if action:
                    return action

                action = self.tank_hide_and_attack(tank, my_ai)
                if action:
                    return

    def get_attack_vehicle_point(self, tank, my_ai, dis):
        ubops_predict = [ubop_record['pos_predict'] for ubop_id, ubop_record in my_ai.enemy_predict.ubops_record.items() if
                        ubop_record['live'] and ubop_record['sub_type'] == const.BopName.Vehicle]
        if not ubops_predict:
            return tank['cur_hex']

        # for ubop_record in ubops_record:
        ubop_pos = np.array(ubops_predict).max(axis=0)
        index_flatten = np.argmax(ubop_pos, axis=None)
        index_tuple = (index_flatten // my_ai.my_map.size[1], index_flatten % my_ai.my_map.size[1])
        index_int4 = com.cvtOffset2Int4loc(index_tuple)
        if com.get_distance(index_int4, my_ai.attack_point['o_main_attack']) > 30:
            return my_ai.attack_point['o_main_attack']
        else:
            pos_tuple = my_ai.hex_cache.get_circle(tank['cur_hex'], 0, dis)
            pos_int4 = com.cvtOffset2Int4loc(pos_tuple)
            maneuver_time = my_ai.see.get_maneuver_time(tank['type'], tank['cur_hex'])[tuple(zip(*pos_tuple))]
            pos_see = []
            dis_record = []
            for pos, time in zip(pos_int4, maneuver_time):
                dis = com.get_distance(pos, tank['cur_hex'])
                dis_time = my_ai.see.get_maneuver_time(tank['type'], pos)[index_tuple]
                dis_record.append((dis, dis_time, time, pos))
                if my_ai.my_map.can_see(pos, index_int4, const.SeeMode.GroundToGround):
                    shoot_dis = my_ai.damage.get_bop_attack_distance(tank, const.BopType.Vehicle)
                    if dis < shoot_dis - 4:
                        # dis = com.get_distance(pos, tank['cur_hex'])
                        pos_see.append(pos)
            if pos_see:
                pos_list = list(set(pos_see))
                center_int4 = index_int4
                kwargs = {'maneuver_time': 1,
                          'maneuver_time_main': .5,
                          'hide_cond': 1,
                          'stack': 0.5,
                          'shoot_ability': 3,
                          'be_shoot_ability': 1,
                          'be_observed_enemy_ability': 1}

                tank_end_int4 = util.select_key_point(my_ai, tank, const.BopType.Vehicle, pos_list, center_int4, \
                                                      top_num=const.top_num, select=const.select, beta=const.beta, **kwargs)
                result_int4 = tank_end_int4
            else:
                dis_record = sorted(dis_record, key=lambda x: x[0], reverse=True)
                dis_record = sorted(dis_record, key=lambda x: x[1] + x[2])

                result_int4 = dis_record[0][3]
                # print(dis_record)
                if result_int4 == tank['cur_hex']:
                    result_int4 = dis_record[1][3]
                i = 1
                while result_int4 in my_ai.land_marks:
                    i += 1
                    result_int4 = dis_record[i][3]

            return result_int4

    def tank_attack_vehicle(self, tank, my_ai, dis=5, hide_flag=False, be_attacked=2):
        # 坦克行进到观察点
        move_action = common.get_bop_action_id_name(my_ai.observation['valid_actions'], tank['obj_id'],
                                                    const.ActionType.Move)
        if move_action and self.wait_time <= 0:
            shoot_point = self.get_attack_vehicle_point(tank, my_ai, dis)
            if shoot_point == tank['cur_hex']:
                self.wait_time = 10
            # if not hide_flag:
            #     action = self.move(tank, shoot_point, my_ai)
            #     return action
            # else:
            if shoot_point:
                kwargs = {'beta': .5,
                          'hide_cond': 1,
                          'shoot_ability': 1,
                          'be_shoot_ability': 0,
                          'be_observed_enemy_ability': 0.2
                          }
                action = self.hide_move(tank, shoot_point, my_ai, number=5, danger_stop=hide_flag,
                                        danger_value=self.get_top_attack_value(my_ai), **kwargs)
                if action:
                    return action
        self.wait_time -= 1
        return None


class Missile(Bop):
    sub_type = const.BopName.Missile

    def __init__(self):
        super(Missile, self).__init__()


'''无人战车行动类'''


class UnmannedVehicle(Bop):
    sub_type = const.BopName.UnmannedVehicle

    def __init__(self):
        super(UnmannedVehicle, self).__init__()

    def get_observe_point(self, unmanned, my_ai, dis=4):
        pos_tuple = my_ai.hex_cache.get_circle(unmanned['cur_hex'], 0, dis)
        pos_int4 = com.cvtOffset2Int4loc(pos_tuple)
        maneuver_time = my_ai.see.get_maneuver_time(unmanned['type'], unmanned['cur_hex'])[tuple(zip(*pos_tuple))]
        observe_enemy_ability = my_ai.enemy_predict.observe_enemy_ability(unmanned, pos_int4, my_ai)
        be_shoot_ability = my_ai.enemy_predict.be_attacked_ability(unmanned, pos_int4, my_ai)
        index = (observe_enemy_ability > 0.4) & (be_shoot_ability < 0.2)
        if not index.all():
            index = random.choice(range(len(pos_int4)))
        #if not index:\nValueError: The truth value of an array with more than one element is ambiguous. Use a.any() or a.all()

        select_int4 = np.array(pos_int4)[index].tolist()
        select_time = maneuver_time[index].tolist()
        # print("select_int4_type=",select_int4,type(select_int4))
        # print("select_time_type=",select_time,type(select_time))
        if select_int4 and select_time:
            # int4_time = zip(select_int4, select_time)
            # int4_time = [select_int4, select_time]
            # int4_time = sorted(int4_time, key=lambda x: x[1])
            # result_int4 = int4_time[0][0]
            result_int4 = select_int4
        else:
            no_hex = my_ai.hex_cache.get_circle(my_ai.attack_point['o_main_attack'], 10, 13)
            pos_start = my_ai.hex_cache.get_circle(unmanned['cur_hex'], 0, 3)
            pos_list = list(set(pos_start) - set(no_hex))
            center_int4 = my_ai.attack_point['e_main_attack']
            kwargs = {'observed_point': 0,
                      'observed_second': 2,
                      'maneuver_time': 0,
                      'maneuver_time_main': .2,
                      'hide_cond': .3,
                      }

            result_int4 = util.select_key_point(my_ai, unmanned, const.BopType.Vehicle, pos_list, center_int4, \
                                                top_num=const.top_num, select=const.select, beta=const.beta, **kwargs)
        #print("无人战车观察点为：", result_int4)
        return result_int4

    def move_hide(self, unmanned, my_ai):
        # 坦克行进到隐蔽点
        move_action = common.get_bop_action_id_name(my_ai.observation['valid_actions'], unmanned['obj_id'],
                                                    const.ActionType.Move)
        if move_action and self.wait_time <= 0:
            hide_point = self.find_hide_point(unmanned, my_ai)
            if hide_point == unmanned['cur_hex']:
                self.wait_time = 20
            if hide_point:
                action = self.move(unmanned, hide_point, my_ai)
                return action
        self.wait_time -= 1
        return None

    def find_hide_point(self, unmanned, my_ai):
        pos_tuple = my_ai.hex_cache.get_circle(unmanned['cur_hex'], 1, 2)
        ai = my_ai
        bop = unmanned
        be_see_type = const.BopType.Vehicle
        pos_tuple = pos_tuple
        center_int4 = my_ai.attack_point['o_main_attack']
        observe_point_dis = 0
        top_num = const.top_num
        select = const.select
        beta = const.beta
        kwargs = {'maneuver_time': 1,
                  'maneuver_time_main': 0,
                  'stack': 0.5,
                  'be_shoot_ability': 4,
                  'observe_enemy_ability': 2}

        hide_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis, \
                                          top_num, select, beta, **kwargs)
        #self.hide_point = hide_int4
        return hide_int4


class Artillery(Bop):
    sub_type = const.BopName.Artillery
    def __init__(self):
        super(Artillery, self).__init__()
        self.random_jm = False

    def can_jm(self, artillery, my_ai):
        jm_actions = common.get_bop_action_id_name(my_ai.observation['valid_actions'], artillery['obj_id'],
                                                   const.ActionType.JMPlan)
        if jm_actions:
            return True
        else:
            return False

    def jm_city(self, bop, my_ai):
        circle = BoundedHex(my_ai.attack_point['e_main_attack']).arc([0, 5], 1, origin=True)
        circle_int4 = com.cvtOffset2Int4loc(circle)
        int4 = random.choice(circle_int4)
        action = self.jm_plan(bop, int4, my_ai)
        if action:
            self.random_jm = True
            return action
        return None

    def cancel_jm(self, bop, my_ai):
        cancel_jm_actions = common.get_bop_action_id_name(my_ai.observation['valid_actions'], bop['obj_id'],
                                                   const.ActionType.CancelJMPlan)
        if cancel_jm_actions:
            # cancel_jm_action = cancel_jm_actions[const.ActionType.CancelJMPlan]
            return {"actor": my_ai.seat,
                    'obj_id': bop['obj_id'],
                    'type': const.ActionType.CancelJMPlan,
                    }
        else:
            return None

    def jm_plan(self, bop, jm_pos, my_ai):
        """Generate jm plan action aimed at a random city."""
        jm_actions = common.get_bop_action_id_name(my_ai.observation['valid_actions'], bop['obj_id'],
                                                   const.ActionType.JMPlan)
        if jm_actions:
            jm_action = jm_actions[const.ActionType.JMPlan]
            weapon_id = jm_action[0]['weapon_id']
            return {"actor": my_ai.seat,
                    'obj_id': bop['obj_id'],
                    'type': const.ActionType.JMPlan,
                    'jm_pos': jm_pos,
                    'weapon_id': weapon_id,
                    }

        else:
            return None

class UAV(Bop):
    sub_type = const.BopName.UAV
    def __init__(self):
        super(UAV, self).__init__()

class ScoutVehicle(Bop):
    sub_type = const.BopName.ScoutVehicle

    def __init__(self):
        super(ScoutVehicle, self).__init__()

    def get_observe_point(self, ScoutVehicle, my_ai, dis=4):
        pos_tuple = my_ai.hex_cache.get_circle(ScoutVehicle['cur_hex'], 0, dis)
        pos_int4 = com.cvtOffset2Int4loc(pos_tuple)
        maneuver_time = my_ai.see.get_maneuver_time(ScoutVehicle['type'], ScoutVehicle['cur_hex'])[tuple(zip(*pos_tuple))]
        observe_enemy_ability = my_ai.enemy_predict.observe_enemy_ability(ScoutVehicle, pos_int4, my_ai)
        be_shoot_ability = my_ai.enemy_predict.be_attacked_ability(ScoutVehicle, pos_int4, my_ai)
        index = (observe_enemy_ability > 0.4) & (be_shoot_ability < 0.2)
        if not index:
            index = random.choice(range(len(pos_int4)))

        select_int4 = np.array(pos_int4)[index].tolist()
        select_time = maneuver_time[index].tolist()
        if select_int4 and select_time:
            # int4_time = zip(select_int4, select_time)
            # int4_time = [select_int4, select_time]
            # int4_time = sorted(int4_time, key=lambda x: x[1])
            # result_int4 = int4_time[0][0]
            result_int4 = select_int4
        else:
            no_hex = my_ai.hex_cache.get_circle(my_ai.attack_point['o_main_attack'], 10, 13)
            pos_start = my_ai.hex_cache.get_circle(ScoutVehicle['cur_hex'], 0, 3)
            pos_list = list(set(pos_start) - set(no_hex))
            center_int4 = my_ai.attack_point['e_main_attack']
            kwargs = {'observed_point': 0,
                      'observed_second': 2,
                      'maneuver_time': 0,
                      'maneuver_time_main': .2,
                      'hide_cond': .3,
                      }

            result_int4 = util.select_key_point(my_ai, ScoutVehicle, const.BopType.Vehicle, pos_list, center_int4, \
                                                top_num=const.top_num, select=const.select, beta=const.beta, **kwargs)
        #print("无人战车观察点为：", result_int4)
        return result_int4

    def move_hide(self, ScoutVehicle, my_ai):
        # 坦克行进到隐蔽点
        move_action = common.get_bop_action_id_name(my_ai.observation['valid_actions'], ScoutVehicle['obj_id'],
                                                    const.ActionType.Move)
        if move_action and self.wait_time <= 0:
            hide_point = self.find_hide_point(ScoutVehicle, my_ai)
            if hide_point == ScoutVehicle['cur_hex']:
                self.wait_time = 20
            if hide_point:
                action = self.move(ScoutVehicle, hide_point, my_ai)
                return action
        self.wait_time -= 1
        return None

    def find_hide_point(self, ScoutVehicle, my_ai):
        pos_tuple = my_ai.hex_cache.get_circle(ScoutVehicle['cur_hex'], 1, 2)
        ai = my_ai
        bop = ScoutVehicle
        be_see_type = const.BopType.Vehicle
        pos_tuple = pos_tuple
        center_int4 = my_ai.attack_point['o_main_attack']
        observe_point_dis = 0
        top_num = const.top_num
        select = const.select
        beta = const.beta
        kwargs = {'maneuver_time': 1,
                  'maneuver_time_main': 0,
                  'stack': 0.5,
                  'be_shoot_ability': 4,
                  'observe_enemy_ability': 0}

        hide_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis, \
                                          top_num, select, beta, **kwargs)
        #print('有敌人时找到隐蔽点为：', hide_int4)
        if my_ai.time < 600:
            hide_int4 = hide_int4
        elif my_ai.time < 1200:
            hide_int4 = hide_int4
        else :
            hide_int4 = hide_int4
        return hide_int4


    def get_guide_call(self, vehicle, my_ai, action_bops):
        launch_ids = vehicle['launch_ids']
        launch_bops = [common.get_bop_obj_id(my_ai.our_bops, obj_id) for obj_id in launch_ids]
        guide_obj_ids = [bop['obj_id'] for bop in launch_bops if bop['guide_ability']]
        guide_call = []
        for guide_obj_id in guide_obj_ids:
            action_bop = common.get_action_bop_obj_id(action_bops, guide_obj_id)
            guide_call.extend(action_bop.call_guide)

        return guide_call

    def get_first_far_point(self, vehicle, my_ai, center_point, center_dis=[6, 10], bop_dis=[3, 8]):
        hexes_start = my_ai.hex_cache.get_circle(vehicle['cur_hex'], bop_dis[0], bop_dis[1])
        hexes_occupy = my_ai.hex_cache.get_circle(center_point, center_dis[0], center_dis[1])
        circle = list(set(hexes_start) & set(hexes_occupy))
        if not circle:
            circle = hexes_start
        ai = my_ai
        bop = vehicle
        be_see_type = const.BopType.Vehicle
        pos_tuple = circle
        center_int4 = center_point
        observe_point_dis = 1
        top_num = const.top_num
        select = const.select
        beta = const.beta

        kwargs = {'observed_ability': 1,
                  'observed_city': 2,
                  'maneuver_time': 1,
                  'maneuver_time_main': .3,
                  'neighbor_max_observe_ability': 0,
                  'hide_cond': 2,
                  'stack': 1,
                  'observe_enemy_time': 0,
                  'be_shoot_ability_time': 0}

        end_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                         top_num,
                                         select, beta, **kwargs)
        # print("战车第一攻击点为：", end_int4)
        return end_int4

    def get_second_far_point(self, vehicle, my_ai, center_point, main_dis=[18,25], bop_dis=[11, 12]):
        pos_start = my_ai.hex_cache.get_circle(vehicle['cur_hex'], bop_dis[0], bop_dis[1])
        # pos_main = my_ai.hex_cache.get_circle(center_point, main_dis[0], main_dis[1])
        # circle = list(set(pos_start) & set(pos_main))
        # if not circle:
        #     circle = pos_main
        ai = my_ai
        bop = vehicle
        be_see_type = const.BopType.Vehicle
        pos_tuple = pos_start
        center_int4 = my_ai.attack_point['e_main_attack']
        observe_point_dis = 0
        top_num = const.top_num
        select = const.select
        beta = const.beta
        kwargs = {'observed_city': 2,
                  'maneuver_time': 1,
                  'maneuver_time_main': .5,
                  'hide_cond': 1.5,
                  'stack': 0,
                  'shoot_ability': 1,
                  'be_shoot_ability': 3,
                  'observe_enemy_ability': 2}

        end_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                              top_num,
                                              select, beta, **kwargs)
        # print("战车第二攻击点为：", end_int4)
        return end_int4


    def get_off_point(self, vehicle, my_ai, center_point, center_dis=[6, 10], bop_dis=[3, 8]):
        hexes_start = my_ai.hex_cache.get_circle(vehicle['cur_hex'], bop_dis[0], bop_dis[1])
        hexes_occupy = my_ai.hex_cache.get_circle(center_point, center_dis[0], center_dis[1])
        circle = list(set(hexes_start) & set(hexes_occupy))
        if not circle:
            circle = hexes_start
        ai = my_ai
        bop = vehicle
        be_see_type = const.BopType.Vehicle
        pos_tuple = circle
        center_int4 = center_point
        observe_point_dis = 1
        top_num = const.top_num
        select = const.select
        beta = const.beta

        kwargs = {'observed_ability': 0,
                  'be_observed_ability': 2,
                  'maneuver_time': 1.5,
                  'maneuver_time_main': 1,
                  'neighbor_max_observe_ability': .5,
                  'hide_cond': 0.2,
                  'stack': 0.2,
                  'observe_enemy_time': 0,
                  'be_shoot_ability_time': 0}

        end_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                         top_num,
                                         select, beta, **kwargs)
        return end_int4

    def DT2get_far_guide_point(self, vehicle, my_ai, center_point, center_dis=[6, 10], bop_dis=[3, 8]):
        hexes_start = my_ai.hex_cache.get_circle(vehicle['cur_hex'], bop_dis[0], bop_dis[1])
        hexes_occupy = my_ai.hex_cache.get_circle(center_point, center_dis[0], center_dis[1])
        circle = list(set(hexes_start) & set(hexes_occupy))
        if not circle:
            circle = hexes_start
        ai = my_ai
        bop = vehicle
        be_see_type = const.BopType.Vehicle
        pos_tuple = circle
        center_int4 = center_point
        observe_point_dis = 1
        top_num = const.top_num
        select = const.select
        beta = const.beta
        kwargs = {'observed_ability': 0,
                  'be_observed_ability': 1.5,
                  'maneuver_time': 2,
                  'maneuver_time_main': 1,
                  'neighbor_max_observe_ability': 0,
                  'hide_cond': 0,
                  'stack': 0.2,
                  'replay_be_attacked_ability': 1, }

        end_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                         top_num,
                                         select, beta, **kwargs)
        return end_int4

    def DT2get_far_hide_point(self, vehicle, my_ai, center_point, bop_dis=[3, 8]):
        hexes_start = my_ai.hex_cache.get_circle(vehicle['cur_hex'], bop_dis[0], bop_dis[1])

        ai = my_ai
        bop = vehicle
        be_see_type = const.BopType.Vehicle
        pos_tuple = hexes_start
        center_int4 = center_point
        observe_point_dis = 0
        top_num = const.top_num
        select = const.select
        beta = const.beta
        kwargs = {'observed_ability': 0,
                  'be_observed_ability': 5,
                  'maneuver_time': 1,
                  'maneuver_time_main': 0,
                  'neighbor_max_observe_ability': 0,
                  'hide_cond': 0,
                  'stack': 0,
                  'replay_be_attacked_ability': 1, }

        end_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                         top_num,
                                         select, beta, **kwargs)
        return end_int4

    def passenger_off(self, bop, my_ai, sub_type=None):
        """Generate get off action only if the bop is within some distance of a random city."""
        off_actions = common.get_bop_action_id_name(my_ai.observation['valid_actions'], bop['obj_id'],
                                                    const.ActionType.GetOff)
        if off_actions:
            off_action = off_actions[const.ActionType.GetOff]
            if sub_type:
                for dic in off_action:
                    passenger = common.get_passenger_bop_obj_id(my_ai.our_passengers, dic['target_obj_id'])
                    if passenger['sub_type'] == sub_type:
                        target_obj_id = dic['target_obj_id']
                        return {"actor": my_ai.seat,
                                'obj_id': bop['obj_id'],
                                'type': const.ActionType.GetOff,
                                'target_obj_id': target_obj_id,
                                }
            else:
                target_obj_id = random.choice(off_action)['target_obj_id']
                return {"actor": my_ai.seat,
                        'obj_id': bop['obj_id'],
                        'type': const.ActionType.GetOff,
                        'target_obj_id': target_obj_id,
                        }
        else:
            return None

    def have_passenger_number(self, my_ai, vehicle, sub_type=None):
        if sub_type:
            number = common.get_passenger_number(vehicle, my_ai.our_passengers, sub_type=sub_type)
            return number
        else:
            number = common.get_passenger_number(vehicle, my_ai.our_passengers)
            return number

    def vehicle_move_hide(self, vehicle, my_ai):
        # 坦克行进到隐蔽点
        move_action = common.get_bop_action_id_name(my_ai.observation['valid_actions'], vehicle['obj_id'],
                                                    const.ActionType.Move)
        if move_action:
            hide_point = self.find_hide_point(vehicle, my_ai)
            if hide_point:
                kwargs = {'beta': 1.5,
                          'hide_cond': 1,
                          'shoot_ability': 0,
                          'be_shoot_ability': 1,
                          'be_shoot_ability_aircraft': 0,
                          'observe_enemy_ability': 0,
                          'be_observed_enemy_ability': 1}
                action = self.hide_move(vehicle, hide_point, my_ai, danger_stop=False, **kwargs)
                return action
        return None
