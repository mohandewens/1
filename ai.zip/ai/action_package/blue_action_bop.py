from .action_bop import *
import copy


# noinspection PyStatementEffect
class BlueVehicle(Vehicle):

    def __init__(self, bop, serial_number=0, group=0):
        super(BlueVehicle, self).__init__()
        assert self.sub_type == bop['sub_type']
        self.obj_id = bop['obj_id']
        self.serial_number = serial_number
        self.group = group
        self.caninto = 0
        self.move_point = -1

    def get_off_point(self, my_ai):
        vehicle = self.get_bop(my_ai)
        if vehicle:
            circle = BoundedHex(my_ai.attack_point['o_main_attack']).arc([0, 5], 3, origin=True)

            ai = my_ai
            bop = vehicle
            be_see_type = const.BopType.Vehicle
            pos_tuple = circle
            center_int4 = my_ai.attack_point['o_main_attack']
            observe_point_dis = 0
            top_num = 5
            select = 1
            beta = 1
            kwargs = {'observed_ability': 0,
                      'be_observed_ability': 1.2,
                      'maneuver_time': 1,
                      'maneuver_time_main': 0.5,
                      'neighbor_max_observe_ability': 0,
                      'hide_cond': 0}

            vehicle_off_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                                    top_num, select, beta, **kwargs)

            self.veicle_off_point = vehicle_off_int4
            self.task_num = 1
            #print('veicle_off_point:', self.veicle_off_point)

    def get_protect_point(self, my_ai):
        vehicle = self.get_bop(my_ai)
        if vehicle:

            pos_tuple = BoundedHex(my_ai.attack_point['o_main_attack']).arc([0, 5], 5, origin=True)
            circle = [point for point in pos_tuple if my_ai.map.can_see(com.cvtOffset2Int4loc(point), my_ai.attack_point['o_main_attack'], const.SeeMode.GroundToGround)]

            ai = my_ai
            bop = vehicle
            be_see_type = const.BopType.Vehicle
            pos_tuple = circle
            center_int4 = my_ai.attack_point['o_main_attack']
            observe_point_dis = 0
            top_num = 10
            select = 1
            beta = 1
            kwargs = {'observed_ability': 0,
                      'be_observed_ability': 1.2,
                      'maneuver_time': 2,
                      'maneuver_time_main': 0.5,
                      'neighbor_max_observe_ability': 0,
                      'hide_cond': 0.5}

            protect_point_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                                     top_num, select, beta, **kwargs)

            self.protect_point = protect_point_int4
            print('veicle_protect_point:', self.protect_point)
            # return protect_point_int4


    def MoveAttack(self, vehicle,my_ai):
        if not hasattr(self, 'veicle_off_point'):
            self.get_off_point(my_ai)
            self.get_protect_point(my_ai)

        vehicle = self.get_bop(my_ai)
        if vehicle:
            action = self.shoot(vehicle, my_ai)
            if action:
                return action
            if vehicle['cur_hex'] != self.veicle_off_point and self.task_num == 1:
                action = self.move(vehicle, self.veicle_off_point, my_ai)
                if action:
                    self.task_num = 2
                    return action
            elif self.have_passenger_number(my_ai):
                action = self.passenger_off(vehicle, my_ai)
                if action:
                    return action
            elif not self.have_passenger_number(my_ai) and self.task_num == 2:
                action = self.move(vehicle, self.protect_point, my_ai)
                if action:
                    self.task_num = 3
                    return action
        return None

    def Protect(self, my_ai):
        return self.MoveAttack(my_ai)


    def main_attack(self, vehicle, my_ai):
        init_pos = common.get_init_pos(vehicle, my_ai.our_bops_init_all)
        if vehicle['cur_hex'] == init_pos:
            if not self.have_passenger_number(my_ai, vehicle, sub_type=const.BopName.Soldier):
                return list()

        if not hasattr(self, 'veicle_off_point'):
            pos_start = vehicle['cur_hex']
            pos_main = my_ai.attack_point['o_main_attack']
            hexes = my_ai.hex_cache.get_circle(pos_main, 0, 3)
            # hexes_start = ai_group.hex_cache.get_circle(pos_start, 3, 10)
            # intersection_hexes = list(set(hexes_main) & set(hexes_start))
            kwargs = {'be_observed_ability': 1,
                      'maneuver_time': 3,
                      'maneuver_time_main': .5,
                      'hide_cond': 0.5,
                      'stack': .5,
                      'observe_enemy_ability': 0}
            self.veicle_off_point = self.get_key_point(my_ai, vehicle, pos_main, hexes, kwargs)
            #print('veicle_off_point:', self.veicle_off_point)

        action = self.shoot(vehicle, my_ai)
        if action:
            return action

        if self.have_passenger_number(my_ai, vehicle) and vehicle['cur_hex'] != self.veicle_off_point:
            action = self.move(vehicle, self.veicle_off_point, my_ai)
            if action:
                return action

        if self.have_passenger_number(my_ai, vehicle):
            action = self.passenger_off(vehicle, my_ai)
            if action:
                return action

        if not self.have_passenger_number(my_ai, vehicle):
            if self.defense_guide == True and ( not self.see_enemy(vehicle) or self.see_can_not_shoot(vehicle, my_ai)):
                return self.defense_guide_move(vehicle, my_ai)

            if common.see_enemy_vehicle(my_ai.enemy_bops):
                self.defense_guide = False

            if not self.defense_guide:
                if self.see_can_shoot(vehicle, my_ai):
                    action = self.stop(vehicle, my_ai)
                    if action:
                        return action

                if not hasattr(self, 'observe_point'):
                    pos_start = vehicle['cur_hex']
                    pos_main = my_ai.attack_point['o_main_attack']
                    hexes_start = my_ai.hex_cache.get_circle(pos_start, 0, 4)

                    kwargs = {'observed_main': 1,
                              'maneuver_time': 1,
                              'hide_cond': 1,
                              'stack': .5,
                              'shoot_ability': 2}
                    self.observe_point = self.get_key_point(my_ai, vehicle, pos_main, hexes_start, kwargs)
                    #print('observe_point:', self.observe_point)
                action = self.move(vehicle, self.observe_point, my_ai)
                if action:
                    return action
        return None

    def DTmain_attack(self, vehicle, my_ai):
        if my_ai.time < 50:
            init_pos = common.get_init_pos(vehicle, my_ai.our_bops_init_all)
            if vehicle['cur_hex'] == init_pos:
                if not self.have_passenger_number(my_ai, vehicle, sub_type=const.BopName.Soldier):
                    return list()
        if not hasattr(self, 'veicle_off_point'):
            hexes_main = my_ai.hex_cache.get_circle(my_ai.attack_point['o_main_attack'], 1, 4)
            # hexes_second = ai_group.hex_cache.get_circle(ai_group.attack_point['o_second_attack'], 0, 3)
            # intersection_hexes = list(set(hexes_main) & set(hexes_second))
            kwargs = {'be_observed_ability': 1,
                      'maneuver_time': 2,
                      'maneuver_time_main': 1,
                      'hide_cond': .6,
                      'stack': 1}
            self.veicle_off_point = self.get_key_point(my_ai, vehicle, my_ai.attack_point['o_main_attack'], hexes_main, kwargs)
            #print('veicle_off_point:', self.veicle_off_point)

        action = self.shoot(vehicle, my_ai)
        if action:
            return action

        if self.have_passenger_number(my_ai, vehicle) and vehicle['cur_hex'] != self.veicle_off_point:
            kwargs = {'beta': 1,
                      'hide_cond': 0,
                      'shoot_ability': 0,
                      'be_shoot_ability': 1,
                      'be_observed_enemy_ability': 0
                      }
            action = self.hide_move(vehicle, self.veicle_off_point, my_ai, number=5, danger_stop=True,
                                    danger_value=0.5, **kwargs)
            if action:
                return action

        if self.have_passenger_number(my_ai, vehicle):
            action = self.passenger_off(vehicle, my_ai)
            if action:
                return action

        if not self.have_passenger_number(my_ai, vehicle):
            if self.defense_guide == True: # and ( not self.see_enemy(vehicle) or self.see_can_not_shoot(vehicle, ai_group)):
                action = self.defense_guide_move(vehicle, my_ai, init_center=my_ai.attack_point['o_main_attack'], dis=2)
                if action:
                    return action

            if common.see_enemy_vehicle(my_ai.enemy_bops) or common.enemy_no_vehicle(my_ai):
                self.defense_guide = False

            if not self.defense_guide:
                # if self.see_can_shoot(vehicle, ai_group):
                #     action = self.stop(vehicle, ai_group)
                #     if action:
                #         return action

                if not hasattr(self, 'observe_point'):
                    pos_start = vehicle['cur_hex']
                    pos_main = my_ai.attack_point['e_main_attack']
                    hexes_start = my_ai.hex_cache.get_circle(pos_start, 0, 4)

                    kwargs = {'observed_second': 1,
                              'maneuver_time': 1,
                              'maneuver_time_main': .5,
                              'hide_cond': 2,
                              'stack': .8,
                              'shoot_ability': 1.5}
                    self.observe_point = self.get_key_point(my_ai, vehicle, pos_main, hexes_start, kwargs)
                    #print('observe_point:', self.observe_point)
                action = self.move(vehicle, self.observe_point, my_ai)
                if action:
                    return action
        return None


    def MainDefense(self, my_ai, action_bops):
        vehicle = self.get_bop(my_ai)
        if vehicle:
            if self.serial_number == 0:
                return self.main_attack(vehicle, my_ai)
            else:
                return self.far_attack(vehicle, my_ai)

    def DTMainDefense(self, my_ai, action_bops):
        vehicle = self.get_bop(my_ai)
        if vehicle:
            if self.sub_type == 0:
                return self.DTmain_attack(vehicle, my_ai)
            else:
                return self.DTmain_attack(vehicle, my_ai)

    def HRMainDefense(self, my_ai, action_bops):
        return self.newpolicy(my_ai)
        vehicle = self.get_bop(my_ai)
        if vehicle:
            init_pos = common.get_init_pos(vehicle, my_ai.our_bops_init_all)
            if vehicle['cur_hex'] == init_pos:
                if not self.have_passenger_number(my_ai, vehicle, sub_type=const.BopName.Soldier):
                    return list()

            if not hasattr(self, 'veicle_off_point'):
                pos_start = vehicle['cur_hex']
                pos_main = my_ai.attack_point['e_main_attack']
                hexes = my_ai.hex_cache.get_circle(pos_main, 5, 7)
                # hexes_start = ai_group.hex_cache.get_circle(pos_start, 3, 10)
                # intersection_hexes = list(set(hexes_main) & set(hexes_start))
                kwargs = {'be_observed_ability': 1,
                          'maneuver_time': 3,
                          'maneuver_time_main': .5,
                          'hide_cond': 0.5,
                          'stack': .5,
                          'observe_enemy_ability': 0}
                self.veicle_off_point = self.get_key_point(my_ai, vehicle, pos_main, hexes, kwargs)
                # print('veicle_off_point:', self.veicle_off_point)

            action = self.shoot(vehicle, my_ai)
            if action:
                return action

            if self.have_passenger_number(my_ai, vehicle) and vehicle['cur_hex'] != self.veicle_off_point:
                action = self.move(vehicle, self.veicle_off_point, my_ai)
                if action:
                    return action

            if self.have_passenger_number(my_ai, vehicle):
                action = self.passenger_off(vehicle, my_ai)
                if action:
                    return action

            if not self.have_passenger_number(my_ai, vehicle):
                if not hasattr(self, 'observe_point'):
                    pos_start = vehicle['cur_hex']
                    pos_main = my_ai.attack_point['e_main_attack']
                    hexes_start = my_ai.hex_cache.get_circle(pos_start, 2, 3)

                    kwargs = {'observed_main': 1,
                              'maneuver_time': 1,
                              'hide_cond': 2,
                              'stack': .5,
                              'shoot_ability': 2}
                    self.observe_point = self.get_key_point(my_ai, vehicle, pos_start, hexes_start, kwargs)
                    # print('observe_point:', self.observe_point)
                if(vehicle['cur_hex'] != self.observe_point):
                    action = self.move(vehicle, self.observe_point, my_ai)
                    if action:
                        return action

            # if self.can_move(vehicle, my_ai):
            #     bops = my_ai.observation['operators']
            #     for bop in bops:
            #         if bop['color'] != my_ai.color and bop['sub_type'] == const.BopName.UAV:
            #             dis = com.get_distance(bop['cur_hex'], vehicle['cur_hex'])
            #             if dis <= 2:
            #                 self.hide_point = self.get_first_far_point(vehicle, my_ai, vehicle['cur_hex'],
            #                                                            center_dis=[1, 2], bop_dis=[0, 20])
            #                 action = self.move(vehicle, self.hide_point, my_ai)
            #                 if action:
            #                     return action

            if my_ai.time > 400:
                action = self.fork(vehicle, my_ai)
                if action:
                    return action


            action = self.hide(vehicle, my_ai)
            if action:
                return action



            return None

    def HROccupying(self, my_ai, action_bops):
        return self.newpolicy(my_ai)
        vehicle = self.get_bop(my_ai)
        if vehicle:
            action = self.shoot(vehicle, my_ai)
            if action:
                return action

            # if self.can_move(vehicle, my_ai):
            #     bops = my_ai.observation['operators']
            #     for bop in bops:
            #         if bop['color'] != my_ai.color and bop['sub_type'] == const.BopName.UAV:
            #             dis = com.get_distance(bop['cur_hex'], vehicle['cur_hex'])
            #             if dis <= 2:
            #                 self.hide_point = self.get_first_far_point(vehicle, my_ai, vehicle['cur_hex'],
            #                                                            center_dis=[1, 2], bop_dis=[0, 20])
            #                 action = self.move(vehicle, self.hide_point, my_ai)
            #                 if action:
            #                     return action

            action = self.fork(vehicle, my_ai)
            if action:
                return action

            if not self.have_passenger_number(my_ai, vehicle):
                if self.defense_guide == True:  # and ( not self.see_enemy(vehicle) or self.see_can_not_shoot(vehicle, ai_group)):
                    action = self.defense_guide_move(vehicle, my_ai, init_center=my_ai.attack_point['o_main_attack'],
                                                     dis=2)
                    if action:
                        return action

                if common.see_enemy_vehicle(my_ai.enemy_bops) or common.enemy_no_vehicle(my_ai):
                    self.defense_guide = False

                if not self.defense_guide:
                    if not hasattr(self, 'observe_point2'):
                        pos_start = vehicle['cur_hex']
                        pos_main = my_ai.attack_point['e_main_attack']
                        hexes_start = my_ai.hex_cache.get_circle(pos_start, 0, 4)

                        kwargs = {'observed_second': 1,
                                  'maneuver_time': 1,
                                  'maneuver_time_main': .5,
                                  'hide_cond': 2,
                                  'stack': .8,
                                  'shoot_ability': 1.5}
                        self.observe_point2 = self.get_key_point(my_ai, vehicle, pos_main, hexes_start, kwargs)
                        # print('observe_point:', self.observe_point)
                    action = self.move(vehicle, self.observe_point2, my_ai)
                    if action:
                        return action
            action = self.hide(vehicle, my_ai)
            if action:
                return action
            return None

    def HRProtect(self, my_ai, action_bops):
        return self.newpolicy(my_ai)
        if my_ai.time < 1500:
            return self.HROccupying(my_ai,action_bops)
        vehicle = self.get_bop(my_ai)
        if vehicle:
            action = self.shoot(vehicle, my_ai)
            if action:
                return action

            # if self.can_move(vehicle, my_ai):
            #     bops = my_ai.observation['operators']
            #     for bop in bops:
            #         if bop['color'] != my_ai.color and bop['sub_type'] == const.BopName.UAV:
            #             dis = com.get_distance(bop['cur_hex'], vehicle['cur_hex'])
            #             if dis <= 2:
            #                 self.hide_point = self.get_first_far_point(vehicle, my_ai, vehicle['cur_hex'],
            #                                                            center_dis=[1, 2], bop_dis=[0, 20])
            #                 action = self.move(vehicle, self.hide_point, my_ai)
            #                 if action:
            #                     return action

            if not self.have_passenger_number(my_ai, vehicle):
                if self.defense_guide == True and (
                        not self.see_enemy(vehicle) or self.see_can_not_shoot(vehicle, my_ai)):
                    return self.defense_guide_move(vehicle, my_ai)

                if common.see_enemy_vehicle(my_ai.enemy_bops):
                    self.defense_guide = False

                if not self.defense_guide:
                    if self.see_can_shoot(vehicle, my_ai):
                        action = self.stop(vehicle, my_ai)
                        if action:
                            return action

                    if not hasattr(self, 'observe_point'):
                        pos_start = vehicle['cur_hex']
                        pos_main = my_ai.attack_point['o_main_attack']
                        hexes_start = my_ai.hex_cache.get_circle(pos_main, 0, 4)

                        kwargs = {'observed_main': 1,
                                  'maneuver_time': 1,
                                  'hide_cond': 1,
                                  'stack': .5,
                                  'shoot_ability': 2}
                        self.observe_point = self.get_key_point(my_ai, vehicle, pos_main, hexes_start, kwargs)
                        # print('observe_point:', self.observe_point)
                    action = self.move(vehicle, self.observe_point, my_ai)
                    if action:
                        return action
            action = self.hide(vehicle, my_ai)
            if action:
                return action
            return None

    def newpolicy(self,my_ai):
        vehicle = self.get_bop(my_ai)
        if vehicle:
            action = self.shoot(vehicle, my_ai)
            if action:
                return action
            action = self.occupy(vehicle, my_ai)
            if action:
                return action
            bop_id = vehicle["obj_id"]
            if (bop_id == my_ai.veid_100):
                if self.caninto == 1:
                    return self.into_hunter(my_ai,vehicle)
                if vehicle['cur_hex'] == 4424  and self.move_point == -1:
                    self.move_point = 3824
                    action = self.move(vehicle, self.move_point, my_ai)
                    action = {"actor": my_ai.seat,
                    'obj_id': vehicle['obj_id'],
                    'type': const.ActionType.Move,
                    'move_path': [4424,4323,4223,4122,4023,3923,3824],}
                    if action:
                        return action
                if vehicle['cur_hex'] != self.move_point:
                    action = self.move(vehicle, self.move_point, my_ai, number = 1)
                    if action:
                        return action
                if vehicle['cur_hex'] == 3824 and self.have_passenger_number(my_ai, vehicle, sub_type = const.BopName.Soldier):
                    action = self.passenger_off(vehicle, my_ai, sub_type = const.BopName.Soldier)
                    if action:
                        self.move_point = 3819
                        return action
                if vehicle['cur_hex'] == 3819 and self.have_passenger_number(my_ai, vehicle, sub_type = const.BopName.Missile):
                    action = self.fork(vehicle,my_ai)
                    if action:
                        return action
                    else:
                        action = self.passenger_off(vehicle, my_ai, sub_type = const.BopName.Missile)
                        if action:
                            self.caninto = 1
                            return action

            if (bop_id == my_ai.veid_104):
                if self.caninto == 1:
                    return self.into_hunter(my_ai,vehicle)
                if vehicle['cur_hex'] == 3819 and self.have_passenger_number(my_ai, vehicle, sub_type = const.BopName.Missile):
                    action = self.passenger_off(vehicle, my_ai, sub_type = const.BopName.Missile)
                    if action:
                        return action
                if vehicle['cur_hex'] == 3819 and not self.have_passenger_number(my_ai, vehicle,sub_type=const.BopName.Missile):
                    action = self.move(vehicle, 3718, my_ai,number = 1)
                    if action:
                        self.caninto = 1
                        return action

            if (bop_id == my_ai.veid_103):
                if self.caninto == 1:
                    return self.into_hunter(my_ai,vehicle)
                if vehicle['cur_hex'] == 4425 and self.move_point == -1:
                    self.move_point = 4126
                if vehicle['cur_hex'] != self.move_point:
                    action = self.move(vehicle, self.move_point, my_ai, number = 1)
                    if action:
                        return action
                if vehicle['cur_hex'] == 4126 and self.have_passenger_number(my_ai, vehicle, sub_type = const.BopName.Soldier):
                    action = self.passenger_off(vehicle, my_ai, sub_type = const.BopName.Soldier)
                    if action:
                        self.move_point = 4523
                        return action
                if vehicle['cur_hex'] == 4523 and self.have_passenger_number(my_ai, vehicle, sub_type = const.BopName.Missile):
                    action = self.passenger_off(vehicle, my_ai, sub_type = const.BopName.Missile)
                    if action:
                        self.caninto = 1
                        return action

            # if (bop_id == my_ai.veid_102):
            #     if self.caninto == 1:
            #         return self.into_hunter(my_ai,vehicle)
            #     if self.have_passenger_number(my_ai, vehicle, sub_type = const.BopName.Missile):
            #         action = self.passenger_off(vehicle, my_ai, sub_type = const.BopName.Missile)
            #         if action:
            #             return action
            #     if vehicle['cur_hex'] == 4425 and self.move_point == -1:
            #         self.move_point = 4126
            #     if vehicle['cur_hex'] != self.move_point:
            #         action = self.move(vehicle, self.move_point, my_ai,number = 1)
            #         if action:
            #             return action
            #     if vehicle['cur_hex'] == 4126 and self.have_passenger_number(my_ai, vehicle, sub_type = const.BopName.Soldier):
            #         action = self.passenger_off(vehicle, my_ai, sub_type = const.BopName.Soldier)
            #         if action:
            #             self.move_point = 4523
            #             return action
            #     if vehicle['cur_hex'] == 4523:
            #         self.caninto = 1

            if (bop_id == 51):
                if self.caninto == 1:
                    return self.into_hunter(my_ai,vehicle)
                if self.have_passenger_number(my_ai, vehicle, sub_type = const.BopName.Missile):
                    action = self.passenger_off(vehicle, my_ai, sub_type = const.BopName.Missile)
                    if action:
                        return action
                if vehicle['cur_hex'] == 4424 and self.move_point == -1:
                    self.move_point = 4225
                if vehicle['cur_hex'] != self.move_point:
                    action = self.move(vehicle, self.move_point, my_ai, number = 1)
                    if action:
                        return action
                if vehicle['cur_hex'] == 4225 and self.have_passenger_number(my_ai, vehicle, sub_type = const.BopName.Soldier):
                    action = self.passenger_off(vehicle, my_ai, sub_type = const.BopName.Soldier)
                    if action:
                        self.move_point = 4322
                        return action
                if vehicle['cur_hex'] == 4322:
                    self.caninto = 1

            if (bop_id == 83):
                if self.caninto == 1:
                    return self.into_hunter(my_ai,vehicle)
                if self.have_passenger_number(my_ai, vehicle, sub_type = const.BopName.Missile):
                    action = self.passenger_off(vehicle, my_ai, sub_type = const.BopName.Missile)
                    if action:
                        return action
                if vehicle['cur_hex'] == 4425 and self.move_point == -1:
                    self.move_point = 4332
                if vehicle['cur_hex'] != self.move_point:
                    action = self.move(vehicle, self.move_point, my_ai, number = 1)
                    if action:
                        return action
                if vehicle['cur_hex'] == 4332 and self.have_passenger_number(my_ai, vehicle, sub_type = const.BopName.Soldier):
                    action = self.passenger_off(vehicle, my_ai, sub_type = const.BopName.Soldier)
                    if action:
                        self.caninto = 1
                        return action



            # if not hasattr(self, 'first_move'):
            #     if vehicle["obj_id"] == 51:
            #         self.first_move = 4528
            #     elif vehicle["obj_id"] == 83:
            #         self.first_move = 4432
            #     elif vehicle["obj_id"] == 102:
            #         self.first_move = 3928
            #     else:
            #         self.first_move = 3827
            # if (vehicle['cur_hex'] != self.first_move) and self.caninto == 0:
            #     action = self.move(vehicle, self.first_move, my_ai)
            #     if action:
            #         return action
            # if hasattr(self, 'first_move') and self.caninto == 0:
            #     if vehicle['cur_hex'] == self.first_move and self.have_passenger_number(my_ai, vehicle):
            #         action = self.passenger_off(vehicle, my_ai)
            #         if action:
            #             return action
            # if not self.have_passenger_number(my_ai, vehicle) and self.caninto == 0:
            #     if vehicle['obj_id'] == 100:
            #         self.caninto = 1
            #     else:
            #         action = self.hide(vehicle,my_ai)
            #         if action:
            #             self.caninto = 1
            #             return action
            # if not self.have_passenger_number(my_ai, vehicle) and self.caninto == 1:
            #     return self.into_hunter(my_ai, vehicle)
            return None


    def into_hunter(self,my_ai,operators):
        action = self.guide_shoot(operators, my_ai)
        if action:
            return action
        action = self.shoot(operators, my_ai)
        if action:
            return action
        action = self.occupy(operators, my_ai)
        if action:
            return action
        if operators['obj_id'] not in my_ai.controllable_ops:
            return None
        if operators['obj_id'] in my_ai.huntermove.keys():
            msg_body = my_ai.huntermove[operators['obj_id']]
            if len(msg_body["hexs"]) > 1:
                if operators['cur_hex'] == msg_body["hexs"][0]:
                    target_point = msg_body["hexs"][1]
                    action = self.move(operators, target_point, my_ai, number = 1)
                    if action:
                        next_hex = action['move_path'][0]
                        msg_body["hexs"][0] = next_hex
                        if msg_body["hexs"][0] == msg_body["hexs"][1]:
                            msg_body["hexs"] = msg_body["hexs"][1:]
                        route = msg_body["hexs"]
                        #my_ai.huntermove = {}
                        return action
            else:
                del my_ai.huntermove[operators['obj_id']]
        return None


class BlueSoldier(Soldier):

    def __init__(self, bop, serial_number=0, group=0):
        super(BlueSoldier, self).__init__()
        assert self.sub_type == bop['sub_type']
        self.obj_id = bop['obj_id']
        self.serial_number = serial_number
        self.group = group
        self.caninto = 0
        self.move_point = -1

    def get_attack_point(self, soldier, my_ai):
        circle = BoundedHex(my_ai.attack_point['o_main_attack']).arc([0, 5], 2, origin=True)

        ai = my_ai
        bop = soldier
        be_see_type = const.BopType.Vehicle
        pos_tuple = circle
        center_int4 = my_ai.attack_point['o_main_attack']
        observe_point_dis = 0
        top_num = 5
        select = 1
        beta = 1
        kwargs = {'observed_ability': .5,
                  'be_observed_ability': 0,
                  'maneuver_time': .5,
                  'maneuver_time_main': 2,
                  'hide_cond': 1,
                  'stack': .5,}

        soldier_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                                top_num,
                                                select, beta, **kwargs)

        #print('soldier_attack_point:', soldier_int4)
        return soldier_int4


    def MoveAttack(self, my_ai):
        soldier = self.get_bop(my_ai)
        if soldier:
            if not hasattr(self, 'soldier_attack_point'):
                self.soldier_attack_point = self.get_attack_point(soldier, my_ai)
            # 夺控
            action = self.occupy(soldier, my_ai)
            if action:
                return action

            #射击
            action = self.shoot(soldier, my_ai)
            if action:
                return action

            # 看到敌人立即停止机动
            if self.see_can_shoot(soldier, my_ai):
                action = self.stop(soldier, my_ai)
                if action:
                    return action

            # 转为二级冲锋状态
            action = self.change_rush_level_two(soldier, my_ai)
            if action:
                return action

            # 人员行进到主夺控点
            if not self.see_enemy(soldier):
                action = self.move(soldier, my_ai.attack_point['o_main_attack'], my_ai)
                if action:
                    return action
        return None

    def Protect(self, my_ai):
        soldier = self.get_bop(my_ai)
        if soldier:
            if not hasattr(self, 'soldier_attack_point'):
                self.get_attack_point(soldier, my_ai)
            # 夺控
            action = self.occupy(soldier, my_ai)
            if action:
                return action

            # 射击
            action = self.shoot(soldier, my_ai)
            if action:
                return action

            # 看到敌人立即停止机动
            if self.see_can_shoot(soldier, my_ai):
                action = self.stop(soldier, my_ai)
                if action:
                    return action

            # 夺控点已经占领，并且有我方棋子时，机动到观察点
            bop_num = len(common.get_bop_pos(my_ai.our_bops, my_ai.attack_point['o_main_attack']))
            if common.my_city(my_ai.observation['cities'], my_ai.color,
                              my_ai.attack_point['o_main_attack']) and bop_num == 2:
                action = self.move(soldier, self.soldier_attack_point, my_ai)
                if action:
                    return action
        return None

    def MainDefense(self, my_ai, action_bops):
        soldier = self.get_bop(my_ai)
        if soldier:
            init_pos = common.get_init_pos(soldier, my_ai.our_bops_init_all)
            if soldier['cur_hex'] == init_pos:
                action = self.get_on(soldier, my_ai)
                if action:
                    return action
                else:
                    return list()
            else:
                return self.OccupyingMain(my_ai, action_bops)
        return None

    def DTMainDefense(self, my_ai, action_bops):
        soldier = self.get_bop(my_ai)
        if soldier:
            if my_ai.time < 50:
                init_pos = common.get_init_pos(soldier, my_ai.our_bops_init_all)
                if soldier['cur_hex'] == init_pos:
                    action = self.get_on(soldier, my_ai)
                    if action:
                        return action
                    else:
                        return list()

            if self.serial_number == 0:
                ubops_tank = [ubop_record for ubop_id, ubop_record in my_ai.enemy_predict.ubops_record.items() if
                              ubop_record['live'] and ubop_record['sub_type'] == const.BopName.Tank]
                if not ubops_tank and common.my_city(my_ai.observation['cities'], my_ai.color, coord=my_ai.attack_point['o_main_attack']):
                    return self.DT_Occupying(my_ai, action_bops, city_coord=my_ai.attack_point['o_second_attack'])
                else:
                    return self.DT_Occupying(my_ai, action_bops, city_coord=my_ai.attack_point['o_main_attack'])
            else:
                return self.DT_Occupying(my_ai, action_bops, city_coord=my_ai.attack_point['o_second_attack'])

        return None

    def HRMainDefense(self, my_ai, action_bops):
        soldier = self.get_bop(my_ai)
        if soldier:
            return self.newpolicy(my_ai)
            if my_ai.SoldierControl == 2:
                return self.into_hunter(my_ai,soldier)
            init_pos = common.get_init_pos(soldier, my_ai.our_bops_init_all)
            if soldier['cur_hex'] == init_pos:
                action = self.get_on(soldier, my_ai)
                if action:
                    return action
                else:
                    return list()
            else:
                change_state = True
                bop = self.get_bop(my_ai)
                if bop:
                    guide_action = self.guide_shoot(bop, my_ai)
                    if guide_action:
                        return guide_action
                    action = self.shoot(bop, my_ai)
                    if action:
                        return action

                    if not common.my_city(my_ai.observation['cities'], my_ai.color,
                                          coord=my_ai.attack_point['o_main_attack']):
                        # 转为二级冲锋状态
                        if change_state and not (
                                bop['move_state'] == const.StateMode.Hide or bop['change_state_remain_time']):
                            action = self.change_rush_level_two(bop, my_ai)
                            if action:
                                return action

                        action = self.occupy(bop, my_ai)
                        if action:
                            return action

                        if common.can_move(bop, my_ai):
                            bop_int4 = self.occupy_move(bop, my_ai, my_ai.attack_point['o_main_attack'])

                            action = self.soldiermove(bop, bop_int4, my_ai)
                            #action['move_path'] = action['move_path'][:1]
                            if action:
                                return action
                    else:
                        if not self.see_enemy(bop):
                            action = self.occupy(bop, my_ai)
                            if action:
                                return action
                            if common.can_move(bop, my_ai) and self.wait_time <= 0:
                                bop_int4 = self.occupy_protect(bop, my_ai, my_ai.attack_point['o_main_attack'])
                                if bop_int4 == bop['cur_hex']:
                                    self.wait_time = 30
                                action = self.soldiermove(bop, bop_int4, my_ai)
                                #action['move_path'] = action['move_path'][:1]
                                if action:
                                    return action
                    action = self.hide(bop, my_ai)
                    if action:
                        return action
                    self.wait_time -= 1
                return None
        return None

    def HROccupying(self, my_ai, action_bops):
        soldier = self.get_bop(my_ai)
        if soldier:
            return self.newpolicy(my_ai)
            if my_ai.SoldierControl == 2:
                return self.into_hunter(my_ai,soldier)
            if not hasattr(self, 'soldier_attack_point'):
                self.soldier_attack_point = self.get_attack_point(soldier, my_ai)
            # 夺控
            action = self.occupy(soldier, my_ai)
            if action:
                return action

            # 射击
            action = self.shoot(soldier, my_ai)
            if action:
                return action

            # 看到敌人立即停止机动
            if self.see_can_shoot(soldier, my_ai):
                action = self.stop(soldier, my_ai)
                if action:
                    return action

            # 转为二级冲锋状态
            action = self.change_rush_level_two(soldier, my_ai)
            if action:
                return action

            # 人员行进到主夺控点
            if not self.see_enemy(soldier):
                action = self.soldiermove(soldier, my_ai.attack_point['o_main_attack'], my_ai)
                #action['move_path'] = action['move_path'][:1]
                if action:
                    return action
        return None

    def HRProtect(self, my_ai, action_bops):
        soldier = self.get_bop(my_ai)
        if soldier:
            return self.newpolicy(my_ai)
            if my_ai.SoldierControl == 2:
                return self.into_hunter(my_ai,soldier)
            if not hasattr(self, 'soldier_attack_point'):
                self.get_attack_point(soldier, my_ai)
            # 夺控
            action = self.occupy(soldier, my_ai)
            if action:
                return action

            # 射击
            action = self.shoot(soldier, my_ai)
            if action:
                return action

            # 看到敌人立即停止机动
            if self.see_can_shoot(soldier, my_ai):
                action = self.stop(soldier, my_ai)
                if action:
                    return action

            # 夺控点已经占领，并且有我方棋子时，机动到观察点
            bop_num = len(common.get_bop_pos(my_ai.our_bops, my_ai.attack_point['o_main_attack']))
            if common.my_city(my_ai.observation['cities'], my_ai.color,
                              my_ai.attack_point['o_main_attack']) and bop_num == 2:
                action = self.soldiermove(soldier, self.soldier_attack_point, my_ai)
                #action['move_path'] = action['move_path'][:1]
                if action:
                    return action
        return None


    def newpolicy(self,my_ai):
        soldier = self.get_bop(my_ai)
        if soldier:
            action = self.shoot(soldier, my_ai)
            if action:
                return action
            action = self.occupy(soldier, my_ai)
            if action:
                return action
            bop_id = soldier["obj_id"]
            if (bop_id == my_ai.sold_200):
                if soldier['cur_hex'] == 3824:
                    action = self.change_rush_level_two(soldier, my_ai)
                    if action:
                        self.caninto = 1
                        return action
                if self.caninto == 1:
                    return self.into_hunter(my_ai,soldier)
            elif (bop_id == my_ai.sold_202):
                if soldier['cur_hex'] == 4126:
                    action = self.change_rush_level_two(soldier, my_ai)
                    if action:
                        self.caninto = 1
                        return action
                if self.caninto == 1:
                    return self.into_hunter(my_ai, soldier)
            elif (bop_id == my_ai.sold_203):
                if soldier['cur_hex'] == 4129:
                    action = self.change_rush_level_two(soldier, my_ai)
                    if action:
                        self.caninto = 1
                        return action
                if self.caninto == 1:
                    return self.into_hunter(my_ai, soldier)
            elif (bop_id == my_ai.sold_86):
                if soldier['cur_hex'] == 4332:
                    action = self.change_rush_level_two(soldier, my_ai)
                    if action:
                        self.caninto = 1
                        return action
                if self.caninto == 1:
                    return self.into_hunter(my_ai, soldier)
            elif (bop_id == my_ai.sold_53):
                if soldier['cur_hex'] == 4225 and self.move_point == -1:
                    self.move_point = 3928
                if soldier['cur_hex'] != self.move_point:
                    if not (soldier['move_state'] == const.StateMode.Hide or soldier['change_state_remain_time']):
                        action = self.change_rush_level_two(soldier, my_ai)
                        if action:
                            return action
                    action = self.soldiermove(soldier, self.move_point, my_ai, number = 1)
                    if action:
                        return action
            return None

    def into_hunter(self, my_ai, operators):
        action = self.guide_shoot(operators, my_ai)
        if action:
            return action
        action = self.shoot(operators, my_ai)
        if action:
            return action
        action = self.occupy(operators, my_ai)
        if action:
            return action
        if operators['obj_id'] not in my_ai.controllable_ops:
            return None
        if operators['obj_id'] in my_ai.huntermove.keys():
            msg_body = my_ai.huntermove[operators['obj_id']]
            if len(msg_body["hexs"]) > 1:
                if operators['cur_hex'] == msg_body["hexs"][0]:
                    target_point = msg_body["hexs"][1]
                    action = self.move(operators, target_point, my_ai, number=1)
                    if action:
                        next_hex = action['move_path'][0]
                        msg_body["hexs"][0] = next_hex
                        if msg_body["hexs"][0] == msg_body["hexs"][1]:
                            msg_body["hexs"] = msg_body["hexs"][1:]
                        route = msg_body["hexs"]
                        # my_ai.huntermove = {}
                        return action
            else:
                del my_ai.huntermove[operators['obj_id']]
        return None

class BlueTank(Tank):
    def __init__(self, bop, serial_number=0, group=0):
        super(BlueTank, self).__init__()
        assert self.sub_type == bop['sub_type']
        self.obj_id = bop['obj_id']
        self.serial_number = serial_number
        self.group = group

    def get_init_hide_point(self, tank, my_ai, center_point=None):
        if not center_point:
            center_point = my_ai.attack_point['o_main_attack']

        circle = my_ai.hex_cache.get_circle(center_point, 0, 3)
        # pos_tuple_inner = BoundedHex(ai_group.attack_point['o_main_attack']).arc([0, 5], 1)
        # pos_tuple = list(set(pos_tuple_outer) - set(pos_tuple_inner))
        ai = my_ai
        bop = tank
        be_see_type = const.BopType.Vehicle
        pos_tuple = circle
        center_int4 = my_ai.attack_point['o_main_attack']
        observe_point_dis = 1
        top_num = const.top_num
        select = const.select
        beta = const.beta
        kwargs = {'observed_ability': 0,
                  'be_observed_ability': .5,
                  'maneuver_time': 1,
                  'maneuver_time_main': 0,
                  'neighbor_max_observe_ability': .8,
                  'hide_cond': 1.5,
                  'stack': 0.2}

        tank_end_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                                top_num,
                                                select, beta, **kwargs)

        self.init_hide = tank_end_int4
        self.init_move = False

    def get_init_attack_point(self, tank, my_ai):
        circle = my_ai.hex_cache.get_circle(my_ai.attack_point['o_main_attack'], 0, 3)
        # pos_tuple_inner = BoundedHex(ai_group.attack_point['o_main_attack']).arc([0, 5], 1)
        # pos_tuple = list(set(pos_tuple_outer) - set(pos_tuple_inner))
        ai = my_ai
        bop = tank
        be_see_type = const.BopType.Vehicle
        pos_tuple = circle
        center_int4 = my_ai.attack_point['o_main_attack']
        observe_point_dis = 2
        top_num = const.top_num
        select = const.select
        beta = const.beta
        kwargs = {'observed_ability': 1,
                  'be_observed_ability': 0,
                  'maneuver_time': 1,
                  'maneuver_time_main': 1.3,
                  'neighbor_max_observe_ability': 0,
                  'stack': 0.5,
                  'hide_cond': 0}

        tank_end_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                                top_num,
                                                select, beta, **kwargs)

        self.init_attack = tank_end_int4
        self.init_move = False

    def get_protect_point(self, tank, my_ai):
        pos_tuple = BoundedHex(my_ai.attack_point['o_main_attack']).arc([0, 5], 5, origin=True)
        circle = [point for point in pos_tuple if
                     my_ai.map.can_see(com.cvtOffset2Int4loc(point), my_ai.attack_point['o_main_attack'],
                                       const.SeeMode.GroundToGround)]
        ai = my_ai
        bop = tank
        be_see_type = const.BopType.Vehicle
        pos_tuple = circle
        center_int4 = my_ai.attack_point['o_main_attack']
        observe_point_dis = 2
        top_num = 10
        select = 1
        beta = 1
        kwargs = {'observed_ability': 0,
                  'be_observed_ability': 1,
                  'maneuver_time': 1,
                  'maneuver_time_main': 0.3,
                  'neighbor_max_observe_ability': 0.5,
                  'hide_cond': 0}

        protect_point_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                                top_num,
                                                select, beta, **kwargs)

        self.protect_point = protect_point_int4


    def MoveAttack(self, my_ai):
        tank = self.get_bop(my_ai)
        if tank:
            if my_ai.TankControl == 2:
                return self.into_hunter(my_ai,tank)
            if not hasattr(self, 'init_hide'):
                self.get_init_hide_point(tank, my_ai)


            action = self.shoot(tank, my_ai)
            if action:
                return action

            if not self.init_move:
                action = self.move(tank, self.init_hide, my_ai)
                if action:
                    self.init_move = True
                    return action
            elif self.see_enemy(tank) and tank['weapon_cool_time'] > 25:
                action = self.tank_move_hide(tank, my_ai)
                if action:
                    return action
            elif not tank['see_enemy_bop_ids'] and tank['weapon_cool_time'] <= 20:
                action = self.tank_move_attack(tank, my_ai, center_point=tank['cur_hex'])
                if action:
                    return action


        return None

    def Protect(self, my_ai):
        tank = self.get_bop(my_ai)
        if tank:
            if my_ai.TankControl == 2:
                return self.into_hunter(my_ai,tank)
            if not hasattr(self, 'protect_point'):
                self.get_protect_point(tank, my_ai)

            action = self.shoot(tank, my_ai)
            if action:
                return action

            if tank['cur_hex'] != self.protect_point:
                action = self.move(tank, self.protect_point, my_ai)
                if action:
                    return action


    def MainDefense(self, my_ai, action_bops):
        tank = self.get_bop(my_ai)
        if tank:
            if not common.my_city(my_ai.observation['cities'], my_ai.color,
                                  coord=my_ai.attack_point['o_second_attack']):
                return self.OccupyingSecond(my_ai, action_bops)
            # if not common.my_city(ai_group.observation['cities'], ai_group.color,
            #                       coord=ai_group.attack_point['o_main_attack']):
            #     return self.OccupyingMain(ai_group, action_bops)

            action = self.shoot(tank, my_ai)
            if action:
                return action

            if self.defense_guide == True and (not self.see_enemy(tank) or self.see_can_not_shoot(tank, my_ai)):
                return self.defense_guide_move(tank, my_ai)

            if common.see_enemy_vehicle(my_ai.enemy_bops) or common.see_enemy_tank(my_ai.enemy_bops):
                self.defense_guide = False

            if not self.defense_guide:
                action = self.friend_see_shoot(tank, my_ai, dis=3)
                if action:
                    return action

                if self.see_enemy(tank) and tank['weapon_cool_time'] >= 30:
                    action = self.tank_move_hide(tank, my_ai)
                    if action:
                        return action

                elif not tank['see_enemy_bop_ids'] and tank['weapon_cool_time'] <= 20:
                    action = self.tank_move_attack(tank, my_ai, center_point=tank['cur_hex'])
                    if action:
                        return action

            action = self.occupy(tank, my_ai)
            if action:
                return action
        return []

    def DTMainDefense(self, my_ai, action_bops):
        tank = self.get_bop(my_ai)
        if tank:
            if my_ai.time < 800 and not common.enemy_no_vehicle(my_ai):
                action = self.shoot(tank, my_ai, tar_sub_type=[const.BopName.Vehicle])
                if action:
                    return action
                action = self.shoot(tank, my_ai, tar_sub_type=[const.BopName.UnmannedVehicle])
                if action:
                    return action

                action = self.shoot(tank, my_ai, tar_sub_type=[const.BopName.Tank])
                if action:
                    return action
                action = self.shoot(tank, my_ai, tar_sub_type=[const.BopName.ScoutVehicle])
                if action:
                    return action
            else:
                action = self.shoot(tank, my_ai)
                if action:
                    return action

            action = self.occupy(tank, my_ai)
            if action:
                return action

            if my_ai.time < 800 and not common.enemy_no_vehicle(my_ai):
                action = self.tank_attack_vehicle(tank, my_ai, dis=4)
                if action:
                    return action
            else:
                action = self.friend_see_shoot(tank, my_ai, dis=3)
                if action:
                    return action

                if self.see_can_shoot(tank, my_ai):
                    action = self.tank_move_hide(tank, my_ai)
                    if action:
                        return action
                elif not tank['see_enemy_bop_ids'] and tank['weapon_cool_time'] <= 20:
                    action = self.tank_move_attack(tank, my_ai, center_point=tank['cur_hex'])
                    if action:
                        return action
            if my_ai.time > 1400:
                return self.OccupyingCity(my_ai, action_bops, my_ai.attack_point['o_second_attack'])

            if my_ai.time > 100:
                action = self.hide(tank, my_ai)
                if action:
                    return action
        return None

    def HRMainDefense(self, my_ai, action_bops):
        tank = self.get_bop(my_ai)
        if tank:
            if my_ai.TankControl == 2:
                return self.into_hunter(my_ai,tank)
            if not common.my_city(my_ai.observation['cities'], my_ai.color,
                                  coord=my_ai.attack_point['o_second_attack']):
                return self.OccupyingSecond(my_ai, action_bops)
            # if not common.my_city(ai_group.observation['cities'], ai_group.color,
            #                       coord=ai_group.attack_point['o_main_attack']):
            #     return self.OccupyingMain(ai_group, action_bops)

            action = self.shoot(tank, my_ai)
            if action:
                return action

            if self.defense_guide == True and (not self.see_enemy(tank) or self.see_can_not_shoot(tank, my_ai)):
                return self.defense_guide_move(tank, my_ai)

            if common.see_enemy_vehicle(my_ai.enemy_bops) or common.see_enemy_tank(my_ai.enemy_bops):
                self.defense_guide = False

            if not self.defense_guide:
                action = self.friend_see_shoot(tank, my_ai, dis=3)
                if action:
                    return action

                if self.see_enemy(tank) and tank['weapon_cool_time'] >= 30:
                    action = self.tank_move_hide(tank, my_ai)
                    if action:
                        return action

                elif not tank['see_enemy_bop_ids'] and tank['weapon_cool_time'] <= 20:
                    action = self.tank_move_attack(tank, my_ai, center_point=tank['cur_hex'])
                    if action:
                        return action



            action = self.occupy(tank, my_ai)
            if action:
                return action
        return []

    def HROccupying(self, my_ai, action_bops):
        return self.MoveAttack(my_ai)

    def HRProtect(self, my_ai, action_bops):
        return self.Protect(my_ai)

    def into_hunter(self, my_ai, operators):
        action = self.guide_shoot(operators, my_ai)
        if action:
            return action
        action = self.shoot(operators, my_ai)
        if action:
            return action
        action = self.occupy(operators, my_ai)
        if action:
            return action
        if operators['obj_id'] not in my_ai.controllable_ops:
            return None
        if operators['obj_id'] in my_ai.huntermove.keys():
            msg_body = my_ai.huntermove[operators['obj_id']]
            if len(msg_body["hexs"]) > 1:
                if operators['cur_hex'] == msg_body["hexs"][0]:
                    target_point = msg_body["hexs"][1]
                    action = self.move(operators, target_point, my_ai, number=1)


                    if action:
                        next_hex = action['move_path'][0]
                        msg_body["hexs"][0] = next_hex
                        if msg_body["hexs"][0] == msg_body["hexs"][1]:
                            msg_body["hexs"] = msg_body["hexs"][1:]
                        route = msg_body["hexs"]
                        # my_ai.huntermove = {}
                        return action
            else:
                del my_ai.huntermove[operators['obj_id']]
        return None


class BlueArtillery(Artillery):

    def __init__(self, bop, serial_number=0, group=0):
        super(BlueArtillery, self).__init__()
        assert self.sub_type == bop['sub_type']
        self.obj_id = bop['obj_id']
        self.serial_number = serial_number
        self.group = group

    def DTMainDefense(self, my_ai, action_bops):
        artillery = self.get_bop(my_ai)
        if artillery:
            if self.can_jm(artillery, my_ai):
                action_bops = sorted(action_bops, key=lambda x: x.sub_type, reverse=True)
                for action_bop in action_bops:
                    for ubop_record in action_bop.artillery_call:
                        if ubop_record and self.random_jm:
                            action = self.cancel_jm(artillery, my_ai)
                            if action:
                                self.random_jm = False
                                return action

                        bop = action_bop.get_bop(my_ai)
                        if bop:
                            if ubop_record['sub_type'] == const.BopName.Soldier:
                                # action_bop.artillery_call.remove(ubop_record)
                                action = self.jm_plan(artillery, ubop_record['cur_hex'], my_ai)
                                if action:
                                    return action
                        else:
                            action_bop.artillery_call = []

                    for ubop_record in action_bop.artillery_call:
                        bop = action_bop.get_bop(my_ai)
                        if bop:
                            if ubop_record['sub_type'] == const.BopName.Vehicle:
                                # action_bop.artillery_call.remove(ubop_record)
                                action = self.jm_plan(artillery, ubop_record['cur_hex'], my_ai)
                                if action:
                                    return action
                        else:
                            action_bop.artillery_call = []

                    for ubop_record in action_bop.artillery_call:
                        bop = action_bop.get_bop(my_ai)
                        if bop:
                            if ubop_record['sub_type'] == const.BopName.Tank:
                                # action_bop.artillery_call.remove(ubop_record)
                                action = self.jm_plan(artillery, ubop_record['cur_hex'], my_ai)
                                if action:
                                    return action
                        else:
                            action_bop.artillery_call = []

                action = self.jm_city(artillery, my_ai)
                if action:
                    return action
        return None

    def OccupyingMain(self, my_ai, action_bops):
        return self.DTMainDefense(my_ai, action_bops)

    def OccupyingSecond(self, my_ai, action_bops):
        return self.DTMainDefense(my_ai, action_bops)

    def HRMainDefense(self, my_ai, action_bops):
        artillery = self.get_bop(my_ai)
        if artillery:
            if self.can_jm(artillery, my_ai):
                action_bops = sorted(action_bops, key=lambda x: x.sub_type, reverse=True)
                for action_bop in action_bops:
                    for ubop_record in action_bop.artillery_call:
                        if ubop_record and self.random_jm:
                            action = self.cancel_jm(artillery, my_ai)
                            if action:
                                self.random_jm = False
                                return action

                        bop = action_bop.get_bop(my_ai)
                        if bop:
                            if ubop_record['sub_type'] == const.BopName.Soldier:
                                # action_bop.artillery_call.remove(ubop_record)
                                action = self.jm_plan(artillery, ubop_record['cur_hex'], my_ai)
                                if action:
                                    return action
                        else:
                            action_bop.artillery_call = []

                    for ubop_record in action_bop.artillery_call:
                        bop = action_bop.get_bop(my_ai)
                        if bop:
                            if ubop_record['sub_type'] == const.BopName.Vehicle:
                                # action_bop.artillery_call.remove(ubop_record)
                                action = self.jm_plan(artillery, ubop_record['cur_hex'], my_ai)
                                if action:
                                    return action
                        else:
                            action_bop.artillery_call = []

                    for ubop_record in action_bop.artillery_call:
                        bop = action_bop.get_bop(my_ai)
                        if bop:
                            if ubop_record['sub_type'] == const.BopName.Tank:
                                # action_bop.artillery_call.remove(ubop_record)
                                action = self.jm_plan(artillery, ubop_record['cur_hex'], my_ai)
                                if action:
                                    return action
                        else:
                            action_bop.artillery_call = []

                action = self.jm_city(artillery, my_ai)
                if action:
                    return action
        return None

    def HROccupying(self, my_ai, action_bops):
        return self.HRMainDefense(my_ai,action_bops)

    def HRProtect(self, my_ai, action_bops):
        return self.HRMainDefense(my_ai,action_bops)

class BlueMissile(Missile):
    def __init__(self, bop, serial_number=0, group=0):
        super(BlueMissile, self).__init__()
        assert self.sub_type == bop['sub_type']
        self.obj_id = bop['obj_id']
        self.serial_number = serial_number
        self.group = group
        self.last_observe_point = []
        self.round_hexes = None


    def get_attack_point(self, missile, my_ai):
        enemy_probably = my_ai.enemy_predict.enemy_predict_sum(my_ai, sub_type=const.BopName.Vehicle)
        if not enemy_probably.all():
            enemy_probably = my_ai.enemy_predict.enemy_predict_sum(my_ai, sub_type=const.BopName.ScoutVehicle)
        if not enemy_probably.all():
            enemy_probably = my_ai.enemy_predict.enemy_predict_sum(my_ai, sub_type=const.BopName.Tank)
        if not enemy_probably.all():
            enemy_probably = my_ai.enemy_predict.enemy_predict_sum(my_ai, sub_type=const.BopName.Soldier)
        index_flatten = np.argsort(enemy_probably, axis=None)[-1]
        index_tuple = (index_flatten // my_ai.my_map.size[1], index_flatten % my_ai.my_map.size[1])
        index_int4 = com.cvtOffset2Int4loc(index_tuple)
        return index_int4

    def get_observe_point(self, missile, my_ai):
        ubops_record = [ubop_record for ubop_id, ubop_record in my_ai.enemy_predict.ubops_record.items() if
                        ubop_record['live'] and not ubop_record['be_see']]

        if ubops_record:
            ubop_record = random.choice(ubops_record)
            ubop_pos = copy.deepcopy(ubop_record['pos_predict'])
        else:
            ubop_pos = np.zeros(my_ai.my_map.size)

        if not self.see_enemy(missile):
            self.last_observe_point.extend(my_ai.hex_cache.get_circle(missile['cur_hex'], 0, 2))
            self.last_observe_point = list(set(self.last_observe_point))

        ubop_pos[tuple(zip(*self.last_observe_point))] = 0
        index_flatten = np.argmax(ubop_pos, axis=None)
        index_tuple = (index_flatten // my_ai.my_map.size[1], index_flatten % my_ai.my_map.size[1])
        index_int4 = com.cvtOffset2Int4loc(index_tuple)
        # print(index_int4)
        if com.get_distance(index_int4, my_ai.attack_point['o_main_attack']) >= 7 or \
                com.get_distance(index_int4, my_ai.attack_point['o_second_attack']) >= 7:
            if ubops_record:
                # 求当前可观察点
                observe_hexes = []
                for bop in my_ai.our_bops:
                    if bop['type'] != const.BopType.Aircraft:
                        bop_LOS = my_ai.see.get_see_LOS(common.get_see_source(bop['type']),
                                                        const.BopType.Vehicle, bop['cur_hex'])
                        rows, cols = np.where(bop_LOS == True)
                        observe_hexes.extend(list(zip(rows, cols)))
                observe_hexes = list(set(observe_hexes))

                if not self.round_hexes:
                    round_main = my_ai.hex_cache.get_circle(my_ai.attack_point['o_main_attack'], 0, 3)
                    round_second = my_ai.hex_cache.get_circle(my_ai.attack_point['o_second_attack'], 0, 3)
                    self.round_hexes = list(set(round_main) | set(round_second))

                observe_hexes = list(set(self.round_hexes) - set(self.last_observe_point) - set(observe_hexes))
                if not observe_hexes or my_ai.time > 1350:
                    # self.last_observe_point = []
                    index_int4 = random.choice([my_ai.attack_point['o_main_attack'], my_ai.attack_point['o_second_attack']])
                else:
                    index_hex = random.choice(observe_hexes)
                    index_int4 = com.cvtOffset2Int4loc(index_hex)
            else:
                enemy_pos = [ubop['cur_hex'] for ubop in my_ai.enemy_bops]
                if enemy_pos:
                    index_int4 = random.choice(enemy_pos)
                else:
                    index_int4 = missile['cur_hex']
        return index_int4

    def stop_and_shoot(self, missile, my_ai):
        # 看到敌人立即停止机动
        if self.see_enemy(missile):
            action = self.stop(missile, my_ai)
            if action:
                return action
            action = self.shoot(missile, my_ai)
            if action:
                return action
        return list()

    # 跟踪射击，当看到敌人的特定棋子后，先追踪，等其停止后再进行射击，这样可以增加毁伤效果
    def trace_shoot(self, missile, my_ai, sub_type=None):
        if sub_type:
            e_bops = common.get_bop_sub_type_under_see(my_ai.enemy_bops, sub_type,
                                                       missile['see_enemy_bop_ids'])
            if e_bops:
                e_bop = e_bops[0]
                if e_bop['stop'] == 1:
                    action = self.stop(missile, my_ai)
                    if action:
                        return action
                    action = self.shoot(missile, my_ai, tar_sub_type=[sub_type])
                    if action:
                        return action
                else:
                    pos_tuple = random.choice(my_ai.hex_cache.get_circle(e_bop['cur_hex'], 1, 1))
                    pos_int4 = com.cvtOffset2Int4loc(pos_tuple)
                    if pos_int4 == missile['cur_hex']:
                        pos_int4 = e_bop['cur_hex']
                    action = self.move(missile, pos_int4, my_ai, number=1)
                    if action:
                        return action

        if missile['alive_remain_time'] < 150 or my_ai.time > 1650:
            return self.stop_and_shoot(missile, my_ai)
        else:
            return None

    def get_first_missile(self, missile, my_ai):
        missiles_live = [obop_record['live'] for obop_id, obop_record in my_ai.enemy_predict.obops_record.items() if
                        obop_record['sub_type']==const.BopName.Missile]
        if False in missiles_live:
            self.first_missile = False
        else:
            self.first_missile = True

    def MoveAttack(self, my_ai):
        missile = self.get_bop(my_ai)
        if missile:
            if not hasattr(self, 'first_missile'):
                self.get_first_missile(missile, my_ai)
            if self.first_missile:
                return self.Attack(missile, my_ai, const.BopName.Vehicle)
            else:
                return self.Observe(missile, my_ai)
        else:
            return None

    def Attack(self, missile, my_ai, sub_type):
        action = self.trace_shoot(missile, my_ai, sub_type=sub_type)
        if action:
            return action

        if common.can_move(missile, my_ai):
            attack_point = self.get_observe_point(missile, my_ai)
            if com.get_distance(missile['cur_hex'], attack_point) <= 3:
                return self.move(missile, attack_point, my_ai, number=1)  # 巡航，发现敌方战车则射击
            else:

                return self.move(missile, attack_point, my_ai, number=4)

        return list()

    def Observe(self, missile, my_ai):
        if missile['alive_remain_time'] < 150 or my_ai.time > 1650:
            action = self.trace_shoot(missile, my_ai)
            if action:
                return action

        if common.can_move(missile, my_ai):
            observe_point = self.get_observe_point(missile, my_ai)
            if com.get_distance(missile['cur_hex'], observe_point) <= 3:
                return self.move(missile, observe_point, my_ai, number=1)  # 巡航，发现敌方战车则射击
            else:

                return self.move(missile, observe_point, my_ai, number=1)

        return list()

    def Gathering(self, my_ai, city_coord=None):
        missile = self.get_bop(my_ai)
        if missile:
            if common.can_move(missile, my_ai):
                attack_point = my_ai.attack_point['o_main_attack']
                if com.get_distance(missile['cur_hex'], attack_point) <= 3:
                    return self.move(missile, attack_point, my_ai, number=1)  # 巡航，发现敌方战车则射击
                else:
                    return self.move(missile, attack_point, my_ai, number=4)

            return list()

    def DTFarAttack(self, my_ai, action_bops):
        return self.MoveAttack(my_ai)

    def DTMiddleFarAttack(self, my_ai, action_bops):
        # missile = self.get_bop(ai_group)
        # if missile:
        #     return self.Observe(missile, ai_group)
        return self.MoveAttack(my_ai)

    def DT2FarAttack(self, my_ai, action_bops):
        missile = self.get_bop(my_ai)
        if missile:
            return self.Attack(missile, my_ai, const.BopName.Vehicle)

    def DT2MiddleFarAttack(self, my_ai, action_bops):
        # missile = self.get_bop(ai_group)
        # if missile:
        #     return self.Observe(missile, ai_group)
        return self.MoveAttack(my_ai)

    def OccupyingMain(self, my_ai, action_bops):
        missile = self.get_bop(my_ai)
        if missile:
            return self.Attack(missile, my_ai, const.BopName.Soldier)

    def OccupyingSecond(self, my_ai, action_bops):
        missile = self.get_bop(my_ai)
        if missile:
            return self.Attack(missile, my_ai, const.BopName.Soldier)

    def HRMainDefense(self, my_ai, action_bops):
        # missile = self.get_bop(ai_group)
        # if missile:
        #     return self.Attack(missile, ai_group, const.BopName.Vehicle)
        return self.MoveAttack(my_ai)

    def HROccupying(self, my_ai, action_bops):
        # missile = self.get_bop(ai_group)
        # if missile:
        #     return self.Observe(missile, ai_group)
        return self.MoveAttack(my_ai)

    def HRProtect(self, my_ai, action_bops):
        return self.MoveAttack(my_ai)


class BlueUAV(UAV):
    def __init__(self, bop, serial_number=0, group=0):
        super(BlueUAV, self).__init__()
        assert self.sub_type == bop['sub_type']
        self.obj_id = bop['obj_id']
        self.serial_number = serial_number
        self.group = group
        self.last_observe_point = []
        self.round_hexes = None
        self.through_mark_point = 0
        self.allow_new_tarhex = True

    # 夺控点右上
    def get_first_attack_point1(self, uav, my_ai, main_dis=[9,11], bop_dis=[17, 18]):


        unmanned_end_int4 =  np.random.choice([3443, 3343])

        # print("蓝方无人机侦查点为：", self.first_attack_point)
        return unmanned_end_int4

    # 红方起点
    def get_first_attack_point2(self, uav, my_ai, main_dis=[9,11], bop_dis=[17, 18]):

        unmanned_end_int4 = np.random.choice([2442, 2542])
        # print("蓝方无人机侦查点为：", self.first_attack_point)
        return unmanned_end_int4

    # 夺控点右侧
    def get_first_attack_point3(self, uav, my_ai, main_dis=[9,11], bop_dis=[17, 18]):

        unmanned_end_int4 = np.random.choice([2524, 2625, 2826])
        # print("蓝方无人机侦查点为：", self.first_attack_point)
        return unmanned_end_int4

    def get_attack_point(self, UAV, my_ai):
        enemy_probably = my_ai.enemy_predict.enemy_predict_sum(my_ai, sub_type=const.BopName.Vehicle)
        if not enemy_probably.all():
            enemy_probably = my_ai.enemy_predict.enemy_predict_sum(my_ai, sub_type=const.BopName.ScoutVehicle)
        if not enemy_probably.all():
            enemy_probably = my_ai.enemy_predict.enemy_predict_sum(my_ai, sub_type=const.BopName.Tank)
        if not enemy_probably.all():
            enemy_probably = my_ai.enemy_predict.enemy_predict_sum(my_ai, sub_type=const.BopName.Soldier)
        index_flatten = np.argsort(enemy_probably, axis=None)[-1]
        index_tuple = (index_flatten // my_ai.my_map.size[1], index_flatten % my_ai.my_map.size[1])
        index_int4 = com.cvtOffset2Int4loc(index_tuple)
        return index_int4

    def get_observe_point(self, UAV, my_ai):
        ubops_record = [ubop_record for ubop_id, ubop_record in my_ai.enemy_predict.ubops_record.items() if
                        ubop_record['live'] and not ubop_record['be_see']]

        if ubops_record:
            ubop_record = random.choice(ubops_record)
            ubop_pos = copy.deepcopy(ubop_record['pos_predict'])
        else:
            ubop_pos = np.zeros(my_ai.my_map.size)

        if not self.see_enemy(UAV):
            self.last_observe_point.extend(my_ai.hex_cache.get_circle(UAV['cur_hex'], 0, 2))
            self.last_observe_point = list(set(self.last_observe_point))

        ubop_pos[tuple(zip(*self.last_observe_point))] = 0
        index_flatten = np.argmax(ubop_pos, axis=None)
        index_tuple = (index_flatten // my_ai.my_map.size[1], index_flatten % my_ai.my_map.size[1])
        index_int4 = com.cvtOffset2Int4loc(index_tuple)
        # print(index_int4)
        if com.get_distance(index_int4, my_ai.attack_point['o_main_attack']) >= 7 or \
                com.get_distance(index_int4, my_ai.attack_point['o_second_attack']) >= 7:
            if ubops_record:
                # 求当前可观察点
                observe_hexes = []
                for bop in my_ai.our_bops:
                    if bop['type'] != const.BopType.Aircraft:
                        bop_LOS = my_ai.see.get_see_LOS(common.get_see_source(bop['type']),
                                                        const.BopType.Vehicle, bop['cur_hex'])
                        rows, cols = np.where(bop_LOS == True)
                        observe_hexes.extend(list(zip(rows, cols)))
                observe_hexes = list(set(observe_hexes))

                if not self.round_hexes:
                    round_main = my_ai.hex_cache.get_circle(my_ai.attack_point['o_main_attack'], 0, 3)
                    round_second = my_ai.hex_cache.get_circle(my_ai.attack_point['o_second_attack'], 0, 3)
                    self.round_hexes = list(set(round_main) | set(round_second))

                observe_hexes = list(set(self.round_hexes) - set(self.last_observe_point) - set(observe_hexes))
                if not observe_hexes or my_ai.time > 1350:
                    # self.last_observe_point = []
                    index_int4 = random.choice([my_ai.attack_point['o_main_attack'], my_ai.attack_point['o_second_attack']])
                else:
                    index_hex = random.choice(observe_hexes)
                    index_int4 = com.cvtOffset2Int4loc(index_hex)
            else:
                enemy_pos = [ubop['cur_hex'] for ubop in my_ai.enemy_bops]
                if enemy_pos:
                    index_int4 = random.choice(enemy_pos)
                else:
                    index_int4 = UAV['cur_hex']
        return index_int4


    def stop_and_shoot(self, UAV, my_ai):
        # 看到敌人立即停止机动
        if self.see_enemy(UAV):
            action = self.stop(UAV, my_ai)
            if action:
                return action
            action = self.shoot(UAV, my_ai)
            if action:
                return action
        return list()

    def partener_guided_UAV_move(self, bop, destination_int4, my_ai, number=None):
        move_actions = common.get_bop_action_id_name(my_ai.observation['valid_actions'], bop['obj_id'],
                                                     const.ActionType.Move)
        if move_actions and bop and bop['cur_hex'] != destination_int4:
            move_type = self.get_move_type(bop)
            march_mode = self.is_march_mode(move_type)
            # route = my_ai.map.gen_move_route(bop['cur_hex'], destination_int4, move_type)
            route = astar(bop, bop['cur_hex'], destination_int4, my_ai, time_mode=True, no_pass=my_ai.land_marks,
                          march_mode=march_mode, maxsteps=2000)

            if my_ai.map.basic[destination_int4//100][destination_int4%100]['cond'] in [1,2]:
                number = -1
            else:
                number = -2

            if route:
                if number:
                    if len(route) > number:
                        route = route[0:number]
                ##更新我方未来位置，减小同格
                my_ai.enemy_predict.update_future_hex(bop['obj_id'], route[-1], my_ai)
                return {"actor": my_ai.seat,
                        'obj_id': bop['obj_id'],
                        'type': const.ActionType.Move,
                        'move_path': route,
                        }
        return None

    # 跟踪射击，当看到敌人的特定棋子后，立即停止
    # def trace_guide(self, UAV, my_ai, sub_type_list):
    #     action = self.guide_shoot(UAV, my_ai)
    #     if action:
    #         print('发生蓝方无人机引导射击动作')
    #         return action
    #
    #
    #     e_bops = []
    #     if sub_type_list != None:    # 明确了需要打击的算子类型，0：坦克，1：战车
    #         for sub_type in sub_type_list:
    #             # if len(UAV['see_enemy_bop_ids']) != len(my_ai.enemy_bops):
    #             #     print('1')
    #             # e_bops是蓝方无人机自己能看到的，红方坦克、战车
    #             e_bops += common.get_bop_sub_type_under_see(my_ai.enemy_bops, sub_type,
    #                                                    UAV['see_enemy_bop_ids'])
    #         if 0 in [bop['sub_type'] for bop in my_ai.enemy_bops] or 1 in [bop['sub_type'] for bop in my_ai.enemy_bops]:
    #
    #             # 若无人机看到红方坦克或车辆立即停止机动（2格），停下，或已经停下
    #             if 0 in [bop['sub_type'] for bop in my_ai.enemy_bops if
    #                      bop['obj_id'] in UAV['see_enemy_bop_ids']] or 1 in [bop['sub_type'] for bop in my_ai.enemy_bops
    #                                                                          if
    #                                                                          bop['obj_id'] in UAV['see_enemy_bop_ids']]:
    #                 try:  # 看到坦克
    #                     # 第一个step
    #                     if not hasattr(self, 'chasing_enemy_id'):
    #                         self.chasing_enemy_id = [bop['obj_id'] for bop in my_ai.enemy_bops if
    #                                                  bop['obj_id'] in UAV['see_enemy_bop_ids'] and bop['sub_type']==0][0]
    #                         follow_point = [bop['cur_hex'] for bop in my_ai.enemy_bops if bop['obj_id']==self.chasing_enemy_id][0]
    #                     else:
    #                         self.chasing_enemy_id = [bop['obj_id'] for bop in my_ai.enemy_bops if
    #                                                  bop['obj_id'] in UAV['see_enemy_bop_ids'] and bop['sub_type'] == 0][0]
    #                         follow_point = \
    #                         [bop['cur_hex'] for bop in my_ai.enemy_bops if bop['obj_id'] == self.chasing_enemy_id][0]
    #                 except:# 看到战车
    #                     # 第一个step
    #                     if not hasattr(self, 'chasing_enemy_id'):
    #                         self.chasing_enemy_id = [bop['obj_id'] for bop in my_ai.enemy_bops if
    #                                                  bop['obj_id'] in UAV['see_enemy_bop_ids'] and bop[
    #                                                      'sub_type'] == 1][0]
    #                         follow_point = \
    #                         [bop['cur_hex'] for bop in my_ai.enemy_bops if bop['obj_id'] == self.chasing_enemy_id][0]
    #                     else:
    #                         self.chasing_enemy_id = [bop['obj_id'] for bop in my_ai.enemy_bops if
    #                                                  bop['obj_id'] in UAV['see_enemy_bop_ids'] and bop[
    #                                                      'sub_type'] == 1][0]
    #                         follow_point = \
    #                             [bop['cur_hex'] for bop in my_ai.enemy_bops if bop['obj_id'] == self.chasing_enemy_id][
    #                                 0]
    #                 action = self.stop(UAV, my_ai)
    #                 if action:
    #                     return action
    #                 return 'stay_still'
    #             else: # 其他蓝方算子看到红方坦克、战车，2格外，去追
    #                 # 2格范围内，从没见过敌方坦克、战车
    #                 if not hasattr(self, 'chasing_enemy_id'):
    #                     try:  # 看到坦克
    #                         self.chasing_enemy_id = [bop['obj_id'] for bop in my_ai.enemy_bops if bop[
    #                             'sub_type'] == 0][0]
    #                         follow_point = \
    #                         [bop['cur_hex'9] for bop in my_ai.enemy_bops if bop['obj_id'] == self.chasing_enemy_id][
    #                             0]
    #
    #                     except:  # 看到战车
    #                         # 第一个step
    #
    #                         self.chasing_enemy_id = [bop['obj_id'] for bop in my_ai.enemy_bops if bop[
    #                             'sub_type'] == 1][0]
    #                         follow_point = \
    #                             [bop['cur_hex'] for bop in my_ai.enemy_bops if
    #                              bop['obj_id'] == self.chasing_enemy_id][0]
    #                 # 见过，如果其他算子能看到刚才出现在2个以内的算子
    #                 elif hasattr(self, 'chasing_enemy_id') and self.chasing_enemy_id in [bop['obj_id'] for bop in my_ai.enemy_bops]:
    #                     follow_point = [bop['cur_hex'] for bop in my_ai.enemy_bops if bop['obj_id']==self.chasing_enemy_id][0]
    #                 # 见过，其他算子看不到刚才的敌方算子，去追一次试一下，
    #                 elif hasattr(self, 'chasing_enemy_id') and self.chasing_enemy_id not in [bop['obj_id'] for bop in my_ai.enemy_bops]:
    #                     # 没有相关裁决信息，追一下
    #                     if 1:
    #                     # 有相关裁决信息，换目标
    #                     else:
    #                 # 其他算子看不到刚才的算子，换个新敌方算子
    #
    #                 self.chasing_tar_hex = follow_point
    #                 if com.get_distance(UAV['cur_hex'], follow_point) <= 3:
    #                     return self.move(UAV, follow_point, my_ai, number=1)
    #                 else:
    #                     return self.move(UAV, follow_point, my_ai, number=30)
    #
    #         else:
    #             # 看不到敌方算子，曾经看到过，不知道敌方是否活着，
    #             # 如果没有其他敌方算子，去算子最近一次出现的位置（消失的位置）,只去一次
    #             if not hasattr(self, 'chasing_chance'):
    #
    #                 if hasattr(self, 'chasing_tar_hex'): # todo 敌方算子是否存活,未完成
    #                     self.chasing_chance = 1
    #                     # follow_point = self.chasing_tar_hex
    #                     follow_point = (self.chasing_tar_hex//100*2 - UAV['cur_hex']//100)*100 +  (self.chasing_tar_hex%100*2 - UAV['cur_hex']%100)
    #                     return self.move(UAV, follow_point, my_ai, number=10)
    #             else:
    #                 # self.chasing_chance = 0
    #                 delattr(self, 'chasing_chance')
    #                 return None # 去下一个巡逻点
    #     else:
    #         return None
    #
    # def trace_guide(self, UAV, my_ai, sub_type_list):
    #     action = self.guide_shoot(UAV, my_ai)
    #     if action:
    #         print('发生蓝方无人机引导射击动作')
    #         return action
    #
    #
    #     e_bops = []
    #     if sub_type_list != None:    # 明确了需要打击的算子类型，0：坦克，1：战车
    #         for sub_type in sub_type_list:
    #             e_bops += common.get_bop_sub_type_under_see(my_ai.enemy_bops, sub_type,
    #                                                    UAV['see_enemy_bop_ids'])
    #         if 0 in [bop['sub_type'] for bop in my_ai.enemy_bops] or 1 in [bop['sub_type'] for bop in my_ai.enemy_bops]:
    #             if not hasattr(self, 'chasing_tar_hex'):
    #                 try:
    #                     self.chasing_tar_hex = common.get_bop_sub_type(my_ai.enemy_bops, 0)[0]['cur_hex']
    #                 except:
    #                     self.chasing_tar_hex = common.get_bop_sub_type(my_ai.enemy_bops, 1)[0]['cur_hex']
    #             # 若无人机看到蓝方坦克或车辆立即停止机动，能停就停
    #             if 0 in [bop['sub_type'] for bop in my_ai.enemy_bops if
    #                      bop['obj_id'] in UAV['see_enemy_bop_ids']] or 1 in [bop['sub_type'] for bop in my_ai.enemy_bops
    #                                                                          if
    #                                                                          bop['obj_id'] in UAV['see_enemy_bop_ids']]:
    #
    #                 self.chasing_tar_hex = [bop['cur_hex'] for bop in my_ai.enemy_bops if
    #                  bop['obj_id'] in UAV['see_enemy_bop_ids']][0]
    #
    #                 action = self.stop(UAV, my_ai)
    #                 if action:
    #                     return action
    #             # 追踪，优先追踪当前无人机能自己看到的敌方坦克、战车棋子
    #             # 停下来，看敌方算子走了没 # todo
    #             if [bop['cur_hex'] for bop in e_bops if bop['obj_id'] in UAV['see_enemy_bop_ids']]:
    #                 follow_point = [bop['cur_hex'] for bop in e_bops if bop['obj_id'] in UAV['see_enemy_bop_ids']][0]
    #             else:
    #                 try:
    #
    #                     follow_point = common.get_bop_sub_type(my_ai.enemy_bops, 0)[0]['cur_hex']  # todo 选择最近的坦克，未完成
    #                 except:
    #                     follow_point = common.get_bop_sub_type(my_ai.enemy_bops, 1)[0]['cur_hex']  # todo 选择最近的战车，未完成
    #             self.chasing_tar_hex = follow_point
    #             if com.get_distance(UAV['cur_hex'], follow_point) <= 3:
    #                 return self.move(UAV, follow_point, my_ai, number=1)
    #             else:
    #                 return self.move(UAV, follow_point, my_ai, number=5)
    #         else:
    #             if hasattr(self, 'chasing_tar_hex'):  # todo 敌方算子是否存活,未完成
    #                 if not hasattr(self, 'chasing_chance'):
    #                     self.chasing_chance = 1
    #                     follow_point1 =  (self.chasing_tar_hex//100*2 - UAV['cur_hex']//100)*100 +  (self.chasing_tar_hex%100*2 - UAV['cur_hex']%100)
    #                     return self.move(UAV, follow_point1, my_ai, number=4)
    #             # 看不到敌方算子，曾经看到过，不知道敌方是否活着，
    #             # 如果没有其他敌方算子，去算子最近一次出现的位置（消失的位置）,只去一次
    #             # if not hasattr(self, 'chasing_chance'):
    #     #         #                 #     if hasattr(self, 'chasing_tar_hex'):  # todo 敌方算子是否存活,未完成
    #     #         #                 #         self.chasing_chance = 1
    #     #         #                 #         follow_point =(self.chasing_tar_hex//100*2 - UAV['cur_hex']//100)*100 +  (self.chasing_tar_hex%100*2 - UAV['cur_hex']%100)
    #     #         #                 #         return self.move(UAV, follow_point, my_ai, number=4)
    #     #         #                 # else:
    #     #         #                 #     self.chasing_chance = 0
    #     #         #                 #     delattr(self, 'chasing_chance')
    #     #         #                 #     return None  # 去下一个巡逻点
    #
    #     else:
    #         return None

    # 跟踪射击，当看到敌人的特定棋子后，立即停止
    def trace_guide(self, UAV, my_ai, sub_type_list):
        action = self.guide_shoot(UAV, my_ai, [0, 1])
        if action:
            print('发生蓝方无人机引导射击动作')
            return action


        e_bops = []
        if sub_type_list != None:    # 明确了需要打击的算子类型，0：坦克，1：战车，4：无人战车
            for sub_type in sub_type_list:
                e_bops += common.get_bop_sub_type_under_see(my_ai.enemy_bops, sub_type,
                                                       UAV['see_enemy_bop_ids'])
            if 0 in [bop['sub_type'] for bop in my_ai.enemy_bops] or 1 in [bop['sub_type'] for bop in
                                                                           my_ai.enemy_bops]:
                # if not hasattr(self, 'chasing_tar_hex'):
                #     try:
                #         # try:
                #         self.chasing_tar_hex = common.get_bop_sub_type(my_ai.enemy_bops, 1)[0]['cur_hex']
                #         # except:
                #         #     self.chasing_tar_hex = common.get_bop_sub_type(my_ai.enemy_bops, 4)[0]['cur_hex']
                #     except:
                #         self.chasing_tar_hex = common.get_bop_sub_type(my_ai.enemy_bops, 0)[0]['cur_hex']
                # 若无人机看到红方战车或无人战车或坦克立即停止机动，能停就停
                # or 4 in [
                #     bop['sub_type'] for bop in
                #     my_ai.enemy_bops
                #     if
                #     bop['obj_id'] in UAV[
                #         'see_enemy_bop_ids']]
                if 0 in [bop['sub_type'] for bop in my_ai.enemy_bops if
                         bop['obj_id'] in UAV['see_enemy_bop_ids']] or 1 in [bop['sub_type'] for bop in
                                                                             my_ai.enemy_bops
                                                                             if
                                                                             bop['obj_id'] in UAV[
                                                                                 'see_enemy_bop_ids']]:
                    if hasattr(self, 'chasing_chance'): # 下次继续追该目标
                        delattr(self, 'chasing_chance')
                    if hasattr(self, 'PartenerSeen_move_step_by_step'):
                        delattr(self, 'PartenerSeen_move_step_by_step')
                    if hasattr(self, 'UAV_pos_when_lost_tar'):
                        delattr(self, 'UAV_pos_when_lost_tar')
                    if hasattr(self, 'move_step_by_step'):
                        delattr(self, 'move_step_by_step')
                    self.chasing_tar_hex = [bop['cur_hex'] for bop in my_ai.enemy_bops if
                                            bop['obj_id'] in UAV['see_enemy_bop_ids'] if bop['sub_type'] in [0,1]][0]
                    # action = self.stop(UAV, my_ai)
                    self.allow_new_tarhex = False  # 如果无人机自己看到，则暂时不追其他目标
                    self.middle_point_crusier = 0
                    # if action:
                    #     return action
                    # return 'stay_still'
                # 追踪。当前无人机能自己看到的敌方棋子优先。无人机已经停下，正在停下
                # 或无人机没看到，仅有我方其他棋子看到
                # if [bop['cur_hex'] for bop in e_bops if bop['obj_id'] in UAV['see_enemy_bop_ids']]:
                #     try:
                #         zhanche_hex = [bop['cur_hex'] for bop in e_bops if
                #                    bop['obj_id'] in UAV['see_enemy_bop_ids'] and bop['sub_type'] == 1][0]
                #     except:
                #         zhanche_hex = []
                #     # try:
                #     #     unmanned_viechle_hex = [bop['cur_hex'] for bop in e_bops if
                #     #                         bop['obj_id'] in UAV['see_enemy_bop_ids'] and bop['sub_type'] == 4][0]
                #     # except:
                #     #     unmanned_viechle_hex = []
                #     try:
                #         tank_hex = [bop['cur_hex'] for bop in e_bops if
                #                 bop['obj_id'] in UAV['see_enemy_bop_ids'] and bop['sub_type'] == 0][0]
                #     except:
                #         tank_hex = []
                #     if zhanche_hex:
                #         follow_point = zhanche_hex
                #     # elif unmanned_viechle_hex:
                #     #     follow_point = unmanned_viechle_hex
                #     elif tank_hex:
                #         follow_point = tank_hex
                #     self.chasing_tar_hex = follow_point
                #     # if self.middle_point_crusier == 1:
                #     self.middle_point_crusier = 0
                #     return 'stay_still'
                #     # action = self.stop(UAV, my_ai)
                #     # if action:
                #     #     return action
                else:   # 追踪。我方其他算子看到的敌方棋子。
                    # 无人机没有看到过棋子，追新目标
                    if self.allow_new_tarhex == True:
                        if hasattr(self, 'PartenerSeen_move_step_by_step'):
                            delattr(self, 'PartenerSeen_move_step_by_step')
                        try:
                            # try:
                            follow_point = common.get_bop_sub_type(my_ai.enemy_bops, 1)[0]['cur_hex']  # todo 选择最近的战车，未完成
                            # except:
                            #     follow_point = common.get_bop_sub_type(my_ai.enemy_bops, 4)[0][
                            #         'cur_hex']  # todo 选择最近的坦克，未完成
                        except:
                            follow_point = common.get_bop_sub_type(my_ai.enemy_bops, 0)[0]['cur_hex']  # todo 选择最近的坦克，未完成
                        self.chasing_tar_hex = follow_point
                        if self.middle_point_crusier == 1:
                            self.middle_point_crusier = 0
                            action = self.stop(UAV, my_ai)
                            if action:
                                return action
                            else:
                                self.middle_point_crusier = 0   # 已经停下
                        # 蓝方其他算子看到对方坦克、车辆，蓝方无人机停止时间内，不能返回空，要返回'stay_still'
                        self.chasing_tar_hex = follow_point
                        if com.get_distance(UAV['cur_hex'], follow_point) == 0:
                            return 'stay_still'
                        elif com.get_distance(UAV['cur_hex'], follow_point) <= 3:
                            action = self.move(UAV, follow_point, my_ai, number=1)
                            if action:
                                return action
                            # else:
                            #     return 'stay_still'
                        else:
                            action = self.partener_guided_UAV_move(UAV, follow_point, my_ai, number=1)
                            if action:
                                return action
                            # else:
                            #     return 'stay_still'
                    # 无人机见过敌方算子,先追旧棋子，再追新棋子，期间不更新目标位置
                    else:
                        # 防止停下的过程中，对方棋子就已经消失，浪费了追踪机会

                        # try:
                        #     # try:
                        #     follow_point = common.get_bop_sub_type(my_ai.enemy_bops, 1)[0]['cur_hex']  # todo 选择最近的战车，未完成
                        #     # except:
                        #     #     follow_point = common.get_bop_sub_type(my_ai.enemy_bops, 4)[0][
                        #     #         'cur_hex']  # todo 选择最近的坦克，未完成
                        # except:
                        #     follow_point = common.get_bop_sub_type(my_ai.enemy_bops, 0)[0]['cur_hex']  # todo 选择最近的坦克，未完成
                        # self.chasing_tar_hex = follow_point

                        if not hasattr(self, 'PartenerSeen_move_step_by_step'):
                            self.PartenerSeen_move_step_by_step = 0
                        if not hasattr(self, 'UAV_pos_when_lost_tar'):
                            self.UAV_pos_when_lost_tar =  UAV['cur_hex']
                        #
                        if self.PartenerSeen_move_step_by_step == 7:
                            # 去追新棋子
                            self.allow_new_tarhex == True
                            delattr(self, 'PartenerSeen_move_step_by_step')
                            delattr(self, 'UAV_pos_when_lost_tar')


                        if hasattr(self, 'PartenerSeen_move_step_by_step'):
                            print('BlueUAV chases the once seen enemy inspite of the enemy seen by parterner move_step_by_step:', self.PartenerSeen_move_step_by_step)
                        # follow_point 必须要在地图尺度内
                        try:
                            assert (self.chasing_tar_hex // 100 * 2 - self.UAV_pos_when_lost_tar // 100) >= 0   # todo 追的过程中，UAV['cur_hex']改变了
                            assert (self.chasing_tar_hex // 100 * 2 - self.UAV_pos_when_lost_tar // 100) < my_ai.my_map.size[0]
                            assert (self.chasing_tar_hex % 100 * 2 - self.UAV_pos_when_lost_tar % 100) >= 0
                            assert (self.chasing_tar_hex % 100 * 2 - self.UAV_pos_when_lost_tar % 100) < my_ai.my_map.size[1]
                            follow_point = (self.chasing_tar_hex // 100 * 2 - self.UAV_pos_when_lost_tar // 100) * 100 + (
                                    self.chasing_tar_hex % 100 * 2 - self.UAV_pos_when_lost_tar % 100)



                            action = self.move(UAV, follow_point, my_ai, number=1)
                            if action:
                                self.PartenerSeen_move_step_by_step += 1
                                # return action

                            if UAV['cur_hex'] == follow_point:
                                self.allow_new_tarhex == True
                                delattr(self, 'PartenerSeen_move_step_by_step')
                                delattr(self, 'UAV_pos_when_lost_tar')

                            if action:
                                # self.PartenerSeen_move_step_by_step += 1
                                return action
                        except:
                            row = (self.chasing_tar_hex // 100 * 2 - self.UAV_pos_when_lost_tar // 100)
                            col = (self.chasing_tar_hex % 100 * 2 - self.UAV_pos_when_lost_tar % 100)
                            # if (self.chasing_tar_hex // 100 * 2 - UAV['cur_hex'] // 100) <= 0:
                            #     follow_point = 0 + (self.chasing_tar_hex%100*2 - UAV['cur_hex']%100)
                            # if (self.chasing_tar_hex // 100 * 2 - UAV['cur_hex'] // 100) >= my_ai.my_map.size[0]:
                            #     follow_point = my_ai.my_map.size[0]*100 + (self.chasing_tar_hex%100*2 - UAV['cur_hex']%100)
                            # if (self.chasing_tar_hex%100*2 - UAV['cur_hex']%100) <= 0:
                            #     follow_point = (self.chasing_tar_hex // 100 * 2 - UAV['cur_hex'] // 100) * 100 + 0
                            # if (self.chasing_tar_hex%100*2 - UAV['cur_hex']%100) >= my_ai.my_map.size[1]:
                            #     follow_point = (self.chasing_tar_hex // 100 * 2 - UAV['cur_hex'] // 100) * 100 + my_ai.my_map.size[1]
                            # return self.move(UAV, follow_point, my_ai, number=4)
                            print('蓝方追踪地图外算子坐标——————————————————————————————')
                            if row <= 0:
                                row = 0
                            if row >= my_ai.my_map.size[0]:
                                row = my_ai.my_map.size[0] - 1
                            if col <= 0:
                                col = 0
                            if col >= my_ai.my_map.size[1]:
                                col = my_ai.my_map.size[1] - 1

                            if UAV['cur_hex'] == row * 100 + col:
                                self.allow_new_tarhex == True
                                delattr(self, 'PartenerSeen_move_step_by_step')
                                delattr(self, 'UAV_pos_when_lost_tar')
                            action = self.move(UAV, row * 100 + col, my_ai, number=1)
                            if action:
                                self.PartenerSeen_move_step_by_step += 1
                                return action

            else:
                # 看不到敌方算子，曾经看到过，不知道敌方是否活着，
                # 如果没有其他敌方算子，去算子最近一次出现的位置（消失的位置）,只去一次
                # if hasattr(self, 'chasing_tar_hex'):  # todo 敌方算子是否存活,未完成
                #     if not hasattr(self, 'chasing_chance'):
                #         self.chasing_chance = 1
                #         follow_point =  (self.chasing_tar_hex//100*2 - UAV['cur_hex']//100)*100 +  (self.chasing_tar_hex%100*2 - UAV['cur_hex']%100)
                #         return self.move(UAV, follow_point, my_ai, number=4)
                if not hasattr(self, 'chasing_chance'):
                    if hasattr(self, 'chasing_tar_hex'):  # todo 敌方算子是否存活,未完成
                        if not hasattr(self, 'move_step_by_step'):
                            self.move_step_by_step = 0
                        if not hasattr(self, 'UAV_pos_when_lost_tar'):
                            self.UAV_pos_when_lost_tar = UAV['cur_hex']

                        if self.move_step_by_step == 7:
                            self.chasing_chance = 1
                            delattr(self, 'move_step_by_step')
                        # print('BlueUAV move_step_by_step:', self.move_step_by_step)
                        # follow_point 必须要在地图尺度内
                        try:
                            assert (self.chasing_tar_hex // 100 * 2 -self.UAV_pos_when_lost_tar // 100)>=0
                            assert (self.chasing_tar_hex // 100 * 2 - self.UAV_pos_when_lost_tar // 100)< my_ai.my_map.size[0]
                            assert (self.chasing_tar_hex%100*2 - self.UAV_pos_when_lost_tar%100)>=0
                            assert (self.chasing_tar_hex % 100 * 2 - self.UAV_pos_when_lost_tar % 100) < my_ai.my_map.size[1]
                            follow_point = (self.chasing_tar_hex // 100 * 2 - self.UAV_pos_when_lost_tar // 100) * 100 + (
                                        self.chasing_tar_hex % 100 * 2 - self.UAV_pos_when_lost_tar % 100)


                            action = self.move(UAV, follow_point, my_ai, number=1)
                            if action:
                                self.move_step_by_step += 1
                                # print('\n蓝方无人机和队友看不到敌方任何战车、坦克，向曾看到过目标位置机动')
                                # return action

                            if UAV['cur_hex'] == follow_point:
                                self.chasing_chance = 1
                                delattr(self, 'move_step_by_step')
                                delattr(self, 'UAV_pos_when_lost_tar')

                            if action:
                                # self.move_step_by_step += 1
                                # print('\n蓝方无人机和队友看不到敌方任何战车、坦克，向曾看到过目标位置机动')
                                return action
                        except:
                            row = (self.chasing_tar_hex // 100 * 2 - UAV['cur_hex'] // 100)
                            col = (self.chasing_tar_hex%100*2 - UAV['cur_hex']%100)
                            # if (self.chasing_tar_hex // 100 * 2 - UAV['cur_hex'] // 100) <= 0:
                            #     follow_point = 0 + (self.chasing_tar_hex%100*2 - UAV['cur_hex']%100)
                            # if (self.chasing_tar_hex // 100 * 2 - UAV['cur_hex'] // 100) >= my_ai.my_map.size[0]:
                            #     follow_point = my_ai.my_map.size[0]*100 + (self.chasing_tar_hex%100*2 - UAV['cur_hex']%100)
                            # if (self.chasing_tar_hex%100*2 - UAV['cur_hex']%100) <= 0:
                            #     follow_point = (self.chasing_tar_hex // 100 * 2 - UAV['cur_hex'] // 100) * 100 + 0
                            # if (self.chasing_tar_hex%100*2 - UAV['cur_hex']%100) >= my_ai.my_map.size[1]:
                            #     follow_point = (self.chasing_tar_hex // 100 * 2 - UAV['cur_hex'] // 100) * 100 + my_ai.my_map.size[1]
                            # return self.move(UAV, follow_point, my_ai, number=4)
                            print('蓝方追踪地图外算子坐标——————————————————————————————')
                            if row<=0:
                                row =0
                            if row>=my_ai.my_map.size[0]:
                                row = my_ai.my_map.size[0]-1
                            if col<=0:
                                col = 0
                            if col>=my_ai.my_map.size[1]:
                                col = my_ai.my_map.size[1]-1

                            action = self.move(UAV, row*100+col, my_ai, number=1)
                            if action:
                                self.move_step_by_step += 1
                                print('\n蓝方无人机和队友看不到敌方任何战车、坦克，向曾看到过目标位置机动')
                                return action
                else:
                    observe_point = self.get_observe_point(UAV, my_ai)
                    if com.get_distance(UAV['cur_hex'], observe_point) <= 3:
                        action = self.move(UAV, observe_point, my_ai, number=1)  # 1格1格走
                        if action:
                            # delattr(self, 'move_step_by_step')
                            self.allow_new_tarhex = True
                            # self.middle_point_crusier = 1
                            delattr(self, 'chasing_chance')
                            return action  # 1格1格走
                    else:

                        action = self.move(UAV, observe_point, my_ai, number=1)
                        if action:
                            # delattr(self, 'move_step_by_step')
                            self.allow_new_tarhex = True
                            # self.middle_point_crusier = 1
                            delattr(self, 'chasing_chance')
                            return action  # 1格1格走
                    return None  # 去下一个巡逻点

    #
    # def MoveAttack(self, my_ai):
    #     # todo 引导射击没加，加步兵的引导射击
    #     UAV = self.get_bop(my_ai)
    #     if UAV:
    #         # 与巡飞弹不同，只有一个无人机
    #         return self.Observe(UAV, my_ai)
    #         # if not hasattr(self, 'first_UAV'):
    #         #     self.get_first_UAV(UAV, my_ai)
    #         # if self.first_UAV:
    #         #     return self.Attack(UAV, my_ai, const.BopName.Vehicle)
    #         # else:
    #         #     return self.Observe(UAV, my_ai)
    #     else:
    #         return None

    def MoveAttack(self, my_ai):
        # todo 引导射击没加，加步兵的引导射击
        UAV = self.get_bop(my_ai)
        if UAV:
            if my_ai.UAVControl == 2:
                return self.into_hunter(my_ai,UAV)
            if hasattr(my_ai, 'UAVmsg'):
                if not hasattr(my_ai, 'last_processed_UAV_msg'): # 首次接收到人工干预的无人机机动命令
                    task = my_ai.UAVmsg
                    print('processing first UAVmsg')
                    # my_ai.last_processed_UAV_msg = my_ai.UAVmsg
                    return self.humancontrol(UAV, my_ai, task)

                elif hasattr(my_ai, 'last_processed_UAV_msg') and my_ai.last_processed_UAV_msg != my_ai.UAVmsg: # 处理过，但又来了新的
                    delattr(my_ai, 'last_processed_UAV_msg')
                    print('receive new UAVmsg, start process')
                    return None

            # 与巡飞弹不同，只有一个无人机
            return self.Observe(UAV, my_ai)
            # if not hasattr(self, 'first_UAV'):
            #     self.get_first_UAV(UAV, my_ai)
            # if self.first_UAV:
            #     return self.Attack(UAV, my_ai, const.BopName.Vehicle)
            # else:
            #     return self.Observe(UAV, my_ai)
        else:
            return None

    def humancontrol(self, UVA, my_ai, task):
        if task['target_pos']:
            goal_hex = task['target_pos']
        else:
            goal_hex = my_ai.attack_point['o_main_attack']
        # action = self.stop(UAV, my_ai)
        # if action:
        #     return action

        if UVA['cur_hex'] != goal_hex:
            action = self.move(UVA, goal_hex, my_ai)
            if action:
                # my_ai.UAVmsg = {}
                return action
        else:
            my_ai.last_processed_UAV_msg = task
            print('first UAVmsg processed')

        return None

    def into_hunter(self, my_ai, operators):
        action = self.guide_shoot(operators, my_ai)
        if action:
            return action
        action = self.shoot(operators, my_ai)
        if action:
            return action

        if operators['obj_id'] not in my_ai.controllable_ops:
            return None
        if operators['obj_id'] in my_ai.huntermove.keys():
            msg_body = my_ai.huntermove[operators['obj_id']]
            if len(msg_body["hexs"]) > 1:
                if operators['cur_hex'] == msg_body["hexs"][0]:
                    target_point = msg_body["hexs"][1]
                    action = self.move(operators, target_point, my_ai, number=1)
                    if action:
                        next_hex = action['move_path'][0]
                        msg_body["hexs"][0] = next_hex
                        if msg_body["hexs"][0] == msg_body["hexs"][1]:
                            msg_body["hexs"] = msg_body["hexs"][1:]
                        route = msg_body["hexs"]
                        # my_ai.huntermove = {}
                        return action
            else:
                del my_ai.huntermove[operators['obj_id']]
        return None

    def ControlPointAttack(self, my_ai):
        # todo 引导射击没加，加步兵的引导射击
        UAV = self.get_bop(my_ai)
        if UAV:
            # 与巡飞弹不同，只有一个无人机
            return self.Attack(UAV, my_ai)
            # if not hasattr(self, 'first_UAV'):
            #     self.get_first_UAV(UAV, my_ai)
            # if self.first_UAV:
            #     return self.Attack(UAV, my_ai, const.BopName.Vehicle)
            # else:
            #     return self.Observe(UAV, my_ai)
        else:
            return None

    def Attack(self, UAV, my_ai):
        action = self.trace_guide(UAV, my_ai, sub_type=0)
        # 防止无人机奔向错误坦克的方法有点简单粗暴，没判断当前追踪坦克的id
        if action == "stay_still":
            return None
        elif action:
            return action

        if common.can_move(UAV, my_ai):
            attack_point = self.get_observe_point(UAV, my_ai)   # 无人机攻击点，具有随机性
            if com.get_distance(UAV['cur_hex'], attack_point) <= 3:
                return self.move(UAV, attack_point, my_ai, number=1)  # 巡航，发现敌方战车则射击
            else:

                return self.move(UAV, attack_point, my_ai, number=4)

        return list()

    def Observe(self, UAV, my_ai):
        if not hasattr(self, 'middle_point_crusier'):
            self.middle_point_crusier = 1

        action = self.trace_guide(UAV, my_ai, [0,1])  # subtype: 0_坦克, 1_战车,4_无人战车
        if action == "stay_still":
            self.middle_point_crusier = 0
            return None
        elif action:
            self.middle_point_crusier = 0
            return action
        if self.middle_point_crusier == 1:
        # if UAV['alive_remain_time'] < 150 or my_ai.time > 1650:
        #     action = self.trace_shoot(UAV, my_ai)
        #     if action:
        #         return action
            if not hasattr(self, 'middle_poiont1'):
                self.middle_poiont1 = int(self.get_first_attack_point1(UAV, my_ai))
            if not hasattr(self, 'middle_poiont2'):
                self.middle_poiont2 = int(self.get_first_attack_point2(UAV, my_ai))
            if not hasattr(self, 'middle_poiont3'):
                self.middle_poiont3 = int(self.get_first_attack_point3(UAV, my_ai))

            if UAV['cur_hex'] == self.middle_poiont1:
                self.through_mark_point = 1
            if UAV['cur_hex'] == self.middle_poiont2:
                self.through_mark_point = 2
            if UAV['cur_hex'] == self.middle_poiont3:
                self.through_mark_point = 3
            if UAV['cur_hex'] == my_ai.attack_point['e_main_attack']:
                self.through_mark_point = 4

            if common.can_move(UAV, my_ai):
                if self.through_mark_point == 0: # 尚未经过主夺控点右上角巡逻点
                    if com.get_distance(UAV['cur_hex'], self.middle_poiont1) <= 5:
                        return self.move(UAV, self.middle_poiont1, my_ai, number=1)
                    else:
                        return self.move(UAV, self.middle_poiont1, my_ai, number=1)
                elif self.through_mark_point == 1: # 尚未经过主夺控点下角巡逻点
                    if com.get_distance(UAV['cur_hex'], self.middle_poiont2) <= 5:
                        return self.move(UAV, self.middle_poiont2, my_ai, number=1)
                    else:
                        return self.move(UAV, self.middle_poiont2, my_ai, number=1)
                elif self.through_mark_point == 2: # 尚未经过主夺控点左角巡逻点
                    if com.get_distance(UAV['cur_hex'], self.middle_poiont3) <= 5:
                        return self.move(UAV, self.middle_poiont3, my_ai, number=1)
                    else:
                        return self.move(UAV, self.middle_poiont3, my_ai, number=1)
                elif self.through_mark_point == 3: # 尚未经过主夺控点
                    if com.get_distance(UAV['cur_hex'], my_ai.attack_point['e_main_attack']) <= 5:
                        return self.move(UAV, my_ai.attack_point['e_main_attack'], my_ai, number=1)
                    else:
                        return self.move(UAV, my_ai.attack_point['e_main_attack'], my_ai, number=1)
                elif self.through_mark_point == 4:  # 已回主夺控点
                    observe_point = self.get_observe_point(UAV, my_ai)
                    if com.get_distance(UAV['cur_hex'], observe_point) <= 3:
                        return self.move(UAV, observe_point, my_ai, number=1)  # 1格1格走
                    else:
                        return self.move(UAV, observe_point, my_ai, number=1)

            return list()


    def Gathering(self, my_ai, city_coord=None):
        missile = self.get_bop(my_ai)
        if missile:
            if common.can_move(missile, my_ai):
                attack_point = my_ai.attack_point['o_main_attack']
                if com.get_distance(missile['cur_hex'], attack_point) <= 3:
                    return self.move(missile, attack_point, my_ai, number=1)  # 巡航，发现敌方战车则射击
                else:
                    return self.move(missile, attack_point, my_ai, number=4)

            return list()

    def DTFarAttack(self, my_ai, action_bops):
        return self.MoveAttack(my_ai)

    def DTMiddleFarAttack(self, my_ai, action_bops):
        # missile = self.get_bop(ai_group)
        # if missile:
        #     return self.Observe(missile, ai_group)
        return self.MoveAttack(my_ai)

    def DT2FarAttack(self, my_ai, action_bops):
        missile = self.get_bop(my_ai)
        if missile:
            return self.Attack(missile, my_ai, const.BopName.Vehicle)

    def DT2MiddleFarAttack(self, my_ai, action_bops):
        # missile = self.get_bop(ai_group)
        # if missile:
        #     return self.Observe(missile, ai_group)
        return self.MoveAttack(my_ai)

    def FarAttack(self, my_ai, action_bops):
        # missile = self.get_bop(ai_group)
        # if missile:
        #     return self.Attack(missile, ai_group, const.BopName.Vehicle)
        return self.MoveAttack(my_ai)

    def MiddleFarAttack(self, my_ai, action_bops):
        # missile = self.get_bop(ai_group)
        # if missile:
        #     return self.Observe(missile, ai_group)
        return self.MoveAttack(my_ai)

    def OccupyingMain(self, my_ai, action_bops):
        missile = self.get_bop(my_ai)
        if missile:
            return self.Attack(missile, my_ai, const.BopName.Soldier)

    def OccupyingSecond(self, my_ai, action_bops):
        missile = self.get_bop(my_ai)
        if missile:
            return self.Attack(missile, my_ai, const.BopName.Soldier)

    def HRMainDefense(self, my_ai, action_bops):  # todo 红方无人机第一阶段动作
        # missile = self.get_bop(ai_group)
        # if missile:
        #     return self.Attack(missile, ai_group, const.BopName.Vehicle)
        # print('\nenter Blue UAV at {}sec'.format(my_ai.observation['time']['cur_step']))

        return self.MoveAttack(my_ai)

    def HROccupying(self, my_ai, action_bops):
        # missile = self.get_bop(ai_group)
        # if missile:
        #     return self.Observe(missile, ai_group)
        # print('\nenter Blue UAV at {}sec'.format(my_ai.observation['time']['cur_step']))
        return self.MoveAttack(my_ai)

    def HRProtect(self, my_ai, action_bops):
        # print('\nenter Blue UAV at {}sec'.format(my_ai.observation['time']['cur_step']))
        return self.MoveAttack(my_ai)


class BlueUnmannedVehicle(UnmannedVehicle):

    def __init__(self, bop, serial_number=0, group=0):
        super(BlueUnmannedVehicle, self).__init__()
        assert self.sub_type == bop['sub_type']
        self.obj_id = bop['obj_id']
        self.serial_number = serial_number
        self.group = group
        self.get_first_attack_points = 0
        self.caninto = 0
        self.move_point = -1
        self.call_guide = []

    def get_first_attack_point(self, unmanned, my_ai, main_dis=[8,12], bop_dis=[2, 6]):
        pos_start = my_ai.hex_cache.get_circle(unmanned['cur_hex'], bop_dis[0], bop_dis[1])
        pos_main = my_ai.hex_cache.get_circle(my_ai.attack_point['o_main_attack'], main_dis[0], main_dis[1])
        circle = list(set(pos_start) & set(pos_main))
        if not circle:
            circle = pos_main
        ai = my_ai
        bop = unmanned
        be_see_type = const.BopType.Vehicle
        pos_tuple = circle
        center_int4 = my_ai.attack_point['e_main_attack']
        observe_point_dis = 0
        top_num = const.top_num
        select = const.select
        beta = const.beta
        kwargs = {'observed_point': 0,
                'observed_main': 1,
                  'maneuver_time': .3,
                  'maneuver_time_main': .8,
                  'hide_cond': 0,
                  'stack': 1,
                  'replay_be_attacked_ability': 1,
                  'replay_observe_ability' : .5}

        unmanned_end_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                              top_num,
                                              select, beta, **kwargs)
        return unmanned_end_int4
        #self.first_attack_point = unmanned_end_int4
        #print("无人战车攻击点为：", self.first_attack_point)

    def get_second_attack_point(self, unmanned, my_ai):
        pos_start = my_ai.hex_cache.get_circle(unmanned['cur_hex'], 0, 2)
        ai = my_ai
        bop = unmanned
        be_see_type = const.BopType.Vehicle
        pos_tuple = pos_start
        center_int4 = my_ai.attack_point['o_main_attack']
        observe_point_dis = 0
        top_num = const.top_num
        select = const.select
        beta = const.beta
        kwargs = {'observed_ability': 2,
                  'maneuver_time': 0.4,
                  'maneuver_time_main': 0.1,
                  'hide_cond': 5,
                  'stack': 1,
                  'shoot_ability': 0,
                  'be_shoot_ability': 3,
                  'observe_enemy_ability': 1.5}

        unmanned_end_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                                  top_num, select, beta, **kwargs)
        #print("无人战车第二攻击点为：", unmanned_end_int4)
        return unmanned_end_int4

    def get_DT_attack_point(self, unmanned, my_ai, main_dis=[18, 25], bop_dis=[11, 12]):
        pos_start = my_ai.hex_cache.get_circle(unmanned['cur_hex'], bop_dis[0], bop_dis[1])
        pos_main = my_ai.hex_cache.get_circle(my_ai.attack_point['o_main_attack'], main_dis[0], main_dis[1])
        circle = list(set(pos_start) & set(pos_main))
        if not circle:
            circle = pos_main
        ai = my_ai
        bop = unmanned
        be_see_type = const.BopType.Vehicle
        pos_tuple = circle
        center_int4 = my_ai.attack_point['e_main_attack']
        observe_point_dis = 0
        top_num = const.top_num
        select = const.select
        beta = const.beta

        kwargs = {'observed_ability': 1,
                  'observed_city': 1,
                  'maneuver_time': 1.5,
                  'maneuver_time_main': .5,
                  'hide_cond': 2,
                  'stack': 1,
                  'shoot_ability': 0,
                  'be_shoot_ability': 0,
                  'observe_enemy_ability': 0,
                  'observe_enemy_time': 0,
                  'be_shoot_ability_time': 0
                  }

        unmanned_end_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                                  top_num, select, beta, **kwargs)
        print("DT无人战车第一攻击点为：", unmanned_end_int4)
        return unmanned_end_int4

    def get_DT2_attack_point(self, unmanned, my_ai, main_dis=[18,25], bop_dis=[11, 12]):
        pos_start = my_ai.hex_cache.get_circle(unmanned['cur_hex'], bop_dis[0], bop_dis[1])
        pos_main = my_ai.hex_cache.get_circle(my_ai.attack_point['o_main_attack'], main_dis[0], main_dis[1])
        circle = list(set(pos_start) & set(pos_main))
        if not circle:
            circle = pos_main
        ai = my_ai
        bop = unmanned
        be_see_type = const.BopType.Vehicle
        pos_tuple = circle
        center_int4 = my_ai.attack_point['e_main_attack']
        observe_point_dis = 0
        top_num = const.top_num
        select = const.select
        beta = const.beta
        kwargs = {'observed_city': 2,
                  'maneuver_time': 1,
                  'maneuver_time_main': .5,
                  'hide_cond': 1.5,
                  'stack': 0,
                  'shoot_ability': 0,
                  'be_shoot_ability': 4,
                  'observe_enemy_ability': 3}

        unmanned_end_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                              top_num,
                                              select, beta, **kwargs)
        print("无人战车第二攻击点为：", unmanned_end_int4)
        return unmanned_end_int4

    def get_protect_point(self, unmanned, my_ai):
        pos_start = my_ai.hex_cache.get_circle(unmanned['cur_hex'], 0, 1)

        ai = my_ai
        bop = unmanned
        be_see_type = const.BopType.Vehicle
        pos_tuple = pos_start
        center_int4 = my_ai.attack_point['e_main_attack']
        observe_point_dis = 0
        top_num = const.top_num
        select = const.select
        beta = const.beta
        kwargs = {'observed_second': -0.7,
                  'hide_cond': 1,
                  'stack': 0.5,
                  'be_shoot_ability': 1}

        unmanned_end_int4 = util.select_key_point(ai, bop, be_see_type, pos_tuple, center_int4, observe_point_dis,
                                                  top_num,
                                                  select, beta, **kwargs)
        print("无人战车保卫点为：", unmanned_end_int4)
        return unmanned_end_int4

    def DTMiddleFarAttack(self, my_ai, action_bops):
        return self.DTmiddlefarattack(my_ai, action_bops)

    def DT2MiddleFarAttack(self, my_ai, action_bops):
        return self.DTmiddlefarattack(my_ai, action_bops)

    def MiddleFarAttack(self, my_ai, action_bops):
        unmanned = self.get_bop(my_ai)
        if unmanned:
            # if not hasattr(self, 'second_attack_point'):
            #     self.get_second_attack_point(unmanned, ai_group)

            # 无人战车能够射击时立即射击， 优先引导射击
            action = self.guide_shoot(unmanned, my_ai)
            if action:
                return action
            action = self.shoot(unmanned, my_ai)
            if action:
                return action



            if self.see_enemy(unmanned):# and self.can_move(unmanned, ai_group):
                be_shoot_ability = my_ai.enemy_predict.be_attacked_ability(unmanned, [unmanned['cur_hex']], my_ai)
                if be_shoot_ability < 0.6:
                    ubops = common.get_see_enemy(unmanned, my_ai.enemy_bops)
                    for ubop in ubops:
                        if ubop['type'] == const.BopType.Vehicle:
                            self.call_guide = [ubop for ubop in ubops if ubop['type'] == const.BopType.Vehicle]
                            action = self.stop(unmanned, my_ai)
                            if action:
                                return action
                else:
                    action = self.move_hide(unmanned, my_ai)
                    if action:
                        return action
            else:
                self.call_guide = []

            if not self.see_enemy(unmanned) and self.can_move(unmanned, my_ai) and self.wait_time <= 0:
                second_attack_point = self.get_observe_point(unmanned, my_ai, dis=4)
                if second_attack_point == unmanned['cur_hex']:
                    self.wait_time = 20
                kwargs = {'beta': 1.5,
                          'hide_cond': 0.3,
                          'shoot_ability': 0,
                          'be_shoot_ability': 1,
                          'be_shoot_ability_aircraft': 0,
                          'observe_enemy_ability': 0,
                          'be_observed_enemy_ability': 0.5}
                action = self.hide_move(unmanned, second_attack_point, my_ai, danger_stop=True, danger_value=0.3,
                                        **kwargs)
                if action:
                    return action
                else:
                    self.wait_time = 20
            action = self.hide(unmanned, my_ai)
            if action:
                return action

            self.wait_time -= 1
        return list()

    def DTmiddlefarattack(self, my_ai, action_bops):
        unmanned = self.get_bop(my_ai)
        if unmanned:
            # if not hasattr(self, 'second_attack_point'):
            #     self.get_second_attack_point(unmanned, ai_group)

            # 无人战车能够射击时立即射击， 优先引导射击
            action = self.guide_shoot(unmanned, my_ai)
            if action:
                return action
            action = self.shoot(unmanned, my_ai)
            if action:
                return action

            if self.see_enemy(unmanned):
                be_shoot_ability = my_ai.enemy_predict.be_attacked_ability(unmanned, [unmanned['cur_hex']], my_ai)
                if be_shoot_ability < 0.5:
                    ubops = common.get_see_enemy(unmanned, my_ai.enemy_bops)
                    for ubop in ubops:
                        if ubop['type'] == const.BopType.Vehicle:
                            self.call_guide = [ubop for ubop in ubops if ubop['type'] == const.BopType.Vehicle]
                            action = self.stop(unmanned, my_ai)
                            if action:
                                return action
                else:
                    action = self.move_hide(unmanned, my_ai)
                    if action:
                        return action
            else:
                self.call_guide = []

            if not self.see_enemy(unmanned) and self.can_move(unmanned, my_ai) and self.wait_time <= 0:
                second_attack_point = self.get_second_attack_point(unmanned, my_ai)
                if second_attack_point == unmanned['cur_hex']:
                    self.wait_time = 80
                kwargs = {'beta': 3,
                          'hide_cond': 0.3,
                          'shoot_ability': 0,
                          'be_shoot_ability': 1,
                          'be_shoot_ability_aircraft': 0,
                          'observe_enemy_ability': 0,
                          'be_observed_enemy_ability': 0.5}
                action = self.hide_move(unmanned, second_attack_point, my_ai, danger_stop=True, danger_value=0.3, **kwargs)
                if action:
                    return action
                else:
                    self.wait_time = 40
            action = self.hide(unmanned, my_ai)
            if action:
                return action
            self.wait_time -= 1
        return list()

    def FarAttack(self, my_ai, action_bops):
        return self.MoveAttack(my_ai)

    def DTFarAttack(self, my_ai, action_bops):
        unmanned = self.get_bop(my_ai)
        if unmanned:
            if not hasattr(self, 'first_attack_point'):
                self.first_attack_point = self.get_DT_attack_point(unmanned, my_ai, main_dis=[13, 20], bop_dis=[0, 18])

            # 无人战车能够射击时立即射击， 优先引导射击
            action = self.guide_shoot(unmanned, my_ai)
            if action:
                return action
            action = self.shoot(unmanned, my_ai)
            if action:
                return action

            if self.see_enemy(unmanned):  # and self.can_move(unmanned, ai_group):
                be_shoot_ability = my_ai.enemy_predict.be_attacked_ability(unmanned, [unmanned['cur_hex']], my_ai)
                if be_shoot_ability < 0.6:
                    ubops = common.get_see_enemy(unmanned, my_ai.enemy_bops)
                    for ubop in ubops:
                        if ubop['type'] == const.BopType.Vehicle and 0 < ubop['move_to_stop_remain_time'] < 75:
                            self.call_guide = [ubop for ubop in ubops if ubop['type'] == const.BopType.Vehicle]
                            action = self.stop(unmanned, my_ai)
                            if action:
                                return action
                else:
                    action = self.move_hide(unmanned, my_ai)
                    if action:
                        return action
            else:
                self.call_guide = []

            if unmanned['cur_hex'] != self.first_attack_point:
                action = self.move(unmanned, self.first_attack_point, my_ai)
                if action:
                    return action

            action = self.hide(unmanned, my_ai)
            if action:
                return action
        return None

    def DT2FarAttack(self, my_ai, action_bops):
        unmanned = self.get_bop(my_ai)
        if unmanned:
            if not hasattr(self, 'first_attack_point1'):
                self.first_move = True
                self.first_attack_point1 = self.get_DT2_attack_point(unmanned, my_ai, main_dis=[13,13], bop_dis=[6, 6])

            action = self.guide_shoot(unmanned, my_ai)
            if action:
                return action
            action = self.shoot(unmanned, my_ai)
            if action:
                return action

            if self.see_enemy(unmanned):# and self.can_move(unmanned, ai_group):
                be_shoot_ability = my_ai.enemy_predict.be_attacked_ability(unmanned, [unmanned['cur_hex']], my_ai)
                if be_shoot_ability < 0.6:
                    ubops = common.get_see_enemy(unmanned, my_ai.enemy_bops)
                    for ubop in ubops:
                        if ubop['type'] == const.BopType.Vehicle:
                            self.call_guide = [ubop for ubop in ubops if ubop['type'] == const.BopType.Vehicle]
                            action = self.stop(unmanned, my_ai)
                            if action:
                                return action
                else:
                    action = self.move_hide(unmanned, my_ai)
                    if action:
                        return action
            else:
                self.call_guide = []

            if self.first_move:
                if unmanned['cur_hex'] != self.first_attack_point1:
                    action = self.move(unmanned, self.first_attack_point1, my_ai)
                    if action:
                        self.first_move = False
                        return action

        else:
            return list()

    def HRMainDefense(self, my_ai, action_bops):
        return self.newpolicy(my_ai)
        if my_ai.time > 500:
            return self.HROccupying(my_ai,action_bops)
        unmanned = self.get_bop(my_ai)
        if unmanned:
            if not hasattr(self, 'first_move'):
                first_move = 5230
                if unmanned["obj_id"] == 7:
                    first_move = 5222
                if (unmanned['cur_hex'] != first_move) and (unmanned["obj_id"] == 7 or unmanned["obj_id"] == 8):
                    action = self.move(unmanned, first_move, my_ai)
                    if action:
                        self.first_move = first_move
                        return action

            action = self.fork(unmanned, my_ai)
            if action:
                return action

            # if not hasattr(self, 'hide_point'):
            #     self.hide_point = self.find_hide_point(unmanned, my_ai)
            #
            # #print("hide_point=",self.hide_point)
            #
            # if unmanned['cur_hex'] != self.hide_point:
            #     action = self.move(unmanned, self.hide_point, my_ai)
            #     if action:
            #         return action

            # 无人战车能够射击时立即射击， 优先引导射击
            action = self.guide_shoot(unmanned, my_ai)
            if action:
                return action
            action = self.shoot(unmanned, my_ai)
            if action:
                return action

            action = self.hide(unmanned, my_ai)
            if action:
                return action
        return list()

    def HROccupying(self, my_ai, action_bops):
        return self.newpolicy(my_ai)
        # if my_ai.time > 800:
        #     return self.HRProtect(my_ai, action_bops)
        unmanned = self.get_bop(my_ai)
        if unmanned:
            if not hasattr(self, 'second_move'):
                second_move = 0
                if unmanned["obj_id"] == 7:
                    second_move = 4418
                elif unmanned["obj_id"] == 8:
                    second_move = 4731
                elif my_ai.jiejuunmanned == 0:
                    second_move = 4722
                    my_ai.jiejuunmanned = 1
                elif my_ai.jiejuunmanned == 1:
                    second_move = 4724
                    my_ai.jiejuunmanned = 2
                elif my_ai.jiejuunmanned == 2:
                    second_move = 4736
                    my_ai.jiejuunmanned = 3
                elif my_ai.jiejuunmanned == 3:
                    second_move = 4641
                if(second_move != 0) and (unmanned['cur_hex'] != second_move):
                    action = self.move(unmanned, second_move, my_ai)
                    if action:
                        self.second_move = second_move
                        return action

            # 无人战车能够射击时立即射击， 优先引导射击
            action = self.guide_shoot(unmanned, my_ai)
            if action:
                return action
            action = self.shoot(unmanned, my_ai)
            if action:
                return action

            # if not hasattr(self, 'second_hide_point'):
            #     self.second_hide_point = self.find_hide_point(unmanned, my_ai)
            #
            #
            # #print("hide_point=",self.hide_point)
            #
            # if unmanned['cur_hex'] != self.second_hide_point:
            #     action = self.move(unmanned, self.second_hide_point, my_ai)
            #     if action:
            #         return action

            action = self.hide(unmanned, my_ai)
            if action:
                return action
        return list()

    def HRProtect(self, my_ai, action_bops):
        return self.newpolicy(my_ai)
        unmanned = self.get_bop(my_ai)
        if unmanned:
            action = self.guide_shoot(unmanned, my_ai)
            if action:
                return action
            action = self.shoot(unmanned, my_ai)
            if action:
                return action

            # if self.see_enemy(unmanned):
            #     be_shoot_ability = my_ai.enemy_predict.be_attacked_ability(unmanned, [unmanned['cur_hex']], my_ai)
            #     if be_shoot_ability < 0.5:
            #         ubops = common.get_see_enemy(unmanned, my_ai.enemy_bops)
            #         for ubop in ubops:
            #             if ubop['type'] == const.BopType.Vehicle:
            #                 self.call_guide = [ubop for ubop in ubops if ubop['type'] == const.BopType.Vehicle]
            #                 action = self.stop(unmanned, my_ai)
            #                 if action:
            #                     return action
            #     else:
            #         action = self.move_hide(unmanned, my_ai)
            #         if action:
            #             return action
            # else:
            #     self.call_guide = []

            if not self.see_enemy(unmanned) and self.can_move(unmanned, my_ai) and self.wait_time <= 0 and self.get_first_attack_points == 0:
                second_attack_point = self.get_first_attack_point(unmanned, my_ai)
                self.get_first_attack_points = 1
                if second_attack_point == unmanned['cur_hex']:
                    self.wait_time = 80
                kwargs = {'beta': 3,
                          'hide_cond': 0.3,
                          'shoot_ability': 0,
                          'be_shoot_ability': 1,
                          'be_shoot_ability_aircraft': 0,
                          'observe_enemy_ability': 0,
                          'be_observed_enemy_ability': 0.5}
                action = self.hide_move(unmanned, second_attack_point, my_ai, danger_stop=True, danger_value=0.3,
                                        **kwargs)
                if action:
                    return action
                else:
                    self.wait_time = 40
            action = self.hide(unmanned, my_ai)
            if action:
                return action
            self.wait_time -= 1
        return list()

    def newpolicy(self,my_ai):
        unmanned = self.get_bop(my_ai)
        if unmanned:
            action = self.guide_shoot(unmanned, my_ai)
            if action:
                return action
            action = self.shoot(unmanned, my_ai)
            if action:
                return action
            action = self.occupy(unmanned,my_ai)
            if action:
                return action
            bop_id = unmanned["obj_id"]
            if (bop_id == 78):
                if self.caninto == 1:
                    return self.into_hunter(my_ai, unmanned)
                if unmanned['cur_hex'] == 4424 and self.move_point == -1:
                    self.move_point = 3017
                    action = self.move(unmanned, self.move_point, my_ai)
                    action = {"actor": my_ai.seat,
                              'obj_id': unmanned['obj_id'],
                              'type': const.ActionType.Move,
                              'move_path': [4424, 4323, 4322, 4222, 4221, 4220, 4119, 4118, 4018, 3917, 3817, 3716, 3616, 3515, 3415, 3314, 3215, 3114, 3015, 3016, 3017],}
                    if action:
                        self.caninto = 1
                        return action

            if (bop_id == my_ai.uveid_400):
                if self.caninto == 1:
                    return self.into_hunter(my_ai, unmanned)
                if unmanned['cur_hex'] == 4424 and self.move_point == -1:
                    self.move_point = 3527
                if unmanned['cur_hex'] != self.move_point:
                    action = self.move(unmanned, self.move_point, my_ai, number=1)
                    if action:
                        return action
                if unmanned['cur_hex'] == 3527:
                    self.move_point = 3516
                if unmanned['cur_hex'] == 3516 :
                    self.caninto = 1

            if (bop_id == 84):
                if self.caninto == 1:
                    return self.into_hunter(my_ai, unmanned)
                if unmanned['cur_hex'] == 4425 and self.move_point == -1:
                    self.move_point = 4528
                if unmanned['cur_hex'] != self.move_point:
                    action = self.move(unmanned, self.move_point, my_ai, number=1)
                    if action:
                        return action
                if unmanned['cur_hex'] == 4528:
                    if unmanned['blood'] == 3:
                        action = self.fork(unmanned,my_ai)
                        if action:
                            self.move_point = 5427
                            return  action
                    else:
                        self.move_point = 5427
                if unmanned['cur_hex'] == 5427:
                    if unmanned['blood'] == 2:
                        action = self.fork(unmanned,my_ai)
                        if action:
                            self.caninto = 1
                            return  action
                    else:
                        self.caninto = 1

            if (bop_id == my_ai.uveid_401):
                if self.caninto == 1:
                    return self.into_hunter(my_ai, unmanned)
                if unmanned['cur_hex'] == 4528 and self.move_point == -1:
                    self.move_point = 4334
                if unmanned['cur_hex'] != self.move_point:
                    action = self.move(unmanned, self.move_point, my_ai,number = 1)
                    if action:
                        return action
                else:
                    self.caninto = 1

            if (bop_id == my_ai.uveid_402):
                if self.caninto == 1:
                    return self.into_hunter(my_ai, unmanned)
                if unmanned['cur_hex'] == 5427 and self.move_point == -1:
                    self.move_point = 5428
                if unmanned['cur_hex'] != self.move_point:
                    action = self.move(unmanned, self.move_point, my_ai,number = 1)
                    if action:
                        return action
                else:
                    self.caninto = 1

            # if unmanned['obj_id'] in my_ai.huntermove.keys():
            #     return self.into_hunter(my_ai, unmanned)
            # if not hasattr(self, 'first_move'):
            #     if unmanned["obj_id"] == 78:
            #         self.first_move = 3017
            #     elif unmanned["obj_id"] == 84:
            #         self.first_move = 3327
            #     elif unmanned["obj_id"] == my_ai.unveid1:
            #         self.first_move = 5428
            #     #elif unmanned['obj_id'] == my_ai.unveid2:
            #     else:
            #         self.first_move = 5427
            # if (unmanned['cur_hex'] != self.first_move) and self.caninto == 0:
            #     action = self.move(unmanned, self.first_move, my_ai ,number= 1)
            #     if action:
            #         return action
            # if unmanned['cur_hex'] == self.first_move and self.caninto == 0:
            #     action = self.hide(unmanned, my_ai)
            #     if action:
            #         self.caninto = 1
            #         return action
            # if self.caninto == 1:
            #     return self.into_hunter(my_ai, unmanned)
            # action = self.hide(unmanned, my_ai)
            # if action:
            #     return action
        return list()

    def into_hunter(self,my_ai,operators):
        self.caninto = 1
        action = self.guide_shoot(operators, my_ai)
        if action:
            return action
        action = self.shoot(operators, my_ai)
        if action:
            return action
        action = self.occupy(operators, my_ai)
        if action:
            return action
        if operators['obj_id'] not in my_ai.controllable_ops:
            return None
        if operators['obj_id'] in my_ai.huntermove.keys():
            msg_body = my_ai.huntermove[operators['obj_id']]
            if len(msg_body["hexs"]) > 1:
                if operators['cur_hex'] == msg_body["hexs"][0]:
                    target_point = msg_body["hexs"][1]
                    action = self.move(operators, target_point, my_ai, number = 1)
                    if action:
                        next_hex = action['move_path'][0]
                        msg_body["hexs"][0] = next_hex
                        if msg_body["hexs"][0] == msg_body["hexs"][1]:
                            msg_body["hexs"] = msg_body["hexs"][1:]
                        route = msg_body["hexs"]
                        #my_ai.huntermove = {}
                        return action
            else:
                del my_ai.huntermove[operators['obj_id']]
        return None


class BlueScoutVehicle(ScoutVehicle):

    def __init__(self, bop, serial_number=0, group=0):
        super(ScoutVehicle, self).__init__()
        assert self.sub_type == bop['sub_type']
        self.obj_id = bop['obj_id']
        self.serial_number = serial_number
        self.group = group

        self.near_off = False

    def HRMainDefense(self, my_ai, action_bops):    # todo 蓝方侦察战车第一阶段动作，
        ScoutVehicle = self.get_bop(my_ai)
        if ScoutVehicle:
            action = self.shoot(ScoutVehicle, my_ai)
            if action:
                return action

            if com.get_distance(ScoutVehicle['cur_hex'], 6041) <= 3:
                return self.move(ScoutVehicle, 6041, my_ai, number=1)  # 机动到右下边缘高地
            else:
                return self.move(ScoutVehicle, 6041, my_ai, number=5)


        return None

    def HROccupying(self, my_ai, action_bops):
        return self.HRMainDefense(my_ai,action_bops)

    def HRProtect(self, my_ai, action_bops):
        return self.HRMainDefense(my_ai, action_bops)