from collections import namedtuple

Transaction = namedtuple("Transaction", ["prev_state", "event", "next_state"])  ## 一次状态转换的所有要素：上一个状态--事件-->下一个状态


class FSM:
    def __init__(self, start_state):  ## context：状态机上下文
        self.start_state = start_state
        self.state_transaction_table = []  ## 常规状态转换表
        self.global_transaction_table = []  ## 全局状态转换表
        self.current_state = start_state
        self.working_state = FsmState

    def add_global_transaction(self, event, end_state):  # 全局转换，直接进入到结束状态
        if not issubclass(end_state, FsmFinalState):
            raise FsmException("The state should be FsmFinalState")
        self.global_transaction_table.append(Transaction(self.working_state, event, end_state))

    def add_transaction(self, prev_state, event, next_state):
        if issubclass(prev_state, FsmFinalState):
            raise FsmException("It's not allowed to add transaction after Final State Node")
        self.state_transaction_table.append(Transaction(prev_state, event, next_state))

    def process_event(self, event, state, my_ai):
        for transaction in self.global_transaction_table:
            if isinstance(event, transaction.event):
                self.current_state = transaction.next_state(state, my_ai)
                self.current_state.enter(my_ai)
                self.clear_transaction_table()
                return

        for transaction in self.state_transaction_table:
            # if isinstance(self.current_state, transaction.next_state) and isinstance(event, transaction.event):
            #     return

            if isinstance(self.current_state, transaction.prev_state) and isinstance(event, transaction.event):
                self.current_state.exit()
                self.current_state = transaction.next_state(state, my_ai)
                if isinstance(self.current_state, FsmFinalState):
                    self.clear_transaction_table()
                return
        # print('不需要处理的事件', event)

    def clear_transaction_table(self):
        self.global_transaction_table = []
        self.state_transaction_table = []
        self.current_state = None

    def run(self, my_ai):

        if len(self.state_transaction_table) == 0:
            return list()
        total_actions = self.current_state.enter(my_ai)
        return total_actions

    def isRunning(self):
        return self.current_state is not None

    def next_state(self, event):
        for transaction in self.global_transaction_table:
            if isinstance(event, transaction.event):
                return transaction.next_state
        for transaction in self.state_transaction_table:
            if isinstance(self.current_state, transaction.prev_state) and isinstance(event, transaction.event):
                return transaction.next_state
        return None


class FsmException(Exception):
    def __init__(self, description):
        super().__init__(description)


class FsmState:
    def __init__(self, FSM, my_ai):
        pass


    def enter(self, my_ai):
        pass

    def exit(self):
        print("{} exit".format(self.name))


class FsmFinalState:
    def enter(self, event):  ## 参数event为触发状态转换的事件, fsm则为状态所在状态机
        pass

    def exit(self, fsm):
        pass


