from .FSM import *
from multiprocessing import Process, Manager
from ..utils import common, const, util
from . import red_action_bop
from ..hexmap.hex import BoundedHex



###############################################红方状态集
class RedMoveAttack(FsmState):
    def __init__(self, FSM, my_ai):
        self.name = '红方移动并攻击阶段'
        self.action_bops = FSM.action_bops

    def enter(self, my_ai):
        total_actions = []
        for action_bop in self.action_bops:
            action = action_bop.MoveAttack(my_ai)
            if action:
                total_actions.append(action)

        return total_actions
'''红方集结阶段：
条件：比赛时间进行到1000秒以上，蓝方力量被消耗较多
行动：1.人员走到可以观察主要和次要夺控点的地方，且距离小于10
2.选择主攻点3格内，隐蔽性好的点作为集结点
3.其它棋子全部机动到集结点'''
class RedGathering(FsmState):
    def __init__(self, FSM, my_ai):
        self.name = '红方集结阶段'
        self.action_bops = FSM.action_bops
        tank = [action_bop for action_bop in FSM.action_bops if action_bop.sub_type == const.BopName.Tank][0]
        self.gathering_point = tank.get_gathering_point(my_ai)

    def enter(self, my_ai):
        total_actions = []
        for action_bop in self.action_bops:
            action = action_bop.Gathering(my_ai, self.gathering_point)
            if action:
                total_actions.append(action)

        # if total_actions:
        #     print("the time is {}, {} start, the total actions are ".format(ai_group.observation['time']['cur_step'],
        #                                                                     self.name), total_actions)
        return total_actions


'''红方夺控阶段：
条件：集结完毕
行动：1.人员原地不动，作为掩护
2.无人战车先冲锋
3.坦克机动射击
4.战车冲锋'''
class RedOccupying(FsmState):
    def __init__(self, FSM, my_ai):
        self.name = '红方夺控阶段'
        self.action_bops = FSM.action_bops

    def enter(self, my_ai):
        total_actions = []
        for action_bop in self.action_bops:
            action = action_bop.Occupying(my_ai)
            if action:
                total_actions.append(action)
        # if total_actions:
        #     print("the time is {}, {} start, the total actions are ".format(ai_group.observation['time']['cur_step'],
        #                                                                     self.name), total_actions)
        return total_actions
#############################################################


#########################################蓝方状态集
class BlueMoveAttack(FsmState):
    def __init__(self, FSM, my_ai):
        self.name = '蓝方移动攻击阶段'
        self.action_bops = FSM.action_bops

    def enter(self, my_ai):
        total_actions = []
        for action_bop in self.action_bops:
            action = action_bop.MoveAttack(my_ai)
            if action:
                total_actions.append(action)
        # if total_actions:
        #     print("the time is {}, {} start, the total actions are ".format(ai_group.observation['time']['cur_step'],
        #                                                                     self.name), total_actions)
        return total_actions


class BlueProtect(FsmState):
    def __init__(self, FSM, my_ai):
        self.name = '蓝方守卫夺控点阶段'
        self.action_bops = FSM.action_bops

    def enter(self, my_ai):
        total_actions = []
        for action_bop in self.action_bops:
            action = action_bop.Protect(my_ai)
            if action:
                total_actions.append(action)
        # if total_actions:
        #     print("the time is {}, {} start, the total actions are ".format(ai_group.observation['time']['cur_step'],
        #                                                                     self.name), total_actions)
        return total_actions


class BlueOccupying(FsmState):
    def __init__(self, FSM, my_ai):
        self.name = '蓝方夺取其它夺控点阶段'
        self.action_bops = FSM.action_bops

    def enter(self, my_ai):
        total_actions = []
        for action_bop in self.action_bops:
            action = action_bop.Occupying(my_ai)
            if action:
                total_actions.append(action)

        return total_actions

#########################################




########想定2010131194，2010141294

#红方/蓝方使用相同状态类
class HideAttack(FsmState):
    def __init__(self, FSM, my_ai):
        self.name = f'{my_ai.color}隐蔽攻击阶段'
        self.action_bops = FSM.action_bops

    def enter(self, my_ai):
        total_actions = []
        for action_bop in self.action_bops:
            action = action_bop.HideAttack(my_ai, self.action_bops)
            if action:
                total_actions.append(action)

        return total_actions


class NearAttack(FsmState):
    def __init__(self, FSM, my_ai):
        self.name =  f'{my_ai.color}近距离攻击阶段'
        self.action_bops = FSM.action_bops

    def enter(self, my_ai):
        total_actions = []
        for action_bop in self.action_bops:
            action = action_bop.NearAttack(my_ai, self.action_bops)
            if action:
                total_actions.append(action)

        return total_actions


class Occupying(FsmState):
    def __init__(self, FSM, my_ai):
        self.name =  f'{my_ai.color}夺控阶段'
        self.action_bops = FSM.action_bops


    def enter(self, my_ai):
        total_actions = []
        for action_bop in self.action_bops:
            action = action_bop.OccupyingMain(my_ai, self.action_bops)
            if action:
                total_actions.append(action)

        return total_actions


########2010211129:  # 连级山地通道夺控战斗想定

class RedFarAttack(FsmState):
    def __init__(self, FSM, my_ai):
        self.name =  '红方远距离攻击阶段'
        self.action_bops = FSM.action_bops


    def enter(self, my_ai):
        total_actions = []
        # 如果有射击动作，优先执行射击
        shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.Shoot)
        guide_shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.GuideShoot)
        shoot_ids.extend(guide_shoot_ids)

        for action_bop in self.action_bops:
            if shoot_ids:
                if action_bop.obj_id in shoot_ids:
                    action = action_bop.FarAttack(my_ai, self.action_bops)
                    if action:
                        total_actions.append(action)
            else:
                action = action_bop.FarAttack(my_ai, self.action_bops)
                if action:
                    total_actions.append(action)
        return total_actions


class RedMiddleFarAttack(FsmState):
    def __init__(self, FSM, my_ai):
        self.name =  '红方中远距离攻击阶段'
        self.action_bops = FSM.action_bops

    def enter(self, my_ai):
        total_actions = []
        # 如果有射击动作，优先执行射击
        shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.Shoot)
        guide_shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.GuideShoot)
        shoot_ids.extend(guide_shoot_ids)
        for action_bop in self.action_bops:
            if shoot_ids:
                if action_bop.obj_id in shoot_ids:
                    action = action_bop.MiddleFarAttack(my_ai, self.action_bops)
                    if action:
                        total_actions.append(action)
            else:
                action = action_bop.MiddleFarAttack(my_ai, self.action_bops)
                if action:
                    total_actions.append(action)
        return total_actions


class RedOccupyingMain(FsmState):
    def __init__(self, FSM, my_ai):
        self.name =  '红方强夺主控点阶段'
        self.action_bops = FSM.action_bops
        self.gathering_Vehicle = False

    def enter(self, my_ai):
        # 如果有射击动作，优先执行射击
        shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.Shoot)
        guide_shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.GuideShoot)
        shoot_ids.extend(guide_shoot_ids)
        total_actions = []
        # if not self.gathering_Vehicle: #集结
        #     gathering_arrive = []
        #     for action_bop in self.action_bops:
        #         if shoot_ids:
        #             if action_bop.obj_id in shoot_ids:
        #                 if action_bop.sub_type in [const.BopName.Vehicle, const.BopName.Tank]:
        #                     action = action_bop.FarGathering(ai_group)
        #                     if action:
        #                         total_actions.append(action)
        #
        #                     if action_bop.is_live(ai_group):
        #                         gathering_arrive.append(action_bop.arrive_gathering_point)
        #                     else:
        #                         gathering_arrive.append(True)
        #                 else:
        #                     action = action_bop.Gathering(ai_group)
        #                     if action:
        #                         total_actions.append(action)
        #         else:
        #             if action_bop.sub_type in [const.BopName.Vehicle, const.BopName.Tank]:
        #                 action = action_bop.FarGathering(ai_group)
        #                 if action:
        #                     total_actions.append(action)
        #
        #                 if action_bop.is_live(ai_group):
        #                     gathering_arrive.append(action_bop.arrive_gathering_point)
        #                 else:
        #                     gathering_arrive.append(True)
        #             else:
        #                 action = action_bop.Gathering(ai_group)
        #                 if action:
        #                     total_actions.append(action)
        #     if False not in gathering_arrive:
        #         self.gathering_Vehicle = True
        # else:  #夺控
        for action_bop in self.action_bops:
            if shoot_ids:
                if action_bop.obj_id in shoot_ids:
                    if action_bop.sub_type == const.BopName.Tank:
                        action = action_bop.Occupying(my_ai, self.action_bops)
                        if action:
                            total_actions.append(action)
                    else:
                        action = action_bop.OccupyingMain(my_ai, self.action_bops)
                        if action:
                            total_actions.append(action)
            else:
                if action_bop.sub_type == const.BopName.Tank:
                    action = action_bop.Occupying(my_ai, self.action_bops)
                    if action:
                        total_actions.append(action)
                else:
                    action = action_bop.OccupyingMain(my_ai, self.action_bops)
                    if action:
                        total_actions.append(action)
        return total_actions


class RedOccupyingSecond(FsmState):
    def __init__(self, FSM, my_ai):
        self.name = '红方抢夺次控点阶段'
        self.action_bops = FSM.action_bops

    def enter(self, my_ai):
        # 如果有射击动作，优先执行射击
        shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.Shoot)
        guide_shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.GuideShoot)
        shoot_ids.extend(guide_shoot_ids)
        total_actions = []
        for action_bop in self.action_bops:
            if shoot_ids:
                if action_bop.obj_id in shoot_ids:
                    action = action_bop.OccupyingSecond(my_ai, self.action_bops)
                    if action:
                        total_actions.append(action)
            else:
                action = action_bop.OccupyingSecond(my_ai, self.action_bops)
                if action:
                    total_actions.append(action)
        return total_actions


class BlueMainDefense(FsmState):
    def __init__(self, FSM, my_ai):
        self.name = '蓝方主攻点防守阶段'
        self.action_bops = FSM.action_bops

    def enter(self, my_ai):
        # 如果有射击动作，优先执行射击
        shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.Shoot)
        guide_shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.GuideShoot)
        shoot_ids.extend(guide_shoot_ids)
        total_actions = []
        for action_bop in self.action_bops:
            if shoot_ids:
                if action_bop.obj_id in shoot_ids:
                    action = action_bop.MainDefense(my_ai, self.action_bops)
                    if action:
                        total_actions.append(action)
            else:
                action = action_bop.MainDefense(my_ai, self.action_bops)
                if action:
                    total_actions.append(action)
        return total_actions


class BlueOccupyingMain(FsmState):
    def __init__(self, FSM, my_ai):
        self.name = '蓝方抢夺主攻点阶段'
        self.action_bops = FSM.action_bops

    def enter(self, my_ai):
        # 如果有射击动作，优先执行射击
        shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.Shoot)
        guide_shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.GuideShoot)
        shoot_ids.extend(guide_shoot_ids)
        total_actions = []
        for action_bop in self.action_bops:
            if shoot_ids:
                if action_bop.obj_id in shoot_ids:
                    action = action_bop.OccupyingMain(my_ai, self.action_bops)
                    if action:
                        total_actions.append(action)
            else:
                action = action_bop.OccupyingMain(my_ai, self.action_bops)
                if action:
                    total_actions.append(action)
        return total_actions

class BlueOccupyingSecond(FsmState):
    def __init__(self, FSM, my_ai):
        self.name = '蓝方抢夺次攻点阶段'
        self.action_bops = FSM.action_bops

    def enter(self, my_ai):
        # 如果有射击动作，优先执行射击
        shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.Shoot)
        guide_shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.GuideShoot)
        shoot_ids.extend(guide_shoot_ids)
        total_actions = []
        for action_bop in self.action_bops:
            if shoot_ids:
                if action_bop.obj_id in shoot_ids:
                    action = action_bop.OccupyingSecond(my_ai, self.action_bops)
                    if action:
                        total_actions.append(action)
            else:
                action = action_bop.OccupyingSecond(my_ai, self.action_bops)
                if action:
                    total_actions.append(action)
        return total_actions
    # if action_bop.sub_type == const.BopName.Vehicle and action_bop.serial_number == 1:
    #     action = action_bop.FarAttack(ai_group, self.action_bops)
    #     if action:
    #         total_actions.append(action)
    # elif action_bop.sub_type == const.BopName.Vehicle and action_bop.serial_number == 2:
    #     action = action_bop.FarAttack(ai_group, self.action_bops)
    #     if action:
    #         total_actions.append(action)
###########################################


'''########2010431153: 连级水网稻田地形遭遇战斗想定Ⅰ,53
'''
class DTRedFarAttack(FsmState):
    def __init__(self, FSM, my_ai):
        self.name =  '红方远距离攻击阶段'
        self.action_bops = FSM.action_bops


    def enter(self, my_ai):
        # 如果有射击动作，优先执行射击
        shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.Shoot)
        guide_shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.GuideShoot)
        shoot_ids.extend(guide_shoot_ids)
        total_actions = []
        for action_bop in self.action_bops:
            action_bop.produce_artillery_call(my_ai)
            if shoot_ids:
                if action_bop.obj_id in shoot_ids:
                    action = action_bop.DTFarAttack(my_ai, self.action_bops)
                    if action:
                        total_actions.append(action)
            else:
                action = action_bop.DTFarAttack(my_ai, self.action_bops)
                if action:
                    total_actions.append(action)
        return total_actions


class DTRedMiddleFarAttack(FsmState):
    def __init__(self, FSM, my_ai):
        self.name = '红方中远距离攻击阶段'
        self.action_bops = FSM.action_bops

    def enter(self, my_ai):
        # 如果有射击动作，优先执行射击
        shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.Shoot)
        guide_shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.GuideShoot)
        shoot_ids.extend(guide_shoot_ids)
        total_actions = []
        for action_bop in self.action_bops:
            action_bop.produce_artillery_call(my_ai)
            if shoot_ids:
                if action_bop.obj_id in shoot_ids:
                    action = action_bop.DTMiddleFarAttack(my_ai, self.action_bops)
                    if action:
                        total_actions.append(action)
            else:
                action = action_bop.DTMiddleFarAttack(my_ai, self.action_bops)
                if action:
                    total_actions.append(action)
        return total_actions


class DTRedOccupyingMain(FsmState):
    def __init__(self, FSM, my_ai):
        self.name =  '红方强夺主控点阶段'
        self.action_bops = FSM.action_bops
        self.gathering_Vehicle = False

        main_enemy_ability = util.city_enemy_ability(my_ai, my_ai.attack_point['o_main_attack'])
        second_enemy_ability = util.city_enemy_ability(my_ai, my_ai.attack_point['o_second_attack'])
        if main_enemy_ability <= second_enemy_ability:
            if not common.my_city(my_ai.observation['cities'], my_ai.color, coord=my_ai.attack_point['o_main_attack']):
                self.occupy_coord = my_ai.attack_point['o_main_attack']
            elif second_enemy_ability <= 1:
                self.occupy_coord = my_ai.attack_point['o_second_attack']
            else:
                self.occupy_coord = my_ai.attack_point['o_main_attack']
        else:
            self.occupy_coord = my_ai.attack_point['o_second_attack']

    def enter(self, my_ai):
        # 如果有射击动作，优先执行射击
        shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.Shoot)
        guide_shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.GuideShoot)
        shoot_ids.extend(guide_shoot_ids)
        total_actions = []
        for action_bop in self.action_bops:
            action_bop.produce_artillery_call(my_ai)
            if shoot_ids:
                if action_bop.obj_id in shoot_ids:
                    if action_bop.sub_type == const.BopName.Tank:
                        action = action_bop.Occupying(my_ai, self.action_bops)
                        if action:
                            total_actions.append(action)
                    else:
                        action = action_bop.DT_Occupying(my_ai, self.action_bops, city_coord=self.occupy_coord)
                        if action:
                            total_actions.append(action)
            else:
                if action_bop.sub_type == const.BopName.Tank:
                    action = action_bop.Occupying(my_ai, self.action_bops)
                    if action:
                        total_actions.append(action)
                else:
                    action = action_bop.DT_Occupying(my_ai, self.action_bops, city_coord=self.occupy_coord)
                    if action:
                        total_actions.append(action)
        return total_actions


class DTBlueMainDefense(FsmState):
    def __init__(self, FSM, my_ai):
        self.name = '蓝方主攻点防守阶段'
        self.action_bops = FSM.action_bops

    def enter(self, my_ai):
        # 如果有射击动作，优先执行射击
        shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.Shoot)
        guide_shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.GuideShoot)
        shoot_ids.extend(guide_shoot_ids)
        total_actions = []
        for action_bop in self.action_bops:
            action_bop.produce_artillery_call(my_ai)
            if shoot_ids:
                if action_bop.obj_id in shoot_ids:
                    action = action_bop.DTMainDefense(my_ai, self.action_bops)
                    if action:
                        total_actions.append(action)
            else:
                action = action_bop.DTMainDefense(my_ai, self.action_bops)
                if action:
                    total_actions.append(action)
        return total_actions


class DTBlueOccupyingMain(FsmState):
    def __init__(self, FSM, my_ai):
        self.name = '蓝方抢夺主攻点阶段'
        self.action_bops = FSM.action_bops

    def enter(self, my_ai):
        # 如果有射击动作，优先执行射击
        shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.Shoot)
        guide_shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.GuideShoot)
        shoot_ids.extend(guide_shoot_ids)
        total_actions = []
        for action_bop in self.action_bops:
            action_bop.produce_artillery_call(my_ai)
            if shoot_ids:
                if action_bop.obj_id in shoot_ids:
                    action = action_bop.OccupyingMain(my_ai, self.action_bops)
                    if action:
                        total_actions.append(action)
            else:
                action = action_bop.OccupyingMain(my_ai, self.action_bops)
                if action:
                    total_actions.append(action)
        return total_actions


class DTBlueOccupyingSecond(FsmState):
    def __init__(self, FSM, my_ai):
        self.name = '蓝方抢夺次攻点阶段'
        self.action_bops = FSM.action_bops

    def enter(self, my_ai):
        # 如果有射击动作，优先执行射击
        shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.Shoot)
        guide_shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.GuideShoot)
        shoot_ids.extend(guide_shoot_ids)
        total_actions = []
        for action_bop in self.action_bops:
            action_bop.produce_artillery_call(my_ai)
            if shoot_ids:
                if action_bop.obj_id in shoot_ids:
                    action = action_bop.OccupyingSecond(my_ai, self.action_bops)
                    if action:
                        total_actions.append(action)
            else:
                action = action_bop.OccupyingSecond(my_ai, self.action_bops)
                if action:
                    total_actions.append(action)
        return total_actions


'''########
2010441253: 连级水网稻田地形遭遇战斗想定Ⅱ,53
'''
class DT2RedFarAttack(FsmState):
    def __init__(self, FSM, my_ai):
        self.name =  '红方远距离攻击阶段'
        self.action_bops = FSM.action_bops


    def enter(self, my_ai):
        # 如果有射击动作，优先执行射击
        shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.Shoot)
        guide_shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.GuideShoot)
        shoot_ids.extend(guide_shoot_ids)
        total_actions = []
        for action_bop in self.action_bops:
            if shoot_ids:
                if action_bop.obj_id in shoot_ids:
                    action = action_bop.DT2FarAttack(my_ai, self.action_bops)
                    if action:
                        total_actions.append(action)
            else:
                action = action_bop.DT2FarAttack(my_ai, self.action_bops)
                if action:
                    total_actions.append(action)
        return total_actions


class DT2RedMiddleFarAttack(FsmState):
    def __init__(self, FSM, my_ai):
        self.name =  '红方中远距离攻击阶段'
        self.action_bops = FSM.action_bops

    def enter(self, my_ai):
        # 如果有射击动作，优先执行射击
        shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.Shoot)
        guide_shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.GuideShoot)
        shoot_ids.extend(guide_shoot_ids)
        total_actions = []
        for action_bop in self.action_bops:
            if shoot_ids:
                if action_bop.obj_id in shoot_ids:
                    action = action_bop.DT2MiddleFarAttack(my_ai, self.action_bops)
                    if action:
                        total_actions.append(action)
            else:
                action = action_bop.DT2MiddleFarAttack(my_ai, self.action_bops)
                if action:
                    total_actions.append(action)
        return total_actions


class DT2RedOccupyingMain(FsmState):
    def __init__(self, FSM, my_ai):
        self.name =  '红方强夺主控点阶段'
        self.action_bops = FSM.action_bops
        self.gathering_Vehicle = False

        main_enemy_ability = util.city_enemy_ability(my_ai, my_ai.attack_point['o_main_attack'])
        second_enemy_ability = util.city_enemy_ability(my_ai, my_ai.attack_point['o_second_attack'])
        # print(main_enemy_ability, second_enemy_ability, main_enemy_ability <= second_enemy_ability)
        if main_enemy_ability <= second_enemy_ability:
            if not common.my_city(my_ai.observation['cities'], my_ai.color, coord=my_ai.attack_point['o_main_attack']):
                self.occupy_coord = my_ai.attack_point['o_main_attack']
            elif second_enemy_ability <= 1:
                self.occupy_coord = my_ai.attack_point['o_second_attack']
            else:
                self.occupy_coord = my_ai.attack_point['o_main_attack']
        else:
            self.occupy_coord = my_ai.attack_point['o_second_attack']


    def enter(self, my_ai):
        # 如果有射击动作，优先执行射击
        shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.Shoot)
        guide_shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.GuideShoot)
        shoot_ids.extend(guide_shoot_ids)
        total_actions = []
        if not self.gathering_Vehicle: #集结
            gathering_arrive = []
            for action_bop in self.action_bops:
                if action_bop.sub_type in [const.BopName.Vehicle, const.BopName.Tank,const.BopName.ScoutVehicle]:
                    action = action_bop.FarGathering(my_ai, city_coord=self.occupy_coord)
                    if action:
                        total_actions.append(action)

                    if action_bop.is_live(my_ai):
                        gathering_arrive.append(action_bop.arrive_gathering_point)
                    else:
                        gathering_arrive.append(True)
                elif action_bop.sub_type in [const.BopName.Soldier]:
                    action = action_bop.DT2FarAttack(my_ai, self.action_bops)
                    if action:
                        total_actions.append(action)
                else:
                    action = action_bop.Gathering(my_ai, city_coord=self.occupy_coord)
                    if action:
                        total_actions.append(action)
            if True not in gathering_arrive:
                self.gathering_Vehicle = True
        else:  #夺控
            for action_bop in self.action_bops:
                if shoot_ids:
                    if action_bop.obj_id in shoot_ids:
                        if action_bop.sub_type == const.BopName.Tank:
                            action = action_bop.Occupying(my_ai, self.action_bops)
                            if action:
                                total_actions.append(action)
                        elif action_bop.sub_type in [const.BopName.Soldier]:
                            action = action_bop.DT2FarAttack(my_ai, self.action_bops)
                            if action:
                                total_actions.append(action)
                        else:
                            action = action_bop.DT_Occupying(my_ai, self.action_bops, city_coord=self.occupy_coord)
                            if action:
                                total_actions.append(action)
                else:
                    if action_bop.sub_type == const.BopName.Tank:
                        action = action_bop.Occupying(my_ai, self.action_bops)
                        if action:
                            total_actions.append(action)
                    elif action_bop.sub_type in [const.BopName.Soldier]:
                        action = action_bop.DT2FarAttack(my_ai, self.action_bops)
                        if action:
                            total_actions.append(action)
                    else:
                        action = action_bop.DT_Occupying(my_ai, self.action_bops, city_coord=self.occupy_coord)
                        if action:
                            total_actions.append(action)

        return total_actions


class DT2BlueMainDefense(FsmState):
    def __init__(self, FSM, my_ai):
        self.name = '蓝方主攻点防守阶段'
        self.action_bops = FSM.action_bops

    def enter(self, my_ai):
        # 如果有射击动作，优先执行射击
        shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.Shoot)
        guide_shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.GuideShoot)
        shoot_ids.extend(guide_shoot_ids)
        total_actions = []
        for action_bop in self.action_bops:
            if shoot_ids:
                if action_bop.obj_id in shoot_ids:
                    action = action_bop.DTMainDefense(my_ai, self.action_bops)
                    if action:
                        total_actions.append(action)
            else:
                action = action_bop.DTMainDefense(my_ai, self.action_bops)
                if action:
                    total_actions.append(action)
        return total_actions


class DT2BlueOccupyingMain(FsmState):
    def __init__(self, FSM, my_ai):
        self.name = '蓝方抢夺主攻点阶段'
        self.action_bops = FSM.action_bops

    def enter(self, my_ai):
        # 如果有射击动作，优先执行射击
        shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.Shoot)
        guide_shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.GuideShoot)
        shoot_ids.extend(guide_shoot_ids)
        total_actions = []
        for action_bop in self.action_bops:
            if shoot_ids:
                if action_bop.obj_id in shoot_ids:
                    action = action_bop.OccupyingMain(my_ai, self.action_bops)
                    if action:
                        total_actions.append(action)
            else:
                action = action_bop.OccupyingMain(my_ai, self.action_bops)
                if action:
                    total_actions.append(action)
        return total_actions

class DT2BlueOccupyingSecond(FsmState):
    def __init__(self, FSM, my_ai):
        self.name = '蓝方抢夺次攻点阶段'
        self.action_bops = FSM.action_bops

    def enter(self, my_ai):
        # 如果有射击动作，优先执行射击
        shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.Shoot)
        guide_shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.GuideShoot)
        shoot_ids.extend(guide_shoot_ids)
        total_actions = []
        for action_bop in self.action_bops:
            if shoot_ids:
                if action_bop.obj_id in shoot_ids:
                    action = action_bop.OccupyingSecond(my_ai, self.action_bops)
                    if action:
                        total_actions.append(action)
            else:
                action = action_bop.OccupyingSecond(my_ai, self.action_bops)
                if action:
                    total_actions.append(action)
        return total_actions


###########################起始和结束状态
class GameStart(FsmState):
    def __init__(self, FSM, my_ai):
        self.name = '游戏开始阶段'
        # print("{}{} start".format(ai_group.color, self.name))

    def enter(self, my_ai):
        print("{} start".format(self.name))
        return list()

    def exit(self):
        print("{} exit".format(self.name))


class ExitFSM(FsmFinalState):
    def __init__(self, FSM, my_ai):
        self.name = '结束阶段'

    def enter(self, my_ai):
        print("{} start".format(self.name))
        return list()

    def exit(self):
        self.done = False
        print("{} exit".format(self.name))

#############人机混合
class HRRedFarAttack(FsmState):
    def __init__(self, FSM, my_ai):
        self.name =  '红方远距离攻击阶段'
        self.action_bops = FSM.action_bops


    def enter(self, my_ai):
        # 如果有射击动作，优先执行射击
        shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.Shoot)
        guide_shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.GuideShoot)
        shoot_ids.extend(guide_shoot_ids)
        total_actions = []
        for action_bop in self.action_bops:
            action_bop.produce_artillery_call(my_ai)
            #action = []
            # operators = action_bop.get_bop(my_ai)
            # if int(operators["obj_id"]) in my_ai.controllable_ops:
            action = action_bop.HRFarAttack(my_ai, self.action_bops)
            if action:
                total_actions.append(action)
            # if shoot_ids:
            #     if action_bop.obj_id in shoot_ids:
            #         action = action_bop.HRFarAttack(my_ai, self.action_bops)
            #         if action:
            #             total_actions.append(action)
            # else:
            #     action = action_bop.HRFarAttack(my_ai, self.action_bops)
            #     if action:
            #         total_actions.append(action)
        return total_actions


class HRRedMiddleFarAttack(FsmState):
    def __init__(self, FSM, my_ai):
        self.name = '红方中远距离攻击阶段'
        self.action_bops = FSM.action_bops

    def enter(self, my_ai):
        # 如果有射击动作，优先执行射击
        shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.Shoot)
        guide_shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.GuideShoot)
        shoot_ids.extend(guide_shoot_ids)
        total_actions = []
        for action_bop in self.action_bops:
            action_bop.produce_artillery_call(my_ai)
            # action = []
            # operators = action_bop.get_bop(my_ai)
            # if operators["obj_id"] in my_ai.controllable_ops:
            action = action_bop.HRMiddleFarAttack(my_ai, self.action_bops)
            if action:
                total_actions.append(action)
            # if shoot_ids:
            #     if action_bop.obj_id in shoot_ids:
            #
            #         action = action_bop.HRMiddleFarAttack(my_ai, self.action_bops)
            #         if action:
            #             total_actions.append(action)
            # else:
            #     action = action_bop.HRMiddleFarAttack(my_ai, self.action_bops)
            #     if action:
            #         total_actions.append(action)
        return total_actions


class HRRedOccupyingMain(FsmState):
    def __init__(self, FSM, my_ai):
        self.name =  '红方强夺主控点阶段'
        self.action_bops = FSM.action_bops
        self.gathering_Vehicle = False

        main_enemy_ability = util.city_enemy_ability(my_ai, my_ai.attack_point['o_main_attack'])
        second_enemy_ability = util.city_enemy_ability(my_ai, my_ai.attack_point['o_second_attack'])
        if main_enemy_ability <= second_enemy_ability:
            if not common.my_city(my_ai.observation['cities'], my_ai.color, coord=my_ai.attack_point['o_main_attack']):
                self.occupy_coord = my_ai.attack_point['o_main_attack']
            elif second_enemy_ability <= 1:
                self.occupy_coord = my_ai.attack_point['o_second_attack']
            else:
                self.occupy_coord = my_ai.attack_point['o_main_attack']
        else:
            self.occupy_coord = my_ai.attack_point['o_second_attack']

    def enter(self, my_ai):
        # 如果有射击动作，优先执行射击
        shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.Shoot)
        guide_shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.GuideShoot)
        shoot_ids.extend(guide_shoot_ids)
        total_actions = []
        for action_bop in self.action_bops:
            action_bop.produce_artillery_call(my_ai)
            # action = []
            # operators = action_bop.get_bop(my_ai)
            # if operators["obj_id"] in my_ai.controllable_ops:
            action = action_bop.HROccupying(my_ai, self.action_bops)
            if action:
                total_actions.append(action)


            # if shoot_ids:
            #     if action_bop.obj_id in shoot_ids:
            #         if action_bop.sub_type == const.BopName.Tank:
            #             action = action_bop.HROccupying(my_ai, self.action_bops)
            #             if action:
            #                 total_actions.append(action)
            #         else:
            #             #action = action_bop.HROccupying(my_ai, self.action_bops, city_coord=self.occupy_coord)
            #             action = action_bop.HROccupying(my_ai, self.action_bops)
            #             if action:
            #                 total_actions.append(action)
            # else:
            #     if action_bop.sub_type == const.BopName.Tank:
            #         action = action_bop.HROccupying(my_ai, self.action_bops)
            #         if action:
            #             total_actions.append(action)
            #     else:
            #         #action = action_bop.HROccupying(my_ai, self.action_bops, city_coord=self.occupy_coord)
            #         action = action_bop.HROccupying(my_ai, self.action_bops)
            #         if action:
            #             total_actions.append(action)
        return total_actions


class HRBlueMainDefense(FsmState):
    def __init__(self, FSM, my_ai):
        self.name = '蓝方主攻点防守阶段'
        self.action_bops = FSM.action_bops

    def enter(self, my_ai):
        # 如果有射击动作，优先执行射击
        shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.Shoot)
        guide_shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.GuideShoot)
        shoot_ids.extend(guide_shoot_ids)
        total_actions = []
        for action_bop in self.action_bops:
            action_bop.produce_artillery_call(my_ai)
            # action = []
            # operators = action_bop.get_bop(my_ai)
            # if operators["obj_id"] in my_ai.controllable_ops:
            action = action_bop.HRMainDefense(my_ai, self.action_bops)
            if action:
                total_actions.append(action)
        return total_actions


class HRBlueOccupying(FsmState):
    def __init__(self, FSM, my_ai):
        self.name = '蓝方抢夺主攻点阶段'
        self.action_bops = FSM.action_bops

    def enter(self, my_ai):
        # 如果有射击动作，优先执行射击
        shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.Shoot)
        guide_shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.GuideShoot)
        shoot_ids.extend(guide_shoot_ids)
        total_actions = []
        for action_bop in self.action_bops:
            action_bop.produce_artillery_call(my_ai)
            # action = []
            # operators = action_bop.get_bop(my_ai)
            # if operators["obj_id"] in my_ai.controllable_ops:
            action = action_bop.HROccupying(my_ai, self.action_bops)
            if action:
                total_actions.append(action)
        return total_actions


class HRBlueProtect(FsmState):
    def __init__(self, FSM, my_ai):
        self.name = '蓝方抢夺次攻点阶段'
        self.action_bops = FSM.action_bops

    def enter(self, my_ai):
        # 如果有射击动作，优先执行射击
        shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.Shoot)
        guide_shoot_ids = common.get_id_by_action_name(my_ai.observation['valid_actions'], const.ActionType.GuideShoot)
        shoot_ids.extend(guide_shoot_ids)
        total_actions = []
        for action_bop in self.action_bops:
            action_bop.produce_artillery_call(my_ai)
            # action = []
            # operators = action_bop.get_bop(my_ai)
            # if operators["obj_id"] in my_ai.controllable_ops:
            action = action_bop.HRProtect(my_ai, self.action_bops)
            if action:
                total_actions.append(action)
        return total_actions