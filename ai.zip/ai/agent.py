"""A simple agent implementation.

DemoAgent class inherits from BaseAgent and implement all three
abstract methods: setup(), step() and reset().
"""
import json
import os
import random
import threading
import json, copy, random
from multiprocessing import Process, Value

from .hexmap.wgmap import MyMap, Visibility
from .utils import util, const, common, update_pos, enemy_observe_zone, damage
from .base_agent import BaseAgent
from .map import Map
from .action_package.RedFSM import RedFSM
from .action_package.BlueFSM import BlueFSM
from .utils.process_attack_value import CCSharedObject, attack_value_multi_process
#from core.utils.map import Map as Map_linji
from .hexmap import hex
from .hexmap import common as common2



class Agent(BaseAgent):
    def __init__(self):
        # self.scenario = None
        # self.color = None
        # self.priority = None
        # self.observation = None
        # self.map = None
        # self.scenario_info = None
        # self.map_data = None
        # self.seat = None
        # self.faction = None
        # self.role = None
        # self.controllable_ops = None
        # self.team_info = None
        # self.my_direction = None
        # self.my_mission = None
        # self.user_name = None
        # self.user_id = None
        # self.history = None

        self.my_message = []
        self.tmp_mission = None
        self.tmp_action = dict()

        # linji sdk
        self.scenario = None
        self.color = None
        self.priority = None
        self.observation = None
        self.map = None
        self.scenario_info = None
        self.map_data = None
        self.seat = None
        self.faction = None
        self.role = None
        self.controllable_ops = None
        self.team_info = None
        self.my_direction = None
        self.my_mission = None
        self.user_name = None
        self.user_id = None
        self.history = None

        self.my_map = None
        self.hex_cache = None
        self.see = None
        self.damage = None
        self.replay_pos = None
        self.enemy_predict = None
        self.attack_point = None
        self.enemy_observe_zone = None
        self.shoot_target_record = None
        self.FSM_ai = None
        self.game_all_time = None

        self.update_thread = None
        self.ubops_record = None
        self.attack_value_precess = None
        self.attack_value_time_process = None
        self.ubops_record_share = None
        self.our_bops_share = None
        self.attack_value_share = None
        self.attack_value = None
        self.attack_value_time = None
        self.lock = None
        self.alone_tank = []

        self.attack_vehicle_flag = []
        self.replay_record = []
        self.update_pos_enable = True

        self.UnmannedVehicle = None
        self.UV_not_exe = True
        self.Tank = {}
        self.AITank = 0
        self.linjihex = {}
        # self.UAVmsg = {}
        self.huntermove = {}
        self.UnVeone = 0
        self.veichleoffone = 0
        self.jiejuunmanned = 0
        self.hidevehicle = 0
        self.tankhideid = -1
        self.tankstopid = -1
        self.UAVControl = 1
        self.SoldierControl = 1
        self.TankControl = 2
        self.MissileControl = 1
        self.unveid1 = -1
        self.unveid2 = -1
        self.veid1 = -1
        self.veid2 = -1
        self.yd_point = {}
        self.last_observation = None


        self.veid_100 = -1
        self.veid_101 = -1
        self.veid_102 = -1
        self.veid_103= -1
        self.veid_104 = -1

        self.uveid_400 = -1
        self.uveid_401 = -1
        self.uveid_402 = -1

        self.sold_200 = -1
        self.sold_201 = -1
        self.sold_202 = -1
        self.sold_203 = -1
        self.sold_53 = -1
        self.sold_68 = -1
        self.sold_69 = -1
        self.sold_86 = -1


        self.timess = 0



    def setup(self, setup_info):
        # self.scenario = setup_info["scenario"]

        # self.color = setup_info["faction"]  # todo
        # self.faction = setup_info["faction"]
        # self.seat = setup_info["seat"]
        # self.role = setup_info["role"]
        # self.user_name = setup_info["user_name"]
        # self.user_id = setup_info["user_id"]
        self.priority = {
            ActionType.Occupy: self.gen_occupy,
            ActionType.Shoot: self.gen_shoot,
            ActionType.GuideShoot: self.gen_guide_shoot,
            ActionType.JMPlan: self.gen_jm_plan,
            ActionType.LayMine: self.gen_lay_mine,
            ActionType.ActivateRadar: self.gen_activate_radar,
            ActionType.ChangeAltitude: self.gen_change_altitude,
            ActionType.GetOn: self.gen_get_on,
            ActionType.GetOff: self.gen_get_off,
            ActionType.Fork: self.gen_fork,
            ActionType.Union: self.gen_union,
            ActionType.EnterFort: self.gen_enter_fort,
            ActionType.ExitFort: self.gen_exit_fort,
            ActionType.Move: self.gen_move,
            ActionType.RemoveKeep: self.gen_remove_keep,
            ActionType.ChangeState: self.gen_change_state,
            # ActionType.StopMove: self.gen_stop_move,
            ActionType.WeaponLock: self.gen_WeaponLock,
            ActionType.WeaponUnFold: self.gen_WeaponUnFold,
            ActionType.CancelJMPlan: self.gen_cancel_JM_plan
        }  # choose action by priority
        # self.observation = None
        self.map = Map(
            setup_info["basic_data"],
            setup_info["cost_data"],
            setup_info["see_data"]
        )  # use 'Map' class as a tool
        self.map_data = self.map.get_map_data()




        # linji_sdk,  mark with _linji
        self.color = const.Color.BLUE if setup_info["faction"] else const.Color.RED
        self.enemy_color = const.Color.RED if setup_info["faction"] else const.Color.BLUE
        self.time = -1

        self.scenario = int(setup_info["scenario"]['scenario_id'])
        self.get_scenario_info(setup_info["state"])
        self.faction = setup_info["faction"]
        self.seat = setup_info["seat"]
        self.role = setup_info["role"]
        self.user_name = setup_info["user_name"]
        self.user_id = setup_info["user_id"]

        self.observation = None
        #self.map_linji = Map_linji(int(setup_info["scenario"]['scenario_id']))  # use 'Map' class as a tool
        # self.map_data = self.map.get_map_data()
        if self.scenario in [2010131194, 2010141294, 2010211129, 2010431153, 2010441253, 2201010101,2201010201,20220102013,2201010202]:
            self.game_all_time = const.company_game_time
        elif self.scenario in [2030111194, 2030331196, 2030341296]:
            self.game_all_time = const.group_game_time
        else:
            raise Exception

        ############载入地图、通视、夺控热度等
        #self.my_map = MyMap(self.map_linji)
        self.my_map = MyMap(self.map)
        # table_produce.make_los(self.my_map, 'ai/hexmap/data/map/221/LOS')   # todo los file already made

        self.hex_cache = hex.HexCache(largest_dis=30, map_size=self.my_map.size)
        # table_produce.produce_LOS(self, 'ai/hexmap/data/map/221/LOS')
        base_map = 'ai/hexmap/data/map'
        map_id = self.my_map.map_id

        self.see = Visibility(self, map_id, base_map, self.hex_cache, self.my_map.size)  # todo manuver file not made

        #######加载对敌方观察区域的类（内部默认用敌方坦克计算得出）
        self.enemy_observe_zone = enemy_observe_zone.EnemyObserveZone(self)
        #############

        self.damage = damage.Damage()
        ################

        ############载入复盘数据的位置概率
        enemy_pos_dir = os.path.join('ai/hexmap/data/enemy_pos', str(self.scenario))

        self.replay_pos = update_pos.UpdateReplay(self, enemy_pos_dir)  # search from replay_log

        self.enemy_predict = update_pos.EnemyPredict(self)
        ##########################

        #######从主次夺控点中选取一个作为主攻点
        self.attack_point = util.get_main_attack(self)
        #############

        self.shoot_target_record = []

        ####初始化状态机ai
        if self.color == const.Color.RED:
            self.FSM_ai = RedFSM(self)
        else:
            self.FSM_ai = BlueFSM(self)
        self.update_precess = True
        self.ubops_record_share = CCSharedObject(5000000)
        self.our_bops_share = CCSharedObject(5000000)
        self.attack_value_share = CCSharedObject(5000000)
        self.lock = threading.Lock()



    def reset(self):
        # self.scenario = None
        # self.color = None
        # self.priority = None
        # self.observation = None
        # self.map = None
        # self.scenario_info = None
        # self.map_data = None
        self.my_message = []
        self.tmp_mission = None
        self.tmp_action = dict()

        # linji
        self.scenario = None
        self.color = None
        self.priority = None
        self.observation = None
        self.map = None
        self.scenario_info = None
        self.map_data = None

        self.my_map = None
        self.hex_cache = None
        self.see = None
        self.damage = None
        self.replay_pos = None
        self.enemy_predict = None
        self.attack_point = None
        self.enemy_observe_zone = None
        self.shoot_target_record = None
        self.FSM_ai = None
        self.game_all_time = None

        self.update_thread = None
        self.ubops_record = None
        self.attack_value_precess = None
        self.attack_value_time_process = None
        self.ubops_record_share = None
        self.our_bops_share = None
        self.attack_value_share = None
        self.attack_value = None
        self.attack_value_time = None
        self.lock = None
        self.alone_tank = []

        self.attack_vehicle_flag = []
        self.replay_record = []
        self.update_pos_enable = True


    def update_observation(self, observation: dict):
        if self.time >= observation['time']['cur_step']:
            return False
        # self.lock.acquire()
        self.replay_record.append(observation)
        self.shoot_target_record = []
        self.observation = observation
        self.time = observation['time']['cur_step']
        self.judge_info = observation['judge_info']
        self.score = observation['scores']
        self.cities = observation['cities']
        self.land_marks = observation['landmarks']['roadblocks']  # [1111, 4323, 5933]
        self.our_bops = common.get_color_bops(observation['operators'], color=self.color)
        self.enemy_bops = common.get_color_bops(observation['operators'], color=self.enemy_color)
        self.our_passengers = common.get_color_bops(observation['passengers'], color=self.color)
        self.enemy_passengers = common.get_color_bops(observation['passengers'], color=self.enemy_color)
        self.our_jiejutank = common.get_color_bops_jiejutank(observation['operators'], color=self.color)

        # self.ubops_record = copy.deepcopy(self.enemy_predict.ubops_record)
        # self.lock.release()
        # if not self.update_thread:
        #     self.update_thread = threading.Thread(target=self.enemy_predict.update, args=(self,))
        #     self.update_thread.start()
        self.enemy_predict.update(self)
        # if self.time >= 1700 and self.update_pos_enable:
        #     self.update_pos_enable = False
        #     read_zip = False
        #     for root, dirs, files in os.walk('logs/replay', topdown=False):
        #         if files:   # 当前路径下所有非目录子文件
        #             read_zip = True
        #             break
        #     if read_zip:
        #         print('*********************directory update')
        #         self.update_thread = threading.Thread(target=self.replay_pos.update_replays,
        #                                               args=(self.color, 'logs/replay', False, 1))
        #         self.update_thread.start()
        #     else:
        #         print('*********************self update')
        #         self.update_thread = threading.Thread(target=self.replay_pos.update_record,
        #                                               args=(copy.deepcopy(self.replay_record), self.color, False))
        #         self.update_thread.start()

        if not self.attack_value_share.done.value:
            self.ubops_record_share.SaveObj(self.enemy_predict.ubops_record)
            self.our_bops_share.SaveObj(self.observation)
            if self.update_precess and not self.attack_value_precess:
                self.update_precess = False
                self.process_done = Value('b', False)
                self.attack_value_precess = Process(target=attack_value_multi_process,
                                                    args=(self.my_map, self.see, self.damage, self.enemy_bops_init_all,
                                                          self.hex_cache, self.ubops_record_share,
                                                          self.our_bops_share, self.attack_value_share,
                                                          self.process_done), name='attack_value_precess')
                self.attack_value_precess.start()
                import atexit
                atexit.register(self.attack_value_precess.terminate)
        if self.attack_value_share.done.value:
            self.attack_value = self.attack_value_share.GetObj()
        if self.time >= self.game_all_time - 10:
            self.process_done.value = True
        return True


    def step(self, observation: dict):

        self.observation = observation  # save observation for later use

        enemy_id_list = []
        enemy_bop_list = []
        for bop in observation["operators"]:
            if bop['color'] == self.enemy_color:
                obj_id = bop['obj_id']
                enemy_id_list.append(obj_id)
                enemy_bop_list.append(bop)





        self.team_info = observation["role_and_grouping_info"]
        self.controllable_ops = None
        self.controllable_ops = observation["role_and_grouping_info"][self.seat]["operators"]       # agent control all ops in this seat
        mine_info = self.team_info.get(self.seat)
        total_actions = []
        hideactions = []
        see_actions = []
        fire_actions = []
        communications = observation["communication"]
        if len(communications) > 0:
            for command in communications:
                if command.__contains__("info"):
                    text = command["info"]
                    if text["company_id"] == self.seat:
                        if command["type"] == 200:      #   下达作战任务
                            if text["start_time"] == 16 or text["start_time"] == 9:
                                self.UAVmsg = text
                            elif text["start_time"] == 1500:
                                self.UnmannedVehicle = text
                                self.UV_not_exe = True

                            else:
                                if text['end_time'] == 1799:
                                    del self.Tank[text['start_time']]
                                    self.AITank = 0
                                else:
                                    tank_msg = {text['start_time']:text}
                                    self.Tank.update(tank_msg)
                                    self.AITank = 1
                elif command["type"] == 205:
                    if command['msg_body']['graphic_type'] == 'target':
                        if len(command['msg_body']['hexs']) > 1:
                            for bop in self.our_bops:
                                if bop['cur_hex'] == command['msg_body']['hexs'][0]:
                                    hunter_move = {bop['obj_id']:command['msg_body']}
                                    self.huntermove.update(hunter_move)
                        elif len(command['msg_body']['hexs']) == 1:
                            car_range = [25, 25, 10, 25, 25, 1, 25, 1, 25, 25, 25, 12, 12, 25, 25, 25, 10, 25, 25]
                            for hex in command['msg_body']['hexs']:
                                flag = 0
                                for bop in self.our_bops:
                                    if bop['cur_hex'] == hex:
                                        msg = self.get_fire_scope(bop)
                                        fire_actions.append(self.gen_send_graphic_message(msg, "fire_range", "火力范围", color="#FF0000"))
                                        flag = 1
                                        break
                                for bop in enemy_bop_list:
                                    if bop['cur_hex'] == hex:
                                        msg = self.get_fire_scope(bop)
                                        fire_actions.append(self.gen_send_graphic_message(msg, "fire_range", "火力范围", color="#FF0000"))
                                        flag = 1
                                        break
                                if not flag:
                                    bop = {'observe_distance': car_range, 'cur_hex': hex}
                                    msg = self.get_fire_scope(bop)
                                    fire_actions.append(self.gen_send_graphic_message(msg, "fire_range", "火力范围", color="#FF0000"))
                    elif command['msg_body']['graphic_type'] == 'attention':
                        for bop in self.our_bops:
                            if bop['cur_hex'] in command['msg_body']['hexs']:
                                hideactions.append(
                                    {
                                        "actor": self.seat,
                                         'obj_id': bop['obj_id'],
                                         'type': const.ActionType.ChangeState,
                                         'target_state': const.StateMode.Hide,
                                    }
                                )
                    elif command['msg_body']['graphic_type'] == 'sub_type':
                        car_range = [25, 25, 10, 25, 25, 1, 25, 1, 25, 25, 25, 12, 12, 25, 25, 25, 10, 25, 25]
                        for hex in command['msg_body']['hexs']:
                            flag = 0
                            for bop in self.our_bops:
                                if bop['cur_hex'] == hex:
                                    msg = self.get_see_scope(bop)
                                    see_actions.append(self.gen_send_graphic_message(msg, "see_range", "视野范围", color="#00FF00"))
                                    flag = 1
                                    break
                            for bop in enemy_bop_list:
                                if bop['cur_hex'] == hex:
                                    msg = self.get_see_scope(bop)
                                    see_actions.append(self.gen_send_graphic_message(msg, "see_range", "视野范围", color="#00FF00"))
                                    flag = 1
                                    break
                            if not flag:
                                bop = {'observe_distance':car_range,'cur_hex':hex}
                                msg = self.get_see_scope(bop)
                                see_actions.append(self.gen_send_graphic_message(msg, "see_range", "视野范围", color="#00FF00"))
        else:
            self.my_mission = None
        if hideactions != []:
            total_actions = total_actions + hideactions
        if fire_actions != []:
            total_actions = total_actions + fire_actions
        if see_actions != []:
            total_actions = total_actions + see_actions

        for bop in observation["operators"]:
            if bop['color'] == const.Color.BLUE and bop['obj_id'] in self.controllable_ops:
                if bop['sub_type'] == const.BopName.Vehicle:
                    if bop['cur_hex'] == 4424 and bop['blood'] == 2 and bop['obj_id'] != 51 and self.veid_100 == -1:
                        self.veid_100 = bop['obj_id']
                    elif bop['cur_hex'] == 4425 and bop['blood'] == 1 and bop['obj_id'] != 83 and self.veid_102 == -1:
                        self.veid_102 = bop['obj_id']
                    elif bop['cur_hex'] == 4425 and bop['blood'] == 1 and bop['obj_id'] != 83 and self.veid_103 == -1 and bop['obj_id'] != self.veid_102:
                        self.veid_103 = bop['obj_id']
                    elif bop['cur_hex'] == 3819 and bop['blood'] == 1 and bop['obj_id'] != self.veid_100 and self.veid_104 == -1:
                        self.veid_104 = bop['obj_id']
                if bop['sub_type'] == const.BopName.UnmannedVehicle:
                    if bop['cur_hex'] == 4424 and bop['blood'] == 1 and self.uveid_400 == -1:
                        self.uveid_400 = bop['obj_id']
                    elif bop['cur_hex'] == 4528 and bop['blood'] == 1 and self.uveid_401 == -1:
                        self.uveid_401 = bop['obj_id']
                    elif bop['cur_hex'] == 5427 and bop['blood'] == 1 and self.uveid_402 == -1 and bop['obj_id'] != 84:
                        self.uveid_402 = bop['obj_id']
                if bop['sub_type'] == const.BopName.Soldier:
                    if bop['cur_hex'] == 3824 and bop['blood'] == 2 and self.sold_200 == -1:
                        self.sold_200 = bop['obj_id']
                    elif bop['cur_hex'] == 4126 and bop['blood'] == 1 and self.sold_202 == -1:
                        self.sold_202 = bop['obj_id']
                    elif bop['cur_hex'] == 4225 and bop['blood'] == 1 and self.sold_53 == -1:
                        self.sold_53 = bop['obj_id']
                    elif bop['cur_hex'] == 4129 and bop['blood'] == 1 and self.sold_203 == -1:
                        self.sold_203 = bop['obj_id']
                    elif bop['cur_hex'] == 4332 and bop['blood'] == 1 and self.sold_86 == -1:
                        self.sold_86 = bop['obj_id']
            elif bop['color'] == const.Color.RED and bop['obj_id'] in self.controllable_ops:
                if bop['sub_type'] == const.BopName.Vehicle:
                    if bop['cur_hex'] == 2743 and bop['blood'] == 1 and bop['obj_id'] != 64 and self.veid_100 == -1:
                        self.veid_100 = bop['obj_id']
                    elif bop['cur_hex'] == 2743 and bop['blood'] == 1 and bop['obj_id'] != self.veid_100 and bop['obj_id'] != 64 and self.veid_101 == -1:
                        self.veid_101 = bop['obj_id']
                    elif bop['cur_hex'] == 2843 and bop['blood'] == 1 and self.veid_102 == -1 and bop['obj_id'] != 66:
                        self.veid_102 = bop['obj_id']
                if bop['sub_type'] == const.BopName.UnmannedVehicle:
                    if bop['cur_hex'] == 2843 and bop['blood'] == 1 and self.uveid_400 == -1:
                        self.uveid_400 = bop['obj_id']
                if bop['sub_type'] == const.BopName.Soldier:
                    if bop['cur_hex'] == 3432 and bop['blood'] == 2 and self.sold_69 == -1:
                        self.sold_69 = bop['obj_id']
                    elif bop['cur_hex'] == 3430 and bop['blood'] == 1 and self.sold_200 == -1:
                        self.sold_200 = bop['obj_id']
                    elif bop['cur_hex'] == 3429 and bop['blood'] == 1 and self.sold_201 == -1:
                        self.sold_201 = bop['obj_id']
                    elif bop['cur_hex'] == 3328 and bop['blood'] == 1 and self.sold_202 == -1:
                        self.sold_202 = bop['obj_id']
                    elif bop['cur_hex'] == 3740 and bop['blood'] == 1 and self.sold_68 == -1:
                        self.sold_68 = bop['obj_id']


        #print(f'{self.color} actions at step: {observation["time"]["cur_step"]}')
        if observation["time"]["stage"] == 1:   #   "当前处于的阶段，0-环境配置阶段，1-部署阶段，2-正常推进阶段"
            actions = []
            for item in observation["operators"]:
                if item["obj_id"] in self.controllable_ops:
                    operator = item
                    if operator["obj_id"]!= 84 and operator["obj_id"] != 78 and self.color == const.Color.BLUE and operator["sub_type"] == const.BopName.UnmannedVehicle:
                        if self.unveid1 == -1:
                            self.unveid1 = operator["obj_id"]
                        else:
                            self.unveid2 = operator["obj_id"]
                    if operator["obj_id"]!= 72 and operator["obj_id"] != 73 and self.color == const.Color.RED and operator["sub_type"] == const.BopName.UnmannedVehicle:
                        if self.unveid1 == -1:
                            self.unveid1 = operator["obj_id"]
                        else:
                            self.unveid2 = operator["obj_id"]
                    if operator["obj_id"] == 84 and operator["blood"] == 3:
                        actions.append(
                            {
                                "actor": self.seat,
                                "obj_id": operator["obj_id"],
                                "type": 314,
                            }
                        )
                    if operator["obj_id"] == 78 and operator["blood"] == 3:
                        actions.append(
                            {
                                "actor": self.seat,
                                "obj_id": operator["obj_id"],
                                "type": 314,
                            }
                        )
                    if operator["obj_id"] == 72 and operator["blood"] == 3:
                        actions.append(
                            {
                                "actor": self.seat,
                                "obj_id": operator["obj_id"],
                                "type": 314,
                            }
                        )
                    if operator["obj_id"] == 73 and operator["blood"] == 3:
                        actions.append(
                            {
                                "actor": self.seat,
                                "obj_id": operator["obj_id"],
                                "type": 314,
                            }
                        )
            if observation['communication']:
                for commun in observation['communication']:
                    if commun['type'] == 204:
                        if commun['msg_body'] == 'over':
                            actions.append({"actor": self.seat, "type": 333})

            #actions.append({"actor": self.seat, "type": 333})

            return actions




        if observation['communication']:
            for commun in observation['communication']:
                if commun['type'] == 204:
                    if commun['msg_body'] == 'U_Q':
                        self.UAVControl = 1
                    if commun['msg_body'] == 'U_W':
                        self.UAVControl = 2
                    if commun['msg_body'] == 'S_Q':
                        self.SoldierControl = 1
                    if commun['msg_body'] == 'S_W':
                        self.SoldierControl = 2
                    if commun['msg_body'] == 'T_Q':
                        self.TankControl = 1
                    if commun['msg_body'] == 'T_W':
                        self.TankControl = 2
                    if commun['msg_body'] == 'M_Q':
                        self.MissileControl = 1
                    if commun['msg_body'] == 'M_W':
                        self.MissileControl = 2
                    if commun['msg_body'] == 'over':
                        pass
                    else:
                        msg_body = commun['msg_body'].split()
                        need_obj = int(msg_body[0])
                        need_tpye = int(msg_body[1])
                        # cur_step = str(observation['time']['cur_step'])
                        # escription =need_obj + "  " + cur_step
                        for bops in observation['operators']:
                            if bops['obj_id'] == need_obj:
                                if (need_tpye == 0):  # shiye
                                    msg = self.get_see_scope(bops)
                                    total_actions.append(
                                        self.gen_send_graphic_message(msg, "see_range", "视野范围", color="#00FF00"))
                                elif (need_tpye == 1):  # huoli
                                    msg = self.get_fire_scope(bops)
                                    total_actions.append(
                                        self.gen_send_graphic_message(msg, "fire_range", "火力范围", color="#FF0000"))
                                elif (need_tpye == 3):  #hide
                                    self.tankhideid = need_obj
                                elif (need_tpye == 4):  #stop
                                    self.tankstopid = need_obj
                                break

        point_actions = {}
        if observation['judge_info'] != []:
            all_see_scope = []
            for bop in observation['operators']:
                if bop['color'] == self.color:
                    bop_see_scope = list(self.get_see_scope(bop))
                    all_see_scope = all_see_scope + bop_see_scope
            all_see_scope = list(set(all_see_scope))
            for item in observation['judge_info']:
                if item['target_color'] == self.color:
                    flag = 1
                    can_see = 0
                    distance = item['distance']
                    att_obj_id = item['att_obj_id']
                    target_obj_id = item['target_obj_id']
                    target_bop_hex = 0
                    wp_id = item['wp_id']
                    if wp_id == 76 or wp_id == 72:
                        continue
                    for bop in observation['operators']:
                        if att_obj_id in enemy_id_list:
                            # print('att_obj_id==',att_obj_id)
                            # print('bop_obj_id==',bop['obj_id'])
                            #print("can_see!!!!")
                            can_see = 1
                            break
                        if target_obj_id == bop['obj_id']:
                            target_bop = bop
                            target_bop_hex = target_bop['cur_hex']
                            flag = 0
                            break
                    if flag and not can_see:
                        for bop in self.last_observation['operators']:
                            if target_obj_id == bop['obj_id']:
                                target_bop = bop
                                target_bop_hex = target_bop['cur_hex']
                                break
                    if can_see == 0:
                        possible_list = []
                        for i in range(70):
                            for j in range(60):
                                hex = i * 100 +j
                                if common2.get_distance(hex,target_bop_hex) == distance:
                                    append = 1
                                    for bop in observation['operators']:
                                        if bop['color'] == self.color:
                                            grid_type = self.map.get_grid_type(hex)
                                            if bop['sub_type'] != const.BopName.UAV and bop['sub_type'] != const.BopName.Missile:
                                                see_mode = const.SeeMode.GroundToGround
                                            else:
                                                see_mode = const.SeeMode.SkyToGround
                                            if hex in all_see_scope:
                                                tongshi = True
                                            else:
                                                tongshi = False
                                            if tongshi:
                                                append = 0
                                                break
                                    if append:
                                        possible_list.append(hex)
                        #print("possible_list==",possible_list)

                        if possible_list != []:
                            if item['type'] == '引导射击':
                                dict = {item['cur_step']:possible_list}
                                self.yd_point.update(dict)
                            point_actions = {"actor": self.seat,
                                    "type": 205,  # xuanran
                                    "msg_body": {
                                        "hexs": possible_list,
                                        "graphic_type": "attention",
                                        "word": "ack",
                                        "color": "#0000FF",
                                        "description": "attack_point"
                                    }}
        if point_actions != {}:
            total_actions.append(point_actions)







        self.last_observation = self.observation

        # linji
        flag = self.update_observation(observation)
        if not flag:
            return list()
        FSM_actions = self.FSM_ai.action(self)
        total_actions = total_actions + FSM_actions
        #if total_actions:
            # print(f'{const.Color.get_name(self.color)} actions at step: {observation["time"]["cur_step"]}', end='\n\t')
            # print(total_actions)
        # if self.time >= 1799:
        #     print(f'The scores : \n {self.score}')

        #xuanran:
        # for bop in observation['operators']:
        #     if bop and (observation["time"]["cur_step"] % 200 == 0):
        #         msg = self.get_see_scope(bop)
        #         total_actions.append(self.gen_send_graphic_message(msg, "see_range", "视野范围", color="#00FF00"))
        #         msg = self.get_fire_scope(bop)
        #         total_actions.append(self.gen_send_graphic_message(msg, "fire_range", "火力范围", color="#FF0000"))



        # if (observation["time"]["cur_step"] % 150 == 0):
        #     attack_point = self.get_key_point(0)
        #     security_point = self.get_key_point(1)
        #     danger_point = self.get_key_point(2)
        #     total_actions.append(
        #         {
        #             "actor": self.seat,
        #             "type": 205,  # xuanran
        #             "msg_body": {
        #                 "hexs": attack_point,
        #                 "graphic_type": "attention",
        #                 "word": "ack",
        #                 "color": "#0000FF",
        #                 "description": "attack_point"
        #             }
        #         }
        #     )
        #     total_actions.append(
        #         {
        #             "actor": self.seat,
        #             "type": 205,  # xuanran
        #             "msg_body": {
        #                 "hexs": danger_point,
        #                 "graphic_type": "attention",
        #                 "word": "dag",
        #                 "color": "#FF0000",
        #                 "description": "danger_point"
        #             }
        #         }
        #     )
        #     total_actions.append(
        #         {
        #             "actor": self.seat,
        #             "type": 205,  # xuanran
        #             "msg_body": {
        #                 "hexs": security_point,
        #                 "graphic_type": "attention",
        #                 "word": "scr",
        #                 "color": "#00FF00",
        #                 "description": "security_point"
        #             }
        #         }
        #     )
        return total_actions

    # def get_scenario_info(self, scenario: int):
    #     SCENARIO_INFO_PATH = os.path.join(
    #         os.path.dirname(__file__), f"scenario_{scenario}.json"
    #     )
    #     with open(SCENARIO_INFO_PATH, encoding="utf8") as f:
    #         self.scenario_info = json.load(f)

    def get_key_point(self,tpye):
        pass

    def get_scenario_info(self, scenario_state):

        self.scenario_info = scenario_state[-1]
        self.our_bops_init = common.get_color_bops(self.scenario_info['operators'], color=self.color)
        self.enemy_bops_init = common.get_color_bops(self.scenario_info['operators'], color=self.enemy_color)

        self.our_passengers_init = common.get_color_bops(self.scenario_info['passengers'], color=self.color)
        self.enemy_passengers_init = common.get_color_bops(self.scenario_info['passengers'], color=self.enemy_color)

        self.our_bops_init_all = self.our_bops_init + self.our_passengers_init
        self.enemy_bops_init_all = self.enemy_bops_init + self.enemy_passengers_init

        self.cities_init = self.scenario_info['cities']
        if len(self.cities_init) == 1:
            self.cities_init.append(copy.deepcopy(self.scenario_info['cities'][0]))
            self.cities_init[0]['value'] = 80
        # print(self.our_bops_init, self.enemy_bops_init, self.our_passengers_init, self.enemy_passengers_init )

    def get_bop(self, obj_id):
        """Get bop in my observation based on its id."""
        for bop in self.observation["operators"]:
            if obj_id == bop["obj_id"]:
                return bop

    def gen_occupy(self, obj_id, candidate):
        """Generate occupy action."""
        return {
            "actor": self.seat,
            "obj_id": obj_id,
            "type": ActionType.Occupy,
        }

    def gen_shoot(self, obj_id, candidate):
        """Generate shoot action with the highest attack level."""
        best = max(candidate, key=lambda x: x["attack_level"])
        return {
            "actor": self.seat,
            "obj_id": obj_id,
            "type": ActionType.Shoot,
            "target_obj_id": best["target_obj_id"],
            "weapon_id": best["weapon_id"],
        }

    def gen_guide_shoot(self, obj_id, candidate):
        """Generate guide shoot action with the highest attack level."""
        best = max(candidate, key=lambda x: x["attack_level"])
        return {
            "actor": self.seat,
            "obj_id": obj_id,
            "type": ActionType.GuideShoot,
            "target_obj_id": best["target_obj_id"],
            "weapon_id": best["weapon_id"],
            "guided_obj_id": best["guided_obj_id"],
        }

    def gen_jm_plan(self, obj_id, candidate):
        """Generate jm plan action aimed at a random city."""
        weapon_id = random.choice(candidate)["weapon_id"]
        jm_pos = random.choice([city["coord"] for city in self.observation["cities"]])
        return {
            "actor": self.seat,
            "obj_id": obj_id,
            "type": ActionType.JMPlan,
            "jm_pos": jm_pos,
            "weapon_id": weapon_id,
        }

    def gen_get_on(self, obj_id, candidate):
        """Generate get on action with some probability."""
        get_on_prob = 0.5
        if random.random() < get_on_prob:
            target_obj_id = random.choice(candidate)["target_obj_id"]
            return {
                "actor": self.seat,
                "obj_id": obj_id,
                "type": ActionType.GetOn,
                "target_obj_id": target_obj_id,
            }

    def gen_get_off(self, obj_id, candidate):
        """Generate get off action only if the bop is within some distance of a random city."""
        bop = self.get_bop(obj_id)
        destination = random.choice(
            [city["coord"] for city in self.observation["cities"]]
        )
        if bop and self.map.get_distance(bop["cur_hex"], destination) <= 10:
            target_obj_id = random.choice(candidate)["target_obj_id"]
            return {
                "actor": self.seat,
                "obj_id": obj_id,
                "type": ActionType.GetOff,
                "target_obj_id": target_obj_id,
            }

    def gen_change_state(self, obj_id, candidate):
        """Generate change state action with some probability."""
        change_state_prob = 0.001
        if random.random() < change_state_prob:
            target_state = random.choice(candidate)["target_state"]
            return {
                "actor": self.seat,
                "obj_id": obj_id,
                "type": ActionType.ChangeState,
                "target_state": target_state,
            }

    def gen_remove_keep(self, obj_id, candidate):
        """Generate remove keep action with some probability."""
        remove_keep_prob = 0.2
        if random.random() < remove_keep_prob:
            return {
                "actor": self.seat,
                "obj_id": obj_id,
                "type": ActionType.RemoveKeep,
            }

    def gen_move(self, obj_id, candidate):
        """Generate move action to a random city."""

        operators = self.observation['operators']
        enemy_cur_hex = [bop['cur_hex'] for bop in filter(lambda bop: bop['color'] != self.color, operators)]

        bop = self.get_bop(obj_id)
        if bop["sub_type"] == 3:
            return
        if candidate:
            destination = random.choice(candidate)
        else:
            destination = random.choice([city["coord"] for city in self.observation["cities"]])

        if self.my_direction:
            destination = self.my_direction["info"]["target_pos"]
        if bop and bop["cur_hex"] != destination:
            move_type = self.get_move_type(bop)     #
            func_idx = random.choice((0, 1))
            print(func_idx)
            func_dict = {
                0: self.map.gen_move_route_ops,
                1: self.map.gen_move_route
            }

            using_func = func_dict[func_idx]
            route = using_func(bop["cur_hex"], destination, move_type, enemy_cur_hex)
            return {
                "actor": self.seat,
                "obj_id": obj_id,
                "type": ActionType.Move,
                "move_path": route,
            }

    def gen_move_origin(self, obj_id, candidate):
        """Generate move action to a random city."""
        bop = self.get_bop(obj_id)
        if bop["sub_type"] == 3:
            return
        destination = random.choice(
            [city["coord"] for city in self.observation["cities"]]
        )
        if self.my_direction:
            destination = self.my_direction["info"]["target_pos"]
        if bop and bop["cur_hex"] != destination:
            move_type = self.get_move_type(bop)
            route = self.map.gen_move_route(bop["cur_hex"], destination, move_type)
            return {
                "actor": self.seat,
                "obj_id": obj_id,
                "type": ActionType.Move,
                "move_path": route,
            }

    def get_move_type(self, bop):
        """Get appropriate move type for a bop."""
        bop_type = bop["type"]
        if bop_type == BopType.Vehicle:
            if bop["move_state"] == MoveType.March:
                move_type = MoveType.March
            else:
                move_type = MoveType.Maneuver
        elif bop_type == BopType.Infantry:
            move_type = MoveType.Walk
        else:
            move_type = MoveType.Fly
        return move_type

    def gen_stop_move(self, obj_id, candidate):
        # """Generate stop move action only if the bop is within some distance of a random city.
        #
        # High probability for the bop with passengers and low for others.
        # """
        # bop = self.get_bop(obj_id)
        # destination = random.choice(
        #     [city["coord"] for city in self.observation["cities"]]
        # )
        # if self.map.get_distance(bop["cur_hex"], destination) <= 10:
        #     stop_move_prob = 0.9 if bop["passenger_ids"] else 0.01
        #     if random.random() < stop_move_prob:
        return {
            "actor": self.seat,
            "obj_id": obj_id,
            "type": ActionType.StopMove,
        }

    def gen_WeaponLock(self, obj_id, candidate):
        bop = self.get_bop(obj_id)
        prob_weaponlock = 0.001
        if (
            max(self.map_data[bop["cur_hex"] // 100][bop["cur_hex"] % 100]["roads"]) > 0
            or random.random() < prob_weaponlock
        ):
            return {"actor": self.seat, "obj_id": obj_id, "type": ActionType.WeaponLock}

    def gen_WeaponUnFold(self, obj_id, candidate):
        bop = self.get_bop(obj_id)
        destination = random.choice(
            [city["coord"] for city in self.observation["cities"]]
        )
        if self.map.get_distance(bop["cur_hex"], destination) <= 10:
            return {
                "actor": self.seat,
                "obj_id": obj_id,
                "type": ActionType.WeaponUnFold,
            }

    def gen_cancel_JM_plan(self, obj_id, candidate):
        cancel_prob = 0.0001
        if random.random() < cancel_prob:
            return {
                "actor": self.seat,
                "obj_id": obj_id,
                "type": ActionType.CancelJMPlan,
            }

    # def gen_grouping_info(self, observation):
    #     def partition(lst, n):
    #         return [lst[i::n] for i in range(n)]
    #
    #     operator_ids = []
    #     for operator in observation["operators"] + observation["passengers"]:
    #         if operator["color"] == self.color:
    #             operator_ids.append(operator["obj_id"])
    #     lists_of_ops = partition(operator_ids, len(self.team_info.keys()))
    #     grouping_info = {"actor": self.seat, "type": 100}
    #     info = {}
    #     for teammate_id in self.team_info.keys():
    #         info[teammate_id] = {"operators": lists_of_ops.pop()}
    #     grouping_info["info"] = info
    #     return grouping_info
    def gen_grouping_info(self, observation, group_type):
        human_list = []
        ai_list = []
        valid_type = [3, 4, 5, 7, 9]
        for operator in observation["operators"] + observation["passengers"]:
            if operator["color"] == self.color:
                # human_list.append(operator["obj_id"])
                if operator['sub_type'] in valid_type and operator['sub_type'] in group_type:
                    ai_list.append(operator["obj_id"])
                else:
                    human_list.append(operator["obj_id"])

        lists_of_ops = [[], []]
        lists_of_ops[0] = human_list
        lists_of_ops[1] = ai_list

        grouping_info = {"actor": self.seat, "type": 100}
        info = {}
        index = 0
        for teammate_id in self.team_info.keys():
            info[teammate_id] = {"operators": lists_of_ops[index]}
            index += 1
        grouping_info["info"] = info
        return grouping_info

    def gen_battle_direction_info(self, observation):
        direction_info = []
        for teammate_id in self.team_info.keys():
            direction = {
                "actor": self.seat,
                "type": 201,
                "info": {
                    "company_id": teammate_id,
                    "target_pos": random.choice(observation["cities"])["coord"],
                    "start_time": 0,
                    "end_time": 1800,
                },
            }
            direction_info.append(direction)
        return direction_info

    # def gen_battle_mission_info(self, observation):
    #     mission_info = []
    #     for teammate_id in self.team_info.keys():
    #         mission = {
    #             "actor": self.seat,
    #             "type": 200,
    #             "info": {
    #                 "company_id": teammate_id,
    #                 "mission_type": random.randint(0, 2),
    #                 "target_pos": random.choice(observation["cities"])["coord"],
    #                 "route": [
    #                     random.randint(0, 9000),
    #                     random.randint(0, 9000),
    #                     random.randint(0, 9000),
    #                 ],
    #                 "start_time": 0,
    #                 "end_time": 1800,
    #             },
    #         }
    #         mission_info.append(mission)
    #     return mission_info
    def gen_battle_mission_info(self, mission_type, target_pos=None, route=None, start_time=0, end_time=1800):
        # 引擎返回的任务指令
        # my_mission: {'actor': 1,
        #               'type': 200,
        #               'info': {'company_id': 2,
        #                       'mission_type': 2,
        #                       'target_pos': 3730,
        #                        'route': [2942, 3240, 3437, 3534, 3730], 'start_time': 0,
        #                        'end_time': 300
        #                        },
        #              'msg_id': 1,
        #              'receive_step': 0,
        #              'msg_type': None, 'msg_body': None, 'to_all': 0
        #              }
        mission = {
            "actor": self.seat,
            "type": 200,
            "info": {
                "company_id": list(self.team_info.keys())[1],
                "mission_type": mission_type,
                "target_pos": target_pos,
                "route": route,
                "start_time": start_time,
                "end_time": end_time,
            },
        }
        return mission

    def gen_cancel_battle_mission(self, msg_id):
        mission = {
            "actor": self.seat,
            "type": 202,    #   202:删除作战指令（包括战斗任务和方向）
            "msg_id": msg_id    #   "int 要删除的作战指令的id"
        }
        return mission

    def gen_fork(self, obj_id, candidate):
        prob = 0.01
        if random.random() < prob:
            return None
        return {"actor": self.seat, "obj_id": obj_id, "type": ActionType.Fork}

    def gen_union(self, obj_id, candidate):
        prob = 0.1
        if random.random() < prob:
            return None
        return {
            "actor": self.seat,
            "obj_id": obj_id,
            "target_obj_id": random.choice(candidate)["target_obj_id"],
            "type": ActionType.Union,
        }

    def gen_change_altitude(self, obj_id, candidate):
        prob = 0.05
        if random.random() < prob:
            return None
        return {
            "actor": self.seat,
            "obj_id": obj_id,
            "target_obj_id": random.choice(candidate)["target_altitude"],
            "type": ActionType.ChangeAltitude,
        }

    def gen_activate_radar(self, obj_id, candidate):
        prob = 1
        if random.random() < prob:
            return None
        return {"actor": self.seat, "obj_id": obj_id, "type": ActionType.ActivateRadar}

    def gen_enter_fort(self, obj_id, candidate):
        prob = 0.5
        if random.random() < prob:
            return None
        return {
            "actor": self.seat,
            "obj_id": obj_id,
            "type": ActionType.EnterFort,
            "target_obj_id": random.choice(candidate)["target_obj_id"],
        }

    def gen_exit_fort(self, obj_id, candidate):
        prob = 0.1
        if random.random() < prob:
            return None
        return {
            "actor": self.seat,
            "obj_id": obj_id,
            "type": ActionType.ExitFort,
            "target_obj_id": random.choice(candidate)["target_obj_id"],
        }

    def gen_lay_mine(self, obj_id, candidate):
        prob = 1
        if random.random() < prob:
            return None
        return {
            "actor": self.seat,
            "obj_id": obj_id,
            "type": 20,
            "target_pos": random.randint(0, 9177),
        }

    def gen_target_pos(self, mission_type):
        target_pos = None
        offense = None
        defense = None
        detect = None
        if self.scenario['scenario_id'].strip() == "2201010201":
            if self.color == 0:
                offense = [3533, 3532, 3433, 3332, 3331, 3530, 3631]
                defense = [2339, 2240, 2239, 2238, 2546, 2547, 3433]
                detect = [3430, 3431, 3432, 3433, 3532, 3531, 3530, 3529, 3528, 3629, 3830]
            else:
                offense = [3728, 3729, 3727, 3532, 3531, 3530, 3431, 3432]
                defense = [3728, 4327, 4426, 4428, 4928, 4929, 4727, 4729, 4725]
                detect = [3430, 3431, 3432, 3433, 3532, 3531, 3530, 3529, 3528, 3629, 3830]
        elif self.scenario['scenario_id'].strip() == "2201010202":
            if self.color == 0:
                offense = [3432, 3531, 3530, 3630, 3329, 3328, 3327, 3328]
                defense = [2546, 2547, 3433, 2339, 2240]
                detect = [3432, 3532, 3632, 3630, 3728, 3327, 3627, 3128]
            else:
                offense = [3630, 3327, 3426, 3326, 3729, 3730]
                defense = [4928, 4929, 3728, 3625, 4323, 4424, 4727, 4725]
                detect = [3432, 3532, 3632, 3630, 3728, 3327, 3627, 3128]
        if mission_type == 0:
            target_pos = offense
        elif mission_type == 1:
            target_pos = defense
        elif mission_type == 2:
            target_pos = detect

        return target_pos

    def gen_move_decided(self, obj_id, target_pos=None, route=None):
        bop = self.get_bop(obj_id)
        if bop["sub_type"] == 3 or (not target_pos and not route):  # 3-炮兵
            return
        if target_pos:
            destination = target_pos
        else:
            destination = route[-1]
        my_route = []
        if bop and bop["cur_hex"] != destination:
            move_type = self.get_move_type(bop)
            if not route:
                my_route = self.map.gen_move_route(bop["cur_hex"], destination, move_type)
            else:
                start_pos = bop["cur_hex"]
                route.append(destination)
                for pos in route:
                    tmp = self.map.gen_move_route(start_pos, pos, move_type)
                    for p in tmp:
                        my_route.append(p)
                    start_pos = pos
            return {
                "actor": self.seat,
                "obj_id": obj_id,
                "type": ActionType.Move,
                "move_path": my_route,
            }

    def get_see_scope(self, bop, target_type=0):
        """
        根据bop对target_type类型的观测距离，计算是否可见相应位置的该类算子
        注： 此处考虑了遮蔽地形，通视距离减半
            由于新引擎的observe_distance格式由dict类型变为list类型，因此target_type需要输入sub_type
        """
        try:
            bop_dis = bop['observe_distance'][target_type]  # 获得bop对target_bop的通视距离

            # 获得正方形区域
            row, col = bop['cur_hex'] // 100, bop['cur_hex'] % 100
            row0, row1 = min(row - bop_dis, 0), min(row + bop_dis + 1, self.map.max_row)
            col0, col1 = min(col - bop_dis, 0), min(col + bop_dis + 1, self.map.max_col)

            can_see_scope = set()
            for row_x in range(row0, row1):
                for col_x in range(col0, col1):
                    pos = row_x * 100 + col_x
                    if self.map.is_valid(pos) and self.map.can_see(bop['cur_hex'], pos):
                        dis = self.map.get_distance(bop['cur_hex'], pos)
                        tmp_bop_dis = int(bop_dis / 2) if self.map.is_in_cover(pos) else bop_dis  # 如果当前位置是遮蔽地形，则bop可观察距离减少一半
                        if dis <= tmp_bop_dis:
                            can_see_scope.add(pos)
            return can_see_scope
        except Exception as e:
            raise e

    def get_fire_scope(self, bop, target_type=2):
        try:
            can_see_scope = self.get_see_scope(bop)
            fire_scope = set()
            if target_type == 1:
                for can_see in can_see_scope:
                    dis = self.map.get_distance(bop['cur_hex'],can_see)
                    if dis <= 10:
                        fire_scope.add(can_see)
            elif target_type == 2:
                for can_see in can_see_scope:
                    dis = self.map.get_distance(bop['cur_hex'], can_see)
                    if dis <= 20:
                        fire_scope.add(can_see)
            return fire_scope
        except Exception as e:
            raise e

    def gen_send_string_message(self, to_all, msg_body):
        message = {
                "actor": self.seat,
                "type": 204,    #   204:发送聊天字符串，可以向己方或者所有人发送字符串信息
                "to_all": to_all,
                "msg_body": msg_body
            }
        return message


    def gen_send_graphic_message(self, msg_body, graphic_type, word="Show", color="#ffffff" , description="Description"):
        message = {
                "actor": self.seat,
                "type": 205,    #   发送辅助渲染信息，前端页面收到此动作之后将进行相应渲染
                "msg_body": {
                    "hexs": list(msg_body),
                    "graphic_type": graphic_type,
                    "word": word,
                    "color": color,
                    "description": description
                }
            }
        return message

    def gen_send_clear_render(self, msg_id):
        message = {
                "actor": self.seat,
                "type": 206,
                "clearing_msg_id": msg_id
            }
        return message

    def execute_mission(self, obj_id, mission_type):
        action = None
        bop = self.get_bop(obj_id)
        if mission_type == 0:
            pass
        elif mission_type == 1:
            pass
        elif mission_type == 2:
            pass

        return action

class BopType:
    Infantry, Vehicle, Aircraft = range(1, 4)


class ActionType:
    (
        Move,
        Shoot,
        GetOn,
        GetOff,
        Occupy,
        ChangeState,
        RemoveKeep,
        JMPlan,
        GuideShoot,
        StopMove,
        WeaponLock,
        WeaponUnFold,
        CancelJMPlan,
        Fork,
        Union,
        ChangeAltitude,
        ActivateRadar,
        EnterFort,
        ExitFort,
        LayMine,
    ) = range(1, 21)


class MoveType:
    Maneuver, March, Walk, Fly = range(4)
