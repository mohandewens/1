import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
import matplotlib.patches as mpathes
import os

class SeeMode:
    GroundToGround, SkyToSky, SkyToGround, GroundToSky = range(0, 4)
    @classmethod
    def get_name(self, value):
        new_dict = {v: k for k, v in self.__dict__.items()}
        return (new_dict[value])



class MyMap(object):

    def __init__(self, mapid, base_dir):
        # 读取see文件
        '''size = (3,row,col,row,col),0:地对地，1：空对空，2：空对地或地对空
        '''
        data_file = np.load(os.path.join(base_dir, 'map_' + str(mapid), 'see.npz'))
        self.see = data_file['data']


    def can_see(self, int4a, int4b, see_mode):
        if see_mode == SeeMode.GroundToSky:
            see_mode = SeeMode.SkyToGround
        row_start, col_start = cvtInt4loc2Offset(int4a)
        row_end, col_end = cvtInt4loc2Offset(int4b)
        can_see = self.see[see_mode][row_start][col_start][row_end][col_end]
        return can_see


    def get_see_array(self, int4a, see_mode):
        if isinstance(int4a, int):
            row_start, col_start = cvtInt4loc2Offset(int4a)
            see_list = self.see[see_mode][row_start][col_start]
            return np.array(see_list)
        elif isinstance(int4a, list):
            pos_tuple_list = cvtInt4loc2Offset(int4a)
            see_list = self.see[see_mode][tuple(zip(*pos_tuple_list))]
            return np.array(see_list).reshape(-1, *self.size)
        else:
            raise Exception


def cvtInt4loc2Offset(int4loc):
    if isinstance(int4loc, int):
        row, col = int4loc // 100, int4loc % 100
        return (row,col)
    elif isinstance(int4loc, list):
        int4loc = np.array(int4loc)
        row, col = int4loc // 100, int4loc % 100
        pos_tuple_list = list(zip(row, col))
        return pos_tuple_list


def cvtOffset2Int4loc(x=0, y=0):
    if isinstance(x, tuple):
        int4loc = x[0] * 100 + x[1]
        return int4loc
    elif isinstance(x, list):
        pos_np = np.array(list(zip(*x)))
        int4loc = pos_np[0] * 100 + pos_np[1]
        return list(int4loc)
    else:
        int4loc = x * 100 + y
        return int4loc


def from_pixel(x=0, y=0):
    if isinstance(x, tuple):
        row_pixel, col_pixel = x[0], x[1]
    else:
        row_pixel, col_pixel = x, y


    row = (row_pixel - 13) // 45
    if row % 2 == 0:
        col = col_pixel // 52

    else:
        col = (col_pixel -26) // 52
    if row < 0:
        row = 0
    if col < 0:
        col = 0

    return (int(row), int(col))


def to_pixel(x=0, y=0):
    if isinstance(x, tuple):
        row, col = x[0], x[1]
    else:
        row, col = x, y

    if row % 2 == 0:
        pixel_y = col * 52

    else:
        pixel_y = col * 52 + 26

    pixel_x = row * 45 + 13
    #得到x、y，六角格中心坐标
    x1, x2, x3, x4, x5, x6 = pixel_y-25, pixel_y, pixel_y+25+1, pixel_y+25+1, pixel_y, pixel_y-25
    y1, y2, y3, y4, y5, y6 = pixel_x-16, pixel_x-28, pixel_x-16, pixel_x+16, pixel_x+28+1, pixel_x+16
    center = (pixel_y,pixel_x)
    w=[(x1,y1),(x2,y2),(x3,y3),(x4,y4),(x5,y5),(x6,y6)]
    return center, w

#鼠标事件
def OnClick(event):
    if event.button == 1:
        ax = plt.gca()
        ax.clear()
        plt.imshow(img, animated=True)
        Coords_col = event.xdata
        Coords_row = event.ydata
        row, col = from_pixel(Coords_row, Coords_col)
        # print(Coords_row, Coords_col)
        # print(row,col)
        int4a = cvtOffset2Int4loc(row, col)
        # print(int4a)
        see_mode = SeeMode.GroundToGround
        see_np = map.get_see_array(int4a, see_mode)
        rows, cols = np.where(see_np == 1)
        center_start, _ = to_pixel(row, col)
        # print(center_start)
        polygon = mpathes.RegularPolygon(center_start, 5, 10, color='r')
        ax.add_patch(polygon)
        centers_end = []
        for row1, col1 in zip(rows, cols):
            if row1 == row and col1 == col:
                continue
            center, _ = to_pixel(row1, col1)
            centers_end.append(center)

        for center_end in centers_end:
            polygon = mpathes.RegularPolygon(center_end, 5, 10, color='g')
            ax.add_patch(polygon)
        ax.figure.canvas.draw()

def call_zoom(event):
    zoom_rate = 5.
    axtemp=event.inaxes
    x_loc = event.xdata
    y_loc = event.ydata
    x_min, x_max = axtemp.get_xlim()
    x_left = (x_loc - x_min) / zoom_rate
    x_right = (x_max - x_loc) / zoom_rate
    y_min, y_max = axtemp.get_ylim()
    y_left = (y_loc - y_min) / zoom_rate
    y_right = (y_max - y_loc) / zoom_rate
    if event.button == 'up':
        axtemp.set(xlim=(x_min + x_left, x_max - x_right))
        axtemp.set(ylim=(y_min + y_left, y_max - y_right))
        # print('up')
    elif event.button == 'down':
        axtemp.set(xlim=(x_min - x_left, x_max + x_right))
        axtemp.set(ylim=(y_min - y_left, y_max + y_right))
        # print('down')
    fig.canvas.draw_idle()  # 绘图动作实时反映在图像上

map_id = 53
base_map = '../../train_env/Data/map/'
base_pic = 'data/map/'
map = MyMap(map_id, base_map)
map_pic=os.path.join(base_pic, str(map_id), str(map_id)+'.jpg')
fig = plt.figure(figsize=(80, 80))
img = Image.open(map_pic)
plt.imshow(img, animated=True)
##关联鼠标点击事件
fig.canvas.mpl_connect('button_press_event', OnClick)
fig.canvas.mpl_connect('scroll_event', call_zoom)
plt.show()
