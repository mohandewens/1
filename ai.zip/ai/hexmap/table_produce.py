# # -*- coding: utf-8 -*-
# """
# Created on Mon Oct 15 14:35:20 2018
#
# @author: Hello！
# """
#
# import common, wgobject
import pandas as pd
import numpy as np
import os, glob, csv
import ai.hexmap.common as com
from ai.utils import util, rule, const, common
import threading
from multiprocessing import Pool
import copy
import numpy as np
import pickle




def produce_LOS(my_ai, map_dir):
    see_sources = [num for num in const.SeeSource.__dict__.values() if isinstance(num, int)]
    bop_types = [num for num in const.BopType.__dict__.values() if isinstance(num, int)]
    size = my_ai.my_map.size
    col_np, row_np = np.meshgrid(np.arange(size[1]), np.arange(size[0]))
    # print(row_np, col_np)
    index_list = (row_np * 100 + col_np).flatten().tolist()
    print(index_list)
    hide_cond_np = my_ai.my_map.get_hide_array(const.BopType.Infantry)
    hide_cond_np[hide_cond_np > 0.5] = True
    hide_cond_np[hide_cond_np <= 0.5] = False
    LOS_data = []
    be_LOS_data = []
    index_source = []
    index_type = []
    index_pos = []
    for see_source in see_sources:
        for bop_type in bop_types:  # bop_types:
            for pos in index_list:
                print(pos)
                index_source.append(see_source)
                index_type.append(bop_type)
                index_pos.append(pos)

                ####计算观察区
                if see_source == const.SeeSource.FromGround:
                    see_bop_type = const.BopType.Vehicle
                    be_bop_type = bop_type
                else:
                    see_bop_type = const.BopType.Aircraft
                    be_bop_type = bop_type
                see_mode = common.get_see_mode(see_bop_type, be_bop_type)
                see_array = my_ai.my_map.get_see_array(pos, see_mode)
                if be_bop_type == const.BopType.Infantry:
                    observe_range = my_ai.hex_cache.get_circle(pos, 0, 10)
                    hide_range = my_ai.hex_cache.get_circle(pos, 6, 10)
                    observe_np = np.zeros(size,dtype=np.bool)
                    observe_np[tuple(zip(*observe_range))] = True
                    hide_cond = copy.deepcopy(hide_cond_np)
                    hide_cond_mask = np.zeros_like(hide_cond, dtype=np.bool)
                    hide_cond_mask[tuple(zip(*hide_range))] = True
                    hide_cond = hide_cond & hide_cond_mask
                    observe_np[hide_cond == True] = False
                    observe = see_array & observe_np
                    LOS_data.append(observe.flatten())
                elif be_bop_type == const.BopType.Vehicle:
                    observe_range = my_ai.hex_cache.get_circle(pos, 0, 25)
                    hide_range = my_ai.hex_cache.get_circle(pos, 13, 25)
                    observe_np = np.zeros(size, dtype=np.bool)
                    observe_np[tuple(zip(*observe_range))] = True
                    hide_cond = copy.deepcopy(hide_cond_np)
                    hide_cond_mask = np.zeros_like(hide_cond, dtype=np.bool)
                    hide_cond_mask[tuple(zip(*hide_range))] = True
                    hide_cond = hide_cond & hide_cond_mask
                    observe_np[hide_cond == True] = False
                    observe = see_array & observe_np
                    LOS_data.append(observe.flatten())
                else:
                    observe_range = my_ai.hex_cache.get_circle(pos, 0, 25)
                    observe_np = np.zeros(size, dtype=np.bool)
                    observe_np[tuple(zip(*observe_range))] = True
                    observe = see_array & observe_np
                    LOS_data.append(observe.flatten())



                # 计算被观察区
                if see_source == const.SeeSource.FromGround:
                    see_bop_type = const.BopType.Vehicle
                    be_bop_type = bop_type
                else:
                    see_bop_type = const.BopType.Aircraft
                    be_bop_type = bop_type
                see_mode = common.get_see_mode(see_bop_type, be_bop_type)
                see_array = my_ai.my_map.get_see_array(pos, see_mode)
                row, col = com.cvtInt4loc2Offset(pos)
                if be_bop_type == const.BopType.Infantry:
                    if hide_cond_np[row, col]:
                        observe_range = my_ai.hex_cache.get_circle(pos, 0, 5)
                    else:
                        observe_range = my_ai.hex_cache.get_circle(pos, 0, 10)
                    observe_np = np.zeros(size,dtype=np.bool)
                    observe_np[tuple(zip(*observe_range))] = True
                    observe = see_array & observe_np
                    be_LOS_data.append(observe.flatten())
                elif be_bop_type == const.BopType.Vehicle:
                    if hide_cond_np[row, col]:
                        observe_range = my_ai.hex_cache.get_circle(pos, 0, 12)
                    else:
                        observe_range = my_ai.hex_cache.get_circle(pos, 0, 25)
                    observe_np = np.zeros(size, dtype=np.bool)
                    observe_np[tuple(zip(*observe_range))] = True
                    observe = see_array & observe_np
                    be_LOS_data.append(observe.flatten())
                else:
                    observe_range = my_ai.hex_cache.get_circle(pos, 0, 25)
                    observe_np = np.zeros(size, dtype=np.bool)
                    observe_np[tuple(zip(*observe_range))] = True
                    observe = see_array & observe_np
                    be_LOS_data.append(observe.flatten())

    LOS_np = np.vstack(LOS_data)
    be_LOS_np = np.vstack(be_LOS_data)

    index = []
    index.append(index_source)
    index.append(index_type)
    index.append(index_pos)
    columns = index_list
    be_LOS = pd.DataFrame(data=be_LOS_np, index=index,columns=columns)#.set_index(['see_source', 'bop_type', 'grid_pos'])
    LOS = pd.DataFrame(data=LOS_np, index=index,columns=columns)#.set_index(['see_source', 'bop_type', 'grid_pos'])

    be_LOS.to_pickle(os.path.join(map_dir, 'be_LOS.pkl'))
    LOS.to_pickle(os.path.join(map_dir, 'LOS.pkl'))

############产生观察表，三级索引'see_source', 'bop_type', 'grid_pos'，视线来源、被看棋子类型、被看位置
def one_row_LOS(row, col, be_see_type, see_source, see_mode, my_map):
    row_size = my_map.size[0]
    col_size = my_map.size[1]
    be_see_pos = com.cvtOffset2Int4loc(row, col)
    LOS_array = np.zeros((row_size, col_size))  # 初始化数组
    for i in range(row_size):
        for j in range(col_size):
            see_pos = com.cvtOffset2Int4loc(i, j)
            observe = rule.can_observe(be_see_type, see_pos, be_see_pos, see_mode, my_map)
            if observe:
                LOS_array[i, j] = 1
    row_data = [see_source, be_see_type, be_see_pos]
    row_data.extend(LOS_array.ravel())
    return row_data

def get_one_row_LOS(row, be_see_type, see_source, see_mode, my_map, columns, save_dir):  #算子在指定位置可被观察到的范围 # 算子类型 人：0，车：1，直升机：2
    col_size = my_map.size[1]
    point_LOS = []
    for col in range(col_size):
        row_data = one_row_LOS(row, col, be_see_type, see_source, see_mode, my_map)
        point_LOS.append(row_data)
    row_LOS = np.vstack(point_LOS)
    print(row_LOS.shape)
    row_LOS_pd = pd.DataFrame(data=row_LOS, columns=columns, dtype=int)
    file_name = str(see_source) + '-' + str(be_see_type) + '-' + str(row) + '.csv'
    row_LOS_pd.to_csv(os.path.join(save_dir, file_name), index=False, header=True)

def get_see_mode(see_source, bop_type):
    if see_source == const.SeeSource.FromSky:
        if bop_type == const.BopType.Aircraft:
            return const.SeeMode.SkyToSky
        else:
            return const.SeeMode.SkyToGround
    else:
        if bop_type == const.BopType.Aircraft:
            return const.SeeMode.GroundToSky
        else:
            return const.SeeMode.GroundToGround

def multi_LOS(z):
    return get_one_row_LOS(*z)


def make_los(my_map, save_dir):
    row_size = my_map.size[0]
    col_size = my_map.size[1]
    index_array = np.zeros((row_size, col_size), dtype=int)
    for i in range(row_size):
        for j in range(col_size):
            Int4loc = i * 100 + j
            index_array[i, j] = int(Int4loc)
    index_array.reshape(row_size * col_size)
    columns = np.append(['see_source', 'bop_type', 'grid_pos'], index_array)
    print(columns)
    see_sources = [num for num in const.SeeSource.__dict__.values() if isinstance(num, int)]
    bop_types = [num for num in const.BopType.__dict__.values() if isinstance(num, int)]
    for see_source in see_sources:
        for bop_type in bop_types:  #bop_types:
            see_mode = get_see_mode(see_source, bop_type)
            para = [(row, bop_type, see_source, see_mode, my_map, columns, save_dir) for row in range(row_size)]
            pool = Pool()
            pool.map(multi_LOS, para)
            pool.close()
            pool.join()
############################################



#########################产生通视表
def getRangeOfsee(position_row, position_col, map, mapsize, mode):  #算子在指定位置可被观察到的范围 # 算子类型 人：1，车：2
    row_size = mapsize[0]
    col_size = mapsize[1]
    position = position_row * 100 + position_col

    see_available_array = np.zeros((row_size, col_size))  #初始化数组

    for i in range(row_size):
        for j in range(col_size):
            Int4loc = i * 100 + j
            can_see = map.can_see(position, Int4loc, mode)
            if can_see:
                see_available_array[i][j] = 1

    return see_available_array


def make_see(map, my_map, save_dir):
    row_size = my_map.size[0]
    col_size = my_map.size[1]
    index_array = np.zeros((row_size, col_size), dtype=int)
    for i in range(row_size):
        for j in range(col_size):
            Int4loc = i * 100 + j
            index_array[i, j] = int(Int4loc)
    index_array.reshape(row_size * col_size)
    columns = np.append(['mode', 'grid_pos'], index_array)
    print(columns)
    see_list = []
    for mode in range(4):
        for i in range(row_size):
            print(i)
            for j in range(col_size):
                Int4loc = i * 100 + j
                see_array = getRangeOfsee(i, j, map, my_map.size, mode)
                row = [mode, Int4loc]
                row.extend(see_array.ravel())
                see_list.append(row)
    see_array = np.vstack(see_list)
    print(see_array.shape)
    see_pd = pd.DataFrame(data=see_array, columns=columns, dtype=int)
    see_pd.to_csv(os.path.join(save_dir, 'can_see.csv'), index=False, header=True)
################################


####################产生机动时间表
def get_maneuver_time(my_ai, save_dir):
    my_map = my_ai.my_map
    row_size = my_map.size[0]
    col_size = my_map.size[1]
    index_array = np.zeros((row_size, col_size), dtype=int)
    for i in range(row_size):
        for j in range(col_size):
            Int4loc = i * 100 + j
            index_array[i, j] = int(Int4loc)
    index_array.reshape(row_size * col_size)
    columns = np.append(['bop_type', 'grid_pos'], index_array)
    print(columns)
    scenario_info = my_ai.scenario_info
    bops = []
    bops.extend(scenario_info['operators'])
    bops.extend(scenario_info['passengers'])
    for bop_type in range(1,4):
        bop = common.get_bop_type(bops, bop_type)[0]
        para = [(i, columns, bop, bop_type, my_map, save_dir) for i in range(row_size)]
        pool = Pool(20)
        pool.map(multi_para, para)
        pool.close()
        pool.join()


def multi_para(z):
	return pool_maneuver_time(z[0], z[1], z[2], z[3], z[4], z[5])


def pool_maneuver_time(i, columns, bop, bop_type, my_map, save_dir):
    col_size = my_map.size[1]

    maneuver_time = []
    threads = [threading.Thread(target=threading_maneuver_time, args=(maneuver_time, i, j, bop, bop_type, my_map)) for j in range(col_size)]
    for fun in threads:
        fun.start()
    for fun in threads:
        fun.join()

    maneuver_time = np.vstack(maneuver_time)
    print(maneuver_time.shape)
    maneuver_time_pd = pd.DataFrame(data=maneuver_time, columns=columns)
    file_name = str(bop_type) + '-' + str(i) + '.csv'
    maneuver_time_pd.to_csv(os.path.join(save_dir, file_name), index=False, header=True)


def threading_maneuver_time(maneuver_time, i, j, bop, bop_type, my_map):
    Int4loc = i * 100 + j
    print(Int4loc)
    maneuver_time_array = util.get_maneuver_time_matrix(bop, Int4loc, my_map)

    row = [bop_type, Int4loc]
    row.extend(list(maneuver_time_array.flatten()))
    lock = threading.Lock()
    lock.acquire()
    maneuver_time.append(row)
    lock.release()
####################################


###########多进程生成的csv文件合并
def maneuver_file_append(file_dir, save_dir):
    data = []
    for csv_file in glob.glob(os.path.join(file_dir, '*.csv')):
        data_csv = pd.read_csv(csv_file)
        data_temp = data_csv.values
        data.append(data_temp)
    data_np = np.vstack(data)
    print(data_np.shape)
    maneuver_time = pd.DataFrame(data=data_np, columns=data_csv.columns, dtype=int)
    maneuver_time.sort_values(['bop_type', 'grid_pos'], ascending=[True, True], inplace=True)  # 升序
    maneuver_time.to_csv(os.path.join(save_dir, 'maneuver_time.csv'), index=False, header=True)
    np.save(save_dir+'/maneuver_time', maneuver_time.values[:, 2:].reshape(3,70,60,70,60))


##################################


def LOS_file_append(file_dir, save_dir):
    data = []
    for csv_file in glob.glob(os.path.join(file_dir, '*.csv')):
        data_csv = pd.read_csv(csv_file)
        data_temp = data_csv.values
        data.append(data_temp)
    data_np = np.vstack(data)
    print(data_np.shape)
    LOS_pd_pd = pd.DataFrame(data=data_np, columns=data_csv.columns, dtype=int)
    LOS_pd_pd.sort_values(['see_source', 'bop_type', 'grid_pos'], ascending=[True, True, True], inplace=True)  # 升序
    LOS_pd_pd.to_csv(os.path.join(save_dir, 'LOS.csv'), index=False, header=True)

##################################


def pd_to_npz(name, save_file):
    file_name = os.path.join(save_file, name + '.csv')
    data_pd = pd.read_csv(file_name)
    columns = np.array(data_pd.columns)
    data = data_pd.values
    print(type(columns), type(data))
    columns_name = os.path.join(save_file, name + '_columns.npy')
    data_name = os.path.join(save_file, name + '_data.npz')
    np.save(columns_name, columns)
    sparse.save_npz(data_name, sparse.csr_matrix(data))


def pkl_to_npz(name, save_file):
    with open(save_file+'/{}.pkl'.format(name), 'rb') as file:
        array = pickle.load(file)


    np.save(save_file+'/{}'.format(name), array.values.reshape(2, 3,70,60,70,60))
    # sparse.save_npz(data_name, sparse.csr_matrix(data))

if __name__ == '__main__':
    # for id in [221]:
    #     print(id)
    #     file_dir = '../hexmap/data/map/{}/Jidong'.format(id)
    #     file_dir1 = '../hexmap/data/map/{}/LOS'.format(id)
    #     save_dir = '../hexmap/data/map/{}'.format(id)
    #     maneuver_file_append(file_dir, save_dir)  # jidongshijian

        # LOS_file_append(file_dir1, save_dir)
    for id in [221]:
        print(id)
        save_file = '../hexmap/data/map/{}/LOS'.format(id)
        name = 'maneuver_time'
        name = 'be_LOS'
        pkl_to_npz(name, save_file)
        name = 'LOS'
        pkl_to_npz(name, save_file)

