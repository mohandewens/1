import heapq
from .hex import BoundedHex
from ..utils import rule, const, util
from . import common as com
import numpy as np

class Node(BoundedHex):
    def __init__(self, *args, **kwargs):
        super(Node, self).__init__(*args, **kwargs)
        self.parent = None
        self.cost = 0
        self.road = False

    def cost_to(self, bop, dest, basic_time, see, map, march_mode):
        row_start, col_start = self.loc()
        row_end, col_end = dest.loc()
        maneuver_time = see.maneuver_time_np[bop['type'] - 1, row_start, col_start, row_end, col_end]
        if march_mode:  # 机动的计算使用基本时间单位，行军的计算直接使用时间s
            if map.have_road(self):
                return maneuver_time / 2
        return maneuver_time / basic_time

    def cost_neigh_to(self, neigh, bop, map, march_mode):
        if march_mode:  # 机动的计算使用基本时间单位，行军的计算直接使用时间s
            if map.road_link(self, neigh):
                neigh.road = True
                time = rule.get_march_time(bop, self, neigh, map)

            else:
                time = rule.get_maneuver_time(bop, self, neigh, map)

                if map.have_road(self):
                    time += rule.state_change_time * 2 #由行军转机动消耗的时间，机动行军切换时需要停止75秒和状态切换75秒

        else:
            time = rule.get_maneuver_time(bop, self, neigh, map, only_cost=True)
        return time

    def blocked(self, bop, hexb, map, no_pass_tuple_list=[], pass_tuple_list=[]):
        # 不在地图范围
        if not map.in_map(self.row, self.col):
            return True
        # 按规则不能通行
        if not rule.can_go(bop, self, hexb, map):
            return True
        # 在不可通行的列表内
        if self.loc() in no_pass_tuple_list:
            return True
        # 在可通行的列表内
        if pass_tuple_list:
            if self.loc() not in pass_tuple_list:
                return True
        return False


def offset2int4(row, col):
    return row * 100 + col


def int42offset(int4):
    row, col = int(int4 // 100), int(int4 % 100)
    return row, col


def retrace(c, march_mode):
    if march_mode:
        path = [c, ]
        while c.parent is not None:
            c = c.parent
            path.append(c)
        path.reverse()

        mode = const.MoveType.Maneuver if not path[0].road else const.MoveType.March
        dic = {'mode': mode,
               'path': []}
        path_march = [dic]
        last_road_flag = path[0].road
        for node in path[1:]:
            if last_road_flag == node.road:
                path_march[-1]['path'].append(offset2int4(*node.loc()))
            else:
                last_road_flag = node.road
                mode = const.MoveType.Maneuver if not node.road else const.MoveType.March
                if mode == const.MoveType.March:
                    path[-1].cost += rule.state_change_time * 2  # 有机动转行军消耗时间，切换状态，加上停止和状态转换的时间

                path_march.append({'mode': mode, 'path': []})
                path_march[-1]['path'].append(offset2int4(*node.loc()))
        if path[-1].road:
            path[-1].cost += rule.state_change_time * 2  # 如果终点在道路上，加上停止和状态转换的时间
        for dic_temp in path_march:
            if dic_temp['mode'] == const.MoveType.March:
                path[-1].cost += rule.state_change_time * 2  # 如果发生了行军，加上武器收拢和展开的时间
                break
        return path[-1].cost, path_march
    else:
        path = [c, ]
        while c.parent is not None:
            c = c.parent
            path.append(c)
        path.reverse()
        path_in4_list = [offset2int4(*node.loc()) for node in path]
        return path[-1].cost, path_in4_list[1:]


def astar(bop, start_int4, end_int4, my_ai, time_mode=True, no_pass=[], march_mode=False, maxsteps=2000, **kwargs):
    if start_int4 == end_int4:
        return list()
    no_pass = [int42offset(int4) for int4 in no_pass]
    beta = 0
    if march_mode:
        _, route = astar_search(bop, start_int4, end_int4, my_ai, no_pass, march_mode, maxsteps, beta, attri_combine=None)
        return route
    else:
        if time_mode:
            _, route = astar_search(bop, start_int4, end_int4, my_ai, no_pass, march_mode, maxsteps, beta, attri_combine=None)
        else:
            attri_combine = calcu_multi_attribute(my_ai, bop, **kwargs)
            beta = kwargs['beta']
            _, route = astar_search(bop, start_int4, end_int4, my_ai, no_pass, march_mode, maxsteps, beta, attri_combine=attri_combine)
    return route


def astar_search(bop, start_int4, end_int4, my_ai, no_pass, march_mode, maxsteps, beta, attri_combine=None):
    basic_time = my_ai.my_map.dis_between_hex / (bop['basic_speed'] * 1000 / 3600)

    heap = list()
    open = set()
    closed = set()
    current = Node(start_int4)
    end = Node(end_int4)
    open.add(current)
    heap.append((0, current))
    while maxsteps > 0 and open:
        maxsteps -= 1
        current = heapq.heappop(heap)[1]
        if current == end:
            return retrace(current, march_mode)
        open.remove(current)
        closed.add(current)
        for node in current.sixpack():
            node = Node(node)
            if node in closed:
                continue
            if node.blocked(bop, current, my_ai.my_map, no_pass_tuple_list=no_pass, pass_tuple_list=[]):
                closed.add(node)
                continue
            if attri_combine:
                attri = attri_combine[node.loc()]
            else:
                attri = 0
            new_cost = current.cost + current.cost_neigh_to(node, bop, my_ai.my_map, march_mode) + beta * attri
            if node in open:
                if node.cost > new_cost:
                    node.cost = new_cost
                    node.parent = current
            else:
                node.cost = new_cost
                node.parent = current
                open.add(node)
                heapq.heappush(heap, (node.cost_to(bop, end, basic_time, my_ai.see, my_ai.my_map, march_mode) + node.cost, node))

    return 0, list()


def calcu_multi_attribute(my_ai, bop, **kwargs):
    combine = np.zeros(my_ai.my_map.size)
    # 综合各项因素， 因素值越大越好
    '''
    kwargs = {'beta': 0,
              'hide_cond': 1,
              'shoot_ability': 1,
              'be_shoot_ability': 0.5,
              'be_shoot_ability_aircraft': 0.5,
              'observe_enemy_ability': 0,
              'be_observed_enemy_ability': 0}
    '''
    # with com.Timer(f'备选点数量为{len(pos_int4)}, 关键点选取消耗时间'):
    for key, value in kwargs.items():
        if key == 'hide_cond' and value > 0:
            hide_cond = my_ai.my_map.get_hide_array(bop['type'])
            combine += value * (1 - com.normalization(hide_cond))

        if key == 'shoot_ability' and value > 0:
            shoot_ability = my_ai.enemy_predict.get_attribute_array(bop, my_ai, 'attack_ability', ubop_type=None)
            combine += value * (1 - com.normalization(shoot_ability))

        if key == 'be_shoot_ability' and value > 0:
            be_shoot_ability = my_ai.enemy_predict.get_attribute_array(bop, my_ai, 'be_attacked_value', ubop_type=None)
            combine += value * com.normalization(be_shoot_ability)

        if key == 'be_shoot_ability_aircraft' and value > 0:
            be_shoot_ability = my_ai.enemy_predict.get_attribute_array(bop, my_ai, 'be_attacked_value', ubop_type=const.BopType.Aircraft)
            combine += value * com.normalization(be_shoot_ability)

        if key == 'observe_enemy_ability' and value > 0:
            observe_enemy_ability = my_ai.enemy_predict.get_attribute_array(bop, my_ai, 'observe_ability', ubop_type=None)
            combine += value * (1 - com.normalization(observe_enemy_ability))

        if key == 'be_observed_enemy_ability' and value > 0:
            observe_enemy_ability = my_ai.enemy_predict.get_attribute_array(bop, my_ai, 'be_observed_value', ubop_type=None)
            combine += value * com.normalization(observe_enemy_ability)
    return combine