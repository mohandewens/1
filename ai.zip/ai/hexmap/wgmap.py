# -*- coding: utf-8 -*-
"""

"""
import pandas as pd
import os, math
from ..utils import const, util
from . import common as com
import numpy as np
import gc
from ..utils import common


# class MyMap(object):
#     def __init__(self, official_map):
#         terrain = official_map._terrain
#         # 读取关键信息
#         self.map_id = terrain.terrain_id
#         self.SlopeGrade = terrain.SlopeGrade
#         self.base_elevation = terrain.basic_data['ele_grade']
#         self.dis_between_hex = terrain.dis_between_hex
#         self.size = (terrain.map_row, terrain.map_col)
#         self.march_cost_ratio = terrain.march_cost_ratio
#         # 读取basic文件
#         '''格式：[[dic]]
#         dic：
#         pos int 4 位整形坐标
#         elev int 坐标高程
#         cond int 坐标地形类型
#         0-开阔地 1-丛林地 2-居民地 3-松软地 4-河流
#         roads list 六个方向上道路类型0-无 1-黑色 2-红色 3-黄色
#         rivers list 六个方向上河流0-无 1-有
#         neighbors list 六个方向上邻域坐标，无效坐标为-1
#         '''
#         self.map_basic = terrain.basic_map_data
#
#         # 读取cost文件
#         '''size= (4,row,col)dic={key位置坐标：value基本时间倍数}.0:普通机动，1：高速行军，2：人员机动；3：飞行器机动
#         '''
#         self.map_cost = terrain.cost_data
#
#         # 读取see文件
#         '''size = (3,row,col,row,col),0:地对地，1：空对空，2：空对地或地对空
#         '''
#         self.see = terrain.see_data
#
#         self.hide_road_array, self.only_forest_array, self.only_resident_array, self.elevation_array = self.get_hide_cond()
#
#         # rows, cols = np.where(self.only_forest_array==1)
#         # postion_list = list(zip(rows, cols))
#         # util.plot_hex(postion_list, self.map_id, see_int4=None, blend_level=0.9, text=[])
#
#     def can_see(self, int4a, int4b, see_mode):
#         if see_mode == const.SeeMode.GroundToSky:
#             see_mode = const.SeeMode.SkyToGround
#         row_start, col_start = com.cvtInt4loc2Offset(int4a)
#         row_end, col_end = com.cvtInt4loc2Offset(int4b)
#         can_see = self.see[see_mode][row_start][col_start][row_end][col_end]
#         return can_see
#
#     def get_see_array(self, int4a, see_mode):
#         if isinstance(int4a, int):
#             row_start, col_start = com.cvtInt4loc2Offset(int4a)
#             see_list = self.see[see_mode][row_start][col_start]
#             return np.array(see_list)
#         elif isinstance(int4a, list):
#             pos_tuple_list = com.cvtInt4loc2Offset(int4a)
#             rows, cols = zip(*pos_tuple_list)
#             see_list = self.see[see_mode, rows, cols]
#             return see_list #np.array(see_list).reshape(-1, *self.size)
#         else:
#             raise Exception
#
#     def is_hide_point(self, int4):
#         row,col = com.cvtInt4loc2Offset(int4)
#         hide_road, only_forest, only_resident = self.hide_road_array[row, col], \
#                                                 self.only_forest_array[row, col], \
#                                                 self.only_resident_array[row, col]
#         if (hide_road + only_forest + only_resident) > 0:
#             return True
#         else:
#             return False
#
#     def get_hide_array(self, bop_type):
#         if bop_type == const.BopType.Vehicle:
#             return self.hide_road_array + self.only_forest_array + self.only_resident_array
#         else:
#             return self.hide_road_array + self.only_forest_array + self.only_resident_array
#
#     def getGrid_offset(self, row, col):
#         return self.map_basic[row][col]
#
#     def get_ele_diff(self, hexa_tuple, hexb_tuple):
#         hexa_elevation = self.getGrid_offset(*hexa_tuple)['elev']
#         hexb_elevation = self.getGrid_offset(*hexb_tuple)['elev']
#         elevation_diff = hexb_elevation - hexa_elevation
#         if elevation_diff >= 0:
#             result = math.floor(elevation_diff // 20)
#         else:
#             result = math.ceil(elevation_diff // 20)
#         return result
#
#     def get_cost(self, hexa, hexb, bop_type, march=False):
#         assert hexa.distance_to(hexb) == 1
#         if bop_type == 1 or bop_type == 3 :  # 为人员或是空中算子
#             return 1
#         '''size= (4,row,col)dic={key位置坐标：value基本时间倍数}.0:普通机动，1：高速行军，2：人员机动；3：飞行器机动
#                 '''
#         if march:
#             cost_type = 1
#         elif bop_type == const.BopType.Vehicle:
#             cost_type = 0
#         elif bop_type == const.BopType.Infantry:
#             cost_type = 2
#         elif bop_type == const.BopType.Aircraft:
#             cost_type = 3
#         else:
#             raise Exception
#         row_start, col_start = hexa.loc()
#         int4b = com.cvtOffset2Int4loc(hexb.loc())
#         cost_dict = self.map_cost[cost_type][row_start][col_start]
#         if int4b in list(cost_dict.keys()):
#             return cost_dict[int4b]
#         else:
#             return None
#
#     def road_link(self, hexa, hexb):
#         assert hexa.distance_to(hexb) == 1
#         hex_start = self.getGrid_offset(hexa.row, hexa.col)
#         roads = hex_start['roads']
#         hex_end_int4 = com.cvtOffset2Int4loc(hexb.loc())
#         road_index = hex_start['neighbors'].index(hex_end_int4)
#         if roads[road_index] == 0:
#             return False
#         else:
#             return True
#
#     def have_road(self, hex):
#         map_hex = self.getGrid_offset(hex.row, hex.col)
#         roads = map_hex['roads']
#         if np.array(roads).any():
#             return True
#         else:
#             return False
#
#     def in_map(self, row, col):
#         if 0 <= row <= self.size[0]-1 and 0 <= col <= self.size[1]-1:
#             return True
#         else:
#             return False
#
#     def is_resident(self, int4):
#         row, col = com.cvtInt4loc2Offset(int4)
#         map_end = self.getGrid_offset(row, col)
#         if map_end['cond'] == 2:  # 普通地形道路穿过居民地
#             return True
#         else:
#             return False
#
#     def is_forest(self, int4):
#         row, col = com.cvtInt4loc2Offset(int4)
#         map_end = self.getGrid_offset(row, col)
#         if map_end['cond'] == 1:  # 丛林地
#             return True
#         else:
#             return False
#
#     def is_waters(self, int4):
#         row, col = com.cvtInt4loc2Offset(int4)
#         map_end = self.getGrid_offset(row, col)
#         if map_end['cond'] == 4 and np.array(map_end['rivers']).all():  # 水域
#             return True
#         return False
#
#     def get_hide_cond(self):
#         hide_road_array = np.zeros(self.size).astype(int)
#         only_forest_array = np.zeros(self.size).astype(int)
#         only_resident_array = np.zeros(self.size).astype(int)
#         elevation = np.zeros_like(hide_road_array)
#         for row in range(self.size[0]):
#             for col in range(self.size[1]):
#                 map_hex = self.getGrid_offset(row, col)
#                 elevation[row, col] = map_hex['elev']
#                 if (map_hex['cond'] == 1 or map_hex['cond'] == 2) and np.array(map_hex['roads']).any():  # 普通地形道路穿过普通地形
#                     hide_road_array[row, col] = 1
#
#                 if map_hex['cond'] == 1:  # 丛林地
#                     only_forest_array[row, col] = 1
#
#                 if map_hex['cond'] == 2:  # 普通居民地
#                     only_resident_array[row, col] = 1
#         elevation = com.normalization(elevation) * 0.5 + 0.5
#         return hide_road_array, only_forest_array, only_resident_array, elevation

class MyMap(object):
    def __init__(self, official_map):
        # terrain = official_map._terrain
        # # 读取关键信息
        # self.map_id = terrain.terrain_id
        # self.SlopeGrade = terrain.SlopeGrade
        # self.base_elevation = terrain.basic_data['ele_grade']
        # self.dis_between_hex = terrain.dis_between_hex
        # self.size = (terrain.map_row, terrain.map_col)
        # self.march_cost_ratio = terrain.march_cost_ratio

        terrain = official_map
        self.map_id = 221
        self.dis_between_hex = 1
        self.size = (terrain.max_row, terrain.max_col)

        # 读取basic文件
        '''格式：[[dic]] 
        dic：
        pos int 4 位整形坐标
        elev int 坐标高程
        cond int 坐标地形类型
        0-开阔地 1-丛林地 2-居民地 3-松软地 4-河流
        roads list 六个方向上道路类型0-无 1-黑色 2-红色 3-黄色
        rivers list 六个方向上河流0-无 1-有
        neighbors list 六个方向上邻域坐标，无效坐标为-1
        '''
        # self.map_basic = terrain.basic_map_data
        self.map_basic = terrain.basic

        # 读取cost文件
        '''size= (4,row,col)dic={key位置坐标：value基本时间倍数}.0:普通机动，1：高速行军，2：人员机动；3：飞行器机动
        '''
        # self.map_cost = terrain.cost_data
        self.map_cost = terrain.cost

        # 读取see文件
        '''size = (3,row,col,row,col),0:地对地，1：空对空，2：空对地或地对空
        '''
        # self.see = terrain.see_data
        self.see = terrain.see

        self.hide_road_array, self.only_forest_array, self.only_resident_array, self.elevation_array = self.get_hide_cond()

        # rows, cols = np.where(self.only_forest_array==1)
        # postion_list = list(zip(rows, cols))
        # util.plot_hex(postion_list, self.map_id, see_int4=None, blend_level=0.9, text=[])

    def can_see(self, int4a, int4b, see_mode):
        if see_mode == const.SeeMode.GroundToSky:
            see_mode = const.SeeMode.SkyToGround
        row_start, col_start = com.cvtInt4loc2Offset(int4a)
        row_end, col_end = com.cvtInt4loc2Offset(int4b)
        can_see = self.see[see_mode][row_start][col_start][row_end][col_end]
        return can_see

    def get_see_array(self, int4a, see_mode):
        if isinstance(int4a, int):
            row_start, col_start = com.cvtInt4loc2Offset(int4a)
            see_list = self.see[see_mode][row_start][col_start]
            return np.array(see_list)
        elif isinstance(int4a, list):
            pos_tuple_list = com.cvtInt4loc2Offset(int4a)
            rows, cols = zip(*pos_tuple_list)
            see_list = self.see[see_mode, rows, cols]
            return see_list  # np.array(see_list).reshape(-1, *self.size)
        else:
            raise Exception

    def is_hide_point(self, int4):
        row, col = com.cvtInt4loc2Offset(int4)
        hide_road, only_forest, only_resident = self.hide_road_array[row, col], \
                                                self.only_forest_array[row, col], \
                                                self.only_resident_array[row, col]
        if (hide_road + only_forest + only_resident) > 0:
            return True
        else:
            return False

    def get_hide_array(self, bop_type):
        if bop_type == const.BopType.Vehicle:
            return self.hide_road_array + self.only_forest_array + self.only_resident_array
        else:
            return self.hide_road_array + self.only_forest_array + self.only_resident_array

    def getGrid_offset(self, row, col):
        return self.map_basic[row][col]

    def get_ele_diff(self, hexa_tuple, hexb_tuple):
        hexa_elevation = self.getGrid_offset(*hexa_tuple)['elev']
        hexb_elevation = self.getGrid_offset(*hexb_tuple)['elev']
        elevation_diff = hexb_elevation - hexa_elevation
        if elevation_diff >= 0:
            result = math.floor(elevation_diff // 20)
        else:
            result = math.ceil(elevation_diff // 20)
        return result

    def get_cost(self, hexa, hexb, bop_type, march=False):
        assert hexa.distance_to(hexb) == 1
        if bop_type == 1 or bop_type == 3:  # 为人员或是空中算子
            return 1
        '''size= (4,row,col)dic={key位置坐标：value基本时间倍数}.0:普通机动，1：高速行军，2：人员机动；3：飞行器机动
                '''
        if march:
            cost_type = 1
        elif bop_type == const.BopType.Vehicle:
            cost_type = 0
        elif bop_type == const.BopType.Infantry:
            cost_type = 2
        elif bop_type == const.BopType.Aircraft:
            cost_type = 3
        else:
            raise Exception
        row_start, col_start = hexa.loc()
        int4b = com.cvtOffset2Int4loc(hexb.loc())
        cost_dict = self.map_cost[cost_type][row_start][col_start]
        if int4b in list(cost_dict.keys()):
            return cost_dict[int4b]
        else:
            return None

    def road_link(self, hexa, hexb):
        assert hexa.distance_to(hexb) == 1
        hex_start = self.getGrid_offset(hexa.row, hexa.col)
        roads = hex_start['roads']
        hex_end_int4 = com.cvtOffset2Int4loc(hexb.loc())
        road_index = hex_start['neighbors'].index(hex_end_int4)
        if roads[road_index] == 0:
            return False
        else:
            return True

    def have_road(self, hex):
        map_hex = self.getGrid_offset(hex.row, hex.col)
        roads = map_hex['roads']
        if np.array(roads).any():
            return True
        else:
            return False

    def in_map(self, row, col):
        if 0 <= row <= self.size[0] - 1 and 0 <= col <= self.size[1] - 1:
            return True
        else:
            return False

    def is_resident(self, int4):
        row, col = com.cvtInt4loc2Offset(int4)
        map_end = self.getGrid_offset(row, col)
        if map_end['cond'] == 2:  # 普通地形道路穿过居民地
            return True
        else:
            return False

    def is_forest(self, int4):
        row, col = com.cvtInt4loc2Offset(int4)
        map_end = self.getGrid_offset(row, col)
        if map_end['cond'] == 1:  # 丛林地
            return True
        else:
            return False

    def is_waters(self, int4):
        row, col = com.cvtInt4loc2Offset(int4)
        map_end = self.getGrid_offset(row, col)
        if map_end['cond'] == 4 and np.array(map_end['rivers']).all():  # 水域
            return True
        return False

    def get_hide_cond(self):
        hide_road_array = np.zeros(self.size).astype(int)
        only_forest_array = np.zeros(self.size).astype(int)
        only_resident_array = np.zeros(self.size).astype(int)
        elevation = np.zeros_like(hide_road_array)
        for row in range(self.size[0]):
            for col in range(self.size[1]):
                map_hex = self.getGrid_offset(row, col)
                elevation[row, col] = map_hex['elev']
                if (map_hex['cond'] == 1 or map_hex['cond'] == 2) and np.array(map_hex['roads']).any():  # 普通地形道路穿过普通地形
                    hide_road_array[row, col] = 1

                if map_hex['cond'] == 1:  # 丛林地
                    only_forest_array[row, col] = 1

                if map_hex['cond'] == 2:  # 普通居民地
                    only_resident_array[row, col] = 1
        elevation = com.normalization(elevation) * 0.5 + 0.5
        return hide_road_array, only_forest_array, only_resident_array, elevation

class Visibility(object):
    def __init__(self, my_ai, map_id, base_map, hex_cache, map_size):
        self.size = map_size
        self.hex_cache = hex_cache
        map_dir = os.path.join(base_map, str(map_id))

        with com.Timer('加载数据'):

            self.be_LOS_np = np.load(os.path.join(map_dir, 'be_LOS.npy'))
            # self.be_LOS_np = np.delete(self.be_LOS_np, 1, axis=0)

            self.LOS_np = np.load(os.path.join(map_dir, 'LOS.npy'))
            self.maneuver_time_np = np.load(os.path.join(map_dir, 'maneuver_time.npy'))
            # pos_bop = {}
            # for bop in common.get_bop_type(my_ai.our_bops_init + my_ai.enemy_bops_init, const.BopType.Vehicle):
            #     pos_bop[bop['cur_hex']] = bop
            # for int4, bop in pos_bop.items():
            #     time_np = util.get_maneuver_time_matrix(bop, int4, my_ai.my_map)
            #     row, col = com.cvtInt4loc2Offset(int4)
            #     self.maneuver_time_np[bop['type']-1, row, col] = time_np
            gc.collect()

    def get_be_see_LOS(self, see_source, bop_type, grid_pos):
        if not grid_pos:
            return []
        # if see_source == const.SeeSource.FromGround and bop_type != const.BopType.Aircraft:
        if isinstance(grid_pos, int):
            row, col = com.cvtInt4loc2Offset(grid_pos)
            if bop_type in [const.BopName.Missile, const.BopName.UAV]:
                self.be_LOS_np[see_source, bop_type - 1, row, col]
            return self.be_LOS_np[see_source, bop_type-1, row, col]
        elif isinstance(grid_pos, list):
            tuple_list = com.cvtInt4loc2Offset(grid_pos)
            rows, cols = zip(*tuple_list)
            return self.be_LOS_np[see_source, bop_type-1, rows, cols]

        else:
            raise Exception

    def get_see_LOS(self, see_source, ubop_type, grid_pos):
        if not grid_pos:
            return []
        # if see_source == const.SeeSource.FromGround and ubop_type != const.BopType.Aircraft:
        if isinstance(grid_pos, int):
            row, col = com.cvtInt4loc2Offset(grid_pos)
            return self.LOS_np[see_source, ubop_type-1, row, col]
        elif isinstance(grid_pos, list):
            tuple_list = com.cvtInt4loc2Offset(grid_pos)
            rows, cols = zip(*tuple_list)
            return self.LOS_np[see_source, ubop_type-1, rows, cols]
        else:
            raise Exception

    def get_maneuver_time(self, bop_type, grid_pos):
        if not grid_pos:
            return []

        if isinstance(grid_pos, int):
            row, col = com.cvtInt4loc2Offset(grid_pos)
            return self.maneuver_time_np[bop_type-1, row, col]
        elif isinstance(grid_pos, list):
            tuple_list = com.cvtInt4loc2Offset(grid_pos)
            rows, cols = zip(*tuple_list)
            return self.maneuver_time_np[bop_type-1, rows, cols]

        else:
            raise Exception

    def in_map(self, row, col):
        if 0 <= row <= self.size[0]-1 and 0 <= col <= self.size[1]-1:
            return True
        else:
            return False

    def get_shoot_LOS(self, see_source, ubop_type, grid_pos, shoot_dis, get_LOS=False):
        if not grid_pos:
            return []
        if isinstance(grid_pos, int):
            LOS = self.get_see_LOS(see_source, ubop_type, grid_pos)

            shoot_range = self.hex_cache.get_circle(grid_pos, 0, shoot_dis)
            data = np.zeros(self.size, dtype=np.bool)
            data[tuple(zip(*shoot_range))] = True
            shoot_LOS = LOS & data
            if get_LOS:
                return LOS, shoot_LOS
            else:
                return shoot_LOS
        elif isinstance(grid_pos, list):
            LOS = self.get_see_LOS(see_source, ubop_type, grid_pos)
            data = np.zeros_like(LOS, dtype=np.bool)
            shoot_range_multi = self.hex_cache.get_circle_multi(grid_pos, 0, shoot_dis)
            for i, shoot_range in enumerate(shoot_range_multi):
                rows, cols = zip(*shoot_range)
                data[i, rows, cols] = True
            shoot_LOS = LOS & data
            if get_LOS:
                return LOS, shoot_LOS
            else:
                return shoot_LOS
        else:
            raise Exception

    def get_be_shoot_LOS(self, see_source, bop_type, grid_pos, be_shoot_dis, get_be_LOS=False):
        if not grid_pos:
            return []
        if isinstance(grid_pos, int):
            be_LOS = self.get_be_see_LOS(see_source, bop_type, grid_pos)
            shoot_range = self.hex_cache.get_circle(grid_pos, 0, be_shoot_dis)
            data = np.zeros(self.size, dtype=np.bool)
            data[tuple(zip(*shoot_range))] = True
            be_shoot_LOS = be_LOS & data
            if get_be_LOS:
                return be_LOS, be_shoot_LOS
            else:
                return be_shoot_LOS
        elif isinstance(grid_pos, list):
            be_LOS = self.get_be_see_LOS(see_source, bop_type, grid_pos)
            data = np.zeros_like(be_LOS, dtype=np.bool)
            shoot_range_multi = self.hex_cache.get_circle_multi(grid_pos, 0, be_shoot_dis)
            for i, shoot_range in enumerate(shoot_range_multi):
                rows, cols = zip(*shoot_range)
                data[i, rows, cols] = True
            be_shoot_LOS = be_LOS & data
            if get_be_LOS:
                return be_LOS, be_shoot_LOS
            else:
                return be_shoot_LOS
        else:
            raise Exception




if __name__ == '__main__':
    map_id = 84
    base_map = 'data/map'
    map = MyMap(map_id, base_map)
    see = Visibility(map_id, base_map, map.size)
    int4 = 2112
    # #
    see_array = map.get_see_array(int4, const.SeeMode.GroundToGround)
    visible_array = see.get_see_LOS(const.SeeSource.FromGround, const.BopType.Vehicle, int4)
    #
    see_rows, see_cols = np.where(see_array==1)
    visible_rows, visible_cols = np.where(visible_array==1)
    map_dir = 'data/map/84/map.jpg'
    util.plot_hex(list(zip(see_rows, see_cols)), map_dir, blend_level=0.9, text=None)
    util.plot_hex(list(zip(visible_rows, visible_cols)), map_dir, blend_level=0.9, text=None)

    ss = pd.read_feather("maneuver_time.feather")



