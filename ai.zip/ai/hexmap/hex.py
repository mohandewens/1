# -*- coding: utf-8 -*- 2

############################################
#
# PAL_Wargame
#
# 2017年4月25日/gsliu
#   单位六角格像素信息 HEX_PIXEL类, 统计绘制拼接地图需要的像素尺度上的信息
# 2017年4月27日/gsliu
#   添加偏移坐标与立方坐标 HEX_OFF / HEX_CUBE 类以及常用的坐标转换函数
#

############################################
import math, re
import numpy as np


####################################
# 全局变量
ji_neigh_offset = [(0, 1), (-1, 1), (-1, 0), (0, -1), (1, 0), (1, 1)]
ou_neigh_offset = [(0, 1), (-1, 0), (-1, -1), (0, -1), (1, -1), (1, 0)]
list_trans_neigh_edgeloc = [3, 4, 5, 0, 1, 2]
list_neighdir_offset_ji = ji_neigh_offset
list_neighdir_offset_ou = ou_neigh_offset
list_dir2cubeoff = [[1,0,-1], [1,-1,0],[0,-1,1],[-1,0,1],[-1,1,0],[0,1,-1]]


'''偏移坐标六角格类'''
class HEX_OFF(object):

    def __init__(self, x=None, y=None):
        '''
        Following constructions are supported.

          * Hex()           # (0,0) origin.
          string input
          * Hex('0134')     # (1,34) even length string.
          * Hex('101034')   # (101,34)
          * Hex('14')       # (1,4)
          * Hex('-1010')    # (-10, 10)
          * Hex('10-10')    # (10, -10)
          * Hex('-10-10')   # (-10, -10)
          x,y input
          * Hex(1, -34)     # (1,-34) +/- integer, +/- integer.
          less 4 int input
          * Hex(301)       # (3,01) Even 'length' integer.
          * Hex(2301)       # (23,01) Even 'length' integer.


        Not valid.
          * Hex(0110)
          * Hex(-1010)
          *
        '''
        if x is None:
            self.row, self.col = 0, 0
        elif (isinstance(x, int) or isinstance(x, np.int64)) and y is None:
            self.row, self.col = x // 100, x % 100
        elif isinstance(x, str) and y is None:
            x, y = self.split(x)
            self.row = int(x)  # read-only
            self.col = int(y)  # read-only
        elif isinstance(x, tuple):
            self.row = int(x[0])  # read-only
            self.col = int(x[1])  # read-only
        else:
            self.row = int(x)  # read-only
            self.col = int(y)  # read-only
        # assert self.row >= 0 and self.col >= 0

    def __str__(self):
        return ('row = %d, col = %d') % (self.row, self.col)

    def __hash__(self):
        # hash tuple to avoid calling .value / string stuff which is expensive
        # and may never need to be calculated.
        return hash((self.row, self.col))
        if not hasattr(self, '_value'):
            self._value = hash((self.row, self.col))
        return self._value

    def loc(self):
        return (self.row, self.col)

    def __eq__(self, other):
        try:
            if isinstance(other, HEX_OFF):
                # Compare this and not .value, much faster.
                return self.row == other.row and self.col == other.col

            elif len(other) == 2:
                row, col = other[0], other[1]
            return self.row == int(row) and self.col == int(col)
        except (TypeError, IndexError, ValueError):
            return False

    def __ne__(self, other): # 不等于
        return not self.__eq__(other)

    def __lt__(self, other):   # 小于
        try:
            if isinstance(other, HEX_OFF):
                # Compare this and not .value, much faster.
                return self.row < other.row and self.col < other.col

            elif len(other) == 2:
                row, col = other[0], other[1]
            return self.row < int(row) and self.col < int(col)
        except (TypeError, IndexError, ValueError):
            return False

    def __le__(self, other): # 小于等于
        try:
            if isinstance(other, HEX_OFF):
                # Compare this and not .value, much faster.
                return self.row <= other.row and self.col <= other.col

            elif len(other) == 2:
                row, col = other[0], other[1]
            return self.row <= int(row) and self.col <= int(col)
        except (TypeError, IndexError, ValueError):
            return False

    def __gt__(self, other): # 大于
        try:
            if isinstance(other, HEX_OFF):
                # Compare this and not .value, much faster.
                return self.row > other.row and self.col > other.col

            elif len(other) == 2:
                row, col = other[0], other[1]
            return self.row > int(row) and self.col > int(col)
        except (TypeError, IndexError, ValueError):
            return False

    def __ge__(self, other): # 大于等于
        try:
            if isinstance(other, HEX_OFF):
                # Compare this and not .value, much faster.
                return self.row >= other.row and self.col >= other.col

            elif len(other) == 2:
                row, col = other[0], other[1]
            return self.row >= int(row) and self.col >= int(col)
        except (TypeError, IndexError, ValueError):
            return False

    def copy(self):
        return self.__class__(self.row, self.col)

    '''
    将当前的偏移坐标(Off)转换到立方坐标(Cube)
  '''
    def cvtToCube(self):
        try:
            assert self.col >= 0 and self.row >= 0
            q = self.col - (self.row - (self.row & 1)) // 2
            r = self.row
            s = 0 - q - r
            return HEX_CUBE(q, r, s)
        except Exception as e:
            echosentence_color(
                'error in class HEX_OFF cvtToCube():[row:col={}:{}]:{}'.format(self.col, self.row, str(e)))
            raise

    def distance_to(self, to_hex):
        try:
            hexa_cube = self.cvtToCube()
            hexb_cube = to_hex.cvtToCube()
            return hexa_cube.getDistance(hexb_cube)
        except Exception as e:
            echosentence_color('error in getDistanceInOff():{}'.format(str(e)))
            raise
        return Distance

    '''
    计算当前坐标在指定方向上的相邻坐标
  '''
    def getSpecifiedNeighFromDirList(self, list_dir_index=None):

        try:
            assert self.col >= 0 and self.row  >= 0 and len(list_dir_index) <= 6
            list_neigh_loc = []
            ji_flag = self.row % 2 == 1
            list_neighdir_offset = list_neighdir_offset_ji if ji_flag else list_neighdir_offset_ou
            for dir_index in list_dir_index:
                assert dir_index < 6 and dir_index >= 0
                list_neigh_loc.append(tuple(np.add((self.row, self.col), list_neighdir_offset[dir_index])))
            return list_neigh_loc

        except Exception as e:
            echosentence_color('error in class HEX_OFF getSpecifiedNeigh():{}'.format(str(e)))
            raise

    ''' 计算当前坐标下6个方向上的相邻坐标'''
    def getSixNeighInOrder(self):
        try:
            assert self.col >= 0 and self.row >= 0
            list_dir_index = range(6)
            return self.getSpecifiedNeighFromDirList(list_dir_index)
        except Exception as e:
            echosentence_color('error in class HEX_OFF getSixNeighInOrder():{}'.format(str(e)))
            raise

# 计算目标格偏离的角度
    def hexsides_angle(self, to_hex):  #（0:9点钟方向 60:10点半方向 120:1点半方向 180:3点钟方向 240:4点半方向 300:7点半方向）
        assert not self.__eq__(to_hex)
        d_row = to_hex.row - self.row
        d_col = to_hex.col - self.col
        # Even / odd columns need a nudge.
        if (self.row % 2) and not (to_hex.row % 2):
            d_col -= .5
        if not (self.row % 2) and (to_hex.row % 2):
            d_col += .5
        # Hexes are wider than tall.
        d_col *= -1  # Negative cause math origin is lower left not upper left.
        d_row *= math.sqrt(3)/2 #-17.32
        angle = -round(math.degrees(math.atan2(d_row, d_col)), 2)
        return angle

# 计算目标格（特别是相邻格）与当前格的交界边，正西边为0，逆时针到西北边为5
    def hexsides_to(self, to_hex):
        '''Tuple of 1, 2, or 6(same hex) hexsides passed through on way to_hex.
        Accurate for distances up to about 10000 hexes.
        :return: Tuple of integer hexsides.
        '''
        if self == to_hex:
            return (1, 2, 3, 4, 5, 6)
        angle = self.hexsides_angle(to_hex)

        if -30 < angle < 30:
            answer = (0, )
        elif 30 < angle < 90:
            answer = (5, )
        elif 90 < angle < 150:
            answer = (4, )
        elif angle > 150 or angle < -150:
            answer = (3, )
        elif -90 > angle > -150:
            answer = (2, )
        elif -30 > angle > -90:
            answer = (1, )
        elif angle == 30:
            answer = (0, 5)
        elif angle == 90:
            answer = (5, 4)
        elif angle == 150:
            answer = (4, 3)
        elif angle == -150:
            answer = (3, 2)
        elif angle == -90:
            answer = (2, 1)
        elif angle == -30:
            answer = (1, 0)
        return answer

        # 计算目标格与夺控点的方向，正西边为0，逆时针到西北边为5，主要是计算夺控点方向的观察度或被观察度
    def occupy_to(self, to_hex):
        '''Tuple of 1, 2, or 6(same hex) hexsides passed through on way to_hex.
        Accurate for distances up to about 10000 hexes.
        :return: Tuple of integer hexsides.
        '''
        if self == to_hex:
            return (1, 2, 3, 4, 5, 6)
        angle = self.hexsides_angle(to_hex)

        if 0 < angle < 60:
            answer = (5,)
        elif 60 < angle < 120:
            answer = (4,)
        elif 120 < angle < 180:
            answer = (3,)
        elif -120 > angle > -180:
            answer = (2,)
        elif -60 > angle > -120:
            answer = (1,)
        elif  0> angle > -60:
            answer = (0,)
        elif angle == 60:
            answer = (5,4)
        elif angle == 120:
            answer = (4,3)
        elif angle == -180:
            answer = (3,2)
        elif angle == -120:
            answer = (2,1)
        elif angle == -60:
            answer = (1,0)
        elif angle == 0:
            answer = (0,5)
        return answer


    @staticmethod  #计算当前格：立体坐标（0，0,0），在某个方向dir上，距离为dis时，包含的所有六角格的立体坐标
    def getDirOffVector(dir, dis):
        try:
            assert  dir in range(6) and dis >= 0
            list_result = []
            sameloc = dir % 3
            varyloc = (sameloc + 1) % 3
            hastovaryloc = (sameloc + 2) % 3
            varyIncre = -1 if dir % 2 == 0  else 1
            for dis_index in range(1, dis+1):
                base_cur  = [x * dis_index for x in list_dir2cubeoff[dir]]
                # base_next = [x * dis_index for x in list_dir2cubeoff[(dir + 1) % 6]]
                list_result.append(base_cur)
                for i in range(1, dis_index):
                    list_tmp_vec = [0] * 3
                    list_tmp_vec[sameloc] = base_cur[sameloc]
                    list_tmp_vec[varyloc] = base_cur[varyloc] + varyIncre * i
                    list_tmp_vec[hastovaryloc] = 0 - list_tmp_vec[sameloc] - list_tmp_vec[varyloc]
                    list_result.append(list_tmp_vec)
            return list_result
        except Exception as e:
            echosentence_color('common > getDirOffVectorList():{}'.format(str(e)))
            raise e

    #求当前格在方向范围上，距离dis内包含的所有格子，输出为偏移坐标列表
    def dir_hex(self, dir=[0,0], dis=1, origin=False): #dir为方向范围，[0,5]表示从0方向到5方向， dis 为距离
        try:
            # assert isinstance(Int6loc, int) and dis > 0
            dir_list = self.rotator(*dir)
            edgeloc_list =[list_trans_neigh_edgeloc[i] for i in dir_list]
            hex_cube = self.cvtToCube()
            cirs_list = []

            for i in edgeloc_list:
                list_cube = self.getDirOffVector(i, dis)
                cirs_list.extend(list_cube)
            cube_list = [tuple(np.add(hex_cube.loc(), cir_cube)) for cir_cube in cirs_list]
            if origin and dis > 0:
                cube_list.insert(0, hex_cube.loc())
            off_list = [HEX_CUBE(*cube).cvtToOff().loc() for cube in cube_list]
            return off_list
        except Exception as e:
            echosentence_color('common > getDirOffVectorList():{}'.format(str(e)))
            raise e

    @staticmethod
    def rotate(hexside, delta):
        '''Calc direction that is 'delta' clockwise rotations from hexside.'''
        hexside += delta
        while hexside > 5:
            hexside -= 6
        while hexside < 0:
            hexside += 6
        return hexside

    def rotator(self, start, end):
        '''Generator, iterates clockwise over directions, start -> end, inclusive.'''
        yield start
        while start != end:
            start = self.rotate(start, 1)
            yield start

    def get_arc(self, direction=[0,0], radius=1):
        """
        生成指定方向上、确定半径下的圆弧
        :param radius: 距当前格的半径
        :param direction: 当前格的楔形方向，0-5, 0表示正西方向，逆时针旋转
        :return: 圆弧上所有六角格构成的列表
        """
        dir_list = self.rotator(*direction)
        edgeloc_list = [list_trans_neigh_edgeloc[i] for i in dir_list]
        hex_cube = self.cvtToCube()

        arcs_cube_list = []
        for dir in edgeloc_list:
            cube_list = hex_cube.get_arc(radius, dir)
            arcs_cube_list.extend(cube_list)
        arcs_list_off = [cube.cvtToOff().loc() for cube in arcs_cube_list]

        return arcs_list_off

    def get_line(self, hex_t: 'HexOffset'):
        """输出一条直线，包含起始格和终止格"""
        hex_s_cube = self.cvtToCube()
        hex_t_cube = hex_t.cvtToCube()
        line = []
        line_cube = hex_s_cube.get_line(hex_t_cube)
        for h in line_cube:
            line.append(h.cvtToOff().loc())
        return line


    @staticmethod
    def split(value):
        '''Split value into hex.x and hex.y.'''
        value = str(value)
        length = len(value.replace('-', ''))
        if length % 2:
            raise ValueError('''Hexes can't be constructed from odd length value [%s]''' % (value,))
        digits = length / 2
        if value.startswith('-'):  # odd length
            x, y = value[:digits + 1], value[digits + 1:]
        else:
            x, y = value[:digits], value[digits:]
        return x, y

####################################
'''立方坐标下的六角格'''
class HEX_CUBE:
    q = None
    r = None
    s = None
    def __init__(self, q, r, s):
        self.q = q
        self.r = r
        self.s = s

    def is_valid(self):
        """判断Cube坐标是否有效，即3个坐标值是否都是整数，且3个坐标值之和等于0"""
        re_str = '^-?\d+\.?0*$'
        # 使用正则表达式进行判断，诸如23.0的浮点型整数也会正确判断成整数
        if re.match(re_str, str(self.q)) is not None:
            if re.match(re_str, str(self.r)) is not None:
                if re.match(re_str, str(self.s)) is not None:
                    if abs(self.q+self.r+self.s) <= 1e-8:
                        return True

    '''返回内部数据'''
    def loc(self):
        try:
            return (self.q, self.r, self.s)
        except Exception as e:
            echosentence_color('error in class HEX_CUBE getLocDataInTuple():{}'.format(str(e)))
            raise

    '''转换到偏移坐标'''
    def cvtToOff(self):
        try:
            col = self.q + (self.r - (self.r & 1)) // 2
            row = self.r
            return HEX_OFF(row, col)
        except Exception as e:
            echosentence_color('error in class HEX_CUBE cvtToOff():{}'.format(str(e)))
            raise

    def getDistance(self, hexb):
        try:
            return sum(abs(a_e - b_e) for a_e, b_e in zip(self.loc(), hexb.loc())) // 2
        except Exception as e:
            echosentence_color('error in getDistanceInCube():{}'.format(str(e)))
            raise

    def addOffVec(self, tuple_offvec):
        t_result = tuple([x + y for x, y in zip(self.loc(), tuple_offvec)])
        return HEX_CUBE(*t_result)

    def cube_round(self):
        """cube坐标的四舍五入"""
        a_bar, b_bar, c_bar = round(self.q), round(self.s), round(self.r)
        e_a, e_b, e_c = abs(self.q - a_bar), abs(self.s - b_bar), abs(self.r - c_bar)
        if e_a >= e_b and e_a >= e_c:
            return HEX_CUBE(-b_bar-c_bar, c_bar, b_bar)
        elif e_a < e_b and e_b >= e_c:
            return HEX_CUBE(a_bar, c_bar, -a_bar-c_bar)
        else:
            return HEX_CUBE(a_bar, -a_bar-b_bar, b_bar)

    def cube_add(self, hex_cube: 'HexCube'):
        """cube坐标加法"""
        return HEX_CUBE(self.q + hex_cube.q,
                        self.r + hex_cube.r,
                        self.s + hex_cube.s)

    def cube_directions(self, direction):
        cube_directions = [HEX_CUBE(1, 0,-1),
                           HEX_CUBE(1, -1, 0),
                           HEX_CUBE(0, -1, 1),
                           HEX_CUBE(-1, 0, 1),
                           HEX_CUBE(-1, 1, 0),
                           HEX_CUBE(0, 1, -1)]
        return cube_directions[direction]

    def neighbor(self, direction):
        """获得当前六角格的邻格"""
        return self.cube_add(self.cube_directions(direction))

    def get_arc(self, radius, direction):
        """ 2020-5-3
        找出指定方向和半径上的圆弧
        """
        try:
            assert self.is_valid()
            if radius == 0:
                return [self]
            hex_arc = []
            sides = {0: [4, 2], 1: [5, 3], 2: [0, 4], 3: [1, 5], 4: [2, 0], 5: [3, 1]}
            cube_direction = self.cube_directions(direction)

            cur_cube = self.cube_add(HEX_CUBE(radius * cube_direction.q,
                                             radius * cube_direction.r,
                                             radius * cube_direction.s))

            hex_arc.append(cur_cube)
            right = sides[direction][0]
            left = sides[direction][1]
            left_cube = cur_cube
            right_cube = cur_cube
            if radius % 2 == 0:
                num_left = int(radius / 2)
                num_right = num_left - 1
            else:
                num_left = int((radius - 1) / 2)
                num_right = num_left
            if num_left > 0:
                for m in range(num_left):
                    left_cube = left_cube.neighbor(left)
                    hex_arc.append(left_cube)
            if num_right > 0:
                for m in range(num_right):
                    right_cube = right_cube.neighbor(right)
                    hex_arc.append(right_cube)
            return hex_arc
        except Exception as e:
            # common.echosentence_color('error in class HexCube get_arc():{}'.format(str(e)))
            pass

    def get_line(self, hex_t: 'HexCube'):
        """输出一条直线，包含终止格，不包含起始格"""
        try:
            assert self.is_valid() and hex_t.is_valid()
            line = []
            dist = self.getDistance(hex_t)
            for n in range(1, dist):
                line.append(HEX_CUBE(self.q + 1.0 * n * (hex_t.q - self.q) / dist,
                                     self.r + 1.0 * n * (hex_t.r - self.r) / dist,
                                     self.s + 1.0 * n * (hex_t.s - self.s) / dist).cube_round()
                            )
            line.append(hex_t)
            return line
        except Exception as e:
            pass


'''限制范围的偏移坐标的六角格类，适用于地图格子在限制范围内'''
class BoundedHex(HEX_OFF):
    '''Same as Hex, except "map" has boundries and Hex instances outside those
    won't be returned and can't be created.
    '''

    # Boundries of map, inclusive.

    def __init__(self, x=None, y=None, size=(70, 60)):
        self.row_min = 0
        self.row_max = size[0]
        self.col_min = 0
        self.col_max = size[1]
        if x is None and y is None:
            x = self.row_min
            y = self.row_min
        super(BoundedHex, self).__init__(x, y)
        if not self._valid(self):
            raise Exception('Out of bounds [%s].' % self)

    def _valid(self, hex):
        if isinstance(hex, tuple):
            return not (hex[0] < self.row_min or
                        hex[1] < self.col_min or
                        hex[0] >= self.row_max or
                        hex[1] >= self.col_max)
        else:
            return not (hex.row < self.row_min or
                        hex.col < self.col_min or
                        hex.row >= self.row_max or
                        hex.col >= self.col_max)
    # 求相邻的六角格
    def sixpack(self):
        # Kind of hackish, inefficient. Use unbounded Hex() to do sixpack.  Then
        # loop over and strip out the out of bounds hexes.
        hexes = self.getSixNeighInOrder()
        return [h for h in hexes if self._valid(h)]

    #求方向范围dir，距离dis的所有六角格
    def arc(self, dir=[0,0], dis=1, origin=False):
        hexes = self.dir_hex(dir, dis, origin)
        return [h for h in hexes if self._valid(h)]

    # 求方向范围dir，距离dis的圆弧
    def arc_line(self, dir=[0, 0], dis=1):
        hexes = self.get_arc(dir, dis)
        return [h for h in hexes if self._valid(h)]

    # 求方向范围dir，距离dis的所有六角格
    def line(self, hexb):
        hexes = self.get_line(hexb)
        return [h for h in hexes if self._valid(h)]


def echosentence_color(str_sentence = None, color = None, flag_newline = True):
    try:
        if color is not None:
            list_str_colors = ['darkbrown', 'red', 'green', 'yellow', 'blue', 'purple', 'yank', 'white']
            assert  str_sentence is not None and color in list_str_colors
            id_color = 30 + list_str_colors.index(color)
            print('\33[1;35;{}m'.format(id_color) + str_sentence + '\033[0m')
        else:
            if flag_newline :
                print(str_sentence)
            else:
                print(str_sentence,end=" ")
    except Exception as e:
        print('error in echosentence_color {}'.format(str(e)))
        raise


class HexCache(BoundedHex):
    def __init__(self, largest_dis=30, map_size=(80,80)):
        self.map_size = map_size
        self.largest_dis = largest_dis
        self.row = 0
        self.col = 0
        super(HexCache, self).__init__(self.row, self.col, size=map_size)
        self.ou_hex_cache = [[(0, 0)]]
        dir = [0, 5]
        for dis in range(1, largest_dis + 1):
            hexes = self.get_arc(dir, dis)
            self.ou_hex_cache.append(hexes)

        ji_hex = HEX_OFF(1, 0)
        self.ji_hex_cache = [[(1, 0)]]
        dir = [0, 5]
        for dis in range(1, largest_dis + 1):
            hexes = ji_hex.get_arc(dir, dis)
            self.ji_hex_cache.append(hexes)

    def get_circle(self, pos_int4, dis_start, dis_end):
        if dis_start > self.largest_dis:
            dis_start = self.largest_dis
        if dis_end > self.largest_dis:
            dis_end = self.largest_dis

        row, col = self.cvtInt4loc2Offset(pos_int4)
        hexes = []
        if row % 2 == 0:
            for i in range(dis_start, dis_end + 1):
                hexes.extend(self.ou_hex_cache[i])
            pos_np = np.array(list(zip(*hexes)))
            row_np = pos_np[0] + row
            col_np = pos_np[1] + col

        else:
            for i in range(dis_start, dis_end + 1):
                hexes.extend(self.ji_hex_cache[i])
            pos_np = np.array(list(zip(*hexes)))
            row_np = pos_np[0] + row - 1
            col_np = pos_np[1] + col
        return [h for h in list(zip(row_np, col_np)) if self._valid(h)]

    def get_circle_multi(self, pos_int4_list, dis_start, dis_end):
        if dis_start > self.largest_dis:
            dis_start = self.largest_dis
        if dis_end > self.largest_dis:
            dis_end = self.largest_dis

        pos_tuple = self.cvtInt4loc2Offset(pos_int4_list)
        hexes_ji = []
        hexes_ou = []
        for i in range(dis_start, dis_end + 1):
            hexes_ji.extend(self.ji_hex_cache[i])
        for i in range(dis_start, dis_end + 1):
            hexes_ou.extend(self.ou_hex_cache[i])
        pos_np_ou = np.array(list(zip(*hexes_ou)))
        pos_np_ji = np.array(list(zip(*hexes_ji)))
        result = []
        for row, col in pos_tuple:
            if row % 2 == 0:
                row_np_old = pos_np_ou[0] + row
                col_np_old = pos_np_ou[1] + col
                row_np1 = row_np_old[(row_np_old > 0) & (col_np_old > 0)]
                col_np1 = col_np_old[(row_np_old > 0) & (col_np_old > 0)]
                row_np = row_np1[(row_np1 < self.map_size[0]) & (col_np1 < self.map_size[1])]
                col_np = col_np1[(row_np1 < self.map_size[0]) & (col_np1 < self.map_size[1])]
                result.append(list(zip(row_np, col_np)))
            else:
                row_np_old = pos_np_ji[0] + row - 1
                col_np_old = pos_np_ji[1] + col
                row_np1 = row_np_old[(row_np_old >= 0) & (col_np_old >= 0)]
                col_np1 = col_np_old[(row_np_old >= 0) & (col_np_old >= 0)]
                row_np = row_np1[(row_np1 < self.map_size[0]) & (col_np1 < self.map_size[1])]
                col_np = col_np1[(row_np1 < self.map_size[0]) & (col_np1 < self.map_size[1])]
                result.append(list(zip(row_np, col_np)))
        return result

    @staticmethod
    def cvtInt4loc2Offset(int4loc):
        '''转换6位坐标int6loc到四位坐标int4loc'''
        try:
            if isinstance(int4loc, int):
                row, col = int4loc // 100, int4loc % 100
                return (row, col)
            elif isinstance(int4loc, list):
                int4loc = np.array(int4loc)
                row, col = int4loc // 100, int4loc % 100
                pos_tuple_list = list(zip(row, col))
                return pos_tuple_list
        except Exception as e:
            echosentence_color('common cvtInt6loc2Int4loc():{}'.format(str(e)))
            raise

if __name__ == '__main__':
    # hex = BoundedHex(3, 4)
    # hex2 = BoundedHex(7, 9)
    # # dis = hex.arc([0,0], 2, True)
    # dis = hex.arc_line(dir=[0,4],dis=0)
    # print(dis)

    cache = HexCache()
    hexes = cache.get_circle(1010, 1, 10)


