# coding:utf-8
import time
import numpy as np
from .hex import HEX_OFF, BoundedHex
# 常用的坐标转换函数
def cvtInt4loc2Int6loc(int4loc):
    '''转换四位整形坐标int4loc到六位整形坐标int6loc'''
    try:
        assert isinstance(int4loc, int)
        tmp_row, tmp_col = int4loc // 100, int4loc % 100
        return cvtHexOffset2Int6loc(tmp_row, tmp_col)
    except Exception as e:
        echosentence_color('common > cvtInt4loc2Int6loc():{}'.format(str(e)))
        raise

def cvtInt6loc2Int4loc(int6loc):
    '''转换6位坐标int6loc到四位坐标int4loc'''
    try:
        assert isinstance(int6loc, int)
        y , x = cvtInt6loc2HexOffset ( int6loc )
        return y * 100 + x
    except Exception as e:
        echosentence_color('common cvtInt6loc2Int4loc():{}'.format(str(e)))
        raise

def cvtHexOffset2Int6loc(row, col):
    '''转换（row,col）到6位整型坐标'''
    try:
        if row % 2 == 1:
            tmpfirst = (row - 1) // 2
            tmplast = col * 2 + 1
        else:
            tmpfirst = row // 2
            tmplast = col * 2
        assert (tmpfirst >= 0 and tmplast >= 0)
        return int(tmpfirst * 10000 + tmplast)
    except Exception as e:
        echosentence_color('common > cvtHexOffset2Int6():{}'.format(str(e)))
        raise

def cvtInt6loc2HexOffset(int6loc):
    '''转换6位整形坐标int6loc转换为偏移坐标（y,x）2元组'''
    try:
        str6loc = str(int6loc)
        len_oristr6loc = len(str6loc)
        assert (len_oristr6loc <= 6)
        if len_oristr6loc < 6:
            str6loc = '0' * (6 - len_oristr6loc) + str6loc

        int_first_2, int_last_3 = int(str6loc[0:2]), int(str6loc[3:])
        if int_last_3 % 2 == 1:
            row , col = int_first_2 * 2 + 1 , (int_last_3 - 1) // 2
        else:
            row , col = int_first_2 * 2 , int_last_3 // 2
        return (row,col)
    except Exception as e:
        echosentence_color('comnon > cvtInt6loc2HexOffset():{}'.format(str(e)))
        raise

def tranlocInto4Str(y, x):
    '''将两个偏移整形坐标拼接成为四位字符串'''
    try:
        assert(x >=0 and x < 100 and y >=0 and y < 100)
        re = ''
        re += str(y) if y >= 10 else str(0) + str(y)
        re += str(x) if x >= 10 else str(0) + str(x)
        return re
    except Exception as e:
        echosentence_color(('error in common tranlocInto4str():{}'.format(str(e))))
        raise


def cvtInt4loc2Offset(int4loc):
    '''转换6位坐标int6loc到四位坐标int4loc'''
    try:
        if isinstance(int4loc, int):
            row, col = int(int4loc // 100), int(int4loc % 100)
            return (row,col)
        elif isinstance(int4loc, list):
            int4loc = np.array(int4loc)
            row, col = int4loc // 100, int4loc % 100
            pos_tuple_list = list(zip(row, col))
            return pos_tuple_list
    except Exception as e:
        echosentence_color('common cvtInt6loc2Int4loc():{}'.format(str(e)))
        raise

def cvtOffset2Int4loc(x=0, y=0):
    '''转换6位坐标int6loc到四位坐标int4loc'''
    try:
        if isinstance(x, tuple):
            int4loc = x[0] * 100 + x[1]
            return int(int4loc)
        elif isinstance(x, list):
            pos_np = np.array(list(zip(*x)))
            int4loc = (pos_np[0] * 100 + pos_np[1]).tolist()
            return int4loc
        else:
            int4loc = x * 100 + y
            return int(int4loc)
    except Exception as e:
        echosentence_color('common cvtInt6loc2Int4loc():{}'.format(str(e)))
        raise

def get_distance(int4a, int4b):
    '''求2个4位坐标的两点间格子距离'''
    try:
        if isinstance(int4a, tuple):
            int4a = cvtOffset2Int4loc(*int4a)
        if isinstance(int4b, tuple):
            int4b = cvtOffset2Int4loc(*int4b)
        assert isinstance(int4a, int) and isinstance(int4b, int)
        return HEX_OFF(int4a).distance_to(HEX_OFF(int4b))
    except Exception as e:
        echosentence_color('common get_distance():{}'.format(str(e)))
        raise

def echosentence_color(str_sentence = None, color = None, flag_newline = True):
    try:
        if color is not None:
            list_str_colors = ['darkbrown', 'red', 'green', 'yellow', 'blue', 'purple', 'yank', 'white']
            assert  str_sentence is not None and color in list_str_colors
            id_color = 30 + list_str_colors.index(color)
            print('\33[1;35;{}m'.format(id_color) + str_sentence + '\033[0m')
        else:
            if flag_newline :
                print(str_sentence)
            else:
                print(str_sentence,end=" ")
    except Exception as e:
        print('error in echosentence_color {}'.format(str(e)))
        raise


def normalization(data):
    _range = np.max(data) - np.min(data)
    if _range != 0:
        return (data - np.min(data)) / _range
    else:
        return np.ones_like(data)


def standardization(data):
    mu = np.mean(data, axis=0)
    sigma = np.std(data, axis=0)
    return (data - mu) / sigma


# 温度调节函数,给定一个数组,输出一个标准化的数组,并且按beta的比例进行调整,beta越大,原数组两个数之间转化为概率值后的比率越大\n",
def apply_temperature(beta, distribution):
    if type(distribution) is not np.ndarray:
        distribution = np.array(distribution, dtype=float)

    if (distribution == 0).all():
        return np.ones_like(distribution) / np.ones_like(distribution).sum()
    ############
    distribution = normalization(distribution)
    ###############
    log_probabilities = np.log(distribution + 1e-05)

    log_probabilities = log_probabilities * beta

    log_probabilities = log_probabilities - log_probabilities.max()

    probabilities = np.exp(log_probabilities)

    return probabilities / probabilities.sum()


class Timer:
    def __init__(self, text, debug=True):
        self.text = text
        self.debug = debug

    def __enter__(self):
        if self.debug:
            print(self.text.ljust(50), end="")
            print('starting...')
        self.start = time.clock()

        return self

    def __exit__(self, *args):
        self.end = time.clock()
        self.interval = self.end - self.start
        if self.debug:
            print(self.text.ljust(50), end="")
            print("finished after {:0.03f} ms\n".format(self.interval * 1000))





if __name__ == "__main__":
    aa = cvtOffset2Int4loc([(0, 0), (1, 4), (3, 6)])

    print(type(aa[0]))
    # print getDirOffVectorList(dir= 3, dis= 3)
    # print(apply_temperature(.5, [0.1 , 0.2, 0.3]))